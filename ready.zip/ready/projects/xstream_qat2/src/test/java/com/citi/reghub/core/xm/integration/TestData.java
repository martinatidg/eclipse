package com.citi.reghub.core.xm.integration;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.ExceptionType;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgException;
import com.citi.reghub.core.xm.xstream.schema.inbound.SenderStatus;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound. OutBoundNotificationMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.Status;

public class TestData {
	private static com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory infactory = new com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory();
	private static com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory outfactory = new com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory();

	private static int mark = 0;
	
	private static String[] ids_uat = {
		"b2bd628d-f291-4a0b-8520-91593cb7204f:489580638:m2trcsheq502435484:CSHEQPRIMO20170927489580638:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
		"7c3b6732-5029-499c-bf0e-7fe2cf766460:315:m2orkrfqeq5944027:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
		"f4760ca9-15fb-46b7-8c23-7ab24c4cbc45:315:m2orkrfqeq5943468:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_product_isin_exception:Product ISIN length is not 12 characters",
		 "7e79e6ed-1b8f-44ce-a2bc-8b4034508f42:321:m2orkrfqeq5946274:RFQEQ32120170920321:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
		 "f8ca5a38-8260-4a95-a237-8bc88000e828:315:m2orkrfqeq5944032:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
		 "c913bdc7-1712-4063-b805-ae30ad641e57:315:m2orkrfqeq5943464:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_product_isin_exception:Product ISIN length is not 12 characters",
		 "ad48cb15-57b3-4b73-89ef-577c72f46491:315:m2orkrfqeq5938816:RFQEQ31520170919315:m2ork:rfqeq:m2ork_all_product_isin_exception:Product ISIN length is not 12 characters",
		 "7e79e6ed-1b8f-44ce-a2bc-8b4034508f42:321:m2orkrfqeq5946274:RFQEQ32120170920321:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
		 "776a0f93-3190-4eb3-92ee-949990c12c2c:17271XCe73l:m2post_csheq_17271XCe73l_1506623168806000000:m2post-csheq-17271XCe73l-1506637568810000000:m2post:csheq:m2p0st_csheq_settldate_time_check_rule:Settlement Date is empty or before today",
		 "b2bd628d-f291-4a0b-8520-91593cb7204f:489580638:m2trcsheq502435484:CSHEQPRIMO20170927489580638:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
		 "679717e5-23e1-4aac-b504-2c1fadbf2a74:484523277:m2trcsheq502435814:CSHEQPRIMO20170927484523277:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
		 "9f88e158-f270-49f4-b242-9ad9b7bc5ad4:489580425:m2trcsheq502434065:CSHEQPRIMO20170927489580425:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
		 "65264b8e-9f12-4a00-8100-8ccec95cfc4f:484523089:m2trcsheq502435091:CSHEQPRIMO20170927484523089:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
		 "9a5ffe11-3747-4b0c-ab22-f00c237c98dc:484523181:m2trcsheq502435472:CSHEQPRIMO20170927484523181:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
	};
	private static String[] ids_qat = {
			"287764e6-4fdb-47b2-8c68-76ed66f4694d:PFS-9890134-39344541-1-UITID:m2trotceqd10150640926563608:OTCEQDPFS20170719PFS9890134393445411UITID:m2tr:otceqd:m2tr_otceqd_firm_account_lei_exception:Length of Firm account LEI should be String of 20 characters; where 1-18 characters are either capital letters or numbers and 19-20 characters are numbers",
			"c315ddbc-b08d-46c5-9b02-203c0cbf7574:PFS-9890003-32035353-1-UITID:m2trotceqd10150609617748421:OTCEQDPFS20170922PFS9890003320353531UITID:m2tr:otceqd:m2tr_all_reporting_firm_code_exception:Reporting firm code should neither be empty nor invalid"
	};

	private static String[] ids_sit = {
			"61b8ddb5-cceb-41d2-ba0a-abd2c2b9d3d2:489580780:m2trcsheq502435885:CSHEQPRIMO20170927489580780:m2tr:csheq:m2tr_all_firm_execution_exception:Firm Execution validation as per UNAVISTA - Execution Within firm is mandatory for all new Trades",
			"7c3b6732-5029-499c-bf0e-7fe2cf766460:315:m2orkrfqeq5944027:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
			"f4760ca9-15fb-46b7-8c23-7ab24c4cbc45:315:m2orkrfqeq5943468:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_product_isin_exception:Product ISIN length is not 12 characters",
			 "7e79e6ed-1b8f-44ce-a2bc-8b4034508f42:321:m2orkrfqeq5946274:RFQEQ32120170920321:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
			 "f8ca5a38-8260-4a95-a237-8bc88000e828:315:m2orkrfqeq5944032:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
			 "c913bdc7-1712-4063-b805-ae30ad641e57:315:m2orkrfqeq5943464:RFQEQ31520170920315:m2ork:rfqeq:m2ork_all_product_isin_exception:Product ISIN length is not 12 characters",
			 "ad48cb15-57b3-4b73-89ef-577c72f46491:315:m2orkrfqeq5938816:RFQEQ31520170919315:m2ork:rfqeq:m2ork_all_product_isin_exception:Product ISIN length is not 12 characters",
			 "7e79e6ed-1b8f-44ce-a2bc-8b4034508f42:321:m2orkrfqeq5946274:RFQEQ32120170920321:m2ork:rfqeq:m2ork_all_ocean_product_id_exception:OCEAN_PRODUCT_ID should avilable",
			 "776a0f93-3190-4eb3-92ee-949990c12c2c:17271XCe73l:m2post_csheq_17271XCe73l_1506623168806000000:m2post-csheq-17271XCe73l-1506637568810000000:m2post:csheq:m2p0st_csheq_settldate_time_check_rule:Settlement Date is empty or before today",
			 "b2bd628d-f291-4a0b-8520-91593cb7204f:489580638:m2trcsheq502435484:CSHEQPRIMO20170927489580638:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
			 "679717e5-23e1-4aac-b504-2c1fadbf2a74:484523277:m2trcsheq502435814:CSHEQPRIMO20170927484523277:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
			 "9f88e158-f270-49f4-b242-9ad9b7bc5ad4:489580425:m2trcsheq502434065:CSHEQPRIMO20170927489580425:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
			 "65264b8e-9f12-4a00-8100-8ccec95cfc4f:484523089:m2trcsheq502435091:CSHEQPRIMO20170927484523089:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
			 "9a5ffe11-3747-4b0c-ab22-f00c237c98dc:484523181:m2trcsheq502435472:CSHEQPRIMO20170927484523181:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
			 "9a5ffe11-3747-4b0c-ab22-f00c237c98dc:484523181:m2trcsheq502435472:CSHEQPRIMO20170927484523181:m2tr:csheq:m2tr_all_trading_capacity_exception:The Trading capacity  must not be NULL or blank",
	};

	public static ExceptionMessage getExMsg() {
		String[] ida = getExceptionId().split(":");
		mark++;

		ExceptionMessage exmsg = new ExceptionMessageBuilder().newException()
				.withId(ida[0])
				.withSourceId(ida[1])
				.withRegHubId(ida[2])
				.withRegReportingRef(ida[3])
				.withStream(ida[4])
				.withFlow(ida[5])
				.withStatus(ExceptionStatus.OPEN)
				.withReasonCode(ida[6])
				.withRuleVersion("1.0")
				.withDescription(ida[7])
				.withOwner(FunctionalOwner.BUS)
				.isXstreamEligible(true)
				.withType(ExceptionType.DATA_QUALITY)
				.withLevel(ExceptionLevel.NACK)
				.withUpdatedSource(EventSource.XM_CONSUMER.value()).build();

		exmsg.setCreatedTS(System.currentTimeMillis());

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope envelope = new EventEnvelope();
		envelope.setEventName(EventName.EXCEPTION_CREATED);
		envelope.setEventSource(EventSource.XM_CONSUMER);
		envelope.setEventType(EventType.EXCEPTION);
		envelope.setEventVersion(EventVersion.V_1);
		envelope.setEventData(getExMsg());

		return envelope;
	}

	public static OutBoundNotificationMsg getNoteMsg(XmFeedMsg xmmsg) {
		 OutBoundNotificationMsg notemsg = outfactory.createOutBoundNotificationMsg();
		MsgExceptionNote exNote = outfactory.createMsgExceptionNote();

		MOMsgEntity msgObj = xmmsg.getMoEntity();
		exNote.setNote("from local JMS client");
		exNote.setLastUpdatedBy("Xm-Stream");
		exNote.setNoteTimestamp(msgObj.getExecutionDateTime());
		exNote.setUserAction("Add Note");

		notemsg.setSrcSystemRefId(msgObj.getExceptionID());
		notemsg.setExceptionRefNumber(msgObj.getExceptionID());
		notemsg.setStatus(Status.OPEN);
		notemsg.setTypeOfOwner(msgObj.getTraderID());
		notemsg.getNote().add(exNote);

		return notemsg;
	}

	public static XmFeedMsg getXmFeedMsg() {
		XmFeedMsg msg = infactory.createXmFeedMsg();

		MOMsgEntity moEntity = infactory.createMOMsgEntity();
		moEntity.setSrcSystemID("19884416");
		moEntity.setTradeVersion(1);
		moEntity.setQuantity(0.0);
		moEntity.setPrice(0.0);
		moEntity.setSide("BUY");
		moEntity.setSecurityID("934998M77");
		moEntity.setSecurityIDSource("CUSIP");
		moEntity.setCreationTimestamp(1503905505L);
		moEntity.setExecutionDateTime(1490613884L);
		moEntity.setTradeDate(1490572800L);
		//moEntity.setTradeStatus("Open");

		MOMsgException moException = infactory.createMOMsgException();
		moException.setSrcSysID("19884416");
		moException.setDescription("test data");
		moException.setSenderCompID("REGHUB");
		moException.setSenderExceptionID("943168035");
		moException.setSenderStatus(SenderStatus.OPEN);
		moException.setCreatedBy("BUS");
		moException.setFirstRaisedDatetime(1505325255618L);

		msg.setRequestId("10001");
		msg.setTimestamp(getXMLGregorianCalendar());
		msg.setMoEntity(moEntity);
		msg.getMoException().add(moException);

		return msg;
	}

	private static XMLGregorianCalendar getXMLGregorianCalendar() {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		GregorianCalendar gregorianCalendar = new GregorianCalendar();

		try {
			DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
			xmlGregorianCalendar = dataTypeFactory.newXMLGregorianCalendar(gregorianCalendar);
		} catch (Exception e) {
			System.out.println("Exception in conversion of Date to XMLGregorianCalendar" + e);
		}

		return xmlGregorianCalendar;
	}

	private static String getExceptionId() {
		if (mark >= ids_sit.length) {
			mark = mark % ids_sit.length;
		}
		return ids_sit[mark];
	}
}
