package com.citi.reghub.core.xm.xstream.topology;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.xm.integration.TestData;

public class XstreamMapperTest {
	XstreamMapper mapper;
	@Before
	public void init() {
		mapper = new XstreamMapper();
	}

	@Test
	public void testGetValueLong() throws JAXBException {
		System.out.println("Testing Long...");
		String num = "190";
		Long expected = 190L;
		Long actual = mapper.getValue(num, Long.class, num);
		System.out.println("actual = \n" + actual + ", expected = " + expected);
		Assert.assertEquals("actual not eaqual to expected.", expected, actual);

		Object num1 = "190";
		Long expected1 = 190L;
		Long actual1 = mapper.getValue(num1, Long.class, num1.toString());
		System.out.println("actual1 = \n" + actual1 + ", expected1 = " + expected1);
		Assert.assertEquals("actual not eaqual to expected.", expected1, actual1);

		Object num2 = "";
		Long expected2 = null;
		Long actual2 = mapper.getValue(num2, Long.class, "null");
		System.out.println("actual2 = \n" + actual2 + ", expected2 = " + expected2);
		Assert.assertEquals("actual not eaqual to expected.", expected2, actual2);

		Object num3 = "wer";
		Long expected3 = null;
		Long actual3 = mapper.getValue(num3, Long.class, num3.toString());
		System.out.println("actual3 = \n" + actual3 + ", expected3 = " + expected3);
		Assert.assertEquals("actual not eaqual to expected.", expected3, actual3);
	}

	@Test
	public void testGetValueDouble() throws JAXBException {
		System.out.println("\nTesting Double...");
		String num = "3.14";
		Double expected = 3.14;
		Double actual = mapper.getValue(num, Double.class, num);
		System.out.println("actual = \n" + actual + ", expected = " + expected);
		Assert.assertEquals("actual not eaqual to expected.", expected, actual);
		
		Object num1 = "190.0";
		Double expected1 = 190.0;
		Double actual1 = mapper.getValue(num1, Double.class, num1.toString());
		System.out.println("actual1 = \n" + actual1 + ", expected1 = " + expected1);
		Assert.assertEquals("actual not eaqual to expected.", expected1, actual1);

		Object num2 = "";
		Double expected2 = null;
		Double actual2 = mapper.getValue(num2, Double.class, "null");
		System.out.println("actual2 = " + actual2 + ", expected2 = " + expected2);
		Assert.assertEquals("actual not eaqual to expected.", expected2, actual2);

		Object num3 = "wer";
		Double expected3 = null;
		Double actual3 = mapper.getValue(num3, Double.class, num3.toString());
		System.out.println("actual3 = " + actual3 + ", expected3 = " + expected3);
		Assert.assertEquals("actual not eaqual to expected.", expected3, actual3);
	}
	
	@Test
	public void testGetLongValue() throws JAXBException {
		String key = "key";
		Long value = 1508161461000000000L;
		Map<String, Object> lmap = new HashMap<>();
		lmap.put(key, value);
		
		Long expected = 1508161461000000000L / 1000_000;
		Long actual = mapper.getLongValue(lmap, key);
		System.out.println("Long actual = " + actual + ", expected = " + expected);

		Assert.assertEquals("actual not eaqual to expected.", expected, actual);

		String valueStr = "1508161461000000000";
		lmap = new HashMap<>();
		lmap.put(key, valueStr);
		
		actual = mapper.getLongValue(lmap, key);
		System.out.println("Long actual = " + actual + ", expected = " + expected);

		Assert.assertEquals("actual not eaqual to expected.", expected, actual);

	}

	@Test
	public void testGetLongValueStr() throws JAXBException {
		String key = "key";
		String value = "2017-07-19T00:00:00.000+0000";
		Map<String, Object> lmap = new HashMap<>();
		lmap.put(key, value);
		
		Long expected = 1508161461000000000L / 1000_000;
		Long actual = mapper.getLongValue(lmap, key);
		System.out.println("Long actual = " + actual + ", expected = " + expected);

		//Assert.assertEquals("actual not eaqual to expected.", expected, actual);

	}
}
