package com.citi.reghub.core.xm.xstream.topology;

import java.lang.reflect.Constructor;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;
import com.citi.reghub.core.xm.xstream.schema.inbound.Action;
import com.citi.reghub.core.xm.xstream.schema.inbound.ExceptionType;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOEntityCode;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgException;
import com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory;
import com.citi.reghub.core.xm.xstream.schema.inbound.SenderStatus;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound.OutBoundNotificationMsg;

public class XstreamMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(XstreamMapper.class);
	private static final String ADD_NOTE = "Add Note";
	private static final String OWNER_TYPE = "Tech";
	private static final long NANOSECONDS = 1000_000L; 
	private static final int MAX_DATE_LENGTH = 14; 

	private ObjectFactory factory = new ObjectFactory();
	private String regHubId = "";

	public XmFeedMsg toXstream(ExceptionMessage exception, Entity entity, EventName eventName) {
		regHubId = entity.regHubId;
		//Create Entity				
		MOMsgEntity momsgEntity = createEntity(entity);
		momsgEntity.setExceptionID(exception.getId()); // 27, required.
		
		//create Exception
		MOMsgException mom = createException(exception, eventName);
		
		//create XMFeed
		XmFeedMsg feedMsg = factory.createXmFeedMsg();
		feedMsg.setMoEntity(momsgEntity);
		feedMsg.getMoException().add(mom);
		feedMsg.setRequestId("REGHUB_" + exception.getSourceId());
		feedMsg.setSenderCompID("REGHUB"); 						// required
		feedMsg.setTimestamp(this.getXMLGregorianCalendar()); 	// required

		return feedMsg;
	}

	private MOMsgException createException(ExceptionMessage exception, EventName eventName) {
		MOMsgException moMsgException = factory.createMOMsgException();
		moMsgException.setCreatedBy(exception.getFunctionalOwner().value());
		moMsgException.setDescription(exception.getDescription()); // required

		moMsgException.setFirstRaisedDatetime(exception.getCreatedTS());
		moMsgException.setSenderCompID("REGHUB");
		moMsgException.setSenderExceptionID(exception.getId()); // required
		moMsgException.setSenderExceptionVersion(0);

		SenderStatus exStatus = ExceptionStatus.CLOSED == exception.getStatus() ? SenderStatus.CLOSED : SenderStatus.OPEN;
		moMsgException.setSenderStatus(exStatus);
		moMsgException.setSrcSysID(exception.getSourceId());

		moMsgException.setSrcSysID(exception.getSourceId()); // required

		ExceptionType et = factory.createExceptionType();
		et.setTypeName("RegHUB Rejection");

		switch (eventName) {
		case EXCEPTION_CLOSED:
			et.getAction().add(Action.CLOSE);
			moMsgException.setSenderStatus(SenderStatus.RESOLVED);
			break;
		case EXCEPTION_CREATED:
			et.getAction().add(Action.ACCEPT);
			moMsgException.setSenderStatus(SenderStatus.OPEN);
			break;
		case EXCEPTION_UPDATED:
		default:
			et.getAction().add(Action.UPDATE);
			moMsgException.setSenderStatus(SenderStatus.OPEN);
		}

		moMsgException.setExceptionType(et);

		return moMsgException;
	}

	private MOMsgEntity createEntity(Entity entity) {

		LOGGER.debug("XmMapper.outboundMap(), entity = \n{}", entity);

		MOMsgEntity outmsg = factory.createMOMsgEntity();
		Map<String, Object> info = entity.info;

		outmsg.setEntityCode(MOEntityCode.TRADE);
		outmsg.setSrcSystemID(entity.sourceId); 						// 1, required
		outmsg.setSrcSystemRef(entity.sourceSystem); 					// 2, FXLMREG
		outmsg.setTradeID(entity.sourceUId); 							// 3, OK
		outmsg.setTradeVersion(getValue(entity.sourceVersion, Integer.class, "sourceVersion")); // 4, OK
		outmsg.setQuantity(getDoubleValue(info, "tradeQty")); 			// 5, ? octTradeQty
		outmsg.setPrice(getDoubleValue(info, "tradePrice")); 			// 6, ?
		outmsg.setExecCurrency(getStringValue(info, "tradePriceCcy"));	// 7, 
		outmsg.setSide(getStringValue(info, "buySellInd")); 			// 8, OK, null
		outmsg.setTraderID(getStringValue(info, "traderId")); 			// 9, OK, not available in SIT DB

		outmsg.setLegalEntity(getStringValue(info, "sourceFirmLEI")); 			// 10, ? AMC, not available in SIT & QAT DB
		outmsg.setClientLegalEntity(getStringValue(info, "sourceCptyLEI")); 	// 11, ? AMC, not available in SIT & QAT DB

		outmsg.setSecurityID(getStringValue(info, "securityId")); 				// 12, ? SMC
		outmsg.setSecurityIDSource(getStringValue(info, "securityIdType")); 	// 13, ? SMC

		outmsg.setFirmMnemonic(getStringValue(info, "firmAcctId")); 			// 14, OK, FLVELO, not available in SIT DB
		outmsg.setUnderlying(getStringValue(info, "underlyingInstrument")); 	// 15, OK, XXXXXXXXXXXX, not available in SIT & QAT DB
		outmsg.setCustomerMnemonic(getStringValue(info, "cptyAcctId")); 			// 16, OK, null, not available in SIT DB
		outmsg.setProductType(getStringValue(info, "productType")); 				// 17, OK, PRODUCT_TYPE, not available in SIT DB
		outmsg.setSourceFrontOfficeSystem(getStringValue(info, "sourceSystem")); 	// 18, OK, entity.sourceSystem, not available in SIT DB
		//outmsg.setSourceFrontOfficeSystem(entity.sourceSystem); 	// 18, OK, entity.sourceSystem, not available in SIT DB
		outmsg.setPrimaryAssetClass(getStringValue(info, "primaryAssetClass")); 	// 19, OK, ForeignExchange, not available in SIT DB
		outmsg.setParty1GFCID(getStringValue(info, "sourceFirmGFCID")); 			// 20, OK, 1000101733, not available in SIT DB. In Qat, it's 'sourceFirmGfcid'
		outmsg.setParty1Mnemonic(getStringValue(info, "firmAcctId")); 				// 21, OK, same as 14, not available in SIT DB. Same as 14
		outmsg.setParty2GFCID(getStringValue(info, "sourceCptyGFCID")); 			// 22, OK, 1000101733, not available in SIT DB. In QAT, it's 'sourceCptyGfcid'
		outmsg.setParty2Mnemonic(getStringValue(info, "cptyAcctId")); 				// 23, OK, same as 16, not available in SIT DB. Same as 16

		outmsg.setMessageID(getStringValue(info, "messageID")); 				// 24, ?, RegHub, not available in SIT & QAT DB
		outmsg.setMessageType(getStringValue(info, "messageType")); 			// 25, ?, RegHub, not available in SIT & QAT DB
		outmsg.setMessageCategory(getStringValue(info, "messageCategory")); 	// 26, ?, RegHub, not available in SIT & QAT DB

		// outmsg.setExceptionID(exception.getId()); 						// 27, required, OK, RegHub, set in the calling class

		outmsg.setExceptionClass(getStringValue(info, "exceptionClass")); 	// 28, ?, RegHub exception.getClass(), not available in SIT & QAT DB
		outmsg.setCreationTimestamp(getLong(entity.receivedTs)); 			// 29, ?, RegHub
		outmsg.setExecutionDateTime(getLong(entity.executionTs)); 			// 30, ?, RegHub

		//outmsg.setTradeStatus(getStringValue(info, "tradeStatus")); 		// 31, ?
		outmsg.setTradeDate(getLongValue(info, "tradeDate")); 				// 32, ?

		// new attributes
		outmsg.setSiFlag(getStringValue(info, "refSIFlag"));							// 1
		outmsg.setTradeSubVersion(getStringValue(info, "sourceVersion"));				// 2
		outmsg.setTotvFlag(getStringValue(info, "refTOTVInstrumentFlag"));				// 3
		outmsg.setAssistedReportingFlag(getStringValue(info, "cptyAssistedReport"));	// 4
//		outmsg.setDeferralFlag(getStringValue(info, "deferralFlag"));					// 5
		outmsg.setInstrumentFullName(getStringValue(info, "refCust1Txt"));				// 6
//		outmsg.setTradedonEEAvenueFlag(getStringValue(info, "tradedonEEAvenueFlag"));	// removed in new mapping
		outmsg.setUnderlyingInstrumentName(getStringValue(info, "underlyingInstrument"));				// 7
		outmsg.setUnderlyingInstrumentCode(getStringValue(info, "underlyingInstrumentClassification"));	// 8
		outmsg.setCfiCode(getStringValue(info, "instrumentClassification"));	// 9
//		outmsg.setCusIp(getValue(info.get("CUSIP"), String.class,"refCusip"));	// 10, not defined in schema
//		outmsg.setFii(getValue(info.get("FII"), String.class,"refFii"));		// 11, not defined in schema
		outmsg.setSmcp(getStringValue(info, "srcSmcp"));						// 12
		outmsg.setExecutionVenue(getStringValue(info, "executionVenue"));		// 13
//		outmsg.setPostLisValue(getStringValue(info, "refPostLISValue"));		// 14
//		outmsg.setPostLisFloor(getStringValue(info, "refPostLISFloor"));		// 15
//		outmsg.setPostSstiValue(getStringValue(info, "refPostSSTIValue"));		// 16
//		outmsg.setPostSstiFloor(getStringValue(info, "refPostSSTIFloor"));		// 17
//		outmsg.setSstiFlag(getStringValue(info, "sstiFlag"));					// removed from the new mapping
//		outmsg.setLisFlag(getStringValue(info, "lisFlag"));						// removed from the new mapping
		outmsg.setLiquidityFlag(getStringValue(info, "refLiquidity"));			// 18
		outmsg.setMifidCountryCode(getStringValue(info, "refMIFIDCountryCode"));	// 19
//		outmsg.setExchangeCountry(getStringValue(info, "exchangeCountry"));		// 20
		outmsg.setMicId(getStringValue(info, "tradingVenueIdCode"));			// 21

		return outmsg;
	}

	private Long getLong(LocalDateTime time) {
		return time.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
	}

	public String getStringValue (Map<String, Object> map, String name) {
		Object obj = map.get(name);
		return getValue(obj, String.class, name);
	}

	public Double getDoubleValue (Map<String, Object> map, String name) {
		Object obj = map.get(name);
		return getValue(obj, Double.class, name);
	}

	public Long getLongValue (Map<String, Object> map, String name) {
		Object obj = map.get(name);
		Long longDate = getValue(obj, Long.class, name);

		if (longDate == null) {
			return null;
		}

		// if length is greater than 13, than it's nano seconds
		int length = String.valueOf(longDate).length();

		// if longDate is null, below statement will throw a NullPointerException.
		// But in Apache Storm log it's displayed as: "IllegalArgumentException: key does not exist."
		return length < MAX_DATE_LENGTH ? longDate : (longDate/NANOSECONDS);
	}

	public <T> T getValue (Object value, Class<T> cls, String name) {
		if (value == null) {
			return null;
		}
		
		if(cls.isInstance(value)) {
			return	cls.cast(value);
		} else {
			T newInstance =null;
			
			try {
				String valueOf = String.valueOf(value);
				Constructor<T> con = cls.getConstructor(String.class);
				newInstance = con.newInstance(valueOf);
			} catch (Exception e){
				LOGGER.error("RegHubId: {}, {}: value \"{}\" expected to be of type {}, but got  {}", regHubId, name, value, cls, value.getClass());
				return null;
			}
			return newInstance;
		}
	}

	public List<EventEnvelope> fromXstream(OutBoundNotificationMsg nmsg) {
		List<MsgExceptionNote> xnotes = nmsg.getNote();
		List<EventEnvelope> envelopes = new ArrayList<>();

		if (nmsg.getStatus() != null) {
			ExceptionMessage exceptionMsg = new ExceptionMessageBuilder().newException().withId(nmsg.getSrcSystemRefId())
					.withStatus(ExceptionStatus.ACTED).build();
			envelopes.add(new EventBuilder().newEvent().withEventName(EventName.EXCEPTION_STATUS_UPDATED)
					.withEventSource(EventSource.XM_XSTREAM).withEventData(exceptionMsg).ofTypeException().build());
		}

		if (xnotes != null && !xnotes.isEmpty()) {
			MsgExceptionNote xnote = xnotes.get(0);
			if (ADD_NOTE.equalsIgnoreCase(xnote.getUserAction())) {
				Note note = new Note();
				note.setNote(xnote.getNote());
				note.setCreatedBy(NoteSource.XSTREAM.value());
				note.setSource(NoteSource.XSTREAM);
				note.setCreatedTS(xnote.getNoteTimestamp());

				ExceptionMessage exceptionMsg = new ExceptionMessageBuilder().newException().withId(nmsg.getSrcSystemRefId())
						.addNote(note).build();
				envelopes.add(new EventBuilder().newEvent().withEventName(EventName.EXCEPTION_NOTE_ADDED)
						.withEventSource(EventSource.XM_XSTREAM).withEventData(exceptionMsg).ofTypeException().build());

			}
		}

		String ownerType = nmsg.getTypeOfOwner();
		if (OWNER_TYPE.equalsIgnoreCase(ownerType)) {
			ExceptionMessage exceptionMsg = new ExceptionMessageBuilder().newException().withId(nmsg.getSrcSystemRefId())
					.withStatus(ExceptionStatus.ACTED).withOwner(FunctionalOwner.TECH).isXstreamEligible(false).build();
			envelopes.add(new EventBuilder().newEvent().withEventName(EventName.EXCEPTION_UPDATED)
					.withEventSource(EventSource.XM_XSTREAM).withEventData(exceptionMsg).ofTypeException().build());

		}

		return envelopes;
	}

	private XMLGregorianCalendar getXMLGregorianCalendar() {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		GregorianCalendar gregorianCalendar = new GregorianCalendar();

		try {
			DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
			xmlGregorianCalendar = dataTypeFactory.newXMLGregorianCalendar(gregorianCalendar);
		} catch (Exception e) {
			LOGGER.error("Exception in conversion of Date to XMLGregorianCalendar: {}", e);
		}

		return xmlGregorianCalendar;
	}
}
