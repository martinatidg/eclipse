package com.citi.reghub.core.xm.xstream.schema;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.OutBoundNotificationMsg;

public class XstreamMarshaller {
	public static final String INBOUND_PACKAGE = "com.citi.reghub.core.xm.xstream.schema.inbound";
	public static final String OUTBOUND_PACKAGE = "com.citi.reghub.core.xm.xstream.schema.outbound";

	private XstreamMarshaller() {
		throw new UnsupportedOperationException(
				"The Util class contains static methods only and cannot be instantiated.");
	}

	public static String marshalXmFeedMsg(XmFeedMsg msg) throws JAXBException {
		StringWriter stringWriter = new StringWriter();
		JAXBContext jaxbContext = JAXBContext.newInstance(XmFeedMsg.class);

		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.marshal(new JAXBElement<XmFeedMsg>(new QName("", "xmFeedMsg"), XmFeedMsg.class, null, msg),
				stringWriter);

		return stringWriter.toString();
	}

	public static XmFeedMsg unmarshalXmFeedMsg(String xml) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(XmFeedMsg.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		InputStream is = new ByteArrayInputStream(xml.getBytes());
		JAXBElement<XmFeedMsg> xmsg = jaxbUnmarshaller.unmarshal(new StreamSource(is),
				XmFeedMsg.class);

		return xmsg.getValue();
	}

	public static String marshalNotificationMsg(OutBoundNotificationMsg msg) throws JAXBException {
		StringWriter stringWriter = new StringWriter();
		JAXBContext jaxbContext = JAXBContext.newInstance(OutBoundNotificationMsg.class);

		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.marshal(new JAXBElement<OutBoundNotificationMsg>(new QName("", "OutBoundNotificationMsg"), OutBoundNotificationMsg.class, null, msg),
				stringWriter);

		return stringWriter.toString();
	}

	public static OutBoundNotificationMsg unmarshalNotificationMsg(String xml) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(OutBoundNotificationMsg.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		InputStream is = new ByteArrayInputStream(xml.getBytes());
		JAXBElement<OutBoundNotificationMsg> xmsg = jaxbUnmarshaller.unmarshal(new StreamSource(is),
				OutBoundNotificationMsg.class);

		return xmsg.getValue();
	}
}
