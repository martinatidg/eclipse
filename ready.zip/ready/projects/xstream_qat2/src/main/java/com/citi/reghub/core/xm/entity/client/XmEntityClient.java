package com.citi.reghub.core.xm.entity.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.entity.client.EntityClientConfig;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;

public class XmEntityClient {
	private EntityClientConfig entityClientConfig;
	private static final Logger LOGGER = LoggerFactory.getLogger(XmEntityClient.class);

	public XmEntityClient(EntityClientConfig entityClientConfig) {
		if (entityClientConfig == null) {
			LOGGER.warn("Entity client config passed is null, using default configuration");
		}

		this.entityClientConfig = (entityClientConfig == null ? new EntityClientConfig() : entityClientConfig);

		if (!this.entityClientConfig.containsKey(MetadataClientConfig.METADATA_URL_KEY)) {
			this.entityClientConfig.setDefaultMetadataUrl();
		}

		LOGGER.info("Instantiated Enrichment client instance with config='{}'", entityClientConfig);
	}

	public Entity getLatestEntity(String stream, String flow, String sourceId) {
		LOGGER.debug("Hitting Entity Service for stream: '{}', flow: '{}', sourceId: '{}'", stream, flow, sourceId);

		String url = entityClientConfig.getEntityUrl() + "?stream=" + stream + "&flow=" + flow
						+ "&sourceId=" + sourceId + "&limit=1" + "&summaryView=" + false;
		LOGGER.debug("Entity service URL: '{}'", url);

		List<Entity> entity = entityClientConfig.getRestClient().getValues(url, Entity.class);

		return entity.get(0);
	}
}
