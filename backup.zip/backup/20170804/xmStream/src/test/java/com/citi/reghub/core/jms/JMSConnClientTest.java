/**
 * 
 */
package com.citi.reghub.core.jms;

import static com.citi.reghub.core.constants.Key.*;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.constants.Key;
import com.citi.reghub.core.message.XmMessageHandler;

/**
 * @author sc54933
 *
 */
@RunWith(JUnit4.class)
public class JMSConnClientTest {
	private Map<Key, String> config = new HashMap<>();
	private MessageProducer jmsClient;

	@Before
	public void setUp() {
		// QueueConnectionFactory = citi.cibtech.na.gicapbpm_153176.XAQueueCF
		// JNDIContextURL = tibjmsnaming://icgesbint.nam.nsroot.net:7222
		//
		// Reghub to X-Stream:
		// citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue
		// X-Stream to Rehub:
		// citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue

		config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		config.put(PROVIDER, "TibjmsInitialContextFactory");
	}

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.jms.XMMessageProcessor#JMSConnectionClient(java.util.Map)}.
	 * @throws JMSException 
	 */
//	@Test
//	public void testJMSConnectionClient() throws JMSException {
//		setUp();
//		jmsClient = new MessageProducer(config);
//		String providerUrl = jmsClient.getConfig().get(PROVIDER_URL);
//		assertTrue(providerUrl.equals(PROVIDER_URL));
//	}

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.jms.XMMessageProducer#initConnection()}.
	 * 
	 * @throws Exception
	 */
	// @Test(expected=Test.None.class)
	// public void testInitConnection() throws Exception {
	// setUp();
	// jmsClient=new XMMessageProducer(config);
	// jmsClient.initConnection();
	// }

	/**
	 * Test method for
	 * {@link com.citi.reghub.core.jms.client.XMMessageProcessor#sendMessage(java.lang.String)}.
	 * 
	 * @throws Exception
	 */
	@Test // (expected=Exception.class)
	public void testSendMessage() throws Exception {
		jmsClient = new MessageProducer(config);
		//jmsClient.initConnection();
		XmMessageHandler xmhandler = new XmMessageHandler();
		String actual = xmhandler.marshal();
		System.out.println("testSendMessage(), actual = " + actual);
		jmsClient.sendMessage(actual);
	}

}
