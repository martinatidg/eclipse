package com.citi.reghub.core.xm;

import static com.citi.reghub.core.constants.Attribute.PAC;
import static com.citi.reghub.core.constants.Attribute.SFOS;
import static com.citi.reghub.core.constants.Attribute.TYPE;
import static com.citi.reghub.core.constants.Attribute.UITI;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.message.XmMessageHandler;
import com.citi.reghub.core.xjc.ObjectFactory;

public class XMHandlerTest {
	private XmMessageHandler xmhandler;
	@Before
	public void init() {
		xmhandler = new XmMessageHandler();

//		Map<String, String> xmMap = new HashMap<>();
//		xmMap.put(PAC.key(), "pac");
//		xmMap.put(SFOS.key(), "sfos");
//		xmMap.put(TYPE.key(), "type");
//		xmMap.put(UITI.key(), "uiti");
//
//		xmhandler = new XMHandler(xmMap);
	}

	@Test
	public void testMarshal() throws JAXBException {
		String expected = "";
		String actual = xmhandler.marshal();
		System.out.println("estMarshal(), actual = " + actual);
		Assert.assertNotNull("result is null", actual);
	}
}
