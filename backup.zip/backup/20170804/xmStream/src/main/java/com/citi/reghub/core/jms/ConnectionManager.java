package com.citi.reghub.core.jms;

import static com.citi.reghub.core.constants.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.constants.Key.DESTINATION;
import static com.citi.reghub.core.constants.Key.PROVIDER_URL;

import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.Key;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class ConnectionManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConnectionManager.class);
	private int connectionCount = 0;
	private Properties context = null;
	private QueueConnection queueConnection;
//	private Queue queue;
	private String factoryName = TibjmsInitialContextFactory.class.getName();

	public void createConnection(Map<Key, String> config) throws NamingException, JMSException {
		context = new Properties();
		// context.put(Context.INITIAL_CONTEXT_FACTORY, config.get(PROVIDER));
		context.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		context.put(Context.PROVIDER_URL, config.get(PROVIDER_URL));
		InitialContext jndi = new InitialContext(context);
		QueueConnectionFactory conFactory = (QueueConnectionFactory) jndi.lookup(config.get(CONNECTION_JNDI));
		queueConnection = conFactory.createQueueConnection();
//		queue = (Queue) jndi.lookup(config.get(DESTINATION));
		queueConnection.start();

		LOGGER.error("Connection {}, destination {} is started.", ++connectionCount, config.get(DESTINATION));
	}

	public QueueSession getSession() throws JMSException {
		return queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
	}

}
