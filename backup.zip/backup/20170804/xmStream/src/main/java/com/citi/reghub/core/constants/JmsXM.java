package com.citi.reghub.core.constants;

import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public enum JmsXM {
	QUEUE_REQUEST("citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue"),
	QUEUE_RESONSE("citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue"),
	COONECTION("citi.cibtech.na.gicapbpm_153176.XAQueueCF"),
	PROVIDER("TibjmsInitialContextFactory"),
	JNDI_URL("tibjmsnaming://icgesbint.nam.nsroot.net:7222");

	private String value;

	private JmsXM(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}
}
