package com.citi.reghub.core.jms;

import static com.citi.reghub.core.constants.Key.*;
//import static com.citi.reghub.core.constants.JmsXM.COONECTION;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.Key;
import com.citi.reghub.core.jms.client.XMMessageProcessor;
import com.citi.reghub.core.message.ResponseMessage;
import com.citi.reghub.core.message.XmMessageHandler;
import com.citi.reghub.core.xjc.RegHubMsg;
import com.citi.reghub.core.xjc.ReghubNotificationMsg;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;

public class XMMessageConsumer implements MessageListener { // 1
	private static final Logger LOGGER = LoggerFactory.getLogger(XMMessageConsumer.class);
	private Map<Key, String> config = null;
	private Properties env = null;
	@Resource(lookup = "citi.cibtech.na.gicapbpm_153176.XAQueueCF") // 2
	private static ConnectionFactory connectionFactory;
	@Resource(lookup = "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue") // 2

	private String factoryName = TibjmsInitialContextFactory.class.getName();
	private QueueConnection queueConnection;
	private static Queue queue;

	public static void main(String[] args) {

		XMMessageConsumer xmconsumer = new XMMessageConsumer();
		try {
			xmconsumer.startQueue();
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	public XMMessageConsumer() {
		config = new HashMap<>();
		config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
		//config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");

		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		initJMS();
	}

	public void onMessage(Message message) { // 6
		try {
			String xml = ((TextMessage) message).getText();
			System.out.println("Message received: " + xml);

			XmMessageHandler xmHandler = new XmMessageHandler();
			RegHubMsg msgObj = xmHandler.unmarshal(xml);
			boolean c = msgObj instanceof RegHubMsg;
			System.out.println("Unmarshaled to RegHubMsg: " + c);

			String exId = msgObj.getExceptionID();
			System.out.println("Unmarshaled to RegHubMsg: " + c);
			sendResponse(exId);
		} catch (JMSException | JAXBException e) {
			e.printStackTrace();
		}
	}

	public void startQueue() throws NamingException {
		try {
			InitialContext jndi = new InitialContext(env);
			connectionFactory = (QueueConnectionFactory) jndi.lookup(config.get(CONNECTION_JNDI));

			Connection connection = connectionFactory.createConnection(); // 3
			queue = (Queue) jndi.lookup(this.config.get(DESTINATION));
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(queue);
			consumer.setMessageListener(new XMMessageConsumer()); // 4

			connection.start();
		} catch (JMSException e) {
			e.printStackTrace();
		} // 5
	}

	private void initJMS() {
		env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		env.put(Context.PROVIDER_URL, this.config.get(PROVIDER_URL));
	}

	public void sendResponse(String exceptionId) throws JAXBException, JMSException {
		Map<Key, String> config = new HashMap<>();
		config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		config.put(PROVIDER, factoryName);
		
		ResponseMessage resMsg = new ResponseMessage();
		resMsg.setExceptionId(exceptionId);
		
		String xmlMsg = resMsg.marshal();
		
		MessageProducer producer;
		producer = new MessageProducer(config);
		
		producer.sendMessage(xmlMsg);
	}

}
