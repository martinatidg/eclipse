package com.citi.reghub.core.message;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import com.citi.reghub.core.xjc.ObjectFactory;
import com.citi.reghub.core.xjc.RegHubMsg;
import com.citi.reghub.core.xjc.Status;

public class XmMessageHandler {
	RegHubMsg msg;

	public XmMessageHandler() {
		ObjectFactory obj = new ObjectFactory();
		msg = obj.createRegHubMsg();
		
		long ct = System.currentTimeMillis();
		msg.setUITI("035506000021863338876");
		msg.setProductType("ForeignExchange:NDF");
		msg.setSourceFrontOfficeSystem("FXLMREG");
		msg.setPrimaryAssetClass("FOREIGNEXCHANGE");
		msg.setParty1ID("1000242191");
		msg.setParty1GFCIDDescription("CITIGROUP GLOBAL MARKETS LTD");
		msg.setParty1GFCID("1000242191");
		msg.setParty2ID("1000019751");
		msg.setParty2GFCIDDescription("BNP PARIBAS SA-PARIS HEAD OFFICE");
		msg.setParty2GFCID("1000019751");
		msg.setOriginatingEvent("CONFIRMATIONAGREEMENT");
		msg.setReportingPurpose("Confirm");
		msg.setReportingObligation("ESMA");
		msg.setOnBehalfOf("Party1");
		msg.setMessageID("936140070");
		msg.setMessageType("PET");
		msg.setExceptionID("555555555555");
		msg.setExceptionClass("NACK");
		msg.setStatus(Status.OPEN.name());
		msg.setCreationTimestamp(ct);
		msg.setExecutionDateTime(ct);
	}
	
	public void setMessageId(String mid) {
		msg.setMessageID(mid);
		msg.setExceptionID(mid);
	}

	public String marshal() throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xjc" );
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(msg, writer );
		
		return writer.toString();
	}

	public RegHubMsg unmarshal(String xml) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xjc" );
		StringWriter writer = new StringWriter();
		Unmarshaller u = jc.createUnmarshaller();
		RegHubMsg msgObj = (RegHubMsg)u.unmarshal(new StreamSource(new StringReader(xml)));
		
		return msgObj;
	}
}
