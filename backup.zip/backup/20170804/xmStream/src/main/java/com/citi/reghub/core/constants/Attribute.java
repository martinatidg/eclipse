package com.citi.reghub.core.constants;

public enum Attribute {
    UITI("UITI"),
    TYPE("productType"),
    SFOS("SourceFrontOfficeSystem"),
    PAC("primaryAssetClass");

	private String key;

	private Attribute(String key) {
		this.key = key;
	}

	public String key() {
		return key;
	}
}
