package com.citi.reghub.core.constants;

public enum Key {
	DESTINATION("jms.destination"),
	USERNAME("jms.username"),
	PASSWORD("jms.password"),
	CONNECTION_JNDI("jms.connection.jndi"),
	PROVIDER("jms.provider"),
	PROVIDER_URL("jms.provider.url");
	
	private String key;

	private Key(String key) {
		this.key = key;
	}

	public String key() {
		return key;
	}
}
