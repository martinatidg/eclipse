package com.citi.reghub.core.message;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import com.citi.reghub.core.xjc.ObjectFactory;
import com.citi.reghub.core.xjc.RegHubMsg;
import com.citi.reghub.core.xjc.Status;

public class RequestMessage {
	RegHubMsg sdrExcMSG;

	public RequestMessage() {
		ObjectFactory obj = new ObjectFactory();
		sdrExcMSG = obj.createRegHubMsg();
		
		long ct = System.currentTimeMillis();
		sdrExcMSG.setUITI("035506000021863338876");
		sdrExcMSG.setProductType("ForeignExchange:NDF");
		sdrExcMSG.setSourceFrontOfficeSystem("FXLMREG");
		sdrExcMSG.setPrimaryAssetClass("FOREIGNEXCHANGE");
		sdrExcMSG.setParty1ID("1000242191");
		sdrExcMSG.setParty1GFCIDDescription("CITIGROUP GLOBAL MARKETS LTD");
		sdrExcMSG.setParty1GFCID("1000242191");
		sdrExcMSG.setParty2ID("1000019751");
		sdrExcMSG.setParty2GFCIDDescription("BNP PARIBAS SA-PARIS HEAD OFFICE");
		sdrExcMSG.setParty2GFCID("1000019751");
		sdrExcMSG.setOriginatingEvent("CONFIRMATIONAGREEMENT");
		sdrExcMSG.setReportingPurpose("Confirm");
		sdrExcMSG.setReportingObligation("ESMA");
		sdrExcMSG.setOnBehalfOf("Party1");
		sdrExcMSG.setMessageID("936140070");
		sdrExcMSG.setMessageType("PET");
		sdrExcMSG.setExceptionID("555555555555");
		sdrExcMSG.setExceptionClass("NACK");
		sdrExcMSG.setStatus(Status.OPEN.name());
		sdrExcMSG.setCreationTimestamp(ct);
		sdrExcMSG.setExecutionDateTime(ct);
	}
	
	public void setMessageId(String mid) {
		sdrExcMSG.setMessageID(mid);
	}

	public String marshal() throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xjc" );
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(sdrExcMSG, writer );
		
		return writer.toString();
	}

	public RegHubMsg unmarshal(String xml) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xjc" );
		StringWriter writer = new StringWriter();
		Unmarshaller u = jc.createUnmarshaller();
		RegHubMsg msgObj = (RegHubMsg)u.unmarshal(new StreamSource(new StringReader(xml)));
		
		return msgObj;
	}
}
