package com.citi.reghub.core.jms.server;

public class XMServer {

}
