package com.citi.reghub.core.jms.client;

import static com.citi.reghub.core.constants.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.constants.Key.DESTINATION;
import static com.citi.reghub.core.constants.Key.PROVIDER;
import static com.citi.reghub.core.constants.Key.PROVIDER_URL;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.citi.reghub.core.constants.Key;
import com.citi.reghub.core.jms.MessageProducer;
import com.citi.reghub.core.message.XmMessageHandler;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

/**
 * JMSConnectionClient for interaction with Middle ware System for sending Fix
 * message to tradeEcho
 * 
 *
 */
public class XMMessageProcessor implements MessageListener, Serializable {
	@Value("${xm.queue.request}")
	String queueRequest;
	@Value("${xm.queue.response}")
	String queueResponse;
	@Value("${xm.jms.jndi}")
	String connectionFactory;
	@Value("${xm.jms.provider}")
	String provider;
	@Value("${xm.jms.provider.url}")
	String url;

	MessageProducer producer;
	private static String factoryName = TibjmsInitialContextFactory.class.getName();

	private static final long serialVersionUID = -8055624586639876364L;

	private static final Logger LOGGER = LoggerFactory.getLogger(XMMessageProcessor.class);

	private transient Map<Key, String> config = null;

	public XMMessageProcessor() throws JMSException {
		config = new HashMap<Key, String>();
		config.put(DESTINATION, queueRequest);
		config.put(CONNECTION_JNDI, connectionFactory);
		config.put(PROVIDER_URL, url);
		config.put(PROVIDER, provider);

		producer = new MessageProducer(config);
	}

	public void sendXmMessage() throws JAXBException, JMSException {
		XmMessageHandler xmhandler = new XmMessageHandler();
		try (Scanner scanner = new Scanner(System.in)) {
			while (true) {
				System.out.println("Type in message ID to send an XM message:");
				String mid = scanner.nextLine();
				if (mid == null || mid.trim().isEmpty()) {
					break;
				}

				xmhandler.setMessageId(mid);
				String msg = xmhandler.marshal();

				LOGGER.info("sending message:\n{}", msg);
				producer.sendMessage(msg);
			}
		}
	}

	public XMMessageProcessor(Map<Key, String> config) throws JMSException {
		this.config = config;
		producer = new MessageProducer(config);
	}

	public static void main(String[] args) throws JMSException, JAXBException {
		Map<Key, String> config = new HashMap<>();
		config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
//		config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		config.put(PROVIDER, factoryName);

		XMMessageProcessor processor = new XMMessageProcessor(config);
		processor.sendXmMessage();
	}

	@Override
	public void onMessage(Message arg0) {

	}
}