package com.citi.reghub.core.xmxstream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmXstreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmXstreamApplication.class, args);
	}
}
