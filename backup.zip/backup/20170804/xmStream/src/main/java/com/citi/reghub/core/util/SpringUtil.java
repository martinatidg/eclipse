package com.citi.reghub.core.util;

public class SpringUtil {
	
	public static boolean isEmpty(String s) {
		return s==null || s.length()==0;
	}

	public static boolean isBlank(String s) {
		return s==null || s.trim().length()==0;
	}

	public static boolean isEmptyAfterTrim(String s) {
		return s==null || s.trim().length()==0;
	}
	/**
	 * Return toString() if not null, else return null
	 * @param obj
	 * @return
	 */
	public static String toString(Object obj) {
		if(obj!=null) {
			return obj.toString();
		}
		return null;
	}

	/**
	 * Return toString() if not null, else return ""
	 * @param obj
	 * @return
	 */
	public static String toString2(Object obj) {
		if(obj!=null) {
			return obj.toString();
		}
		return ""; //THIS is the difference
	}

	public static Integer toInteger(Object obj) {
		if(obj!=null) {
			return (Integer)obj;
		}
		return -1;
	}
	
	public static boolean equals(String str1, String str2) {
		if(str1 == null || str2 == null) {
			return false;
		}
		else {
			return str1.equals(str2);
		}
	}	
	
	public static boolean equalsIgnoreCase(String str1, String str2) {
		if(str1 == null || str2 == null) {
			return false;
		}
		else {
			return str1.equalsIgnoreCase(str2);
		}
	}
	
	public static boolean oneOf(String inputString,String... stringList){
		return oneOf(true, inputString, stringList);
	}	
	
	public static boolean oneOf(boolean ignoreCase, String inputString, String... stringList){
		if(inputString == null)
			return false;
		
		for(String str:stringList){
			if(str == null) 
				continue;
			
			if(ignoreCase) {
				if(inputString.equalsIgnoreCase(str))
					return true;
				
			}	else {
				if(inputString.equals(str)) {
					return true;
				}
			}
		}
		return false;
	}	
	
	public static boolean contains(String inputString, String... stringList){
		return contains(true, inputString, stringList);
	}	
	
	public static boolean contains(boolean ignoreCase, String inputString, String... stringList){
		if(inputString == null) 
			return false;
		
		if(ignoreCase) {
			inputString = inputString.toUpperCase();
		}
		
		for(String str:stringList){
			if(str == null) 
				continue;
			
			if(ignoreCase) {
				str = str.toUpperCase();
			}

			if(inputString.contains(str))
				return true;
		}
		return false;
	}

	public static boolean endsWithOneOf(String inputString, String... stringList){
		return endsWithOneOf(true, inputString, stringList);
	}
	
	public static boolean endsWithOneOf(boolean ignoreCase, String inputString, String... stringList){
		if(inputString == null) 
			return false;
		
		if(ignoreCase) {
			inputString = inputString.toUpperCase();
		}
		
		for(String str:stringList){
			if(str == null) 
				continue;
			
			if(ignoreCase) {
				str = str.toUpperCase();
			}

			if(inputString.endsWith(str))
				return true;
		}
		return false;
	}
	
	public static boolean isTrue(String inputString) {
		return oneOf(inputString, "TRUE", "YES");
	}	
}
