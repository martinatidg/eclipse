package com.citi.reghub.core.jms;

import static com.citi.reghub.core.constants.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.constants.Key.DESTINATION;
import static com.citi.reghub.core.constants.Key.PROVIDER;
import static com.citi.reghub.core.constants.Key.PROVIDER_URL;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.Key;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

/**
 * JMSConnectionClient for interaction with Middle ware System for sending Fix
 * message to tradeEcho
 * 
 *
 */
public class MessageProducer implements Serializable {
	private static final long serialVersionUID = -8055624586639876364L;

	public static final Logger LOGGER = LoggerFactory.getLogger(MessageProducer.class);

	private Map<Key, String> config = null;
	private Properties context = null;
	private QueueConnection queueConnection;
	private Queue queue;
	private String factoryName = TibjmsInitialContextFactory.class.getName();

//	public MessageProducer() {
//		config = new HashMap<Key, String>();
//		config.put(DESTINATION, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
//		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
//		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
//
//	}

	public MessageProducer(Map<Key, String> config) throws JMSException {
		this.config = config;
		initContext(config);
		openConnection();
	}

	/**
	 * Initializing JMS connection
	 * 
	 */
	private void initContext(Map<Key, String> config) {
		context = new Properties();
		context.put(Context.INITIAL_CONTEXT_FACTORY, config.get(PROVIDER));
		//context.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		context.put(Context.PROVIDER_URL, this.config.get(PROVIDER_URL));
	}

	/**
	 * 
	 * @param text
	 *            Fix Messeage to be sent to Middleware
	 * @throws JMSException
	 */
	public void sendMessage(String text) throws JMSException {
		QueueSession queueSession = null;

		if (StringUtils.isEmpty(text)) {
			LOGGER.error("Message to be sent cannot be null");
			throw new JMSException("Message to be sent cannot be null");
		}

		try {
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			QueueSender producer = queueSession.createSender(queue);
			TextMessage message = queueSession.createTextMessage();
			message.setText(text);
			producer.send(message);
			// message.acknowledge();
			queueSession.close();

		} catch (JMSException e) {
			LOGGER.error("Issue occured while sending message to Middleware {}", e.getMessage());
			throw e;
		}

	}

	/**
	 * Opening connection with JMS setting up ENV properties.
	 * 
	 * @throws Exception
	 */
	public void openConnection() throws JMSException {

		try {
			InitialContext jndi = new InitialContext(context);
			QueueConnectionFactory conFactory = (QueueConnectionFactory) jndi.lookup(config.get(CONNECTION_JNDI));
			queueConnection = conFactory.createQueueConnection();
			queue = (Queue) jndi.lookup(this.config.get(DESTINATION));
			queueConnection.start();
		} catch (Exception e) {
			LOGGER.error("Issue occured while opening connection with Middleware {}", e.getMessage());
			throw new JMSException(e.getMessage());
		}
	}

	/**
	 * @return
	 */
	public Map<Key, String> getConfig() {
		return config;
	}

}