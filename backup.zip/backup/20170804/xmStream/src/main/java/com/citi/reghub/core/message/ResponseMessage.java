package com.citi.reghub.core.message;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import com.citi.reghub.core.xjc.ObjectFactory;
import com.citi.reghub.core.xjc.RegHubMsg;
import com.citi.reghub.core.xjc.ReghubNotificationMsg;
import com.citi.reghub.core.xjc.Status;

public class ResponseMessage {
	private ReghubNotificationMsg msg;

	public ResponseMessage() {
		ObjectFactory obj = new ObjectFactory();
		msg = obj.createReghubNotificationMsg();
		msg.setExceptionID("3333333333333");
		msg.setExceptionRefNumber("55555555555");
		msg.setStatus(Status.CLOSED);
		msg.setTypeOfOwner("Manager");
		
	}
	
	public ReghubNotificationMsg getResponseMsg() {
		return msg;
	}

	public void setExceptionId(String exId) {
		msg.setExceptionID(exId);
	}

	public String marshal() throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xjc" );
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(msg, writer );
		
		return writer.toString();
	}

	public ReghubNotificationMsg unmarshal(String xml) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xjc" );
		Unmarshaller u = jc.createUnmarshaller();
		ReghubNotificationMsg msgObj = (ReghubNotificationMsg)u.unmarshal(new StreamSource(new StringReader(xml)));
		
		return msgObj;
	}
}
