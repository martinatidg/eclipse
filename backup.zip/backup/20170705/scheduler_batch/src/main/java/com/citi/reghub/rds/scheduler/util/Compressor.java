package com.citi.reghub.rds.scheduler.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipFile;
import org.apache.commons.compress.utils.IOUtils;

/**
 *
 * @author martin.tan
 */
public class Compressor {


    private Compressor() throws Exception {
        throw new Exception("The ZipUtil class contains static methods only and cannot be instantiated.");
    }

    public static boolean zip(Collection<String> filenames, String zipFile) throws Exception {
        /* Create Output Stream that will have final zip files */
        OutputStream zip_output = new FileOutputStream(new File(zipFile));
        /* Create Archive Output Stream that attaches File Output Stream / and specifies type of compression */
        ArchiveOutputStream logical_zip = new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.ZIP, zip_output);

        for (String fname : filenames) {
            /* Create Archieve entry - write header information*/
            logical_zip.putArchiveEntry(new ZipArchiveEntry(fname));
            /* Copy input file */
            IOUtils.copy(new FileInputStream(new File(fname)), logical_zip);
            /* Close Archieve entry, write trailer information */
            logical_zip.closeArchiveEntry();
        }

        /* Finish addition of entries to the file */
        logical_zip.finish();
        /* Close output stream, our files are zipped */
        zip_output.close();

        return true;
    }

    public static boolean zip(String[] filenames, String zipFile) throws Exception {
        /* Create Output Stream that will have final zip files */
        OutputStream zip_output = new FileOutputStream(new File(zipFile));
        /* Create Archive Output Stream that attaches File Output Stream / and specifies type of compression */
        ArchiveOutputStream logical_zip = new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.ZIP, zip_output);

        for (String fname : filenames) {
            /* Create Archieve entry - write header information*/
            logical_zip.putArchiveEntry(new ZipArchiveEntry(fname));
            /* Copy input file */
            IOUtils.copy(new FileInputStream(new File(fname)), logical_zip);
            /* Close Archieve entry, write trailer information */
            logical_zip.closeArchiveEntry();
        }

        /* Finish addition of entries to the file */
        logical_zip.finish();
        /* Close output stream, our files are zipped */
        zip_output.close();

        return true;
    }

    public static boolean zip(String filename, String zipFile) throws Exception {
        /* Create Output Stream that will have final zip files */
        OutputStream zip_output = new FileOutputStream(new File(zipFile));
        /* Create Archive Output Stream that attaches File Output Stream / and specifies type of compression */
        ArchiveOutputStream logical_zip = new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.ZIP, zip_output);
        /* Create Archieve entry - write header information*/
        logical_zip.putArchiveEntry(new ZipArchiveEntry(filename));
        /* Copy input file */
        IOUtils.copy(new FileInputStream(new File(filename)), logical_zip);
        /* Close Archieve entry, write trailer information */
        logical_zip.closeArchiveEntry();
        /* Repeat steps for file - 2 */
        logical_zip.putArchiveEntry(new ZipArchiveEntry("test_file_2.xml"));
        IOUtils.copy(new FileInputStream(new File("test_file_2.xml")), logical_zip);
        logical_zip.closeArchiveEntry();
        /* Finish addition of entries to the file */
        logical_zip.finish();
        /* Close output stream, our files are zipped */
        zip_output.close();

        return true;
    }

    public static boolean compress(String filename, Extension archiveType) throws IOException {
        File file = new File(filename);
        String zipname = filename;
        Collection<File> files;

        if (file.isFile()) {
            files = new ArrayList<>();
            files.add(file);
            zipname = IOUtil.getFilenameWithoutExtension(filename) + archiveType.ext();
        }
        else {
            files = Arrays.asList(file.listFiles());
        }

        File zipfile = new File(zipname);

        return compressFiles(files, zipfile, archiveType);
    }

    public static boolean compress(String filename, String destName, Extension archiveType) throws IOException {
        File file = new File(filename);
        Collection<File> files;

        if (file.isFile()) {
            files = new ArrayList<>();
            files.add(file);
        }
        else {
            files = Arrays.asList(file.listFiles());
        }

        File zipfile = new File(destName);

        return compressFiles(files, zipfile, archiveType);
    }

    public static boolean compressFiles(Collection<File> files, File file, Extension archiveType) throws IOException {
  //log.debug("Compressingfifiles.size() + " to "+file.getAbsoluteFile());
        // Create the output stream for the output file
        FileOutputStream fos;
        switch (archiveType) {
            case TAR_GZIP:
                fos = new FileOutputStream(new File(file.getCanonicalPath() + "." + Extension.TAR_GZIP.ext()));
                // Wrap the output file stream in streams that will tar and gzip everything
                TarArchiveOutputStream taos = new TarArchiveOutputStream(new GZIPOutputStream(new BufferedOutputStream(fos)));
                // TAR has an 8 gig file limit by default, this gets around that
                taos.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR); // to get past the 8 gig limit
                // TAR originally didn't support long file names, so enable the support for it
                taos.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                // Get to putting all the files in the compressed output file
                for (File f : files) {
                    addFilesToCompression(taos, f, ".", Extension.TAR_GZIP);
                }
                // Close everything up
                taos.close();
                fos.close();
                break;
            case ZIP:
                fos = new FileOutputStream(new File(file.getCanonicalPath() + "." + Extension.ZIP.ext()));
                // Wrap the output file stream in streams that will tar and zip everything
                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(
                        new BufferedOutputStream(fos));
                zaos.setEncoding("UTF-8");
                zaos.setCreateUnicodeExtraFields(ZipArchiveOutputStream.UnicodeExtraFieldPolicy.ALWAYS);

                // Get to putting all the files in the compressed output file
                for (File f : files) {
                    addFilesToCompression(zaos, f, ".", Extension.ZIP);
                }

                // Close everything up
                zaos.close();
                fos.close();
                break;
        }
        
        return true;
    }

//add entries to archive file...
    private static void addFilesToCompression(ArchiveOutputStream taos, File file, String dir, Extension archiveType) throws IOException {
        // Create an entry for the file
        switch (archiveType) {
            case TAR_GZIP:
                taos.putArchiveEntry(new TarArchiveEntry(file, dir + "/" + file.getName()));
                break;
            case ZIP:
                taos.putArchiveEntry(new ZipArchiveEntry(file, dir + "/" + file.getName()));
                break;
        }

        if (file.isFile()) {
            // Add the file to the archive
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
            IOUtils.copy(bis, taos);
            taos.closeArchiveEntry();
            bis.close();

        } else if (file.isDirectory()) {
            // close the archive entry
            taos.closeArchiveEntry();
            // go through all the files in the directory and using recursion, add them to the archive

            for (File childFile : file.listFiles()) {
                addFilesToCompression(taos, childFile, file.getName(), archiveType);
            }
        }
    }

    public static Path unzip(String zipname, String destination, String taskName) throws IOException {
        Path zipfile = Paths.get(zipname);
        Path destfile = Paths.get(destination);

        return unzip(zipfile, destfile, taskName);
    }

    /**
     * Unzip a zip file, notifying the given monitor along the way.
     *
     * @param zipFile
     * @param destination
     * @param taskName
     * @throws java.io.IOException
     */
//    public static void unzip(File zipFile, File destination, String taskName, IProgressMonitor monitor) throws IOException {
    public static Path unzip(Path zipFile, Path destination, String taskName) throws IOException {
        ZipFile zip = new ZipFile(zipFile.toFile());
        Path retfile = null;
        String retname = "";
//        if (monitor != null) {
//            monitor.beginTask(taskName, 1);
//        }
        Enumeration<ZipArchiveEntry> e = zip.getEntries();

        int i = 0;
        while (e.hasMoreElements()) {
            ZipArchiveEntry entry = e.nextElement();
            String entryName = entry.getName();
            System.out.println("unzip detail tracking...... , loop " + i + ", entry.getName() = " + entryName);
            i++;

            Path file = destination.resolve(entry.getName());
            if (entryName.length() > retname.length()) {
                retname = entryName;
                retfile = file;
            }

            if (entry.isDirectory()) {
                Files.createDirectories(file);
                //file.mkdirs();
            } else {
                InputStream is = zip.getInputStream(entry);
                Path parent = file.getParent();
                if (parent != null && !Files.exists(parent, LinkOption.NOFOLLOW_LINKS)) {
                    Files.createDirectories(parent);
                }

                FileOutputStream os = new FileOutputStream(file.toFile());
                try {
                    IOUtils.copy(is, os);
                } finally {
                    os.close();
                    is.close();
                }

                Files.setLastModifiedTime(file, entry.getLastModifiedTime());
                //file..setLastModified(entry.getTime());
//                int mode = entry.getUnixMode();
//                if ((mode & EXEC_MASK) != 0) {
//                    file.setExecutable(true);
//                }
            }
        }
//        if (monitor != null) {
//            monitor.worked(1);
//            monitor.done();
//        }
         // if the zip file contains multiple files or an directory, then return the top tmp folder
        if (retfile != null && (Files.isDirectory(retfile, LinkOption.NOFOLLOW_LINKS) || i > 1)) {
            retfile = destination;
        }

        return retfile;
    }

}
