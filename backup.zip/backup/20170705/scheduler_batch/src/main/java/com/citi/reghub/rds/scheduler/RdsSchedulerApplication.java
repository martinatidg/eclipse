package com.citi.reghub.rds.scheduler;

import java.util.concurrent.ExecutionException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class RdsSchedulerApplication {
	private static ConfigurableApplicationContext context;

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		try {
			context = SpringApplication.run(RdsSchedulerApplication.class, args);
		}
		catch(Exception e) {
			System.out.println("################# application not started. error message:" + e.getMessage());
		}
	}
}
