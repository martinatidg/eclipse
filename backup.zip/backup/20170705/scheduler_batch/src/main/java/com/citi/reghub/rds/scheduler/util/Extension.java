package com.citi.reghub.rds.scheduler.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum Extension {
    // compressed file
    JAR("jar"), ZIP("zip"), GZIP("gzip"), TAR_GZIP("tar.gz"), SEVEN_Z("7z"), AR("ar"), ARJ("arj"), BZIP2("bzip2"), CPIO("cpio"), DEFLATE("deflate"), DUMP("dump"), Z("z"), XZ("xz"), TAR("tar"), SNAPPY("snappy"), PACK200("pack200"), LZMA("lzma"), 
    OTHER("other");

    private final String ext;
    private static Set<Extension> zipSet;

    static {
        zipSet = new HashSet<>();
        zipSet.addAll(Arrays.asList(Z, ZIP, GZIP, SEVEN_Z, AR, ARJ, BZIP2, CPIO, DEFLATE, DUMP, Z, XZ, TAR, SNAPPY, PACK200, LZMA));
    }

    Extension() {
        this.ext = "";
    }

    Extension(String name) {
        this.ext = name.trim().toLowerCase();
    }

    public String ext() {
        return ext;
    }

    static public boolean isZipFile(String extStr) {
        Extension ext1 = type(extStr);

        return zipSet.contains(ext1);
    }

    static public boolean isZipFile(Extension ext) {
        return zipSet.contains(ext);
    }

    public static Set<Extension> zipExt() {
        return zipSet;
    }

    public boolean equals(String ext) {
        return this.ext.equalsIgnoreCase(ext);
    }

    static public Extension type(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        
        typeStr = typeStr.trim();
        typeStr.replaceFirst(".", "");

        Extension ext = OTHER;
        try {
            ext = Enum.valueOf(Extension.class, typeStr.toUpperCase());
        }
        catch (Exception e) {
            /*
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    "File extension " + typeStr.toUpperCase() + " error:\n" + e.getMessage(),
                    "File Extension Not Supported");
            */
            ext = OTHER;
        }

        return ext;
    }
}
