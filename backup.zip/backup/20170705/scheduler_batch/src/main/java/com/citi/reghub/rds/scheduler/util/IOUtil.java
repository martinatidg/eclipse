package com.citi.reghub.rds.scheduler.util;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import static java.nio.file.FileVisitResult.CONTINUE;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;

public class IOUtil {

    public static String CURRENT_DIR;
    public static FileChooser.ExtensionFilter ALL; // = new FileChooser.ExtensionFilter("All Files", "*.*");
    public static FileChooser.ExtensionFilter XML; // = new FileChooser.ExtensionFilter("XMl Files", "*.xml");

    static {
        CURRENT_DIR = Dir.DOCUMENT.dir();
        ALL = new FileChooser.ExtensionFilter("All Files", "*.*");
        XML = new FileChooser.ExtensionFilter("XMl Files", "*.xml");
    }
    

    private IOUtil() {
    }

    public static void saveStringToFile(String strSource, String filename) throws IOException {
        java.io.FileWriter fw = new java.io.FileWriter(filename);
        fw.write(strSource);
        fw.close();
    }

    public static File saveInputStreamToFile(InputStream inputStream, String filename) {
        File file = new File(filename);
        saveInputStreamToFile(inputStream, file);

        return file;
    }

    public static File saveInputStreamToFile(InputStream inputStream, File file) {
        try (OutputStream outputStream = new FileOutputStream(file)) {
            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }

            System.out.println("Done!");

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return file;
    }

    public static String getStringFromFile(String filename) {

        try (InputStream inputStream = new FileInputStream(filename);
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {

            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            System.out.println(sb.toString());
            System.out.println("\nDone!");

            return sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getStringFromInputStream(InputStream is) {
        StringBuilder sb = new StringBuilder("");

        String line;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return sb.toString();

    }

    public static String getFileExtension(Path fullPath) {
        return getFileExtension(fullPath.getFileName().toString());
    }

    public static String getFilenameWithoutExtension(Path fullPath) {
        String pstr = fullPath.getFileName().toString();
        return getFilenameWithoutExtension(pstr);
    }

    public static String getFileExtension(String fullPath) {
        int dot = fullPath.lastIndexOf(".");
        return fullPath.substring(dot + 1);
    }

    public static String getFilenameWithoutExtension(String fullPath) {
        int dot = fullPath.lastIndexOf(".");
        return fullPath.substring(0, dot);
    }

    public static String replaceExtension(String fullPath, String newExt) {
        String newext = getFilenameWithoutExtension(fullPath) + "." + newExt;
        return newext;
    }

//    public static Path browseFile(FileChooser.ExtensionFilter filter, boolean openFile, String title) throws IOException {
//        FileChooser fileChooser = new FileChooser();
//        //currentDir = new java.io.File(".");
//        File currentDir = new File(CURRENT_DIR);
//        fileChooser.setInitialDirectory(currentDir);
//        fileChooser.getExtensionFilters().addAll(filter);
//        fileChooser.setTitle(title);
//
//        File f; // = fileChooser.showOpenDialog(ReaderMain.getStage());
//        if (openFile) {
//            f = fileChooser.showOpenDialog(ReaderMain.getStage());
//        } else {
//            f = fileChooser.showSaveDialog(ReaderMain.getStage());
//        }
//
//        if (f == null) {
//            return null;
//        }
//
//        //String fname = f.getName();
//        Path path = f.toPath();
//
//        currentDir = f.getParentFile();
//        CURRENT_DIR = f.getParent();
//        return path;
//    }

//    public static Path browseDirPath(String title) throws IOException {
//        DirectoryChooser dirChooser = new DirectoryChooser();
//        File currentDir = new File(CURRENT_DIR);
//        dirChooser.setInitialDirectory(currentDir);
//        //fileChooser.getExtensionFilters().addAll(filter);
//        dirChooser.setTitle(title);
//
//        File f = dirChooser.showDialog(ReaderMain.getStage());
//
//        if (f == null) {
//            return null;
//        }
//
//        CURRENT_DIR = f.getParent();
//        Path path = f.toPath();
//
//        return path;
//    }

//    public static File browseDirFile(String title) throws IOException {
//        DirectoryChooser dirChooser = new DirectoryChooser();
//        File currentDir = new File(CURRENT_DIR);
//        dirChooser.setInitialDirectory(currentDir);
//        //fileChooser.getExtensionFilters().addAll(filter);
//        dirChooser.setTitle(title);
//
//        File f = dirChooser.showDialog(ReaderMain.getStage());
//
//        CURRENT_DIR = f.getParent();
//
//        return f;
//    }

    private static int delFileCount = 0;
    private static int delDirCount = 0;

    // Delte a directory and its children, not work
    public static boolean deleteAllInDir(Path dirpath) throws IOException {
        if (!Files.isDirectory(dirpath)) {
            Files.deleteIfExists(dirpath);
            delFileCount++;
            System.out.println("Deleted file count " + delFileCount + ": " + dirpath.toString() + " was deleted. ");
            return true;
        } else if (Files.list(dirpath).count() < 1) {
            Files.deleteIfExists(dirpath);
            delDirCount++;
            System.out.println("Deleted Dir inner count " + delDirCount + ": " + dirpath.toString() + " was deleted. ");
            return true;
        }

        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(dirpath)) {
            for (Path path : directoryStream) {
                deleteAllInDir(path);
            }
            delDirCount++;
            System.out.println("Deleted a dir outer, count " + delDirCount + ": " + dirpath.toString() + " was deleted. ");
            Files.delete(dirpath);
        }

        return true;
    }

    // delete a directory and its sub dirs and files
    public static boolean deleteDir(Path dir) throws IOException {
        //try {
            Files.walkFileTree(dir, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    System.out.println("Deleting file: " + file);
                    Files.delete(file);
                    return CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    System.out.println("Deleting dir: " + dir);
                    if (exc == null) {
                        Files.delete(dir);
                        return CONTINUE;
                    } else {
                        throw exc;
                    }
                }
            });
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        return true;
    }

}
