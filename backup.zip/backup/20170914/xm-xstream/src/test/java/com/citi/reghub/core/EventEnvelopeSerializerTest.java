package com.citi.reghub.core;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.citi.reghub.core.EventEnvelopeSerializer;
import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.xm.integration.TestData;

public class EventEnvelopeSerializerTest {
	private static EventEnvelopeSerializer serializer  = new EventEnvelopeSerializer();
	EventEnvelope evtmsg;
	
	@BeforeClass
	public static void initClass() {
		serializer  = new EventEnvelopeSerializer();
	}

	@Before
	public void initTest() {
		evtmsg = TestData.getEvtMsg();
	}

	@Test
	public void testSerializer() {
		byte[] evtBytes = serializer.serialize(null, evtmsg);

		EventEnvelope result = serializer.deserialize("", evtBytes);
		
		Assert.assertEquals(evtmsg, result);
	}
}
