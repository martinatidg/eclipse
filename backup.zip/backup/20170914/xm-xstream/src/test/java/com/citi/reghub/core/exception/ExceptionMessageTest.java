package com.citi.reghub.core.exception;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class ExceptionMessageTest {
	@Test
	public void testExceptionMessageBuilder() {
		long createdTS = System.currentTimeMillis();
		Note note = new NoteBuilder().source("XM-Xstream").exceptionNote("UI Exception").createdBy("Martin")
				.createdTS(createdTS).build();
		List<Note> notes = new ArrayList<>();
		notes.add(note);

		ExceptionMessage message = new ExceptionMessageBuilder().createdTS(createdTS).description("UI Exception")
				.id("100000001").level("EXCEPTION").reasonCode("running out of memory").functionOwner("BUS")
				.regReportingRef("Stream flow 100001").requestedTS(createdTS).sourceId("s0001").status("OPEN")
				.type("DQ").updatedSource("UI").updatedTS(createdTS).xstreamEligible(true).notes(notes).build();

		Assert.assertEquals("not equal.", createdTS, message.getCreatedTS());
		Assert.assertEquals("not equal.", "UI Exception", message.getDescription());
		Assert.assertEquals("not equal.", "100000001", message.getId());
		Assert.assertEquals("not equal.", "EXCEPTION", message.getLevel());
		Assert.assertEquals("not equal.", "running out of memory", message.getReasonCode());
		Assert.assertEquals("not equal.", "BUS", message.getFunctionOwner());
		Assert.assertEquals("not equal.", "Stream flow 100001", message.getRegReportingRef());
		Assert.assertEquals("not equal.", createdTS, message.getRequestedTS());
		Assert.assertEquals("not equal.", "s0001", message.getSourceId());
		Assert.assertEquals("not equal.", "OPEN", message.getStatus());
		Assert.assertEquals("not equal.", "DQ", message.getType());
		Assert.assertEquals("not equal.", "UI", message.getUpdatedSource());
		Assert.assertEquals("not equal.", createdTS, message.getUpdatedTS());
		Assert.assertTrue("not true.", message.isXstreamEligible());
		Assert.assertEquals("not equal.", notes, message.getNotes());
	}
}
