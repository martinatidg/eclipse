package com.citi.reghub.core.xm.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.exception.EventEnvelopeBuilder;
import com.citi.reghub.core.exception.ExceptionMessage;
import com.citi.reghub.core.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.exception.Note;
import com.citi.reghub.core.exception.NoteBuilder;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound.NotificationMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.Status;

public class TestData {
	private static com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory outfactory = new com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory();
	private static Random random = new Random();
	private static String[] sourceIds_qat =
		{"03550600LDN822356275", "03550600LDN822356352", "03550600LDN822356502", "N14527300NYK2017080115118_E",
		 "03550600LDN822356286", "03550600LDN822356359", "03550600LDN822356290", "03550600LDN822356298",
		 "03550600LDN822356401", "03550600LDN822356417", "03550600LDN822356389", "03550600LDN822356447"};

	private static String[] sourceIds_sit =
		{"19885943", "19884410", "19884412", "19884414",
		 "19884416", "5610337", "5610419", "5610415",
		 "5610387", "5610352", "5610308", "5610309"};
	private static String[] eventNames =
		{"exceptionRequested", "exceptionCreated", "exceptionUpdated", "exceptionClosed"};

	private static String[] fnOwners = {"AMC", "BUS", "TECH", "SMC"};
	private static String[] eventSources = {"reporting stream", "UI", "file sender", "XM-XSTREAM_1"};
	private static String[] types = {"DQ", "AX", "BX"};
	private static String[] levels = {"WARN", "EXCEPTION"};

	public static Note getNote(String source, String noteName, String createdBy) {
		Note note = new NoteBuilder().source(source).exceptionNote(noteName).createdBy(createdBy).createdTS(System.currentTimeMillis()).build();

		return note;
	}

	public static ExceptionMessage getExMsg(String exId) {
		List<Note> notes = new ArrayList<Note>();
		notes.add(getNote(eventSource(), "note1", "Martin"));
		notes.add(getNote(eventSource(), "note2", "Michael"));
		notes.add(getNote(eventSource(), "note3", "Elan"));

		ExceptionMessage exmsg = new ExceptionMessageBuilder().id(exId).sourceId(sourceId()).regReportingRef("").stream("m2tr").flow("cshfx").status("OPEN")
				.reasonCode("SOME_EXCEPTION").ruleVersion("1.0").description("test data").functionOwner(fnOwner())
				.xstreamEligible(true).notes(notes)
				.type(type()).level(level()).requestedTS(System.currentTimeMillis())
				.createdTS(System.currentTimeMillis()).updatedTS(System.currentTimeMillis()).build();

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope evtmsg = new EventEnvelopeBuilder().eventVersion(1).eventSource(eventSource())
				.eventName(eventName()).eventTime(System.currentTimeMillis()).eventData(getExMsg(exId())).build();

		return evtmsg;
	}
	
	private static String fnOwner() {
		int index = random.nextInt(4);
		return fnOwners[index];
	}

	private static String sourceId() {
		int index = random.nextInt(12);
		return sourceIds_sit[index];
	}

	private static String eventName() {
		int index = random.nextInt(4);
		return eventNames[index];
	}

	private static String eventSource() {
		int index = random.nextInt(4);
		return eventSources[index];
	}

	private static String type() {
		int index = random.nextInt(3);
		return types[index];
	}

	private static String level() {
		int index = random.nextInt(2);
		return levels[index];
	}

	private static String exId() {
		int i = random.nextInt(1000000000);
		return String.format("%09d", i);
	}
	
	public static NotificationMsg getNoteMsg(XmFeedMsg xmmsg) {
		NotificationMsg notemsg = outfactory.createNotificationMsg();
		MsgExceptionNote exNote = outfactory.createMsgExceptionNote();
		
		MOMsgEntity msgObj = xmmsg.getMoEntity();
		exNote.setNote("Approved");
		exNote.setLastUpdatedBy(xmmsg.getRequestId());
		exNote.setNoteTimestamp(msgObj.getExecutionDateTime());
		
		notemsg.setExceptionID(msgObj.getExceptionID());
		notemsg.setExceptionRefNumber(msgObj.getSrcSystemRef());
		notemsg.setStatus(Status.CLOSED);
		notemsg.setTypeOfOwner(msgObj.getTraderID());
		notemsg.getNote().add(exNote);
		
		return notemsg;
	}
}
