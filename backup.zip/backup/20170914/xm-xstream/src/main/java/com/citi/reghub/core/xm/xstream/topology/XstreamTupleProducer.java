package com.citi.reghub.core.xm.xstream.topology;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.storm.jms.JmsTupleProducer;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;

import com.citi.reghub.core.RegHubBolt;

public class XstreamTupleProducer implements JmsTupleProducer {
	private static final long serialVersionUID = 1L;

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(RegHubBolt.TUPLE_MESSAGE));
	}

	@Override
	public Values toTuple(Message message) throws JMSException {
		String xml = ((TextMessage)message).getText();

		return new Values(xml);
	}
}
