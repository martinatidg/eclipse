package com.citi.reghub.core.xm.xstream.topology;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;

import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;

public class ToXstreamBolt extends RegHubBolt {
	private static final long serialVersionUID = 1L;
	private transient OutputCollector collector;

	public void execute(Tuple tuple, BasicOutputCollector outputCollector) {
		EmitMsg boltMsg = (EmitMsg) tuple.getValueByField("message");

		XstreamMapper mapper = new XstreamMapper();
		XmFeedMsg regmsg = mapper.toXstream(boltMsg.getException(), boltMsg.getEntity());

		outputCollector.emit(Arrays.asList(regmsg));
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("message"));
	}

	@Override
	public void process(Tuple input) throws Exception {
		EmitMsg boltMsg = (EmitMsg) input.getValueByField(TUPLE_MESSAGE);

		XstreamMapper mapper = new XstreamMapper();
		XmFeedMsg regmsg = mapper.toXstream(boltMsg.getException(), boltMsg.getEntity());

		getCollector().emit(Arrays.asList(regmsg));
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}

	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}
