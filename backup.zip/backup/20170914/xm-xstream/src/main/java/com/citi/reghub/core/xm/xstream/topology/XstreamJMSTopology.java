package com.citi.reghub.core.xm.xstream.topology;

import java.util.Map;

import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.jms.spout.JmsSpout;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EventEnvelopeSerializer;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.kafka.RegHubKafkaBolt;
import com.citi.reghub.core.xm.xstream.Constants;
import com.citi.reghub.core.xm.xstream.Key;

public class XstreamJMSTopology extends BaseTopology {
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseTopology.class);
	private static final String TOPOLOGY_NAME = "XstreamJMSTopology";
	private static final String KAFKA_INPUT_TOPIC_NAMES = "kafka.input.topic.names";

	public static void main(String[] args) throws Exception {
		new XstreamJMSTopology().runTopology(args);
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		topologyConfig.put(GlobalProperties.TOPOLOGY_NAME, TOPOLOGY_NAME);
		LOGGER.info("Start to build topology: {}", topologyConfig.get(GlobalProperties.TOPOLOGY_NAME));

		final TopologyBuilder tp = new TopologyBuilder();

		topologyConfig.put(Key.KAFKA_KEY_SERIALIZER.value(), StringSerializer.class.getName());
		topologyConfig.put(Key.KAFKA_VALUE_SERIALIZER.value(), EventEnvelopeSerializer.class.getName());
		String inputTopicNames = topologyConfig.get(KAFKA_INPUT_TOPIC_NAMES);

		XstreamTupleProducer tupleProducer = new XstreamTupleProducer();
		XstreamJmsProvider provider = new XstreamJmsProvider(topologyConfig, false);

		JmsSpout spout = new JmsSpout();
		spout.setJmsProvider(provider);
		spout.setJmsTupleProducer(tupleProducer);

		tp.setSpout(Constants.JMS_SPOUT.value(), spout, 3);
		tp.setBolt(Constants.FROM_BOLT.value(), new FromXstreamBolt(), 3).shuffleGrouping(Constants.JMS_SPOUT.value());
		tp.setBolt(Constants.KAFKA_BOLT.value(), RegHubKafkaBolt.getKafkaBolt(topologyConfig, inputTopicNames, Constants.FROM_BOLT.value()), 3)
		.shuffleGrouping(Constants.FROM_BOLT.value());

		return tp.createTopology();
	}
}
