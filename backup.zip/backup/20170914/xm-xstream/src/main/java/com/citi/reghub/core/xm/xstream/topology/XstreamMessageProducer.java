package com.citi.reghub.core.xm.xstream.topology;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBException;

import org.apache.storm.jms.JmsMessageProducer;
import org.apache.storm.tuple.ITuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.xm.xstream.schema.XstreamMarshaller;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;

public class XstreamMessageProducer implements JmsMessageProducer {
	private static final Logger LOGGER = LoggerFactory.getLogger(XstreamMessageProducer.class);

	private static final long serialVersionUID = 1L;

	@Override
	public Message toMessage(Session session, ITuple input) throws JMSException {

		XmFeedMsg regmsg = (XmFeedMsg) input.getValueByField("message");

		String xmlMsg;
		try {
			xmlMsg = XstreamMarshaller.marshal(regmsg);
			TextMessage message = session.createTextMessage();
			message.setText(xmlMsg);

			return message;

		} catch (JAXBException e) {
			LOGGER.error("ToXstreamBolt.execute(), failed to marshal the object: {}", e);
			throw new JMSException(e.getMessage());
		}
	}
}
