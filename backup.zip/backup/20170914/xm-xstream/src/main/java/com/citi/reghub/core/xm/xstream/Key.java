package com.citi.reghub.core.xm.xstream;

public enum Key {
	ENTITY_SERVICE_URL("entity.service.url"),
	
	KAFKA_KEY_SERIALIZER("kafka.commons.key.serializer"),
	KAFKA_VALUE_SERIALIZER("kafka.commons.value.serializer"),
	KAFKA_TOPIC("kafka.input.topic.names"),
	
	QUEUE_REQUEST("xstream.jms.queue.request"),
	QUEUE_RESPONSE("xstream.jms.queue.response"),
	PROVIDER_URL("xstream.jms.provider.url"),
	CONNECTION_JNDI("xstream.jms.jndi"),
	;
	private final String value;

    Key(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Key fromValue(String v) {
        for (Key c: Key.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
