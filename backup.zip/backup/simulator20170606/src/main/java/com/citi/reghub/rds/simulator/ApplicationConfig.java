package com.citi.reghub.rds.simulator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.convert.CustomConversions;

import com.citi.reghub.rds.simulator.converter.LocalDateTimeToStringConverter;
import com.citi.reghub.rds.simulator.converter.StringToLocalDateTimeConverter;
import com.citi.reghub.rds.simulator.util.Simulator;
//import com.citi.reghub.db.dao.ProfileRepository;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;

@Configuration
class ApplicationConfig extends AbstractMongoConfiguration {
	@Override
	protected String getDatabaseName() {
		return "simulator";
	}

	@Override
	@Bean //("mongoClient")
	public Mongo mongo() throws Exception {
		return new MongoClient("localhost");
	}

//	@Override
//	public CustomConversions customConversions() {
//		List<Converter> converters = new ArrayList<Converter>();
//		converters.add(new LocalDateTimeToStringConverter());
//		converters.add(new StringToLocalDateTimeConverter());
//		return new CustomConversions(converters);
//	}

	@Bean(name="simulator")
	@DependsOn("dataGenerator")
	public Simulator simulator() {
		return new Simulator();
	}

}