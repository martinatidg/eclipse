package com.citi.reghub.xm.consumer.validator;

import java.util.Map;
import java.util.Optional;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;

public class EntityNullValidator implements Validator<Tuple> {
	protected static final Logger LOG = LoggerFactory.getLogger(TupleNullValidator.class);
	private OutputCollector collector;

	@Override
	public boolean validate(Tuple tuple) {
		return Optional.ofNullable(tuple).map((Tuple t) -> (Entity)t.getValueByField("message")).isPresent();
	}

	@Override
	public void handle(Tuple tuple) {
		collector.ack(tuple);
	}

	@Override
	public void init(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		this.collector = outputCollector;
	}
}
