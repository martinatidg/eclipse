package com.citi.reghub.xm.consumer.validator;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.xm.consumer.topology.entity.InitExceptionBolt;

public class ValidatorManager {
	protected static final Logger LOG = LoggerFactory.getLogger(InitExceptionBolt.class);

	private Map config;
	private TopologyContext topologyContext;
	private OutputCollector outputCollector;

	private List<Validator<Tuple>> validators = new LinkedList<>();

	public ValidatorManager(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		this.config = config;
		this.topologyContext = topologyContext;
		this.outputCollector = outputCollector;
	}

	public void addValidator(Class<? extends Validator<Tuple>> validator) {
		Validator<Tuple> instance;
		try {
			instance = validator.newInstance();
			instance.init(config, topologyContext, outputCollector);
			validators.add(instance);
		} catch (Exception e) {
			LOG.error("Validator '{}' cannot be added:\n{}", validator.getName(), e);
		}
	}

	public boolean validate(Tuple tuple) {
		return initValidator(tuple);
	}

	private boolean initValidator(Tuple tuple) {
		for (Validator<Tuple> validator : validators) {
			if (!validator.validate(tuple)) {
				validator.handle(tuple);
				return false;
			}
		}

		return true;
	}
}
