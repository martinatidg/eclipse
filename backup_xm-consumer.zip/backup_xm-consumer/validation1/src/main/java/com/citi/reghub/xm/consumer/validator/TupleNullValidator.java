package com.citi.reghub.xm.consumer.validator;

import java.util.Map;
import java.util.Optional;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TupleNullValidator implements Validator<Tuple> {
	protected static final Logger LOG = LoggerFactory.getLogger(TupleNullValidator.class);
	private OutputCollector collector;

	@Override
	public boolean validate(Tuple tuple) {
		return Optional.ofNullable(tuple).isPresent();
	}

	@Override
	public void handle(Tuple tuple) {
		collector.ack(tuple);
	}

	@Override
	public void init(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		this.collector = outputCollector;
	}
}
