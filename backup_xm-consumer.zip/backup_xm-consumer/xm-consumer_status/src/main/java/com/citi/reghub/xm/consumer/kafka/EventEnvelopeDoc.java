package com.citi.reghub.xm.consumer.kafka;

import java.io.*;
import java.util.*;

import org.bson.*;

import com.citi.reghub.core.*;
import com.citi.reghub.core.event.*;

public class EventEnvelopeDoc implements ConvertToMongoMap<EventEnvelope>, Serializable {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("rawtypes")
	@Override
	public Map toMap(EventEnvelope eventEnvelope) {
		Document doc = new Document();
		return doc;
	}
	
}