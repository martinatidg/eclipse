package com.citi.reghub.xm.consumer.rulesservice;

import java.time.*;
import java.util.*;

import org.bson.types.*;

import com.fasterxml.jackson.databind.annotation.*;
import com.fasterxml.jackson.datatype.jsr310.deser.*;


public class Rule {

    public static final String VALIDATION_ERROR_MSG = "Validation failed in saving rule. Stream, Flow, Name, Description and Definition are mandatory fields.";

    private ObjectId id;

    private String stream;
    
    private String flow;

    private String name;

    private String description;

    private String definition;
    
    private String resultCode;

    private List<Metadata> metadata;

    private String upstreamSource;   
    private String type;
  	private String conditions;
  	private String regulator;
  	private String regulation;
    private String regRuleReference;
    private String regRuleTraceability;
  	private String version;
  	private String owner;
  	private String level;
  	private String xstream;
  	private String displayName;
  	private String location;
  	private List<String> attributes;
  	
  	private String createdBy;
  	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
  	private LocalDateTime createdDate;
  	public String updatedBy;
  	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
  	public LocalDateTime updatedDate;

	public Rule(String id, String stream, String flow, String name, String description, String definition,String resultCode, List<Metadata> metadata) {
        this.metadata = metadata;
        if (id != null) this.id = new ObjectId(id);
        this.stream = stream;
        this.flow = flow;
        this.name = name;
        this.description = description;
        this.definition = definition;
        this.resultCode = resultCode;
    }
	
	public Rule(String id, String stream, String flow, String name, String description, String definition,
			String resultCode, List<Metadata> metadata, String upstreamSource, String type, String conditions,
			String regulator, String regulation, String regRuleReference, String regRuleTraceability, String version,
			String createdBy, LocalDateTime createdDate, String updatedBy, LocalDateTime updatedDate, String owner,
			String level, String xstream, List<String> attributes, String location, String displayName) {
		super();
		if (id != null) this.id = new ObjectId(id);
		this.stream = stream;
		this.flow = flow;
		this.name = name;
		this.description = description;
		this.definition = definition;
		this.resultCode = resultCode;
		this.metadata = metadata;
		this.upstreamSource = upstreamSource;
		this.type = type;
		this.conditions = conditions;
		this.regulator = regulator;
		this.regulation = regulation;
		this.regRuleReference = regRuleReference;
		this.regRuleTraceability = regRuleTraceability;
		this.version = version;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;
		this.owner = owner;
		this.level = level;
		this.xstream = xstream;
		this.attributes = attributes;	
		this.location = location;
		this.displayName = displayName;
		
	}
    


	public Rule() {
    }

    public ObjectId getId() {
        return id;
    }

    public String getStream() {
        return stream;
    }
    
    public String getFlow() {
        return flow;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getDefinition() {
        return definition;
    }

	public String getResultCode() {
		return resultCode;
	}
    
    public List<Metadata> getMetadata() {
        return metadata != null ? metadata : new ArrayList<>();
    }
    
    public static String getValidationErrorMsg() {
		return VALIDATION_ERROR_MSG;
	}

	public String getUpstreamSource() {
		return upstreamSource;
	}

	public String getType() {
		return type;
	}

	public String getConditions() {
		return conditions;
	}

	public String getRegulator() {
		return regulator;
	}

	public String getRegulation() {
		return regulation;
	}

	public String getRegRuleReference() {
		return regRuleReference;
	}

	public String getRegRuleTraceability() {
		return regRuleTraceability;
	}

	public String getVersion() {
		return version;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public String getOwner() {
		return owner;
	}

	public String getLevel() {
		return level;
	}

	public String getXstream() {
		return xstream;
	}

	public List<String> getAttributes() {
		return attributes != null ? attributes : new ArrayList<>();
	}

	public String getDisplayName() {
		return displayName;
	}

	public String getLocation() {
		return location;
	}
}
