/**
 * 
 */
package com.citi.reghub.xm.consumer.rulesservice;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

/**
 * @author dk77005
 *
 */
public class RulesServiceClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(RulesServiceClient.class);

	private String ruleServiceUrl = null;
	private RestClient restClient = null;
	private LoadingCache<String, Rule> cache;

	public RulesServiceClient() {
	}

	public RulesServiceClient(String ruleServiceUrl) {
		this(ruleServiceUrl, false);
	}
	

	public RulesServiceClient(String ruleServiceUrl, boolean cacheEnable) {
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		restClient = new RestClient(builder.build());
		this.ruleServiceUrl = ruleServiceUrl;

		cache = CacheBuilder.newBuilder().expireAfterWrite(15l, TimeUnit.MINUTES).maximumSize(100)
				.build(new CacheLoader<String, Rule>() {
					@Override
					public Rule load(String key) throws Exception {
						LOGGER.info("RulesService calling repository");
						System.err.println("loading cache for "+key);
						String[] keys = key.split(" ");

						if (null != keys && keys.length > 1) {
							return getRuleForCache(keys[0], keys[1]);
						}
						return null;
					}
				});
	}

	// @GetMapping("/rules/{stream}/{resultCode}")
	private Rule getRuleForCache(String stream, String resultCode) {
		return restClient.get(ruleServiceUrl + "/rules/" + stream + "/" + resultCode, Rule.class);
	}

	// @GetMapping("/rules/{stream}/{resultCode}")
	public Rule getRule(String stream, String resultCode) {
		try {
			return cache.get(stream + " " + resultCode);
		} catch (ExecutionException e) {
			LOGGER.error("Error fetching data from rule cache: {}", e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	
	public List getAllRules(){
		return restClient.get(ruleServiceUrl + "/rules/" , List.class);
	}
}