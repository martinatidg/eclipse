package com.citi.reghub.xm.consumer.topology;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;


public abstract class XmBolt extends RegHubBolt {
	
	protected static final String DEFAULT_EXCEPTION_SOURCE ="RegHub";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(XmBolt.class);
	private static final long serialVersionUID = 1L;
	private transient OutputCollector collector;
	private transient XmUtils xmUtils;
	
	@SuppressWarnings({ "rawtypes" })
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector outputCollector) {
		LOGGER.info("XmBolt prepareBolt = {}", stormConf);
		this.collector = outputCollector;
		xmUtils = new XmUtils();
		xmUtils.init(stormConf);
		
	}

	@Override
	public void process(Tuple input) throws Exception {
		//the process method should be implemented by the sub classes
		
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
		
	}

	

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
		
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.EXCEPTIONS);
		return exceptionTags;
	}
	
	public void setXmUtils(XmUtils xmUtils) {
		this.xmUtils = xmUtils;
	}

	public XmUtils getXmUtils() {
		return xmUtils;
	}
	
	@Override
	public void cleanup() {
		xmUtils.getMongoClient().close();
		super.cleanup();
	}

}
