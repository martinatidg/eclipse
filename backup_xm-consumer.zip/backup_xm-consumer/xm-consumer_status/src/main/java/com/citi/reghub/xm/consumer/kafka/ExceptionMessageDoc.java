package com.citi.reghub.xm.consumer.kafka;

import java.io.*;
import java.util.*;

import org.bson.*;

import com.citi.reghub.core.*;
import com.citi.reghub.core.event.exception.*;

public class ExceptionMessageDoc implements ConvertToMongoMap<ExceptionMessage>, Serializable {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("rawtypes")
	@Override
	public Map toMap(ExceptionMessage exceptionMessage) {
		Document doc = new Document()
				.append("_id", exceptionMessage.getId())
				.append("sourceId", exceptionMessage.getSourceId())
				.append("regHubId", exceptionMessage.getRegHubId())
				.append("regReportingRef", exceptionMessage.getRegReportingRef())
				.append("stream", exceptionMessage.getStream())
				.append("flow", exceptionMessage.getFlow())
				.append("reasonCode", exceptionMessage.getReasonCode())
				.append("ruleVersion", exceptionMessage.getRuleVersion())
				.append("description", exceptionMessage.getDescription())
				.append("xstreamEligible", exceptionMessage.isXstreamEligible())
				.append("attributes", exceptionMessage.getAttributes())
				.append("requestedTS", exceptionMessage.getRequestedTS())
				.append("createdTS", exceptionMessage.getCreatedTS())
				.append("updatedTS", exceptionMessage.getUpdatedTS())
				.append("updatedSource", exceptionMessage.getUpdatedSource());
		
		doc.values().removeIf(Objects::isNull);
		if(null!=exceptionMessage.getStatus()) {
			doc.append("status", exceptionMessage.getStatus().toString());
		}
		
		if(null!=exceptionMessage.getFunctionalOwner()) {
			doc.append("functionalOwner", exceptionMessage.getFunctionalOwner().toString());
		}
		
		if(null!=exceptionMessage.getType()) {
			doc.append("type", exceptionMessage.getType().toString());
		}
		
		if(null!=exceptionMessage.getLevel()) {
			doc.append("level", exceptionMessage.getLevel().toString());
		}
		
		
		if(null!=exceptionMessage.getNotes() && !exceptionMessage.getNotes().isEmpty()) {
			doc.append("notes", createNotesListMap(exceptionMessage.getNotes()));
		}
		return doc;
	}

	private List<Map<String, String>> createNotesListMap(List<Note> notes) {
		List<Map<String, String>> noteslistMap = new ArrayList<Map<String,String>>();
		for (Note note : notes) {
			Map<String, String> noteMap = new LinkedHashMap<>();

			noteMap.put("source", note.getSource().name());
			noteMap.put("exceptionNote", note.getNote());
			noteMap.put("createdTS", String.valueOf(note.getCreatedTS()));
			noteMap.put("createdBy", note.getCreatedBy());
			noteslistMap.add(noteMap);
		}
		return noteslistMap;
	}	
}