package com.citi.reghub.xm.consumer.topology.entity;


import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.*;

import com.citi.reghub.core.constants.*;
import com.citi.reghub.core.event.*;
import com.citi.reghub.core.event.exception.*;

import com.citi.reghub.xm.consumer.topology.XmBolt;


public class CloseExceptionBolt extends XmBolt {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(CloseExceptionBolt.class);
	private static final long serialVersionUID = 1L;
	

	@Override
	public void process(Tuple input) throws Exception {
		EntityExceptionWrapper entityAndExceptionMessage = (EntityExceptionWrapper) input.getValueByField("message");
		
		ExceptionMessage inputExceptionMessage = entityAndExceptionMessage.getExceptionMessage();
		if(null!=inputExceptionMessage.getId() && inputExceptionMessage.getStatus().equals(ExceptionStatus.CLOSED)) {
			// Update the record in DB to close.
			
			getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(inputExceptionMessage), false);
			// Publish an event for this exception close.
			EventEnvelope envelope = new EventEnvelope(); 
			envelope.setEventVersion(EventVersion.V_1);
			envelope.setEventSource(EventSource.XM_CONSUMER);
			envelope.setEventType(EventType.EXCEPTION);
			envelope.setEventName(EventName.EXCEPTION_CLOSED);
			envelope.setEventTime(System.currentTimeMillis());
			envelope.setEventData(inputExceptionMessage);
			getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(inputExceptionMessage.getId() , envelope));
			LOGGER.info("Publishing Envelop : {}" , envelope);
		}		
		getCollector().ack(input);
	}
	
	
}