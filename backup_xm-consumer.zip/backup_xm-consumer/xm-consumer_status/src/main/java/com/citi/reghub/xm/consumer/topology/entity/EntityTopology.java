package com.citi.reghub.xm.consumer.topology.entity;

import java.util.*;

import org.apache.kafka.common.serialization.*;
import org.apache.storm.Config;
import org.apache.storm.generated.*;
import org.apache.storm.topology.*;
import org.slf4j.*;

import com.citi.reghub.core.*;
import com.citi.reghub.core.constants.*;
import com.citi.reghub.core.kafka.*;
import com.citi.reghub.xm.consumer.topology.entity.CloseExceptionBolt;
import com.citi.reghub.xm.consumer.topology.entity.InitExceptionBolt;
import com.citi.reghub.xm.consumer.topology.entity.NewUpdateExceptionBolt;

public class EntityTopology extends BaseTopology {
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseTopology.class);
	
	public static final String KAFKA_INPUT_TOPIC_NAMES = "kafka.input.topic.names";
	private static final String EXCEPTION_EVENT_OUTBOUND_TOPIC_NAMES = "event_emit_bolt.kafka.topic.names";
	
	private static final String TOPOLOGY_NAME = "xm_entity_topology";
	
	private static final String ENTITY_SPOUT = "entity_spout";
	private static final String INIT_EXCEPTION_BOLT = "init_exception_bolt";
	private static final String CLOSE_EXCEPTION_BOLT = "close_exception_bolt";
	private static final String NEW_UPDATE_EXCEPTION_BOLT = "new_update_exception_bolt";
	private static final String EVENT_EMIT_BOLT = "event_emit_bolt";
	
	public static void main(String[] args) throws Exception {
		new EntityTopology().runTopology(args);
	}
	
	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		topologyConfig.put(GlobalProperties.TOPOLOGY_NAME, TOPOLOGY_NAME);
		LOGGER.info("Start to build topology: {}", topologyConfig.get(GlobalProperties.TOPOLOGY_NAME));		
		
		topologyConfig.put("kafka.commons.key.serializer", StringSerializer.class.getName());
		topologyConfig.put("kafka.commons.value.serializer", EventEnvelopeSerializer.class.getName());
		
		
		String exceptionInputTopicName = topologyConfig.get(KAFKA_INPUT_TOPIC_NAMES);
		String exceptionOutBoundTopicName = topologyConfig.get(EXCEPTION_EVENT_OUTBOUND_TOPIC_NAMES);
		
		//spout
		RegHubKafkaSpout<String, Entity> regHubExceptionKafkaSpout = RegHubKafkaSpout.builder(exceptionInputTopicName, StormStreams.INBOUND_KAFKA_STREAM_NAME, topologyConfig)
				.setKeyDesClazz(StringDeserializer.class)
				.setValueDesClazz(EntityKafkaSerializerDeserializer.class)
				.build();
				
		final TopologyBuilder tb = new TopologyBuilder();
		tb.setSpout(ENTITY_SPOUT, regHubExceptionKafkaSpout.getSpout(), 3);
		tb.setBolt(INIT_EXCEPTION_BOLT, new InitExceptionBolt(),30)
			.shuffleGrouping(ENTITY_SPOUT, StormStreams.INBOUND_KAFKA_STREAM_NAME);
		tb.setBolt(CLOSE_EXCEPTION_BOLT, new CloseExceptionBolt(), 6)
			.shuffleGrouping(INIT_EXCEPTION_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM);
		tb.setBolt(NEW_UPDATE_EXCEPTION_BOLT, new NewUpdateExceptionBolt(), 12)
			.shuffleGrouping(INIT_EXCEPTION_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM);
		tb.setBolt(EVENT_EMIT_BOLT , RegHubKafkaBolt.getKafkaBolt(topologyConfig, exceptionOutBoundTopicName, EVENT_EMIT_BOLT ), 6)
			.shuffleGrouping(CLOSE_EXCEPTION_BOLT , StormStreams.XM_EXCEPTION_MESSAGE_STREAM)
			.shuffleGrouping(NEW_UPDATE_EXCEPTION_BOLT , StormStreams.XM_EXCEPTION_MESSAGE_STREAM);
	
		return tb.createTopology();
	}
	
	
	@Override
	protected Config getTopologyConfig() {
		Config conf = new Config();
		conf.setDebug(false);
		conf.setNumWorkers(3);
    	conf.put(Config.TOPOLOGY_BACKPRESSURE_ENABLE,            true);
      	conf.put(Config.TOPOLOGY_EXECUTOR_RECEIVE_BUFFER_SIZE, 1024);
    	conf.put(Config.TOPOLOGY_EXECUTOR_SEND_BUFFER_SIZE,    1024);
    	conf.put(Config.BACKPRESSURE_DISRUPTOR_HIGH_WATERMARK,    0.8);
    	conf.put(Config.BACKPRESSURE_DISRUPTOR_LOW_WATERMARK,    0.5);
      	conf.setMessageTimeoutSecs(60);
      	conf.setMaxSpoutPending(5000);
    	return conf;
	}
}