package com.citi.reghub.xm.consumer.topology.event;


import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.xm.consumer.topology.XmBolt;


public class StatusUpdateBolt extends XmBolt {

	protected static final Logger LOGGER = LoggerFactory.getLogger(StatusUpdateBolt.class);
	private static final long serialVersionUID = 1L;
	

	
	private boolean valid(Object object, String msg) {
		if (object == null) {
			LOGGER.error(msg);
			return false;
		}

		return true;
	}

	private boolean validate(EventEnvelope envelope) {
		// Assuming that entire envelope is validated and event data is not null

		ExceptionMessage exMsg = (ExceptionMessage) envelope.getEventData();
		boolean v = true;
		v = valid(exMsg.getStatus(), "Status cannot be null");
		v = v && valid(exMsg.getId(), "Exception id cannot be null");

		return v;
	}

	@Override
	public void process(Tuple input) throws Exception {
		EventEnvelope envelope = (EventEnvelope) input.getValueByField("message");

		if (!validate(envelope)) {
			getCollector().ack(input);
			return;
		}

		if (!EventSource.XM_CONSUMER.equals(envelope.getEventSource())
				&& EventName.EXCEPTION_STATUS_UPDATED == envelope.getEventName()) {
			ExceptionMessage exMsg = (ExceptionMessage) envelope.getEventData();

			// validate we can update the status
			if (ExceptionStatus.CLOSED == exMsg.getStatus()) {
				LOGGER.warn("StatusUpdate event cannot set exception status to CLOSED");
				getCollector().ack(input);
				return;
			}

			ExceptionMessage existingException = getXmUtils().getExistingExceptionMessagesById(exMsg.getId());
			if (existingException == null || existingException.getStatus() == ExceptionStatus.CLOSED) {
				LOGGER.warn("Exception with id {} either do not exist or was already closed.", exMsg.getId());
			} else {

				/// update the status

				existingException.setUpdatedTS(System.currentTimeMillis());
				existingException.setId(exMsg.getId());
				existingException.setStatus(exMsg.getStatus());
				existingException.setUpdatedSource(envelope.getEventSource().toString());

				// save to collection
				getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(existingException), false);

				// emit update event
				getXmUtils().emitExceptionEvent(getCollector(), existingException);
			}
		}

		getCollector().ack(input);
	}

	
}
