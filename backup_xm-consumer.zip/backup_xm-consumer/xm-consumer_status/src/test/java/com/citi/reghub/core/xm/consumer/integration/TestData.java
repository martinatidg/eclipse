package com.citi.reghub.core.xm.consumer.integration;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;

public class TestData {
	public static ExceptionMessage getExMsg() {
		Note note = new com.citi.reghub.core.event.exception.Note();
		note.setNote("Note");
		note.setCreatedBy("XM_XSTREAM");
		note.setSource(NoteSource.XSTREAM);
		note.setCreatedTS(System.currentTimeMillis());

		ExceptionMessage exmsg = new ExceptionMessageBuilder().newException()
				.withId("53abe19b-cbdf-43d0-9c2e-92395c181b54").addNote(note)
				.build();

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope envelope = new EventEnvelope();
		envelope.setEventName(EventName.EXCEPTION_NOTE_ADDED);
		envelope.setEventSource(EventSource.CORE_CHANGE_REQUEST);
		envelope.setEventType(EventType.EXCEPTION);
		envelope.setEventVersion(EventVersion.V_1);
		envelope.setEventData(getExMsg());

		return envelope;
	}
}
