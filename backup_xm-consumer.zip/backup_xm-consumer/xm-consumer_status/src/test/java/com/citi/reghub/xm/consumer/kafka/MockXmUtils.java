package com.citi.reghub.xm.consumer.kafka;

import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.bson.Document;

import com.citi.reghub.core.ConvertToMongoMap;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.ExceptionType;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;
import com.citi.reghub.xm.consumer.topology.XmUtils;

class MockXmUtils extends XmUtils {
	@Override
	public void init(Map config){
		
	}
	@Override
	public ExceptionMessage getExistingExceptionMessagesById(String id) {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(1506633315171L);
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId(id).withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		if(id.equalsIgnoreCase("nullNotes")){
			em.setNotes(null);
		}
		
		return em;
	}
	@Override
	public void saveToExceptionCollection(Document document, boolean isUpsert) {
		
	}
	@Override
	public void emitExceptionEvent(OutputCollector collector, ExceptionMessage em) {
		
	}
	@Override
	public ConvertToMongoMap<ExceptionMessage> getToMongoMap() {
		return new ExceptionMessageDoc();
	}
}