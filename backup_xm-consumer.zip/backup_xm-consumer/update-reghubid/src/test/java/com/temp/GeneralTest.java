package com.temp;

import org.junit.Test;

import com.citi.reghub.core.constants.EntityStatus;

public class GeneralTest {

	@Test
	public void testEnum() {
		
		System.out.println("enum test null: " + EntityStatus.BIZ_EXCEPTION == null);
	}

}
