# XM-Consumer Topology

## Prerequisites

## Running topology on remote
Environment variables:

$decryptKey: decryptKey
$env: dev/qa/prod

	$ storm jar xm-consumer.jar Toplogy.class consumer $env
