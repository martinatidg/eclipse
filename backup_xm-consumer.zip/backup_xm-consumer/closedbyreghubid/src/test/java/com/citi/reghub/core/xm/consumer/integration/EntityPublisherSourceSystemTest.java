/**
 * 
 */
package com.citi.reghub.core.xm.consumer.integration;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;

/**
 * @author rb96909
 *
 */
public class EntityPublisherSourceSystemTest {

	/**
	 * @param args
	 */
	@Test
	public void updateEntitySourceSystem(){
		Producer<String, Entity> producer = null;
		String topicName = null;
		Properties props = new Properties();
		props.put("bootstrap.servers", "sd-dec5-c167.nam.nsroot.net:9092,sd-9caf-fdef.nam.nsroot.net:9092,sd-fdc5-8620.nam.nsroot.net:9092");
		props.put("acks", "all");
		props.put("group.id", "xm_consumer_group");
		props.put("retries", 0);
		props.put("batch.size", 16384);
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		producer = new KafkaProducer<String, Entity>(props);
		topicName = "common_entity_exception";
		
		Entity t = new EntityBuilder()
                .regHubId("test_reghub_id_" + System.currentTimeMillis())
                .status(EntityStatus.BIZ_EXCEPTION).setRdsEligible(true)
                .stream("m2tr")
                .sourceSystem("322")
                .info("tradeDate", LocalDate.of(2017, 06, 01))
                .build();
		List<String> reasonCodes = new ArrayList<String>();
		reasonCodes.add("m2p0st_all_domain_refdata_amc_lookup_counterparty_failed");
		reasonCodes.add("m2p0st_all_domain_refdata_amc_lookup_party_failed");
		reasonCodes.add("m2p0st_all_domain_refdata_smc_lookup_failed");
		reasonCodes.add("m2p0st_all_sender_bats_nack");
		reasonCodes.add("m2p0st_all_sender_tradeecho_nack");
		reasonCodes.add("m2p0st_all_sequence_service_entity_unavailable");
		reasonCodes.add("m2post_comderv_c6_energy_derivaties_non_reportable_rule");
		reasonCodes.add("m2p0st_comderv_emission_allowance_type_value_check_and_map_rule");
		reasonCodes.add("m2post_comderv_jurisdiction_remit_non_reportable");
		reasonCodes.add("m2post_all_allocated_trade_processing_non_reportable");
		reasonCodes.add("m2post_all_allocation_status_exclude");
		reasonCodes.add("m2p0st_all_amc_enrichment_cpty_rule");
		reasonCodes.add("m2p0st_all_amc_enrichment_firm_rule");
		reasonCodes.add("m2post_all_block_trade_allocation_non_reportable");
		reasonCodes.add("m2post_all_book_swing_non_reportable");
		reasonCodes.add("m2post_all_citi_legal_entity_check");
		reasonCodes.add("m2p0st_all_citi_mic_code_check");
		reasonCodes.add("m2p0st_all_cp_non_reportable");
		reasonCodes.add("m2p0st_all_instr_ident_type_code_value_check_and_map_rule");
		reasonCodes.add("m2post_all_isin_format_validation_rule");
		reasonCodes.add("m2post_all_notational_amount_format_check_rule");
		reasonCodes.add("m2p0st_all_notational_currency_format_check_rule");
		reasonCodes.add("m2post_all_notation_of_qty_value_check_rule");
		reasonCodes.add("m2post_all_operational_events_risk_event_rule");
		reasonCodes.add("m2post_all_operational_event_rule");
		reasonCodes.add("m2post_all_OTC_post-trade_indicator_check_rule");
		reasonCodes.add("m2post_all_portfolio_compression_new_non_reportable");
		reasonCodes.add("m2post_all_portfolio_compression_terminated_non_reportable");
		reasonCodes.add("m2post_all_pre_mifid_rule");
		reasonCodes.add("m2p0st_all_price_currency_format_check_rule");
		reasonCodes.add("m2post_all_price_notation_value_check_rule");
		reasonCodes.add("m2p0st_all_price_validation_rule");
		reasonCodes.add("m2post_all_qty_in_msrmnt_unit_format_check_rule");
		reasonCodes.add("m2post_all_reporting_obligation_assisted_reporting");
		reasonCodes.add("m2p0st_all_smc_enrichment_rule");
		reasonCodes.add("m2p0st_all_tlc_event_clearing_non_reporting");
		reasonCodes.add("m2p0st_all_tlc_event_clearing_off_venue_non_reporting");
		reasonCodes.add("m2p0st_all_tlc_event_clearing_on_venue_non_reporting");
		reasonCodes.add("m2p0st_all_tlc_event_trade_settled_non_reporting");
		reasonCodes.add("m2p0st_all_tlc_event_trade_unsettled_non_reporting");
		reasonCodes.add("m2post_all_totv_check");
		reasonCodes.add("m2p0st_all_traded_qty_format_check_rule");
		reasonCodes.add("m2p0st_all_tradeecho_nack_invalid_party_information");
		reasonCodes.add("m2p0st_all_tradeecho_nack_invalid_trade_type");
		reasonCodes.add("m2p0st_all_tradeecho_nack_reject_code_unknown");
		reasonCodes.add("m2p0st_all_tradeecho_nack_unauthorized_to_report_trades");
		reasonCodes.add("m2p0st_all_tradeecho_nack_unknown_instrument");
		reasonCodes.add("m2post_all_trade_state_check_non_reportable");
		reasonCodes.add("m2post_all_trading_date_time_check_rule");
		reasonCodes.add("m2post_all_trading_venue_transaction_identification_code_check_rule");
		reasonCodes.add("m2post_all_transaction_to_be_cleared_check_rule");
		reasonCodes.add("m2p0st_all_venue_of_execution_format_check_rule");
		reasonCodes.add("rejection_tradeecho_contra_firm_unknown");
		reasonCodes.add("rejection_tradeecho_contra_user_default_unknown");
		reasonCodes.add("rejection_tradeecho_contra_user_not_from_contra_firm");
		reasonCodes.add("rejection_tradeecho_contra_user_owner_unknown");
		reasonCodes.add("rejection_tradeecho_executing_firm_not_registered");
		reasonCodes.add("rejection_tradeecho_executing_firm_owner_not_registered");
		reasonCodes.add("rejection_tradeecho_executing_firm_side_invalid");
		reasonCodes.add("rejection_tradeecho_executing_firm_unknown");
		reasonCodes.add("rejection_tradeecho_executing_user_not_from_contra_firm");
		reasonCodes.add("rejection_tradeecho_executing_user_unknown");
		reasonCodes.add("rejection_tradeecho_invalid_price");
		reasonCodes.add("rejection_tradeecho_invalid_size");
		reasonCodes.add("rejection_tradeecho_off_book_prohibited");
		reasonCodes.add("rejection_tradeecho_other");
		reasonCodes.add("rejection_tradeecho_package_component_trade_number_different");
		reasonCodes.add("rejection_tradeecho_package_component_trade_number_greater");
		reasonCodes.add("rejection_tradeecho_reject_code_unknown");
		reasonCodes.add("rejection_tradeecho_tradeid_unknown");
		reasonCodes.add("rejection_tradeecho_trade_already_cancelled");
		reasonCodes.add("rejection_tradeecho_trade_time_invalid");
		reasonCodes.add("m2p0st_csheq_acc0unt_exempted_ip0_b00k_rule");
		reasonCodes.add("m2p0st_csheq_bargain_c0nditi0n_exempt_rule");
		reasonCodes.add("m2p0st_csheq_c0mm_mifid_rule");
		reasonCodes.add("m2p0st_csheq_cr0ss_le_b00k_t0_b00k_rule");
		reasonCodes.add("m2p0st_csheq_currency_format_check_rule");
		reasonCodes.add("m2p0st_csheq_exempt_fr0m_trade_rep0rting_rule");
		reasonCodes.add("m2p0st_csheq_firm_account_mifid_regulated_rule");
		reasonCodes.add("m2p0st_csheq_lastprice_format_check_rule");
		reasonCodes.add("m2p0st_csheq_lastqty_format_check_rule");
		reasonCodes.add("m2p0st_csheq_market_destinati0n_rule");
		reasonCodes.add("m2p0st_csheq_mifid_st0ck_rule");
		reasonCodes.add("m2p0st_csheq_pre_mifid_rule");
		reasonCodes.add("m2p0st_csheq_settlcurrency_format_check_rule");
		reasonCodes.add("m2p0st_csheq_settldate_time_check_rule");
		reasonCodes.add("m2p0st_csheq_single_bargain_c0nditi0n_nr_rule");
		reasonCodes.add("m2p0st_csheq_tradedate_time_check_rule");
		reasonCodes.add("m2p0st_cshfx_spot_instrument_exclude");
		reasonCodes.add("m2p0st_eqderv_reporting_purpose_rule");
		t.reasonCodes = reasonCodes;
		//t.sourceId = "test-" + System.currentTimeMillis();
		t.sourceId = "test-all-rules";
		
		producer.send(new ProducerRecord<String, Entity>(topicName, t.regHubId, t));
		producer.close();
	}
}