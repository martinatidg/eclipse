/**
 * 
 */
package com.citi.reghub.core.xm.consumer.integration;

import java.util.*;

import org.apache.kafka.clients.producer.*;

import com.citi.reghub.core.event.*;
import com.citi.reghub.core.event.exception.*;

/**
 * @author dk77005
 *
 */
public class ExceptionEventPublisher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Producer<String, EventEnvelope> producer = null;
		String topicName = null;
		Properties props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("acks", "all");
		props.put("group.id", "xm_consumer_group");
		props.put("retries", 0);
		props.put("batch.size", 16384);
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "com.citi.reghub.core.EventEnvelopeSerializer");
		producer = new KafkaProducer<String, EventEnvelope>(props);
		topicName = "common_event_exception";
		
		/*Entity t = new EntityBuilder()
                .regHubId("test_reghub_id_" + System.currentTimeMillis() )
                .status(EntityStatus.BIZ_EXCEPTION).setRdsEligible(true)
                .info("tradeDate", LocalDate.of(2017, 06, 01))
                .build();
		List<String> reasonCodes = new ArrayList<String>();
		reasonCodes.add("REASON1");
		reasonCodes.add("REASON2");
		reasonCodes.add("REASON3");
		reasonCodes.add("REASON4");
		t.reasonCodes = reasonCodes;*/
		
		ExceptionMessage exceptionMessage = new ExceptionMessage();
		Long currentTime = System.currentTimeMillis();
		//exceptionMessage.setId("4839539621");
		exceptionMessage.setSourceId("483953962");
		
		exceptionMessage.setReasonCode("updatedCode1");
		exceptionMessage.setRequestedTS(currentTime);
		exceptionMessage.setCreatedTS(currentTime) ;
		exceptionMessage.setUpdatedTS(currentTime);
		exceptionMessage.setUpdatedSource("XM-CONSUMER");
		
		EventEnvelope t = new EventEnvelope();
		t.setEventVersion(EventVersion.valueOf("3"));
		t.setEventSource(EventSource.valueOf("UI"));
		t.setEventName(EventName.EXCEPTION_REQUESTED);
		t.setEventTime(System.currentTimeMillis());
		t.setEventData(exceptionMessage);
		
		
		producer.send(new ProducerRecord<String, EventEnvelope>(topicName, exceptionMessage.getId(), t));
		producer.close();
	}
}