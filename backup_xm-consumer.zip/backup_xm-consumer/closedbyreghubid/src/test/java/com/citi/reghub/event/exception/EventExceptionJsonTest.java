package com.citi.reghub.event.exception;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import org.junit.Test;

import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;

public class EventExceptionJsonTest   {

		@Test
		public void convertEventExceptionAsJson() {
			
			ExceptionMessageBuilder exceptionBuilder = new ExceptionMessageBuilder();

			Note note = new com.citi.reghub.core.event.exception.Note();
			note.setNote("Note");
			note.setCreatedBy("XM_XSTREAM");
			note.setSource(NoteSource.XSTREAM);
			note.setCreatedTS(System.currentTimeMillis());
			
			ExceptionMessage exception = exceptionBuilder.newException()
					.withId("9a5ffe11-3747-4b0c-ab22-f00c237c98dc")
					.withSourceId("484523181")
					.withRegHubId("m2trcsheq502435472")
					.withRegReportingRef("CSHEQPRIMO20170927484523181")
					.withStream("m2tr")
					.withFlow("csheq")
					.withReasonCode("m2tr_all_trading_capacity_exception")
					.withRuleVersion("")
					.withDescription("The Trading capacity  must not be NULL or blank")
					.isXstreamEligible(true)
					.addNote(note)
					.addAttribute("mifidTradingCapacity", "XKZZ2JZF41MRHTR1V493")
					.addAttribute("execLei", null)
					.withStatus(ExceptionStatus.OPEN)
					.withOwner(FunctionalOwner.BUS)
					.withType(null)
					.withLevel(ExceptionLevel.EXCEPTION)
					.withUpdatedSource(EventSource.XM_CONSUMER.value())
					.build();

			
			EventBuilder eventBuilder = new EventBuilder();
			EventEnvelope event = eventBuilder.newEvent().ofTypeException().withEventName(EventName.EXCEPTION_CREATED)
					.withEventSource(EventSource.STREAM_M2TR).withEventData(exception).build();
			
		JsonGenerator gen = null;
		try {
			//gen = new JsonFactory().createGenerator(new FileOutputStream(jsonPath + fileName+"_"+i+".json"));
			gen = new JsonFactory().createGenerator(new FileOutputStream("c:/tmp/exception_sample_1023.json"));
			gen.setPrettyPrinter(new DefaultPrettyPrinter());

			gen.writeStartObject();

			gen.writeStringField("eventType", event.getEventType() != null ? event.getEventType().name():null);
			gen.writeStringField("eventName", event.getEventName() != null ?event.getEventName().name():null);
			gen.writeNumberField("eventVersion", event.getEventVersion() != null ?event.getEventVersion().value():null);
			gen.writeStringField("eventSource", event.getEventSource() != null ?event.getEventSource().name():null);
			gen.writeNumberField("eventTime", event.getEventTime());

			ExceptionMessage msg = (ExceptionMessage) event.getEventData();
			gen.writeObjectFieldStart("eventData");
			gen.writeStringField("id",  event.getEventType()!= null ? event.getEventType().value():null);
			gen.writeStringField("sourceId", msg.getSourceId());
			gen.writeStringField("regReportingRef", msg.getRegReportingRef());
			gen.writeStringField("stream", msg.getStream());
			gen.writeStringField("flow", msg.getFlow());
			gen.writeStringField("status", msg.getStatus() != null ? msg.getStatus().name():null);

			gen.writeStringField("reasonCode", msg.getReasonCode());
			gen.writeStringField("ruleVersion", msg.getRuleVersion());
			gen.writeStringField("description", msg.getDescription());
			gen.writeStringField("functionalOwner", msg.getFunctionalOwner() != null ? msg.getFunctionalOwner().name():null);
			gen.writeBooleanField("xstreamEligible", msg.isXstreamEligible());

			gen.writeObjectFieldStart("notes"); // start data sources aray
			for (Note note1 : msg.getNotes()) {
				//gen.writeStartObject();
				gen.writeStringField("source", note1.getSource() != null ? note1.getSource().name(): null);
				gen.writeStringField("exceptionNote", note1.getNote());
				gen.writeNumberField("createdTS", note1.getCreatedTS());
				gen.writeStringField("createdBy", note1.getCreatedBy());
				//gen.writeEndObject();
			}
			gen.writeEndObject();

			gen.writeStringField("type", msg.getType() !=null ? msg.getType().name():null);
			gen.writeStringField("level", msg.getLevel().value() !=null ? msg.getLevel().name(): null);
			gen.writeObjectFieldStart("attributes"); // start data sources aray
			for (Map.Entry<String, Object> entry : msg.getAttributes().entrySet()) {
				gen.writeObjectField(entry.getKey(), entry.getValue());
			}
			gen.writeEndObject();
			gen.writeNumberField("requestedTS", msg.getRequestedTS());
			gen.writeNumberField("createdTS", msg.getCreatedTS());
			gen.writeNumberField("updatedTS", msg.getUpdatedTS());
			gen.writeStringField("updatedSource", msg.getUpdatedSource());

			gen.writeEndObject();
			gen.writeEndObject();

			gen.flush();
			gen.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
