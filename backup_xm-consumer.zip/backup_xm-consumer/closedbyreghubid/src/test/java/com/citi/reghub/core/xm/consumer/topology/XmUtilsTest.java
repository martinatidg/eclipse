package com.citi.reghub.core.xm.consumer.topology;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.xm.consumer.topology.XmUtils;

public class XmUtilsTest{
	static Map config;
	static XmUtils xmUtils;

	
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
		xmUtils = new  XmUtils();
	}
	
	
	@Test
	public void testIsValidStreamWithEnabledStreams() {
		config = new HashMap();
		Map<String, String> topologyConfig = new HashMap<>();
		topologyConfig.put(GlobalProperties.MONGO_URL, "mongodb://local/ex");
		topologyConfig.put(XmUtils.ENTITY_COLLECTION_NAME, "exceptions");
		topologyConfig.put(XmUtils.XM_ENABLED_STREAMS, "m2post,m2tr");
		config.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		xmUtils.init(config);
		
		String stream = "m2post";
		String streamNull = null;
		String stream2 = "m2post121";
		assertTrue(xmUtils.isValidStream(stream));
		assertFalse(xmUtils.isValidStream(streamNull));
		assertFalse(xmUtils.isValidStream(stream2));
	}
	
	@Test
	public void testIsValidStreamWithoutEnabledStreams() {

		config = new HashMap();
		Map<String, String> topologyConfig = new HashMap<>();
		topologyConfig.put(GlobalProperties.MONGO_URL, "mongodb://local/ex");
		topologyConfig.put(XmUtils.ENTITY_COLLECTION_NAME, "exceptions");
		config.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		xmUtils.init(config);
		
		String stream = "m2post";
		String streamNull = null;
		String stream2 = "m2post121";
		assertTrue(xmUtils.isValidStream(stream));
		assertTrue(xmUtils.isValidStream(streamNull));
		assertTrue(xmUtils.isValidStream(stream2));
	}
	
	@Test
	public void testLowerCaseExceptionID() {
		assertEquals(xmUtils.generateExceptionID("MTR", "testflow", "testRule"),"mtr-testflow-53365771");
		assertNotEquals(xmUtils.generateExceptionID("MTR", "testflow", "testRule"),"MTR-testflow-53365771");
	}
}