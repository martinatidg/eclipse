package com.citi.reghub.core.xm.consumer.integration;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;

public class TestData {
	public static ExceptionMessage getExMsg() {
		Note note = new com.citi.reghub.core.event.exception.Note();
		note.setNote("Note");
		note.setCreatedBy("XM_XSTREAM");
		note.setSource(NoteSource.XSTREAM);
		note.setCreatedTS(System.currentTimeMillis());

		ExceptionMessage exmsg = new ExceptionMessageBuilder().newException()
				.withId("d56c30b2-88a9-44cf-b4d2-abbfe33a7f3d").withStatus(ExceptionStatus.OPEN)
				.withStream("m2tr")
				.withSourceSystem("322")
				.build();

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope envelope = new EventEnvelope();
		envelope.setEventName(EventName.EXCEPTION_UPDATED);
		envelope.setEventSource(EventSource.CORE_CHANGE_REQUEST);
		envelope.setEventType(EventType.EXCEPTION);
		envelope.setEventVersion(EventVersion.V_1);
		envelope.setEventData(getExMsg());

		return envelope;
	}
}
