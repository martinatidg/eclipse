package com.citi.reghub.xm.consumer.topology.entity;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;

import org.apache.storm.tuple.Tuple;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;

import com.citi.reghub.core.xm.consumer.topology.MockXmUtils;
import com.citi.reghub.xm.consumer.topology.XmUtils;
import com.citi.reghub.xm.consumer.topology.entity.InitExceptionBolt;


public class InitExceptionBoltTest {
	
	static InitExceptionBolt initExceptionBolt;
	static TopologyContext topologyContext;
	static OutputCollector outputCollector;
	static Map config;
	static Tuple input;
	static XmUtils xmUtils;

	
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
		initExceptionBolt = new InitExceptionBolt();
		topologyContext = mock(TopologyContext.class);
		outputCollector = mock(OutputCollector.class);
		xmUtils = new MockXmUtils();
		
		config = new HashMap();
		Map<String, String> topologyConfig = new HashMap<>();
		topologyConfig.put(GlobalProperties.MONGO_URL, "mongodb://local/ex");
		topologyConfig.put(XmUtils.ENTITY_COLLECTION_NAME, "exceptions");
		config.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		
		
		input = mock(Tuple.class);
		initExceptionBolt.prepareBolt(config, topologyContext, outputCollector);
		initExceptionBolt.setXmUtils(xmUtils);
	}
	
	@Test
	public void shouldProcessCanceledTradeTest() throws Exception {
		Entity t = new EntityBuilder()
                .regHubId("test_reghub_id_" + System.currentTimeMillis())
                .status(EntityStatus.BIZ_EXCEPTION).setRdsEligible(true)
                .info("tradeDate", LocalDate.of(2017, 06, 01)).stream("m2post")
                .build();
		List<String> reasonCodes = new ArrayList<String>();
		reasonCodes.add("m2p0st_all_domain_refdata_amc_lookup_counterparty_failed");
		reasonCodes.add("m2p0st_all_domain_refdata_amc_lookup_party_failed");
		reasonCodes.add("m2p0st_all_domain_refdata_smc_lookup_failed");
		
		t.reasonCodes = reasonCodes;
		t.sourceId = "test-canceled-trade";
		t.sourceStatus = "canceled";
		when(input.getValueByField("message"))
        .thenReturn(t);
			
		Mockito.reset(outputCollector);
		initExceptionBolt.process(input);
		verify(outputCollector, times(1)).ack(input);
	}
	
	@Test
	public void shouldProcessCancelledTradeTest() throws Exception {
		Entity t = new EntityBuilder()
                .regHubId("test_reghub_id_" + System.currentTimeMillis())
                .status(EntityStatus.BIZ_EXCEPTION).setRdsEligible(true)
                .info("tradeDate", LocalDate.of(2017, 06, 01)).stream("m2post")
                .build();
		List<String> reasonCodes = new ArrayList<String>();
		reasonCodes.add("m2p0st_all_domain_refdata_amc_lookup_counterparty_failed");
		reasonCodes.add("m2p0st_all_domain_refdata_amc_lookup_party_failed");
		reasonCodes.add("m2p0st_all_domain_refdata_smc_lookup_failed");
		
		t.reasonCodes = reasonCodes;
		t.sourceId = "test-canceled-trade";
		t.sourceStatus = "CANCELLED";
		when(input.getValueByField("message"))
        .thenReturn(t);
			
		Mockito.reset(outputCollector);
		initExceptionBolt.process(input);
		verify(outputCollector, times(1)).ack(input);
	}

	@Test
	public void shouldProcessCanceledTradeWithEmptyReasonCodesTest() throws Exception {
		Entity t = new EntityBuilder()
                .regHubId("test_reghub_id_" + System.currentTimeMillis())
                .status(EntityStatus.BIZ_EXCEPTION).setRdsEligible(true)
                .info("tradeDate", LocalDate.of(2017, 06, 01)).stream("m2post")
                .build();
		
		
		t.reasonCodes = new ArrayList<String>();;
		t.sourceId = "test-canceled-trade";
		t.sourceStatus = "canceled";
		when(input.getValueByField("message"))
        .thenReturn(t);
			
		Mockito.reset(outputCollector);
		initExceptionBolt.process(input);
		verify(outputCollector, times(1)).ack(input);
	}
	
}