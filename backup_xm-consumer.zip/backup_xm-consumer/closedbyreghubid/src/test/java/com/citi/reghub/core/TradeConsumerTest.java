package com.citi.reghub.core;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Ignore;

import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;

public class TradeConsumerTest {

	private static final int port = 19092;
	private static final String valueSerializer = EntityKafkaSerializerDeserializer.class.getName();
	private static final String valueDeserializer = EntityKafkaSerializerDeserializer.class.getName();

	private static Map<String, String> appProps;
	private static LocalCluster cluster;

	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(port, valueSerializer,
			valueDeserializer);

	@Ignore
	@org.junit.Test
	public void shouldConsumeStreamsFromKafkaTopic() {

	}

	@Ignore
	@org.junit.Test
	public void test() throws java.lang.Exception {
		// final String exceptionInputTopic =
		// appProps.get(EntityConsumerTopology.KAFKA_INPUT_TOPIC_NAMES);
		// send trade on inputTopics
		// populateTopicData(exceptionInputTopic.split(",")[0], 20);
		// Thread.sleep(4000);
	}

	void populateTopicData(String topicName, int msgCount) {
		List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new EntityBuilder().regHubId(topicName + "_reghub_id_" + value)
					.status(EntityStatus.BIZ_EXCEPTION).setRdsEligible(true)
					.info("tradeDate", LocalDate.of(2017, 06, 01)).build();
			messages.add(t);
		});

		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (java.lang.Exception e) {
			// LOG.error("Error sending messages to kafka", e);
		}
	}

	@BeforeClass
	public static void setUp() throws java.lang.Exception {
		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());

		Thread.sleep(3000);

		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(false);
		conf.put(GlobalProperties.TOPOLOGY_CONFIG, appProps);
		// cluster.submitTopology("TestTopology", conf, new
		// EntityConsumerTopology().buildTopology(appProps));

		// Wait till topology to get started
		Thread.sleep(20000);
	}

}
