package com.citi.reghub.xm.consumer.topology.event;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsGetter;
import org.apache.storm.tuple.Tuple;
import org.junit.BeforeClass;
import org.junit.Test;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.ExceptionType;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;
import com.citi.reghub.core.xm.consumer.topology.MockXmUtils;
import com.citi.reghub.xm.consumer.topology.XmUtils;
import com.citi.reghub.xm.consumer.topology.event.NotesBolt;

public class NotesBoltTest {
	
	static NotesBolt notesBolt;
	static TopologyContext topologyContext;
	static OutputCollector outputCollector;
	static Map config;
	static Tuple input;
	static XmUtils xmUtils;

	
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
		notesBolt = new NotesBolt();
		topologyContext = mock(TopologyContext.class);
		outputCollector = mock(OutputCollector.class);
		xmUtils = new MockXmUtils();
		
		config = new HashMap();
		Map<String, String> topologyConfig = new HashMap<>();
		topologyConfig.put(GlobalProperties.MONGO_URL, "mongodb://local/ex");
		topologyConfig.put(XmUtils.ENTITY_COLLECTION_NAME, "exceptions");
		config.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		
		
		input = mock(Tuple.class);
		notesBolt.prepareBolt(config, topologyContext, outputCollector);
		notesBolt.setXmUtils(xmUtils);
	}
	
	@Test
	public void shouldProcessNotesAddedTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(0);
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_ADDED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
			
		
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldProcessNotesAddedInvalidNoteTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(null);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(Clock.systemUTC().millis());
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_ADDED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
			
		
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldProcessNotesAddedNullNoteTest() throws Exception {
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("nullNotes").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(null).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_ADDED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
			
		
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldProcessNotesAddedNullExistingNoteTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(Clock.systemUTC().millis());
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("nullNotes").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_ADDED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
			
		
		notesBolt.process(input);
		
	}
	
	
	@Test
	public void shouldProcessNotesDeletedTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(1506633315171L);
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_DELETED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
				
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldProcessNotesDeletedNullNoteTest() throws Exception {
		
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(null).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_DELETED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
				
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldProcessNotesDeletedInvalidTimeTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(Clock.systemUTC().millis());
		
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_NOTE_DELETED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
				
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldIgnoreExceptionUpdatedTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(Clock.systemUTC().millis());
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.CORE_UI).withEventName(EventName.EXCEPTION_UPDATED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
				
		notesBolt.process(input);
		
	}
	
	@Test
	public void shouldIgnoreXmConsumerSourceTest() throws Exception {
		Note aNote = new Note();
        aNote.setSource(NoteSource.CORE_UI);
        aNote.setNote("Test Note");
        aNote.setCreatedBy("Elan");
        aNote.setCreatedTS(Clock.systemUTC().millis());
		ExceptionMessage em = new ExceptionMessageBuilder().newException().withId("1").withStatus(ExceptionStatus.OPEN).withOwner(FunctionalOwner.BUS).withType(ExceptionType.DATA_QUALITY).withLevel(ExceptionLevel.EXCEPTION).addNote(aNote).build();
		EventEnvelope envelope = new EventBuilder().newEvent().ofTypeException().withEventSource(EventSource.XM_CONSUMER).withEventName(EventName.EXCEPTION_UPDATED).withEventData(em).build();
		when(input.getValueByField("message"))
        .thenReturn(envelope);
				
		notesBolt.process(input);
		
	}
	
	@Test
	public void miscellaneousTest() throws Exception {
		OutputFieldsGetter declarer = new OutputFieldsGetter();
		notesBolt.declareBoltSpecificOutFields(declarer);
		assertNotNull(declarer.getFieldsDeclaration() );
		
		assertNotNull(notesBolt.getCollector() );
		assertNotNull(notesBolt.getAuditExceptionEvent());
		assertNotNull(notesBolt.getAuditExceptionsTags());
		assertFalse(notesBolt.validateForAddNotes(null));
		assertNull(notesBolt.findNotesAfterDelete(null, null));
		
	}
	
}