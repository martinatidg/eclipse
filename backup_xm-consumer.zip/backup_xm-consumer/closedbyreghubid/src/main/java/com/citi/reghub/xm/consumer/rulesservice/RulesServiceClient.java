/**
 * 
 */
package com.citi.reghub.xm.consumer.rulesservice;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

/**
 * @author dk77005
 *
 */
public class RulesServiceClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(RulesServiceClient.class);

	private String ruleServiceUrl = null;
	private RestClient restClient = null;
	private LoadingCache<String, Rule> cache;

	public RulesServiceClient() {
		// Do nothing 
	}

	public RulesServiceClient(String ruleServiceUrl) {
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		restClient = new RestClient(builder.build());
		this.ruleServiceUrl = ruleServiceUrl;

		cache = CacheBuilder.newBuilder().expireAfterWrite(15l, TimeUnit.MINUTES).maximumSize(500)
				.build(new CacheLoader<String, Rule>() {
					@Override
					public Rule load(String key) throws Exception {
						LOGGER.debug("RulesService cache call : {}", key);
						String[] keys = key.split(" ");

						if (null != keys && keys.length > 1) {
							return getRuleForCache(keys[0], keys[1]);
						}
						return new Rule();
					}
				});
	}

	// @GetMapping("/rules/{stream}/{resultCode}")
	private Rule getRuleForCache(String stream, String resultCode) {
		Rule rule = null;

		try {
			rule = restClient.get(ruleServiceUrl + "/rules/" + stream + "/" + resultCode, Rule.class);
			if (rule == null) {
				rule = new Rule();
			}
		} catch (Exception e) {
			LOGGER.error("Error fetching data from rule-service: {}", e);
			rule = new Rule();
		}

		return rule;
	}

	// @GetMapping("/rules/{stream}/{resultCode}")
	public Rule getRule(String stream, String resultCode) {
		try {
			return cache.get(stream + " " + resultCode);
		} catch (Exception e) {
			LOGGER.error("Error fetching data from rule cache: {}", e);
		}
		return new Rule();
	}

	public List getAllRules() {
		return restClient.get(ruleServiceUrl + "/rules/", List.class);
	}
	
	}