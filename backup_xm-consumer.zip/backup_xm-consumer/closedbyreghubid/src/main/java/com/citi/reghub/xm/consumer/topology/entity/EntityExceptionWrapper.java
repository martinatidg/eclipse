package com.citi.reghub.xm.consumer.topology.entity;

import java.io.Serializable;

import com.citi.reghub.core.*;
import com.citi.reghub.core.event.exception.*;
import com.fasterxml.jackson.annotation.*;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EntityExceptionWrapper implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private ExceptionMessage exceptionMessage;

	private Entity entity;
	
	public EntityExceptionWrapper(ExceptionMessage exceptionMessage, Entity entity) {
		this.exceptionMessage = exceptionMessage;
		this.entity = entity;
	}

	public ExceptionMessage getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(ExceptionMessage exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}
}
