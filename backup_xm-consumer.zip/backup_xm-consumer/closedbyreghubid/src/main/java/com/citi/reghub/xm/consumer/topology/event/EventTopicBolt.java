package com.citi.reghub.xm.consumer.topology.event;


import org.apache.storm.tuple.*;
import org.slf4j.*;

import com.citi.reghub.core.constants.*;
import com.citi.reghub.core.event.*;
import com.citi.reghub.xm.consumer.topology.XmBolt;

public class EventTopicBolt extends XmBolt {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(EventTopicBolt.class);
	private static final long serialVersionUID = 1L;
	
	
	@Override
	public void process(Tuple input) throws Exception {
		EventEnvelope envelope = (EventEnvelope) input.getValueByField("message");
		LOGGER.info("EventTopicBolt envelope =  {}", envelope);
		getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(envelope.getEventData(), envelope.getEventData()));
	}

	
}
