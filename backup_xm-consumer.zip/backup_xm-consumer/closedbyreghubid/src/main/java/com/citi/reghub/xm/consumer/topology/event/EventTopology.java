package com.citi.reghub.xm.consumer.topology.event;


import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.Config;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EventEnvelopeSerializer;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.kafka.RegHubKafkaBolt;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;
import com.citi.reghub.xm.consumer.topology.AllClosedBolt;

public class EventTopology extends BaseTopology {
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseTopology.class);
	private  static final String KAFKA_EVENT_INPUT_TOPIC_NAMES = "event_emit_bolt.kafka.topic.names";
	private  static final String KAFKA_AUDIT_WRITE_TOPIC_NAMES = "audit_bolt.kafka.topic.names";
	private static final String TOPOLOGY_NAME = "xm_event_topology";
	
	private static final String EVENT_SPOUT = "event_spout";
	private static final String MERGE_BOLT = "merge_bolt";
	private static final String STATUS_UPDATE_BOLT = "status_update_bolt";
	private static final String NOTES_BOLT = "notes_bolt";
	private static final String ALL_CLOSED_BOLT = "all_closed_bolt";
	private static final String EVENT_EMIT_BOLT = "event_emit_bolt";
	private static final String AUDIT_BOLT = "audit_bolt";
	
	
	public static void main(String[] args) throws Exception {
		new EventTopology().runTopology(args);
	}
	
	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		topologyConfig.put(GlobalProperties.TOPOLOGY_NAME, TOPOLOGY_NAME);
		LOGGER.info("Start to build topology: {}", topologyConfig.get(GlobalProperties.TOPOLOGY_NAME));	
		final TopologyBuilder tp = new TopologyBuilder();
		String exceptionEventInputTopicName = topologyConfig.get(KAFKA_EVENT_INPUT_TOPIC_NAMES);
		String auditWriteTopicName = topologyConfig.get(KAFKA_AUDIT_WRITE_TOPIC_NAMES);

		 RegHubKafkaSpout<String, EventEnvelope> regHubExceptionEventKafkaSpout = RegHubKafkaSpout.builder(exceptionEventInputTopicName, StormStreams.INBOUND_KAFKA_STREAM_NAME, topologyConfig)
				.setKeyDesClazz(StringDeserializer.class)
				.setValueDesClazz(EventEnvelopeSerializer.class)
				.build();

		
		tp.setSpout(EVENT_SPOUT, regHubExceptionEventKafkaSpout.getSpout(), 12);
		tp.setBolt(MERGE_BOLT, new ExceptionMergeBolt(), 3)
			.shuffleGrouping(EVENT_SPOUT , StormStreams.INBOUND_KAFKA_STREAM_NAME);
		tp.setBolt(STATUS_UPDATE_BOLT, new StatusUpdateBolt(), 3)
			.shuffleGrouping(EVENT_SPOUT, StormStreams.INBOUND_KAFKA_STREAM_NAME);
		tp.setBolt(NOTES_BOLT, new NotesBolt(), 3)
			.shuffleGrouping(EVENT_SPOUT, StormStreams.INBOUND_KAFKA_STREAM_NAME);
	
		tp.setBolt(ALL_CLOSED_BOLT ,  new AllClosedBolt(), 3)
		.shuffleGrouping(STATUS_UPDATE_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM);
		
		tp.setBolt(EVENT_EMIT_BOLT, RegHubKafkaBolt.getKafkaBolt(topologyConfig, exceptionEventInputTopicName, EVENT_EMIT_BOLT), 3)
			.shuffleGrouping(MERGE_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM)
			.shuffleGrouping(STATUS_UPDATE_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM)
			.shuffleGrouping(NOTES_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM)
			.shuffleGrouping(ALL_CLOSED_BOLT, StormStreams.XM_EXCEPTION_MESSAGE_STREAM);
		
		tp.setBolt(AUDIT_BOLT, RegHubKafkaBolt.getKafkaBolt(topologyConfig, auditWriteTopicName, AUDIT_BOLT), 3)
		.shuffleGrouping(MERGE_BOLT, StormStreams.AUDIT)
		.shuffleGrouping(STATUS_UPDATE_BOLT, StormStreams.AUDIT)
		.shuffleGrouping(NOTES_BOLT, StormStreams.AUDIT)
		.shuffleGrouping(ALL_CLOSED_BOLT, StormStreams.AUDIT);
		return tp.createTopology();
	}
	
	@Override
	protected Config getTopologyConfig() {
		Config conf = new Config();
		conf.setDebug(false);
		conf.setNumWorkers(3);
    	conf.put(Config.TOPOLOGY_BACKPRESSURE_ENABLE,            true);
      	conf.put(Config.TOPOLOGY_EXECUTOR_RECEIVE_BUFFER_SIZE, 1024);
    	conf.put(Config.TOPOLOGY_EXECUTOR_SEND_BUFFER_SIZE,    1024);
    	conf.put(Config.BACKPRESSURE_DISRUPTOR_HIGH_WATERMARK,    0.8);
    	conf.put(Config.BACKPRESSURE_DISRUPTOR_LOW_WATERMARK,    0.5);
        conf.put(Config.TOPOLOGY_WORKER_MAX_HEAP_SIZE_MB, 2048);
        conf.put(Config.WORKER_HEAP_MEMORY_MB, 2000);
      	conf.setMessageTimeoutSecs(60);
      	conf.setMaxSpoutPending(5000);
      	conf.registerSerialization(Audit.class);

    	return conf;
	}
}
