package com.citi.reghub.xm.consumer.rulesservice;

public class Metadata {

    private String name;

    private String key;

    public Metadata() {
    	//do nothing
    }

    public Metadata(String name) {
        this.name = name;
        this.key = name;
    }

    public Metadata(String name, String key) {
        this.name = name;
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public String getKey() {
        return key != null ? key : name;
    }
}
