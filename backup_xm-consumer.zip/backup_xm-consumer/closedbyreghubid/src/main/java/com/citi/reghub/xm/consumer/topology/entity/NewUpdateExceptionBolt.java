package com.citi.reghub.xm.consumer.topology.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.xm.consumer.topology.XmBolt;

public class NewUpdateExceptionBolt extends XmBolt {
	protected static final Logger LOGGER = LoggerFactory.getLogger(NewUpdateExceptionBolt.class);
	private static final long serialVersionUID = 1L;

	@Override
	public void process(Tuple input) throws Exception {
		LOGGER.debug("Incoming Tuple : {}" , input);
		EntityExceptionWrapper entityAndExceptionMessage = (EntityExceptionWrapper) input.getValueByField("message");
		LOGGER.debug("Received Exception Message : {} ", entityAndExceptionMessage.getExceptionMessage());

		ExceptionMessage inputExceptionMessage = entityAndExceptionMessage.getExceptionMessage();

		if (null != inputExceptionMessage.getStatus()
				&& !inputExceptionMessage.getStatus().equals(ExceptionStatus.CLOSED)) {
			EventEnvelope envelope = new EventEnvelope();
			envelope.setEventType(EventType.EXCEPTION);
			envelope.setEventVersion(EventVersion.V_1);
			envelope.setEventSource(EventSource.XM_CONSUMER);
			envelope.setEventTime(System.currentTimeMillis());
			envelope.setEventData(inputExceptionMessage);

			if (null == inputExceptionMessage.getId() || StringUtils.isEmpty(inputExceptionMessage.getId())) {
				inputExceptionMessage.setId(getXmUtils().generateExceptionID(inputExceptionMessage.getStream(),inputExceptionMessage.getSourceId(), inputExceptionMessage.getReasonCode()));

				getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(inputExceptionMessage), false);
				
				envelope.setEventName(EventName.EXCEPTION_CREATED);
			} else {
				getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(inputExceptionMessage), false);

				envelope.setEventName(EventName.EXCEPTION_UPDATED);
			}

			LOGGER.info("Publishing Envelop : {} ", envelope);
			createAndPublishAudit(inputExceptionMessage, envelope.getEventName());

			getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(inputExceptionMessage.getId(), envelope));
		}
		getCollector().ack(input);
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}
