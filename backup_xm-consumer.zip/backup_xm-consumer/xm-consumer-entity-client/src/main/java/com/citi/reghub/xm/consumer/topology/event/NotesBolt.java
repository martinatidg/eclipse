package com.citi.reghub.xm.consumer.topology.event;

import java.time.Clock;
import java.util.ArrayList;
import java.util.List;

import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.xm.consumer.topology.XmBolt;


public class NotesBolt extends XmBolt {

	protected static final Logger LOGGER = LoggerFactory.getLogger(NotesBolt.class);
	private static final long serialVersionUID = 1L;


	@Override
	public void process(Tuple input) throws Exception {
		try {
			EventEnvelope envelope = (EventEnvelope) input.getValueByField("message");
			LOGGER.debug("NotesBolt process envelope = {}", envelope);

			if (!EventSource.XM_CONSUMER.equals(envelope.getEventSource())) {
				LOGGER.debug("NotesBolt EventSource = {}, eventName = {} ", envelope.getEventSource(),
						envelope.getEventName());
				if (EventName.EXCEPTION_NOTE_ADDED.equals(envelope.getEventName())
						|| EventName.EXCEPTION_NOTE_DELETED.equals(envelope.getEventName())) {

					ExceptionMessage existingExceptionMessage = updateExistingExceptionMessageWithNotes(envelope);
					if (existingExceptionMessage != null) {
						LOGGER.debug("NotesBolt saving document");
						getXmUtils().saveToExceptionCollection(
								getXmUtils().exceptionToDocument(existingExceptionMessage), false);
						LOGGER.debug("NotesBolt publishing audit");
						createAndPublishAudit(existingExceptionMessage, envelope.getEventName());
						LOGGER.info("NotesBolt emitting Event  : {} ",existingExceptionMessage);

						getXmUtils().emitExceptionEvent(getCollector(), existingExceptionMessage);
					}

				} else {
					LOGGER.debug("EventName = {} . NotesBolt ignoring this message. No action required.",
							envelope.getEventName());
				}
			} else {
				LOGGER.debug("Envelope is from XM-CONSUMER. NotesBolt ignoring this message. No action required.");
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in NotesBolt.process ", ex);
			
		} finally {
			getCollector().ack(input);
		}
	}


	ExceptionMessage updateExistingExceptionMessageWithNotes(EventEnvelope envelope) {
		ExceptionMessage exceptionMessage = (ExceptionMessage) envelope.getEventData();
		LOGGER.debug("NotesBolt calling getExistingExceptionMessagesById id = {}", exceptionMessage.getId());
		ExceptionMessage existingExceptionMessage = getXmUtils().getExistingExceptionMessagesById(exceptionMessage.getId());
		LOGGER.debug("NotesBolt existingExceptionMessage = {}", existingExceptionMessage);
		if (existingExceptionMessage != null && existingExceptionMessage.getId() != null && !existingExceptionMessage.getId().isEmpty()) {
			List<Note> notes = exceptionMessage.getNotes();

			if (EventName.EXCEPTION_NOTE_ADDED.equals(envelope.getEventName())) {
				boolean valid = validateForAddNotes(notes);
				if (valid) {
					if (existingExceptionMessage.getNotes() == null) {
						existingExceptionMessage.setNotes(new ArrayList<Note>());
					}
					addToExistingNotes(existingExceptionMessage, notes);
					existingExceptionMessage.setUpdatedTS(System.currentTimeMillis());
					existingExceptionMessage.setUpdatedSource(envelope.getEventSource().toString());
					return existingExceptionMessage;
				}

			} else { // for delete notes, notes can be null or empty, if the
						// last notes is deleted
				List<Note> notesToDelete = findNotesToDelete(existingExceptionMessage.getNotes(), notes);
				if (notesToDelete != null) {
					existingExceptionMessage.getNotes().removeAll(notesToDelete);
					existingExceptionMessage.setUpdatedTS(System.currentTimeMillis());
					existingExceptionMessage.setUpdatedSource(envelope.getEventSource().toString());
					return existingExceptionMessage;
				}

			}

		}
		return null;
	}

	void addToExistingNotes(ExceptionMessage existingExceptionMessage, List<Note> newNotes) {
		if (existingExceptionMessage == null || newNotes == null) {
			return;
		}
		for (Note rNote : newNotes) {
			boolean alreadyExists = false;
			for (Note eNote : existingExceptionMessage.getNotes()) {
				if (rNote.getSource().equals(eNote.getSource()) && rNote.getCreatedBy().equals(eNote.getCreatedBy())
						&& rNote.getNote().equals(eNote.getNote())) {
					alreadyExists = true;
					break;
				}
			}
			if (!alreadyExists) {
				existingExceptionMessage.getNotes().add(rNote);
			}
		}
	}

	public boolean validateForAddNotes(List<Note> notes) {
		if (notes == null || notes.isEmpty()) {
			return false;
		}
		for (Note note : notes) {
			if (note == null) {
				return false;
			}
			if ((note.getSource() == null) || (note.getCreatedBy() == null) || note.getCreatedBy().isEmpty()
					|| (note.getNote() == null) || note.getNote().isEmpty()) {
				return false;
			}
			if (note.getCreatedTS() <= 0) {
				note.setCreatedTS(Clock.systemUTC().millis());
			}
		}
		return true;

	}

	public List<Note> findNotesToDelete(List<Note> existingNotes, List<Note> request) {
		List<Note> notesTD = new ArrayList<>();
		if (request == null || request.isEmpty()) {
			return notesTD;
		}
		for (Note note : request) {

			if ((note != null) && (note.getSource() != null) && (note.getCreatedBy() != null)
					&& !note.getCreatedBy().isEmpty() && (note.getCreatedTS() > 0)) {

				for (Note eNote : existingNotes) {
					if ((eNote.getSource() == note.getSource()) && (eNote.getCreatedBy().equals(note.getCreatedBy()))
							&& (eNote.getCreatedTS() == note.getCreatedTS())) {
						notesTD.add(eNote);
					}
				}

			}

		}

		return notesTD;

	}

}