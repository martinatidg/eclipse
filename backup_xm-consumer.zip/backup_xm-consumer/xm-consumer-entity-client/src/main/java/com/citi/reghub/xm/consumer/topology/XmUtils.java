package com.citi.reghub.xm.consumer.topology;

import static com.mongodb.client.model.Filters.eq;

import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.Validate;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.tuple.Values;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.ExceptionType;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;
import com.citi.reghub.core.mongo.RegHubMongoClient;
import com.google.common.hash.Hashing;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.UpdateOptions;

public class XmUtils {

	public static final String ENTITY_COLLECTION_NAME = "entity.collection.name";
	public static final Logger LOGGER = LoggerFactory.getLogger(XmUtils.class);
	private static final String SOURCE_ID = "sourceId";
	private static final String CREATED_TS = "createdTS";
	private static final String NOTES = "notes";

	private MongoCollection<Document> collection;
	private RegHubMongoClient mongoClient;

	public void init(Map config) {
		try {
			Map<String, String> topologyConfig = (Map<String, String>) config.get(GlobalProperties.TOPOLOGY_CONFIG);
			Validate.notEmpty((String) topologyConfig.get(GlobalProperties.MONGO_URL), "url can not be blank or null");
			String url = topologyConfig.get(GlobalProperties.MONGO_URL);
			String password = topologyConfig.get(GlobalProperties.MONGO_PASSWORD);
			String trustStore = topologyConfig.get(GlobalProperties.MONGO_TRUSTSTORE);
			String trustStorePassword = topologyConfig.get(GlobalProperties.MONGO_TRUSTSTORE_PASSWORD);
			String decryptKey = topologyConfig.get(GlobalProperties.DECRYPT_KEY);

			String collectionName = topologyConfig.get(ENTITY_COLLECTION_NAME);

			if (password != null) {
				Map<String, Object> mongoProps = new HashMap<>();
				mongoProps.put(RegHubMongoClient.CONNECTION_URL, url);
				mongoProps.put(RegHubMongoClient.PASSWORD, password);
				mongoProps.put(RegHubMongoClient.TRUSTSTORE, trustStore);
				mongoProps.put(RegHubMongoClient.TRUSTSTORE_PASSWORD, trustStorePassword);
				mongoProps.put(RegHubMongoClient.DECRYPT_KEY, decryptKey);
				if (mongoClient == null) {
					mongoClient = new RegHubMongoClient(mongoProps);
				}
			} else {
				if (mongoClient == null) {
					mongoClient = new RegHubMongoClient(url);
				}
			}

			if (collection == null) {
				collection = mongoClient.getDatabase().getCollection(collectionName);
			}
			
		} catch (Exception ex) {
			LOGGER.error("Exception in XmUtils.init ", ex);
			throw ex;
		}

	}

	public ExceptionMessage getExistingExceptionMessagesById(String id) {
		try {
			BasicDBObject query = new BasicDBObject("_id", id);
			Document document = collection.find(query).first();
			if (document == null)
				return null;
			return createExceptionMessageFromDocument(document);
		} catch (Exception ex) {
			LOGGER.error("Exception in XmUtils.getExistingExceptionMessagesById ", ex);
			throw ex;
		}

	}

	public List<ExceptionMessage> getExistingExceptionMessagesBySourceID(String sourceId) {
		BasicDBObject query = new BasicDBObject(SOURCE_ID, sourceId);
		List<ExceptionMessage> exceptionList = new ArrayList<>();

		FindIterable<Document> documents = collection.find(query);

		for (Document document : documents) {
			exceptionList.add(createExceptionMessageFromDocument(document));
		}

		return exceptionList;
	}

	@SuppressWarnings("unchecked")
	private ExceptionMessage createExceptionMessageFromDocument(Document document) {
		try {
			ExceptionMessage exceptionMessage = new ExceptionMessage();
			exceptionMessage.setId(document.getString("_id"));
			exceptionMessage.setSourceId(document.getString(SOURCE_ID));
			exceptionMessage.setRegHubId(document.getString("regHubId"));
			exceptionMessage.setRegReportingRef(document.getString("regReportingRef"));
			exceptionMessage.setStatus(enumValueOf(ExceptionStatus.class, document.getString("status")));
			exceptionMessage.setReasonCode(document.getString("reasonCode"));
			exceptionMessage.setDescription(document.getString("description"));
			exceptionMessage.setDisplayErrorCode(document.getString("displayErrorCode"));
			exceptionMessage.setNackSource(document.getString("nackSource"));
			exceptionMessage.setXstreamEligible(document.getBoolean("xstreamEligible"));
			exceptionMessage.setType(enumValueOf(ExceptionType.class, document.getString("type")));
			exceptionMessage.setLevel(enumValueOf(ExceptionLevel.class, document.getString("level")));
			exceptionMessage.setStream(document.getString("stream"));
			exceptionMessage.setFlow(document.getString("flow"));
			exceptionMessage.setRuleVersion(document.getString("ruleVersion"));
			exceptionMessage.setAttributes(document.get("attributes", Map.class));
			exceptionMessage.setRequestedTS(document.getLong("requestedTS"));
			exceptionMessage.setCreatedTS(document.getLong(CREATED_TS));
			exceptionMessage.setUpdatedTS(document.getLong("updatedTS"));
			exceptionMessage.setUpdatedSource(document.getString("updatedSource"));
			exceptionMessage
					.setFunctionalOwner(enumValueOf(FunctionalOwner.class, document.getString("functionalOwner")));

			if (null != document.get(NOTES)) {
				List<Document> noteDocuments = (List<Document>) document.get(NOTES);
				if (!noteDocuments.isEmpty()) {
					List<Note> notesList = new ArrayList<>();
					for (Document noteDocument : noteDocuments) {
						Note note = new Note();

						NoteSource ns = enumValueOf(NoteSource.class, noteDocument.getString("source"));
						note.setSource(ns);
						note.setNote(noteDocument.getString("exceptionNote"));
						note.setCreatedTS(Long.parseLong(noteDocument.getString(CREATED_TS)));
						note.setCreatedBy(noteDocument.getString("createdBy"));
						notesList.add(note);
					}
					exceptionMessage.setNotes(notesList);
				}
			}

			return exceptionMessage;
		} catch (Exception ex) {
			LOGGER.error(document.toString());
			LOGGER.error("Exception in XmUtils.createExceptionMessageFromDocument ", ex);
			throw ex;
		}
	}

	public void saveToExceptionCollection(Document document, boolean isUpsert) {
		try {
			Object id = document.get("_id");
			if (id == null) {
				collection.insertOne(document);
			} else if (!isUpsert) {
				collection.replaceOne(eq("_id", id), document, new UpdateOptions().upsert(true));
			} else {
				collection.updateOne(eq("_id", id), new Document("$set", document), new UpdateOptions().upsert(true));
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in XmUtils.saveToExceptionCollection ", ex);
			throw ex;
		}
	}

	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.EXCEPTIONS);
		return exceptionTags;
	}

	

	public void emitExceptionEvent(OutputCollector collector, ExceptionMessage em) {
		try {

			EventEnvelope event = new EventBuilder().newEvent().withEventData(em)
					.withEventName(EventName.EXCEPTION_UPDATED).withEventSource(EventSource.XM_CONSUMER)
					.ofTypeException().build();

			collector.emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(em.getId(), event));
		} catch (Exception ex) {
			LOGGER.error("Exception in XmUtils.emitExceptionEvent ", ex);
			throw ex;
		}

	}

	public Document exceptionToDocument(ExceptionMessage exceptionMessage) {
		Document doc = new Document()
				.append("_id", exceptionMessage.getId())
				.append(SOURCE_ID, exceptionMessage.getSourceId())
				.append("regHubId", exceptionMessage.getRegHubId())
				.append("regReportingRef", exceptionMessage.getRegReportingRef())
				.append("stream", exceptionMessage.getStream())
				.append("flow", exceptionMessage.getFlow())
				.append("reasonCode", exceptionMessage.getReasonCode())
				.append("ruleVersion", exceptionMessage.getRuleVersion())
				.append("description", exceptionMessage.getDescription())
				.append("displayErrorCode", exceptionMessage.getDisplayErrorCode())
				.append("nackSource", exceptionMessage.getNackSource())
				.append("xstreamEligible", exceptionMessage.isXstreamEligible())
				.append("attributes", exceptionMessage.getAttributes())
				.append("requestedTS", exceptionMessage.getRequestedTS())
				.append(CREATED_TS, exceptionMessage.getCreatedTS())
				.append("updatedTS", exceptionMessage.getUpdatedTS())
				.append("updatedSource", exceptionMessage.getUpdatedSource());
		
		doc.values().removeIf(Objects::isNull);
		if(null!=exceptionMessage.getStatus()) {
			doc.append("status", exceptionMessage.getStatus().toString());
		}
		
		if(null!=exceptionMessage.getFunctionalOwner()) {
			doc.append("functionalOwner", exceptionMessage.getFunctionalOwner().toString());
		}
		
		if(null!=exceptionMessage.getType()) {
			doc.append("type", exceptionMessage.getType().toString());
		}
		
		if(null!=exceptionMessage.getLevel()) {
			doc.append("level", exceptionMessage.getLevel().toString());
		}
		
		
		if(null!=exceptionMessage.getNotes() && !exceptionMessage.getNotes().isEmpty()) {
			doc.append("notes", createNotesListMap(exceptionMessage.getNotes()));
		}
		return doc;
		 
	}
	
	private List<Map<String, String>> createNotesListMap(List<Note> notes) {
		List<Map<String, String>> noteslistMap = new ArrayList<>();
		for (Note note : notes) {
			if(null != note) {
			 Map<String, String> noteMap = new LinkedHashMap<>();
           
			 noteMap.put("source", note.getSource().name());
			 noteMap.put("exceptionNote", note.getNote());
			 noteMap.put(CREATED_TS, String.valueOf(note.getCreatedTS()));
			 noteMap.put("createdBy", note.getCreatedBy());
			 noteslistMap.add(noteMap);
			}
		}
		return noteslistMap;
	}	

	
	public MongoCollection<Document> getCollection() {
		return collection;
	}

	public void setCollection(MongoCollection<Document> collection) {
		this.collection = collection;
	}

	public <T> T enumFromValue(Class<T> en, String value) {
		if (value == null || value.isEmpty()) {
			return null;
		}

		Method method = null;

		try {
			method = en.getMethod("fromValue", String.class);
		} catch (Exception e) {
			LOGGER.error("Exception in XmUtils enumValueOf ", e);
			return null;
		}

		if (method != null) {
			try {
				return (T) method.invoke(en, value);
			} catch (Exception e) {
				LOGGER.error("Exception in XmUtils enumValueOf ", e);
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T extends Enum<T>> T enumValueOf(Class<T> enumType, String name) {
		if (name == null || name.isEmpty()) {
			return null;
		}

		try {
			return (T) Enum.valueOf(enumType, name);
		} catch (Exception e) {
			LOGGER.error("Exception in XmUtils.enumValueOf ", e);
			return null;
		}

	}

	public void setMongoClient(RegHubMongoClient mongoClient) {
		this.mongoClient = mongoClient;
	}

	public RegHubMongoClient getMongoClient() {
		return mongoClient;
	}

	public String generateExceptionID(String stream, String sourceId, String ruleName) {
		return stream + "-" + sourceId + "-" + Hashing.murmur3_32().hashString(ruleName, Charset.forName("UTF-8"));
	}

}
