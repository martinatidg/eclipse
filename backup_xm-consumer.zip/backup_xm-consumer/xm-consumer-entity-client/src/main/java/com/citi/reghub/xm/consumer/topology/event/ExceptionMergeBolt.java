package com.citi.reghub.xm.consumer.topology.event;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.xm.consumer.topology.XmBolt;


public class ExceptionMergeBolt extends XmBolt {

	protected static final Logger LOGGER = LoggerFactory.getLogger(ExceptionMergeBolt.class);
	private static final long serialVersionUID = 1L;

	
	@Override
	public void process(Tuple input) throws Exception {
		EventEnvelope envelope = (EventEnvelope) input.getValueByField("message");
		LOGGER.debug("ExceptionMergeBolt envelope =  {}", envelope);
		ExceptionMessage exceptionMessage = (ExceptionMessage) envelope.getEventData();
		
		if(!EventSource.XM_CONSUMER.equals(envelope.getEventSource())) {
			if(EventName.EXCEPTION_UPDATED.equals(envelope.getEventName())) {
				ExceptionMessage mergedExceptionMessage = exceptionMessage;		
				ExceptionMessage existingExceptionMessage = getXmUtils().getExistingExceptionMessagesById(exceptionMessage.getId());
				if(null != existingExceptionMessage) {	
					
					mergedExceptionMessage = merge(exceptionMessage, existingExceptionMessage);
				}
				getXmUtils().saveToExceptionCollection( getXmUtils().exceptionToDocument(mergedExceptionMessage), false);
				createAndPublishAudit(exceptionMessage, envelope.getEventName());
				getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(exceptionMessage.getId() , envelope));
			} else if(EventName.EXCEPTION_REQUESTED.equals(envelope.getEventName())) {
				// Expecting all details are sent by stream application for creating exception.
				exceptionMessage.setId(getXmUtils().generateExceptionID(exceptionMessage.getStream(),exceptionMessage.getSourceId(), exceptionMessage.getReasonCode()));
				if(exceptionMessage.getCreatedTS() == 0){
					exceptionMessage.setCreatedTS(System.currentTimeMillis());
				}
				if(exceptionMessage.getUpdatedTS() == 0){
					exceptionMessage.setUpdatedTS(System.currentTimeMillis());
				}
				if(exceptionMessage.getRequestedTS() == 0){
					exceptionMessage.setRequestedTS(System.currentTimeMillis());
				}
				getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(exceptionMessage), false);
				
				envelope.setEventSource(EventSource.XM_CONSUMER);
				envelope.setEventName(EventName.EXCEPTION_CREATED);
				envelope.setEventVersion(EventVersion.V_1);
				envelope.setEventTime(System.currentTimeMillis());
				envelope.setEventType(EventType.EXCEPTION);
				
				createAndPublishAudit(exceptionMessage, envelope.getEventName());
				LOGGER.info("Publishing Envelop : {} ", envelope);
				getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(exceptionMessage.getId() , envelope));
			}
		} else {
			LOGGER.debug("Envelope is from XM-CONSUMER. Ignoring this message. No action required.");
		}
		
		getCollector().ack(input);
	}
	

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
	
	public ExceptionMessage merge(ExceptionMessage envelopeExceptionMsg, ExceptionMessage exceptionMessage) {
		ExceptionMessage mergedenvelopeExceptionMsg = envelopeExceptionMsg;
		if(null == envelopeExceptionMsg.getRegReportingRef() )
			mergedenvelopeExceptionMsg.setRegReportingRef(exceptionMessage.getRegReportingRef());
		
		if(null == envelopeExceptionMsg.getStream())
			mergedenvelopeExceptionMsg.setStream(exceptionMessage.getStream());
		
		if(null == envelopeExceptionMsg.getFlow())
			mergedenvelopeExceptionMsg.setFlow(exceptionMessage.getFlow());
		
		if(null == envelopeExceptionMsg.getStatus())
			mergedenvelopeExceptionMsg.setStatus(exceptionMessage.getStatus());
		
		if(null == envelopeExceptionMsg.getReasonCode())
			mergedenvelopeExceptionMsg.setReasonCode(exceptionMessage.getReasonCode());
		
		if(null == envelopeExceptionMsg.getRuleVersion())
			mergedenvelopeExceptionMsg.setRuleVersion(exceptionMessage.getRuleVersion());

		if(null == envelopeExceptionMsg.getDescription())
			mergedenvelopeExceptionMsg.setDescription(exceptionMessage.getDescription());
		
		if(null == envelopeExceptionMsg.getFunctionalOwner())
			mergedenvelopeExceptionMsg.setFunctionalOwner(exceptionMessage.getFunctionalOwner());
		

		if(null == envelopeExceptionMsg.getDisplayErrorCode())
			mergedenvelopeExceptionMsg.setDisplayErrorCode(exceptionMessage.getDisplayErrorCode());

		if(null == envelopeExceptionMsg.getNackSource())
			mergedenvelopeExceptionMsg.setNackSource(exceptionMessage.getNackSource());
		
		if( envelopeExceptionMsg.isXstreamEligible())
			mergedenvelopeExceptionMsg.setXstreamEligible(exceptionMessage.isXstreamEligible());
		
		if(null == envelopeExceptionMsg.getType())
			mergedenvelopeExceptionMsg.setType(exceptionMessage.getType());
		
		if( null == envelopeExceptionMsg.getLevel())
			mergedenvelopeExceptionMsg.setLevel(exceptionMessage.getLevel());
		
		Map<String, Object> attributes = new HashMap<>();
		if( null != envelopeExceptionMsg.getAttributes()) {
			attributes.putAll(envelopeExceptionMsg.getAttributes());
		}
		if( null != exceptionMessage.getAttributes()) {
			attributes.putAll(exceptionMessage.getAttributes());
		}
		mergedenvelopeExceptionMsg.setAttributes(attributes);
		
		List<Note> notes = new ArrayList<>();
		if(null != envelopeExceptionMsg.getNotes() && !envelopeExceptionMsg.getNotes().isEmpty()) {
			notes.addAll(envelopeExceptionMsg.getNotes());
		}
		if(null != exceptionMessage.getNotes() && !exceptionMessage.getNotes().isEmpty()) {
			notes.addAll(exceptionMessage.getNotes());
		}
		mergedenvelopeExceptionMsg.setNotes(notes);	
		if(null == Long.valueOf(envelopeExceptionMsg.getRequestedTS()))
			mergedenvelopeExceptionMsg.setRequestedTS(exceptionMessage.getRequestedTS());
		
		if(null == Long.valueOf(envelopeExceptionMsg.getCreatedTS()))
			mergedenvelopeExceptionMsg.setCreatedTS(exceptionMessage.getCreatedTS());
		
		if(null == Long.valueOf(envelopeExceptionMsg.getUpdatedTS()))
			mergedenvelopeExceptionMsg.setUpdatedTS(exceptionMessage.getUpdatedTS());
		
		if(null == envelopeExceptionMsg.getUpdatedSource())
			mergedenvelopeExceptionMsg.setUpdatedSource(exceptionMessage.getUpdatedSource());
		
		return mergedenvelopeExceptionMsg;
			
	}

}
