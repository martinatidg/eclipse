package com.citi.reghub.xm.consumer.topology;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.xm.consumer.topology.entity.InitExceptionBolt;
import com.fasterxml.jackson.core.JsonProcessingException;

public class AllClosedBolt extends XmBolt {

	protected static final Logger LOGGER = LoggerFactory.getLogger(InitExceptionBolt.class);
	public static final String ENTITY_SERVICE_URL = "entity.service.patch.url";
	public static final String STATUS = "status";
	public static final String SEPARATOR = "/";
	private static final long serialVersionUID = 1L;

	public static final String REG_HUB_ID = "regHubId";
	public static final String SOURCE_ID = "sourceId";
	public static final String UPDATED_TS = "updatedTS";

	private RestClient restClient;
	private String entityServiceUrl;

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector outputCollector) {
		super.prepareBolt(stormConf, context, outputCollector);
		LOGGER.debug("XmBolt prepareBolt = {}", stormConf);
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		entityServiceUrl = topologyConfig.get(ENTITY_SERVICE_URL);
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		restClient = new RestClient(builder.build());
	}

	private boolean valid(String object, String msg) {
		if (object == null || "".equals(object)) {
			LOGGER.error(msg);
			return false;
		}
		return true;
	}

	private boolean validate(ExceptionMessage exMsg) {
		boolean v ;
		v = valid(exMsg.getStatus().value(), "Status cannot be null");
		v = v && valid(exMsg.getId(), "Exception id cannot be null");
		return v;
	}

	@Override
	public void process(Tuple input) throws Exception {
		LOGGER.debug("Incoming Tuple : {}" , input);
		EventEnvelope envelope = (EventEnvelope) input.getValueByField(TUPLE_MESSAGE);
		ExceptionMessage inputExceptionMessage = (ExceptionMessage) envelope.getEventData();
		
		if (!validate(inputExceptionMessage)) {
			getCollector().ack(input);
			return;
		}

		if (null != inputExceptionMessage && null != inputExceptionMessage.getStatus()
				&& (inputExceptionMessage.getStatus().equals(ExceptionStatus.CLOSED)
						|| inputExceptionMessage.getStatus().equals(ExceptionStatus.CLOSED_IGNORED))) {

			ExceptionMessage existingMessage = getXmUtils()
					.getExistingExceptionMessagesById(inputExceptionMessage.getId());

			if (null != existingMessage) {

				Set<ExceptionStatus> uniqueStatusSet = getStatusList(inputExceptionMessage, existingMessage);

				ExceptionMessage newException = new ExceptionMessageBuilder().newException()
						.withSourceId(inputExceptionMessage.getSourceId())
						.withRegHubId(inputExceptionMessage.getRegHubId()).build();

				if (uniqueStatusSet.size() == 1
						&& uniqueStatusSet.iterator().next().equals(inputExceptionMessage.getStatus())) {
					if (inputExceptionMessage.getStatus() == ExceptionStatus.CLOSED_IGNORED) {
						// for CLOSED_IGNORED update entity status
						Map patchEntityResponse = patchEntity(existingMessage.getStream(),
								inputExceptionMessage.getFlow(), inputExceptionMessage.getRegHubId());
						if (patchEntityResponse == null) {
							getCollector().fail(input);
							return;
						}
						// CLOSED_IGNORED status
						emitClosedIgnored(inputExceptionMessage, newException);
					}else{
						emitClosed(inputExceptionMessage, newException);
					}
					
				} else {
					// other than CLOSED or CLOSED_IGNORED status
					boolean otherStatus = isOtherStatus(uniqueStatusSet);
					if (otherStatus) {
						LOGGER.debug("No action taken since one of the exception is not CLOSED or CLOSED_IGNORED");
						getCollector().ack(input);
						return;
					}
					// CLOSED status
					emitClosed(inputExceptionMessage, newException);
				}

			}
		}
		getCollector().ack(input);
	}

	private Set<ExceptionStatus> getStatusList(ExceptionMessage inputExceptionMessage,
			ExceptionMessage existingMessage) {
		List<ExceptionMessage> existingExceptionList = getXmUtils()
				.getExistingExceptionMessagesBySourceID(existingMessage.getSourceId());

		Set<ExceptionStatus> uniqueStatusSet = new HashSet<>();
		if (existingExceptionList != null && !existingExceptionList.isEmpty()) {
			// remove inputExceptionMessage before checking statuses of other exceptions
			existingExceptionList.remove(inputExceptionMessage);

			// get distinct list of existing statuses
			for (ExceptionMessage ex : existingExceptionList) {
				uniqueStatusSet.add(ex.getStatus());
			}
		}
		return uniqueStatusSet;

	}

	private void emitClosedIgnored(ExceptionMessage inputExceptionMessage, ExceptionMessage newException)
			throws JsonProcessingException {
		EventEnvelope eventEnvelope = new EventBuilder().newEvent().withEventData(inputExceptionMessage)
				.withEventName(inputExceptionMessage.getStatus() == ExceptionStatus.CLOSED_IGNORED
						? EventName.EXCEPTION_ALL_CLOSED_IGNORED : EventName.EXCEPTION_ALL_CLOSED)
				.withEventSource(EventSource.XM_CONSUMER).withEventData(newException).ofTypeException().build();
		LOGGER.info("Publishing Envelop : {}" , eventEnvelope);
		getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,
				new Values(inputExceptionMessage.getRegHubId(), eventEnvelope));
	}

	private boolean isOtherStatus(Set<ExceptionStatus> uniqueStatusSet) {
		for (ExceptionStatus status : uniqueStatusSet) {
			if (!ExceptionStatus.CLOSED_IGNORED.equals(status) && !ExceptionStatus.CLOSED.equals(status)) {
				return true;
			}
		}
		return false;
	}

	private void emitClosed(ExceptionMessage inputExceptionMessage, ExceptionMessage newException) {

		EventEnvelope eventEnvelope = new EventBuilder().newEvent().withEventData(newException)
				.withEventName(EventName.EXCEPTION_ALL_CLOSED).withEventSource(EventSource.XM_CONSUMER)
				.ofTypeException().build();
		LOGGER.info("Publishing Envelop : {}" , eventEnvelope);
		// Emit EXCEPTION_ALL_CLOSED event
		getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,
				new Values(inputExceptionMessage.getRegHubId(), eventEnvelope));
	}

	public Map patchEntity(String stream, String flow, String id) throws JsonProcessingException {
		// update entity status to NON REPORTABLE
		Map<String, String> entityPayload = new HashMap<>();
		entityPayload.put(STATUS, EntityStatus.NON_REPORTABLE);
		String url = entityServiceUrl + SEPARATOR + stream + SEPARATOR + flow + SEPARATOR + id + SEPARATOR + "patch";

		LOGGER.debug("Hitting Entity Service for payload='{}'", entityPayload);
		Map entity = restClient.doPost(entityPayload, url, Map.class, false);
		if (entity == null) {
			LOGGER.error("Error during updating entity status with payload='{}' and url='{}'", entityPayload, url);
		} else {
			LOGGER.info("Entity Status has been updated successfully with payload='{}' and url='{}'", entityPayload,
					url);
		}
		return entity;
	}
}
