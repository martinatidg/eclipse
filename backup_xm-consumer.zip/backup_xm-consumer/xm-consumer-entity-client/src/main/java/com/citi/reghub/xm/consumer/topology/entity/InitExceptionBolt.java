package com.citi.reghub.xm.consumer.topology.entity;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.ExceptionType;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.xm.consumer.rulesservice.Rule;
import com.citi.reghub.xm.consumer.rulesservice.RulesServiceClient;
import com.citi.reghub.xm.consumer.topology.XmBolt;



public class InitExceptionBolt extends XmBolt {

	protected static final Logger LOG = LoggerFactory.getLogger(InitExceptionBolt.class);

	private static final long serialVersionUID = 1L;
	
	private transient RulesServiceClient rulesServiceClient;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		super.prepareBolt(config, topologyContext, outputCollector);

		Map<String, String> topologyConfig = (Map<String, String>) config.get(GlobalProperties.TOPOLOGY_CONFIG);
		
		this.rulesServiceClient = new RulesServiceClient(topologyConfig.get("rule.service.url"));
	}

	@Override
	public void process(Tuple input) throws Exception {
		Entity entity = (Entity) input.getValueByField("message");
		
		
		if (entity == null ){
			LOG.warn("Skipping Tuple due to entity is null: {}", input);
			getCollector().ack(input);
			return;
		}
		
		if (entity.sourceId == null || entity.sourceId.isEmpty()) {
			LOG.warn("Skipping entity due to empty sourceId: {}", entity);
			getCollector().ack(input);
			return;
		}
		//temp skip due to junk data from m2tr.
		if (entity.reasonCodes !=null && entity.reasonCodes.contains("m2tr_all_firm_account_lei_exception")){
			LOG.warn("Skipping entity due icorrect rule {}", entity);
			getCollector().ack(input);
			return;
		}

		List<ExceptionMessage> existingExceptionList = getXmUtils().getExistingExceptionMessagesBySourceID(entity.sourceId);
		if (null != entity.status && entity.status.equals(EntityStatus.BIZ_EXCEPTION)
				|| entity.status.equals(EntityStatus.TECH_EXCEPTION)
				|| entity.status.equals(EntityStatus.APP_EXCEPTION)
				|| entity.status.equals(EntityStatus.REJECTED)) {

			Map<String, ExceptionMessage> reasonCodeExceptionMessageMap = new HashMap<>();
			if (existingExceptionList != null && !existingExceptionList.isEmpty()) {
				for (ExceptionMessage exceptionMessage : existingExceptionList) {
					reasonCodeExceptionMessageMap.put(exceptionMessage.getReasonCode(), exceptionMessage);
				}
			}

			if (!entity.reasonCodes.isEmpty()) {
				for (String reasonCode : entity.reasonCodes) {
					if (reasonCodeExceptionMessageMap.containsKey(reasonCode)) {
						// updating already existing exception
						ExceptionMessage exceptionMessage = reasonCodeExceptionMessageMap.get(reasonCode);
						updateException(entity, exceptionMessage);

						EntityExceptionWrapper wrapper = new EntityExceptionWrapper(exceptionMessage, entity);
						getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,
								new Values(wrapper.getExceptionMessage().getId(), wrapper));

						reasonCodeExceptionMessageMap.remove(reasonCode);
					} else {
						// create new exception
						ExceptionMessage exceptionMessage = openExceptionMessage(entity, reasonCode);

						EntityExceptionWrapper wrapper = new EntityExceptionWrapper(exceptionMessage, entity);
						getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,
								new Values(wrapper.getExceptionMessage().getId(), wrapper));
					}
				}

				if (!reasonCodeExceptionMessageMap.isEmpty()) {
					// close remaining exceptions because there reason code is
					// not found in current entity.
					for (Map.Entry<String, ExceptionMessage> entry : reasonCodeExceptionMessageMap.entrySet()) {
						ExceptionMessage exceptionMessage = entry.getValue();

						closeException(exceptionMessage);
						EntityExceptionWrapper wrapper = new EntityExceptionWrapper(exceptionMessage, entity);
						getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,
								new Values(wrapper.getExceptionMessage().getId(), wrapper));
					}
				}
			}
		} else {

			// Entity is not in EXCEPTION state, clear all existing exceptions
			for (ExceptionMessage exceptionMessage : existingExceptionList) {
				closeException(exceptionMessage);

				EntityExceptionWrapper wrapper = new EntityExceptionWrapper(exceptionMessage, entity);
				getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,
						new Values(wrapper.getExceptionMessage().getId(), wrapper));
			}
		}

		getCollector().ack(input);
	}

	private void closeException(ExceptionMessage exceptionMessage) {
		exceptionMessage.setStatus(ExceptionStatus.CLOSED);
		exceptionMessage.setUpdatedTS(System.currentTimeMillis());
		exceptionMessage.setUpdatedSource(DEFAULT_EXCEPTION_SOURCE);
	}

	private void updateException(Entity entity, ExceptionMessage exceptionMessage) {

		exceptionMessage.setRegHubId(entity.regHubId);
		exceptionMessage.setUpdatedTS(System.currentTimeMillis());
		exceptionMessage.setUpdatedSource(DEFAULT_EXCEPTION_SOURCE);
		exceptionMessage.setAttributes(getEntityAttributes(entity, exceptionMessage));

	}

	private Map<String, Object> getEntityAttributes(Entity entity, ExceptionMessage exceptionMessage) {
		Map<String, Object> returnAttributes = new HashMap<>();

		if (entity.info != null && !entity.info.isEmpty()) {
			Rule rule = rulesServiceClient.getRule(entity.stream, exceptionMessage.getReasonCode());
			if (rule != null) {
				List<String> attributeList = rule.getAttributes();
				if (attributeList != null && !attributeList.isEmpty()) {
					for (String string : attributeList) {
						returnAttributes.put(string, entity.info.get(string));
					}
				}
			}
		}

		return returnAttributes;
	}

	private ExceptionMessage openExceptionMessage(Entity entity, String reasonCode) {
		Long currentTime = System.currentTimeMillis();

		ExceptionMessage exceptionMessage = new ExceptionMessage();
		exceptionMessage.setStatus(ExceptionStatus.OPEN);
		exceptionMessage.setSourceId(entity.sourceId);
		exceptionMessage.setRegHubId(entity.regHubId);
		exceptionMessage.setRegReportingRef(entity.regReportingRef);
		exceptionMessage.setReasonCode(reasonCode);
		exceptionMessage.setRequestedTS(currentTime);
		exceptionMessage.setCreatedTS(currentTime);
		exceptionMessage.setUpdatedTS(currentTime);
		exceptionMessage.setUpdatedSource(DEFAULT_EXCEPTION_SOURCE);
		exceptionMessage.setStream(entity.stream);
		exceptionMessage.setAttributes(getEntityAttributes(entity, exceptionMessage));
		updateExceptionWithLatestRuleInfo(entity, exceptionMessage);

		exceptionMessage.setFlow(entity.flow);

		return exceptionMessage;
	}

	

	private void updateExceptionWithLatestRuleInfo(Entity entity, ExceptionMessage inputExceptionMessage) {
		if (inputExceptionMessage.getReasonCode() != null) {
			Rule rule = null;
			try {
				rule = rulesServiceClient.getRule(inputExceptionMessage.getStream(),
						inputExceptionMessage.getReasonCode());
			} catch (Exception e) {
				LOG.warn("Exception while fetching rule with reason code {}",inputExceptionMessage.getReasonCode(), e);
			}
			if (null != rule) {
				inputExceptionMessage.setDescription(rule.getDescription());
				inputExceptionMessage.setFunctionalOwner(getXmUtils().enumFromValue(FunctionalOwner.class, rule.getOwner()));
				inputExceptionMessage
						.setXstreamEligible(rule.getXstream() != null ? Boolean.valueOf(rule.getXstream()) : false);
				inputExceptionMessage.setLevel(getXmUtils().enumFromValue(ExceptionLevel.class, rule.getLevel()));
				inputExceptionMessage.setRuleVersion(rule.getVersion());
				inputExceptionMessage.setType(getXmUtils().enumFromValue(ExceptionType.class, rule.getType()));
				inputExceptionMessage.setDisplayErrorCode(rule.getDisplayName());
				//REJECTED status
				if(entity.status != null && entity.status.equals(EntityStatus.REJECTED)){
					inputExceptionMessage.setNackSource(rule.getLocation());
				}
			}
		}
	}
	
	}