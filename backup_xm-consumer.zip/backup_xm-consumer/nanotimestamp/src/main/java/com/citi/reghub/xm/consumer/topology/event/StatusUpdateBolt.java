package com.citi.reghub.xm.consumer.topology.event;

import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.xm.consumer.topology.XmBolt;
import com.citi.reghub.xm.consumer.validator.ExceptionMessageNullValidator;
import com.citi.reghub.xm.consumer.validator.TupleNullValidator;
import com.citi.reghub.xm.consumer.validator.ValidatorManager;

public class StatusUpdateBolt extends XmBolt {
	protected static final Logger LOGGER = LoggerFactory.getLogger(StatusUpdateBolt.class);
	private static final long serialVersionUID = 1L;
	private transient ValidatorManager manager;
	
	private boolean valid(String object, String msg) {
		if (object == null || "".equals(object)) {
			LOGGER.error(msg);
			return false;
		}
		return true;
	}

	private boolean validate(ExceptionMessage exMsg) {
		boolean v ;
		v = valid(exMsg.getStatus().value(), "Status cannot be null");
		v = v && valid(exMsg.getId(), "Exception id cannot be null");
		return v;
	}

	@Override
	public void process(Tuple input) throws Exception {
		if (!manager.validate(input)) {
			return;
		}

		EventEnvelope envelope = (EventEnvelope) input.getValueByField("message");
		
		if (!EventSource.XM_CONSUMER.equals(envelope.getEventSource())
				&& EventName.EXCEPTION_STATUS_UPDATED == envelope.getEventName()) {
			ExceptionMessage exMsg = (ExceptionMessage) envelope.getEventData();
			
			if(!getXmUtils().isValidStream(exMsg.getStream())){
				LOGGER.warn("Skipping Tuple due to invalid stream: {}", input);
				getCollector().ack(input);
				return;
			}
			if (!validate(exMsg)) {
				getCollector().ack(input);
				return;
			}

			// validate we can update the status
			if (ExceptionStatus.CLOSED == exMsg.getStatus()) {
				LOGGER.warn("StatusUpdate event cannot set exception status to CLOSED");
				getCollector().ack(input);
				return;
			}

			ExceptionMessage existingException = getXmUtils().getExistingExceptionMessagesById(exMsg.getId());
			if (existingException == null || existingException.getStatus() == ExceptionStatus.CLOSED) {
				LOGGER.warn("Exception with id {} either do not exist or was already closed.", exMsg.getId());
			} else {

				/// update the status

				existingException.setUpdatedTS(System.currentTimeMillis());
				existingException.setId(exMsg.getId());
				existingException.setStatus(exMsg.getStatus());
				existingException.setUpdatedSource(envelope.getEventSource().toString());

				// save to collection
				getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(existingException), false);
				
				createAndPublishAudit(existingException, envelope.getEventName());
				LOGGER.info("StatusUpdateBolt emitting Event {}", envelope);
				// emit update event
				getXmUtils().emitExceptionEvent(getCollector(), existingException);
			}
		}

		getCollector().ack(input);
	}

	@SuppressWarnings({ "rawtypes"})
	@Override
	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		super.prepareBolt(config, topologyContext, outputCollector);

		manager = new ValidatorManager(config, topologyContext, outputCollector);
		manager.addValidator(TupleNullValidator.class);
		manager.addValidator(ExceptionMessageNullValidator.class);
	}
}
