package com.citi.reghub.xm.consumer.validator;

import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;

public interface Validator<T> {
	boolean validate(T t);
	void handle(T t);
	@SuppressWarnings({ "rawtypes" })
	void init(Map config, TopologyContext topologyContext, OutputCollector outputCollector);
}
