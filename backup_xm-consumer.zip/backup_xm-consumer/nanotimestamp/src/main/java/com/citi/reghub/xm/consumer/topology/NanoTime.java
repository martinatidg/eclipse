package com.citi.reghub.xm.consumer.topology;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Optional;

public class NanoTime {
	private static final long NANOSECONDS = 1000_000L; 
	private static final int MAX_DATE_LENGTH = 14; 

	private NanoTime() {
		throw new UnsupportedOperationException("The Util class contains static methods only and cannot be instantiated.");
	}

	public static Long getCurrentTimestamp() {
		LocalDateTime currentTs = LocalDateTime.now();
		return getTimestamp(currentTs);
	}

	public static Long getTimestamp(LocalDateTime ldateTime) {
		long epochSec = ldateTime.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
		Integer nanos = ldateTime.getNano();

		return epochSec * 1000000000 + nanos;
	}

	public static Long getTimestamp(String millisecond) {
		Optional<Long> ldtOpt = stringToLong(millisecond);

		if (!ldtOpt.isPresent()) {
			return null;
		}

		Long longDate = ldtOpt.get();

		return convertMilliToNano(longDate);
	}

	public static Long convertMilliToNano(Long millisecond) {
		if (millisecond == null) {
			return null;
		}

		// if length is greater than 13, than it's nano seconds
		int length = String.valueOf(millisecond).length();

		return length <= MAX_DATE_LENGTH ? millisecond * NANOSECONDS : millisecond;

	}

	public static Optional<Long> stringToLong(String millisecondStr) {
		try {
			return Optional.of(Long.parseLong(millisecondStr));
		}
		catch (NumberFormatException e) {
			return Optional.empty();
		}
	}
}
