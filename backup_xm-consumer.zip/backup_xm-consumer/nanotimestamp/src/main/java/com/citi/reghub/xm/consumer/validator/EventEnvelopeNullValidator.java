package com.citi.reghub.xm.consumer.validator;

import java.util.Map;
import java.util.Optional;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;

import com.citi.reghub.core.event.EventEnvelope;

public class EventEnvelopeNullValidator implements Validator<Tuple> {
	private OutputCollector collector;

	@Override
	public boolean validate(Tuple tuple) {
		return Optional.ofNullable(tuple).map((Tuple t) -> (EventEnvelope)t.getValueByField("message")).isPresent();
	}

	@Override
	public void handle(Tuple tuple) {
		collector.ack(tuple);
	}

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void init(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		this.collector = outputCollector;
	}
}
