package com.citi.reghub.xm.consumer.topology.entity;

import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.xm.consumer.topology.XmBolt;
import com.citi.reghub.xm.consumer.validator.ExceptionMessageNullValidator;
import com.citi.reghub.xm.consumer.validator.TupleNullValidator;
import com.citi.reghub.xm.consumer.validator.ValidatorManager;

public class CloseExceptionBolt extends XmBolt {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(CloseExceptionBolt.class);
	private static final long serialVersionUID = 1L;
	
	private transient ValidatorManager manager;

	@Override
	public void process(Tuple input) throws Exception {
		if (!manager.validate(input)) {
			return;
		}

		LOGGER.debug("Incoming Tuple : {}" , input);
		EntityExceptionWrapper entityAndExceptionMessage = (EntityExceptionWrapper) input.getValueByField("message");
		
		ExceptionMessage inputExceptionMessage = entityAndExceptionMessage.getExceptionMessage();
		if(null!=inputExceptionMessage.getId() && inputExceptionMessage.getStatus().equals(ExceptionStatus.CLOSED)) {
			// Update the record in DB to close.
			
			getXmUtils().saveToExceptionCollection(getXmUtils().exceptionToDocument(inputExceptionMessage), false);
			// Publish an event for this exception close.
			EventEnvelope envelope = new EventEnvelope(); 
			envelope.setEventVersion(EventVersion.V_1);
			envelope.setEventSource(EventSource.XM_CONSUMER);
			envelope.setEventType(EventType.EXCEPTION);
			envelope.setEventName(EventName.EXCEPTION_CLOSED);
			envelope.setEventTime(System.currentTimeMillis());
			envelope.setEventData(inputExceptionMessage);
			createAndPublishAudit(inputExceptionMessage, envelope.getEventName());
			getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(inputExceptionMessage.getId() , envelope));
			LOGGER.info("Publishing Envelop : {}" , envelope);
		}		
		getCollector().ack(input);
	}
	
	@SuppressWarnings({ "rawtypes"})
	@Override
	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		super.prepareBolt(config, topologyContext, outputCollector);

		manager = new ValidatorManager(config, topologyContext, outputCollector);
		manager.addValidator(TupleNullValidator.class);
		manager.addValidator(ExceptionMessageNullValidator.class);
	}

}