package com.citi.reghub.xm.consumer.validator;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;

public class EntitySpecificValidator implements Validator<Tuple> {
	protected static final Logger LOG = LoggerFactory.getLogger(EntitySpecificValidator.class);
	public static final String XM_ENABLED_STREAMS = "xm.enabled.streams";

	private OutputCollector collector;
	private Optional<List<String>> xmEnabledStreamList;
	
	@Override
	public boolean validate(Tuple tuple) {
		Entity entity = (Entity) tuple.getValueByField("message");

		if(!isValidStream(entity.stream)){
			LOG.warn("Skipping Tuple due to invalid stream: {}", tuple);
			return false;
		}
		
		if (entity.sourceId == null || entity.sourceId.isEmpty()) {
			LOG.warn("Skipping entity due to empty sourceId: {}", entity);
			return false;
		}

		//temp skip due to junk data from m2tr.
		if (entity.reasonCodes !=null && entity.reasonCodes.contains("m2tr_all_firm_account_lei_exception")){
			LOG.warn("Skipping entity due icorrect rule {}", entity);
			return false;
		}

		return true;
	}

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void init(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		this.collector = outputCollector;

		Optional<String> streamOpt = Optional.ofNullable(config.get(XM_ENABLED_STREAMS)).map(Object::toString);
		xmEnabledStreamList = streamOpt.map(s -> s.replace(" ", "")).map(s -> s.split(",")).map(Arrays::asList);
	}

	@Override
	public void handle(Tuple t) {
		collector.ack(t);
	}

	public boolean isValidStream(String stream) {
		if (!xmEnabledStreamList.isPresent()) {
			return false;
		}
		
		return xmEnabledStreamList.get().contains(stream);
	}
}
