package com.citi.reghub.xm.consumer.topology.entity;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.xm.consumer.validator.EntityNullValidator;
import com.citi.reghub.xm.consumer.validator.TupleNullValidator;
import com.citi.reghub.xm.consumer.validator.ValidatorManager;

public class InitNackBolt extends RegHubBolt {

	protected static final Logger LOG = LoggerFactory.getLogger(InitNackBolt.class);
	private static final long serialVersionUID = 1L;
	private transient OutputCollector collector;
	private transient ValidatorManager manager;

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector outputCollector) {
		this.collector = outputCollector;

		manager = new ValidatorManager(stormConf, context, outputCollector);
		manager.addValidator(TupleNullValidator.class);
		manager.addValidator(EntityNullValidator.class);
	}

	@Override
	public void process(Tuple input) throws Exception {
		if (!manager.validate(input)) {
			return;
		}

		Entity entity = (Entity) input.getValueByField("message");

		if (entity != null && entity.stream != null && entity.status != null
				&& entity.status.equals(EntityStatus.REJECTED)) {
			LOG.info("Nack entity was detected: {}", entity);
			collector.emit(StormStreams.PARTIAL_UPDATE_STREAM_NAME, new Values(entity.regHubId, entity));
		}

		collector.ack(input);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.PARTIAL_UPDATE_STREAM_NAME, new Fields(TUPLE_KEY, TUPLE_MESSAGE));

	}

	@Override
	public OutputCollector getCollector() {
		return this.collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return null;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		return Collections.emptyList();          
	}

}