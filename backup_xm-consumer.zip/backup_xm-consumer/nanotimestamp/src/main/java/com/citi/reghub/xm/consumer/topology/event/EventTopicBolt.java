package com.citi.reghub.xm.consumer.topology.event;


import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.xm.consumer.topology.XmBolt;
import com.citi.reghub.xm.consumer.validator.EventEnvelopeNullValidator;
import com.citi.reghub.xm.consumer.validator.TupleNullValidator;
import com.citi.reghub.xm.consumer.validator.ValidatorManager;

public class EventTopicBolt extends XmBolt {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(EventTopicBolt.class);
	private static final long serialVersionUID = 1L;
	
	private transient ValidatorManager manager;

	@Override
	public void process(Tuple input) throws Exception {
		if (!manager.validate(input)) {
			return;
		}

		EventEnvelope envelope = (EventEnvelope) input.getValueByField("message");
		LOGGER.info("EventTopicBolt envelope =  {}", envelope);
		getCollector().emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Values(envelope.getEventData(), envelope.getEventData()));
	}

	@SuppressWarnings({ "rawtypes"})
	@Override
	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		super.prepareBolt(config, topologyContext, outputCollector);

		manager = new ValidatorManager(config, topologyContext, outputCollector);
		manager.addValidator(TupleNullValidator.class);
		manager.addValidator(EventEnvelopeNullValidator.class);
	}
}
