package com.citi.reghub.xm.consumer.validator;

import static org.mockito.Mockito.mock;

import org.apache.storm.tuple.Tuple;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TupleNullValidatorTest {
	private TupleNullValidator validator;
	private Tuple tuple = mock(Tuple.class);

	@Before
	public void init() {
		validator = new TupleNullValidator();
	}

	@Test
	public void testValidate() {
		boolean valid = validator.validate(tuple);

		Assert.assertTrue(valid);
	}
}
