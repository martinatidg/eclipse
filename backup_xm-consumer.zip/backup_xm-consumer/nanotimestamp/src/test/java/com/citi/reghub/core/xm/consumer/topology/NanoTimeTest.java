package com.citi.reghub.core.xm.consumer.topology;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.xm.consumer.topology.NanoTime;

public class NanoTimeTest {
	@Test
	public void testGetCurrentTimestamp() {
		
	}

	@Test
	public void testGetTimestamp() {
		
	}
}
