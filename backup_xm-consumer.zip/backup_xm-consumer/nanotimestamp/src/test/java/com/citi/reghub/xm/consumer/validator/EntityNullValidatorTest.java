package com.citi.reghub.xm.consumer.validator;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.storm.tuple.Tuple;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;

public class EntityNullValidatorTest {
	private EntityNullValidator validator;

	private Tuple tuple = mock(Tuple.class);
	private Object entity = mock(Entity.class);

	@Before
	public void init() {
		validator = new EntityNullValidator();
		entity = new EntityBuilder().build();
	}

	@Test
	public void testValidate() {
		when(tuple.getValueByField("message")).thenReturn(entity);
		boolean valid = validator.validate(tuple);

		Assert.assertTrue(valid);
	}
}
