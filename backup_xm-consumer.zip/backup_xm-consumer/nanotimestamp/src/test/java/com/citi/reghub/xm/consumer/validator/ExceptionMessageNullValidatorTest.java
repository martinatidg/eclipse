package com.citi.reghub.xm.consumer.validator;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.storm.tuple.Tuple;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.xm.consumer.topology.entity.EntityExceptionWrapper;

public class ExceptionMessageNullValidatorTest {
	private ExceptionMessageNullValidator validator;

	private Tuple tuple = mock(Tuple.class);
	private EventEnvelope envelope = mock(EventEnvelope.class);
	private ExceptionMessage exMessage = mock(ExceptionMessage.class);
	private EntityExceptionWrapper wrapper = mock(EntityExceptionWrapper.class);


	@Before
	public void init() {
		validator = new ExceptionMessageNullValidator();

	}

	@Test
	public void testValidateEnvelope() {
		when(tuple.getValueByField("message")).thenReturn(envelope);
		when(envelope.getEventData()).thenReturn(exMessage);
		when(exMessage.getRegHubId()).thenReturn("RegHubId");
		
		boolean valid = validator.validate(tuple);

		Assert.assertTrue(valid);
	}

	@Test
	public void testValidateEnvelopeFalse() {
		when(tuple.getValueByField("message")).thenReturn(wrapper);
		when(envelope.getEventData()).thenReturn(exMessage);
		when(exMessage.getRegHubId()).thenReturn("RegHubId");
		
		boolean valid = validator.validate(tuple);

		Assert.assertFalse(valid);
	}

	@Test
	public void testValidateWrapper() {
		when(tuple.getValueByField("message")).thenReturn(wrapper);
		when(wrapper.getExceptionMessage()).thenReturn(exMessage);
		when(exMessage.getRegHubId()).thenReturn("RegHubId");
		
		boolean valid = validator.validate(tuple);

		Assert.assertTrue(valid);
	}

	@Test
	public void testValidateWrapperFalse() {
		when(tuple.getValueByField("message")).thenReturn(envelope);
		when(wrapper.getExceptionMessage()).thenReturn(exMessage);
		when(exMessage.getRegHubId()).thenReturn("RegHubId");
		
		boolean valid = validator.validate(tuple);

		Assert.assertFalse(valid);
	}
}
