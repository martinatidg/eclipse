package com.citi.reghub.xm.consumer.validator;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.tuple.Tuple;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;


public class EntityValidatorTest {
	private static final String XM_ENABLED_STREAMS = "xm.enabled.streams";
	private EntitySpecificValidator validator;

	private Entity entity;

	@Before
	public void init() {
		validator = new EntitySpecificValidator();
		String streams = "m2post,stream1,    stream2, stream3";
		Map config = new HashMap();
		config.put(XM_ENABLED_STREAMS, streams);
		validator.init(config, null, null);
	}

	@Test
	public void testIsValidStream() {
		String streams = "m2post,stream1,    stream2, stream3";
		Map config = new HashMap();
		config.put(XM_ENABLED_STREAMS, streams);
		validator.init(config, null, null);

		boolean valid = validator.isValidStream("m2post");
		Assert.assertTrue(valid);

		valid = validator.isValidStream("stream2");
		Assert.assertTrue(valid);

		valid = validator.isValidStream("stream2 ");
		Assert.assertFalse(valid);

		valid = validator.isValidStream("stream2.");
		Assert.assertFalse(valid);
	}

	@Test
	public void testIsValidStreamNull() {
		String streams = null;
		Map config = new HashMap();
		config.put(XM_ENABLED_STREAMS, streams);
		validator.init(config, null, null);

		boolean valid = validator.isValidStream("m2post");
		Assert.assertFalse(valid);

		valid = validator.isValidStream("stream2");
		Assert.assertFalse(valid);

		valid = validator.isValidStream("stream2 ");
		Assert.assertFalse(valid);

		valid = validator.isValidStream("stream2.");
		Assert.assertFalse(valid);
	}

	@Test
	public void testValidateTrue() {
		String streams = "m2post,stream1,    stream2, stream3";
		Map config = new HashMap();
		config.put(XM_ENABLED_STREAMS, streams);
		validator.init(config, null, null);

		entity = new EntityBuilder().stream("m2post").build();
		Tuple t = mock(Tuple.class);
		when(t.getValueByField("message")).thenReturn(entity);

		boolean valid = validator.validate(t);
		Assert.assertTrue(valid);
	}

	@Test
	public void testValidateFalse() {
		String streams = "m2post,stream1,    stream2, stream3";
		Map config = new HashMap();
		config.put(XM_ENABLED_STREAMS, streams);
		validator.init(config, null, null);

		entity = new EntityBuilder().stream("m2posttt").build();
		Tuple t = mock(Tuple.class);
		when(t.getValueByField("message")).thenReturn(entity);

		boolean valid = validator.validate(t);
		Assert.assertFalse(valid);
	}
}
