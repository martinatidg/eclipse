package com.citi.reghub.xm.consumer.validator;

import java.util.Map;
import java.util.Optional;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.EventData;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.xm.consumer.topology.entity.EntityExceptionWrapper;

public class ExceptionMessageNullValidator implements Validator<Tuple> {
	protected static final Logger LOG = LoggerFactory.getLogger(TupleNullValidator.class);
	private OutputCollector collector;

	@SuppressWarnings({"all"})
	@Override
	public boolean validate(Tuple tuple) {
		Optional<EventData> envelopeMsgOpt = Optional.ofNullable(tuple).flatMap((Tuple t) -> {
			Optional<EventEnvelope> enveOpt;
			try {
				enveOpt = Optional.ofNullable((EventEnvelope) t.getValueByField("message"));
			} catch (ClassCastException e) {
				enveOpt = Optional.empty();
			}
			return enveOpt;
		}).map(EventEnvelope::getEventData);

		Optional<ExceptionMessage> wrapperMsgOpt = Optional.ofNullable(tuple).flatMap((Tuple t) -> {
			Optional<EntityExceptionWrapper> wrapperOpt;
			try {
				wrapperOpt = Optional.ofNullable((EntityExceptionWrapper) t.getValueByField("message"));
			} catch (ClassCastException e) {
				wrapperOpt = Optional.empty();
			}

			return wrapperOpt;

		}).map(EntityExceptionWrapper::getExceptionMessage);

		Optional<String> envRegHubId = Optional.empty();
		Optional<String> wrapperRegHubId = Optional.empty();

		if(envelopeMsgOpt.isPresent()) {
			envRegHubId = Optional.ofNullable(((ExceptionMessage) envelopeMsgOpt.get()).getRegHubId());
		}

		if(wrapperMsgOpt.isPresent()) {
			wrapperRegHubId = Optional.ofNullable(wrapperMsgOpt.get().getRegHubId());
		}
		return (envelopeMsgOpt.isPresent()&& envRegHubId.isPresent()) || ( wrapperMsgOpt.isPresent() && wrapperRegHubId.isPresent());
	}

	@Override
	public void handle(Tuple tuple) {
		collector.ack(tuple);
	}

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void init(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		this.collector = outputCollector;
	}
}
