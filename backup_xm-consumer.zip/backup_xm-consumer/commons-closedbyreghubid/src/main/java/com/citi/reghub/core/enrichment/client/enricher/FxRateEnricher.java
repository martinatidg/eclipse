package com.citi.reghub.core.enrichment.client.enricher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.rules.client.DroolsEngine;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;

public class FxRateEnricher extends Enricher {

	private static final Logger LOGGER = LoggerFactory.getLogger(FxRateEnricher.class);
	
	private static final String ALL_STREAM = "all";
	
	private static final String ALL_FLOW = "all";

	@SuppressWarnings({"unchecked" })
	private Map<String, Object> getData(String lookupKey) {
		Map<String, Object> data = (HashMap<String, Object>)clientConfig.getMetadataClient().get(lookupKey,ALL_STREAM, ALL_FLOW);
		if(data == null) {
			data = new HashMap<>();
		}
		return data;
	}

	public EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefereshCache) {
		LOGGER.debug("processing enrich, request with enricherConfig='{}', root='{}', forceRefreshCache='{}' initiated", enricherConfig, root, forceRefereshCache);
		Map<String, Object> metadata= getData((String)enricherConfig.configuration.get("lookupKey"));
		Rule enrichmentRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName, (String)enricherConfig.configuration.get(UPDATE_DEFINITION), null, new ArrayList<>());
		RuleResult ruleResult =  DroolsEngine.getEngine().execute(enrichmentRule, root, metadata,forceRefereshCache);
		return new EnricherResult(ruleResult.ruleName, ruleResult.comments, ruleResult.value);
	}

}
