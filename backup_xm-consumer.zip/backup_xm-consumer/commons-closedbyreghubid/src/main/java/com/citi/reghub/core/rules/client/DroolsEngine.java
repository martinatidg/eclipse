package com.citi.reghub.core.rules.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DroolsEngine {

    private static final Logger LOGGER = LoggerFactory.getLogger(DroolsEngine.class);
    private static DroolsEngine ENGINE;

    private Map<String, KieBase> cachedRules = new ConcurrentHashMap<String, KieBase>();

    public static DroolsEngine getEngine() {
    	if (ENGINE != null) {
    		return ENGINE;
    	}
    	
    	synchronized(DroolsEngine.class) {
            if (ENGINE == null) {
            	ENGINE = new DroolsEngine();
            }
    	}
    	
        return ENGINE;
    }

    public RuleResult execute(Rule rule, Object root, Map<String,Object> data, boolean forceRefreshCache) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing excute, request with rule='{}', root='{}', data='{}', cacheRefresh='{}'", rule, root, data, forceRefreshCache);
    	}

    	RuleResult result = new RuleResult(rule.name);

        List<Object> values = new ArrayList<>();
        values.add(data);
        values.add(root);
        values.add(result);

        KieBase kbase = getKieBase(rule, forceRefreshCache);
        kbase.newStatelessKieSession().execute(values);
        
        return result;
    }
    
    private final KieBase getKieBase(Rule r, boolean forceRefreshCache) {
    	KieBase kb = cachedRules.get(r.name);
    	
        if (forceRefreshCache || kb == null) {
        	synchronized(this) {
            	String rname = r.name;
                if (forceRefreshCache || cachedRules.get(rname) == null) {
		            KieServices kieServices = KieServices.Factory.get();
		            KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
		            kieFileSystem.write("src/main/resources/com/citi/reghub/" + rname + ".drl", r.getBase64DecodedDefinition());
		            KieBuilder kbuilder = kieServices.newKieBuilder(kieFileSystem);
		            kbuilder.buildAll();
		            if (kbuilder.getResults().hasMessages(Message.Level.ERROR)) {
		                throw new RuntimeException("Error building drools rule: " + kbuilder.getResults().toString());
		            }
		            KieContainer kContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
		            kb = kContainer.getKieBase();
		            cachedRules.put(rname, kb);
                }
        	}
        } 

        return kb;
    }
}
