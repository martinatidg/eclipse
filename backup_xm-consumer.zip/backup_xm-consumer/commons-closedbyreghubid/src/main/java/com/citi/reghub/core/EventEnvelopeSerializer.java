package com.citi.reghub.core;

import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.Note;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.ByteBufferOutput;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;
import com.esotericsoftware.kryo.serializers.FieldSerializer;

public class EventEnvelopeSerializer implements Serializer<EventEnvelope>, Deserializer<EventEnvelope> {
	private static final Logger LOGGER = LoggerFactory.getLogger(EventEnvelopeSerializer.class);
	private ThreadLocal<Kryo> kryos = new ThreadLocal<Kryo>() {
		@Override
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			kryo.getFieldSerializerConfig()
					.setCachedFieldNameStrategy(FieldSerializer.CachedFieldNameStrategy.EXTENDED);
			CompatibleFieldSerializer<EventEnvelope> serializer = new CompatibleFieldSerializer<EventEnvelope>(kryo,
					EventEnvelope.class);

			CompatibleFieldSerializer<ExceptionMessage> serializerExceptionMessage = new CompatibleFieldSerializer<ExceptionMessage>(
					kryo, ExceptionMessage.class);
			CompatibleFieldSerializer<Note> serializerNote = new CompatibleFieldSerializer<Note>(kryo, Note.class);

			kryo.register(EventEnvelope.class, serializer);
			kryo.register(ExceptionMessage.class, serializerExceptionMessage);
			kryo.register(Note.class, serializerNote);
			return kryo;
		}
	};

	public EventEnvelope deserialize(String arg0, byte[] bytes) {
		try {
			Input input = new Input(bytes);
			EventEnvelope audit = ((Kryo) kryos.get()).readObject(input, EventEnvelope.class);
			input.close();
			return audit;
		} catch (Exception e) {
			LOGGER.error("Cannot desirialize due to: {}", e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public void close() {
		LOGGER.info("This method is not implemented.");
	}

	public void configure(Map<String, ?> arg0, boolean arg1) {
		LOGGER.info("This method is not implemented.");
	}

	public byte[] serialize(String arg0, EventEnvelope eventMsg) {
		Output output = new ByteBufferOutput(24576); // Setting buffer size 24KB
		kryos.get().writeObject(output, eventMsg);
		output.flush();
		return output.toBytes();
	}

}
