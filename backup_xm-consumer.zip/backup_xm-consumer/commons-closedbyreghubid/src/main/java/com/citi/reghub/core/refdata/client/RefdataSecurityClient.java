package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.dataobject.product.OceanProductSummary;
import com.citi.reghub.core.CommonUtils;

public class RefdataSecurityClient implements RefdataInterface {

	public static Logger LOGGER = LoggerFactory.getLogger(RefdataSecurityClient.class);

	private final OceanGemfireCacheClient oceanGemfireCacheClient;

	public RefdataSecurityClient(final OceanGemfireCacheClient oceanGemfireCacheClient) {
		this.oceanGemfireCacheClient = oceanGemfireCacheClient;
	}

	private Map<String, Object> getSecurityDetailsByOceanId(Object oceanId) {
		Long identifierValue = Long.parseLong(oceanId.toString());
		OceanProductSummary resp = oceanGemfireCacheClient.getByOceanProductId(identifierValue);
		return CommonUtils.objectToMap(resp);
	}

	private Map<String, Object> getSecurityDetailsByFII(Object fii) {
		Long identifierValue = Long.parseLong(fii.toString());
		OceanProductSummary fiiInfo = oceanGemfireCacheClient.getProductsByFII(identifierValue);
		return CommonUtils.objectToMap(fiiInfo);
	}

	private Map<String, Object> getSecurityDetailsByISIN(Object isin) {
		OceanProductSummary isinInfo = oceanGemfireCacheClient.getProductsByISIN(isin.toString());
		return CommonUtils.objectToMap(isinInfo);
	}

	private Map<String, Object> getSecurityDetailsByCUSIP(Object cusip) {
		OceanProductSummary cusipInfo = oceanGemfireCacheClient.getProductsByCUSIP(cusip.toString());
		return CommonUtils.objectToMap(cusipInfo);
	}

	private Map<String, Object> getSecurityDetailsBySMCP(Object smcp) {
		OceanProductSummary smcpSummary = oceanGemfireCacheClient.getProductsBySMCP(smcp.toString());
		return CommonUtils.objectToMap(smcpSummary);
	}

	private Map<String, Object> getSecurityDetailsByRIC(Object ric) {
		OceanProductSummary ricSummary = oceanGemfireCacheClient.getProductsByRIC(ric.toString());
		return CommonUtils.objectToMap(ricSummary);
	}

	@Override
	public Map<String, Object> getData(String identifier, Object value) {
		try {
			SecurityIdentifier inputIdentifier = SecurityIdentifier.valueOf(identifier.toUpperCase());
			
			switch (inputIdentifier) {
				case SMCP:
					return getSecurityDetailsBySMCP(value);
				case ISIN:
					return getSecurityDetailsByISIN(value);
				case FII:
					return getSecurityDetailsByFII(value);
				case CUSIP:
					return getSecurityDetailsByCUSIP(value);
				case OCEAN_ID:
					return getSecurityDetailsByOceanId(value);
				case RIC:
					return getSecurityDetailsByRIC(value);
			}
			return null;
		} catch (IllegalArgumentException e) {
			LOGGER.error("Invalid input Security Identifier: '{}'", identifier, e);
			throw new RuntimeException("Invalid input Security Identifier: " + identifier + " supported Security Identifier are " + SecurityIdentifier.values().toString());
		}	
		
	}
}
