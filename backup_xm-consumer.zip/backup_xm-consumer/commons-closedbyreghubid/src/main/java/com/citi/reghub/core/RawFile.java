package com.citi.reghub.core;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.UUID;

public class RawFile  {

	private String _id;
	
	private String stream;
	private String flow;
	private String sendTo;
	private String recivedFrom;
	
	private LocalDateTime logTs;
	private String fileName;
	private String extension;
	private byte[] content;

	public RawFile(){
		_id = UUID.randomUUID().toString();
	}

	public RawFile(String name, String ext, byte[] is){
		_id = UUID.randomUUID().toString();
		this.logTs = LocalDateTime.now(Clock.systemUTC());
		this.fileName=name;
		this.extension=ext;
		this.content=is;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public String getSendTo() {
		return sendTo;
	}

	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	public String getRecivedFrom() {
		return recivedFrom;
	}

	public void setRecivedFrom(String recivedFrom) {
		this.recivedFrom = recivedFrom;
	}

	public String get_id() {
		return _id;
	}

	public LocalDateTime getLogTs() {
		return logTs;
	}

	public String getFileName() {
		return fileName;
	}

	public String getExtension() {
		return extension;
	}

	public byte[] getContent() {
		return content;
	}


}
