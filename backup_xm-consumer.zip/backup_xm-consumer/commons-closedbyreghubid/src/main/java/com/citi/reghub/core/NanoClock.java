package com.citi.reghub.core;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class NanoClock extends Clock {
	
	private final Clock clock;

	private final long initialNanos;

	private final Instant initialInstant;

	public NanoClock() {
		this(Clock.systemUTC());
	}

	public NanoClock(final Clock clock) {
		this.clock = clock;
		initialInstant = clock.instant();
		initialNanos = getSystemNanos();
	}

	@Override
	public ZoneId getZone() {
		return clock.getZone();
	}

	@Override
	public Instant instant() {
		return initialInstant.plusNanos(getSystemNanos() - initialNanos);
	}

	@Override
	public Clock withZone(final ZoneId zone) {
		return new NanoClock(clock.withZone(zone));
	}

	public LocalDateTime now() {
		LocalDateTime ldt = LocalDateTime.ofInstant(instant(), getZone());
		return ldt.withNano(instant().getNano());
	}
	
	private long getSystemNanos() {
		return System.nanoTime();
	}
}
