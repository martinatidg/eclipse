package com.citi.reghub.core.enrichment.client;

import java.util.HashMap;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.hrmstrader.client.HrmsTraderClient;
import com.citi.reghub.core.metadata.client.MetadataClient;
import com.citi.reghub.core.refdata.client.RefdataClient;

public class EnrichmentClientConfig extends HashMap<String, Object>{

	private static final long serialVersionUID = 1L;
	public static final String REST_CLIENT = "restClient";
	public static final String METADATA_CLIENT = "metadataClient";
	public static final String REFDATA_CLIENT = "refdataClient";
	public static final String CACHE_CLIENT = "cacheClient";
	public static final String HRMS_TRADER_CLIENT = "hrmsTraderClient";
    public static final String ENRICHMENT_PLAN_SERVICE_URL = "enrichmentPlanUrl";
    public static final String ENRICHMENT_PLAN_SERVICE_URL_VALUE = "http://localhost:8081/reghub-api/enricher-service/enricher-graphs/%s/details";
	
    
    public String getEnrichmentPlanServiceUrl() {
        return (String) get(ENRICHMENT_PLAN_SERVICE_URL);
    }
    
    public void setEnrichmentPlanServiceUrl(String url) {
        put(ENRICHMENT_PLAN_SERVICE_URL, url);
    }
    
    public void setDefaultEnrichmentPlanServiceUrl() {
        put(ENRICHMENT_PLAN_SERVICE_URL, ENRICHMENT_PLAN_SERVICE_URL_VALUE);
    }
    
    public RestClient getRestClient() {
        return (RestClient) get(REST_CLIENT);
    }
    
    public MetadataClient getMetadataClient() {
    	return (MetadataClient) get(METADATA_CLIENT);
    }
    
    public RefdataClient getRefDataClient() {
    	return (RefdataClient) get(REFDATA_CLIENT);
    }
    
    public CacheClient getCacheClient(){
    	return (CacheClient)get(CACHE_CLIENT);
    }
   
    public HrmsTraderClient getHrmsTraderClient() {
		return (HrmsTraderClient) get(HRMS_TRADER_CLIENT);
	}
    
    public EnrichmentClientConfig set(String key,Object value){
        put(key,value);
        return this;
    }
}
