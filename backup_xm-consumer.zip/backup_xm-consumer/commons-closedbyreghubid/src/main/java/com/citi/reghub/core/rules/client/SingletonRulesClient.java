package com.citi.reghub.core.rules.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonRulesClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonRulesClient.class);
	private static RulesClient CLIENT;

	public static RulesClient getInstance() {
		if (CLIENT == null) {
			LOGGER.error("RulesClient instance='{}'", CLIENT, new RuntimeException("Instance of RulesClient  is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonRulesClient");
		}
		return CLIENT;
	}

	public static void setInstance(RulesClientConfig config) {
		CLIENT = new RulesClient(config);
	}

	public static void setInstance(RulesClient rulesClient) {
		CLIENT = rulesClient;
	}
}
