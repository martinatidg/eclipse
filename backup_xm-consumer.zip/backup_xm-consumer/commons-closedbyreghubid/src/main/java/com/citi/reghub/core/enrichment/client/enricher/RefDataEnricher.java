package com.citi.reghub.core.enrichment.client.enricher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.refdata.client.Refdata;
import com.citi.reghub.core.refdata.client.RefdataClient;
import com.citi.reghub.core.rules.client.DroolsEngine;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;

public class RefDataEnricher extends Enricher {

	public static final String LOOK_UP_TYPE = "lookupType";
	public static final String LOOK_UP_KEY_DEFINITION = "lookupKeyDefinition";

	private static final Logger LOGGER = LoggerFactory.getLogger(RefDataEnricher.class);

	private Map<String, Object> getData(String lookupType, Map<String, Object> input) {
		LOGGER.debug("Processing getData, request with lookupType='{}', input='{}'", lookupType, input);

		RefdataClient refdataClient = clientConfig.getRefDataClient();
		Map<String, Object> result = new HashMap<>();

		String lookupKeyType = (String) input.get("lookupKeyType");
		Object lookupKeyValue = input.get("lookupKeyValue");

		Refdata response = refdataClient.getDetails(lookupType, lookupKeyType, lookupKeyValue);
		if (response != null) {
			result.put(response.getType(), response.getData());
		}
		return result;
	}

	@Override
	public EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefereshCache) {

		LOGGER.debug("processing enrich, request with enricherConfig='{}', root='{}', forceRefreshCache='{}' initiated",
				enricherConfig, root, forceRefereshCache);
		Rule lookupKeyRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName + "_lookup",
				(String) enricherConfig.configuration.get(LOOK_UP_KEY_DEFINITION), null, new ArrayList<>());
		Map<String, Object> metadata = new HashMap<String, Object>();

		try {
			
			RuleResult keyLookUpRuleResult = DroolsEngine.getEngine().execute(lookupKeyRule, root, metadata,
					forceRefereshCache);

			if (keyLookUpRuleResult.value == null) {
				((Entity)root).info.put(enricherConfig.enricherName, "false");
				return new EnricherResult(keyLookUpRuleResult.ruleName, "Enrichment lookup rule failed, skiping enrichment.",
						keyLookUpRuleResult.value);
			}
			Map<String, Object> refdata = getData((String) enricherConfig.configuration.get(LOOK_UP_TYPE),
					(HashMap<String, Object>) keyLookUpRuleResult.value);

			Rule enrichmentRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName,
					(String) enricherConfig.configuration.get(UPDATE_DEFINITION), null, new ArrayList<>());
			RuleResult enrichmentRuleResult = DroolsEngine.getEngine().execute(enrichmentRule, root, refdata,
					forceRefereshCache);
			((Entity)root).info.put(enricherConfig.enricherName, "true");

			return new EnricherResult(enrichmentRuleResult.ruleName, enrichmentRuleResult.comments,
					enrichmentRuleResult.value);
		} catch (Throwable t) {
			LOGGER.error(t.getMessage());
			((Entity)root).info.put(enricherConfig.enricherName, "false");
			return new EnricherResult(enricherConfig.enricherName, t.getMessage(), null);
		}

	}

}
