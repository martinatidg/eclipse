package com.citi.reghub.core.event.exception;

import java.util.List;
import java.util.Map;

import com.citi.reghub.core.event.EventData;

public class ExceptionMessage implements EventData {

	private static final long serialVersionUID = 1L;

	private String id;
	private String sourceId;
	private String regHubId;
	private String regReportingRef; // from Entity record: used as reporting id
									// for trade/quote/order/transaction e.g.
									// stream + flow + sourceId
	private String stream;
	private String flow;
	private String sourceSystem;
	private String reasonCode;
	private String ruleVersion;
	private String description;
	private String displayErrorCode;
	private String nackSource;
	private boolean xstreamEligible;
	private List<Note> notes;
	private Map<String, Object> attributes;
	private long requestedTS;
	private long createdTS;
	private long updatedTS;
	private String updatedSource; // UI, X-STREAM, ARM

	private ExceptionStatus status;
	private FunctionalOwner functionalOwner; // BUS, TECH, SMC, AMC, ORC
	private ExceptionType type;
	private ExceptionLevel level;

	private String closedByRegHubId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getRegReportingRef() {
		return regReportingRef;
	}

	public void setRegReportingRef(String regReportingRef) {
		this.regReportingRef = regReportingRef;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public ExceptionStatus getStatus() {
		return status;
	}

	public void setStatus(ExceptionStatus status) {
		this.status = status;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getRuleVersion() {
		return ruleVersion;
	}

	public void setRuleVersion(String ruleVersion) {
		this.ruleVersion = ruleVersion;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayErrorCode() {
		return displayErrorCode;
	}

	public void setDisplayErrorCode(String displayErrorCode) {
		this.displayErrorCode = displayErrorCode;
	}

	public String getNackSource() {
		return nackSource;
	}

	public void setNackSource(String nackSource) {
		this.nackSource = nackSource;
	}

	public FunctionalOwner getFunctionalOwner() {
		return functionalOwner;
	}

	public void setFunctionalOwner(FunctionalOwner functionalOwner) {
		this.functionalOwner = functionalOwner;
	}

	public boolean isXstreamEligible() {
		return xstreamEligible;
	}

	public void setXstreamEligible(boolean xstreamEligible) {
		this.xstreamEligible = xstreamEligible;
	}

	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}

	public ExceptionType getType() {
		return type;
	}

	public void setType(ExceptionType type) {
		this.type = type;
	}

	public ExceptionLevel getLevel() {
		return level;
	}

	public void setLevel(ExceptionLevel level) {
		this.level = level;
	}

	public Map<String, Object> getAttributes() {
		return attributes;
	}

	public void setAttributes(Map<String, Object> attributes) {
		this.attributes = attributes;
	}

	public long getRequestedTS() {
		return requestedTS;
	}

	public void setRequestedTS(long requestedTS) {
		this.requestedTS = requestedTS;
	}

	public long getCreatedTS() {
		return createdTS;
	}

	public void setCreatedTS(long createdTS) {
		this.createdTS = createdTS;
	}

	public long getUpdatedTS() {
		return updatedTS;
	}

	public void setUpdatedTS(long updatedTS) {
		this.updatedTS = updatedTS;
	}

	public String getUpdatedSource() {
		return updatedSource;
	}

	public void setUpdatedSource(String updatedSource) {
		this.updatedSource = updatedSource;
	}

	public String getRegHubId() {
		return regHubId;
	}

	public void setRegHubId(String regHubId) {
		this.regHubId = regHubId;
	}

	public String getClosedByRegHubId() {
		return closedByRegHubId;
	}

	public void setClosedByRegHubId(String closedByRegHubId) {
		this.closedByRegHubId = closedByRegHubId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExceptionMessage other = (ExceptionMessage) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ExceptionMessage [id=" + id + ", sourceId=" + sourceId + ", regHubId=" + regHubId + ", regReportingRef="
				+ regReportingRef + ", stream=" + stream + ", flow=" + flow + ", sourceSystem=" + sourceSystem
				+ ", reasonCode=" + reasonCode + ", ruleVersion=" + ruleVersion + ", description=" + description
				+ ", displayErrorCode=" + displayErrorCode + ", nackSource=" + nackSource + ", xstreamEligible="
				+ xstreamEligible + ", notes=" + notes + ", attributes=" + attributes + ", requestedTS=" + requestedTS
				+ ", createdTS=" + createdTS + ", updatedTS=" + updatedTS + ", updatedSource=" + updatedSource
				+ ", status=" + status + ", functionalOwner=" + functionalOwner + ", type=" + type + ", level=" + level
				+ ", closedByRegHubId=" + closedByRegHubId + "]";
	}
}