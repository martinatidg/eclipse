package com.citi.reghub.core;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class Entity extends InfoablePojo {
	
	public String regHubId;				// reghub generated unique id for each message
	public String status;				// reghub reporting status e.g. REPORTABLE, NON_REPORTABLE, EXCEPTION, PENDING, REPORTED, REJECTED 
	public String stream;				// reporting stream (always 4 char) e.g. M2TR, M2PR, M2PO
	public String flow;					// reporting asset class / product (always 3 char) e.g. CEQ (cash equities), CFI (cash fixed income)
	
	public String sourceUId;			// unique id for a message received from source e.g. OceanId for transaction reporting
	public String sourceId;				// trade/quote/order id
	public String sourceVersion;		// trade/quote/order version
	public String sourceStatus;			// always normalised to NEW, AMEND and CANCEL
	public String sourceSystem;			// upstream source system generated the message e.g. TPS, PRIMO
	public String regReportingRef;		// used as reporting id for trade/quote/order/transaction e.g. stream + flow + sourceId
	public String correlationId;		// used as correlationId id for trade/quote/order/transaction e.g. stream+flow code + sourceId + time
	
	public LocalDateTime receivedTs;	// Time when entity is received in reghub
	public LocalDateTime publishedTs;	// trade activity time .i.r when this trade version was created
	public LocalDateTime executionTs;	// trade origination time
	public LocalDateTime lastUpdatedTs;	// timestamp of last activity in reghub, classical updated timestamp for reghub
	
	public List<String> reasonCodes = new ArrayList<String>();
	public List<String> flags = new ArrayList<String>();
	private boolean rdsEligible;  // flag that holds RDS Eligibility used by RDS Stream
	
	public boolean isRdsEligible() {
		return rdsEligible;
	}

	public void setRdsEligible(boolean rdsEligible) {
		this.rdsEligible = rdsEligible;
	}

	public Audit toAudit(){
		Audit audit = new Audit();
		audit.regHubId = this.regHubId;
		audit.stream = this.stream;
		audit.flow = this.flow;
		return audit;
	}

	public void generateRegReportingRef(){
		String executionDate = executionTs == null ? "null":executionTs.toLocalDate().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		String srcSystem = sourceSystem == null? "null" :sourceSystem.replaceAll("[^0-9a-zA-Z]", "");
		String tradeId = sourceId == null? "null" :sourceId.replaceAll("[^0-9a-zA-Z]", "");
		regReportingRef = flow + srcSystem + executionDate + tradeId;
		regReportingRef = regReportingRef.toUpperCase();
	}

	public void merge(Entity entity) {
		
		if(entity.status != null)
			this.status = entity.status;
		if(entity.sourceUId != null)
			this.sourceUId = entity.sourceUId;
		if(entity.sourceId != null)
			this.sourceId = entity.sourceId;
		if(entity.sourceVersion != null)
			this.sourceVersion = entity.sourceVersion;
		if(entity.sourceStatus != null)
			this.sourceStatus = entity.sourceStatus;
		if(entity.sourceSystem != null)
			this.sourceSystem = entity.sourceSystem;
		
		if(entity.publishedTs != null)
			this.publishedTs = entity.publishedTs;
		if(entity.executionTs != null)
			this.executionTs = entity.executionTs;
		if(entity.lastUpdatedTs != null)
			this.lastUpdatedTs = entity.lastUpdatedTs;
		
		this.rdsEligible = entity.rdsEligible;
		
		if(entity.flags != null && entity.flags.size() > 0) {
			entity.flags.forEach(flag -> {
								if (!this.flags.contains(flag))
									this.flags.add(flag);
								});
		}
		
		if(entity.reasonCodes != null && entity.reasonCodes.size() > 0) {
			entity.reasonCodes.forEach(reasonCode -> {
								if (!this.reasonCodes.contains(reasonCode))
									this.reasonCodes.add(reasonCode);
								});
		}
		
		if (entity.info != null && entity.info.size() > 0) {
			deepMerge(this.info , entity.info);
		}
	}
	
	public Map deepMerge(Map original, Map newMap) {
	    for (Object key : newMap.keySet()) {
	        if (newMap.get(key) instanceof Map && original.get(key) instanceof Map) {
	            Map originalChild = (Map) original.get(key);
	            Map newChild = (Map) newMap.get(key);
	            original.put(key, deepMerge(originalChild, newChild));
	        } else {
	            original.put(key, newMap.get(key));
	        }
	    }
	    return original;
	}
	
	public final boolean isStatus(String s) {
		return StringUtils.equalsIgnoreCase(this.status, s);
	}
	
	public final boolean isSourceStatus(String s) {
		return StringUtils.equalsIgnoreCase(this.sourceStatus, s);
	}
}

