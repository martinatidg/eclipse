package com.citi.reghub.core.enrichment.client.enricher;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.enrichment.client.EnrichmentClientConfig;

public abstract class Enricher {
	
	public static final String UPDATE_DEFINITION = "updateDefinition";
	
	EnrichmentClientConfig clientConfig;
	
	public Enricher setConfig(EnrichmentClientConfig config) {
		this.clientConfig = config;
		return this;
	}
	
	public abstract EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefreshCache);
}
