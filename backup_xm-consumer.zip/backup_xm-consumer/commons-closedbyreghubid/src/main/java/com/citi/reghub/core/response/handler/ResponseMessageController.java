package com.citi.reghub.core.response.handler;

import java.util.List;

import com.citi.reghub.core.Audit;

public interface ResponseMessageController {

	public ResponseMessageParser getParser(String fixMessage);
	
	public void process(ParsedResponseBundle prb);
	
	public Audit getRejectionAudit(ParsedResponseBundle prb, String event, List<String> exceptionTags);
}
