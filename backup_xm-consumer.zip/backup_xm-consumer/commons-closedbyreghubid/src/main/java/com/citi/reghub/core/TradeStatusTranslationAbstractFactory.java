package com.citi.reghub.core;

import java.io.Serializable;

public abstract class TradeStatusTranslationAbstractFactory implements Serializable{
	
	public abstract TradeStatusTranslator getTranslator(Entity inputEntity);
	public abstract void addTranslator(String identifier, TradeStatusTranslator statusTranslator);

}
