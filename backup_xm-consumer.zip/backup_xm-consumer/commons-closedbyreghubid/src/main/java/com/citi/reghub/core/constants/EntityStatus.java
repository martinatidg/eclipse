package com.citi.reghub.core.constants;

public interface EntityStatus {
	
	String REPORTABLE = "REPORTABLE";
	String PENDING = "PENDING";
	String NON_REPORTABLE = "NON_REPORTABLE";
	String BIZ_EXCEPTION = "BIZ_EXCEPTION";
	String TECH_EXCEPTION = "TECH_EXCEPTION";
	String APP_EXCEPTION = "APP_EXCEPTION";
	String REPORTED = "REPORTED";
	String REJECTED = "REJECTED";
	String REPLAYED = "REPLAYED";
	String ACCEPTED = "ACCEPTED";
	
}