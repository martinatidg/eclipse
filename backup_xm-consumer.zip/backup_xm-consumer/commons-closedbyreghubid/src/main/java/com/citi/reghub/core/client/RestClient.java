package com.citi.reghub.core.client;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.CustomConversionsModule;
import com.citi.reghub.core.converter.LongToLocalDateTimeDeserializer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;

public class RestClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestClient.class);
    private HttpClient client;
    private ObjectMapper mapper;

    public RestClient(HttpClient client) {
        this.client = client;
        this.mapper = new ObjectMapper();
        this.mapper.registerModules(new JSR310Module(), new CustomConversionsModule());
        this.mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        LOGGER.info("Instantiated Rest client instance with HttpClient='{}'", client);
    }

	public <T> T get(String url, Class<T> klass) {
        return (T) execute(new HttpGet(url), klass, false);
    }

	public <T> List<T> getValues(String url, Class<T> klass) {
        return (List<T>) execute(new HttpGet(url), klass, true);
    }

    public void doPost(Object payload, String url) throws JsonProcessingException {
        doPost(payload, url, HashMap.class, false);
        LOGGER.trace("doPost request has been processed successfully with payload='{}' and url='{}'", payload, url);
    }

	public  <T> List<T> doPostReturnValues(Object payload, String url, Class<T> klass) throws JsonProcessingException {
        return  (List<T>) doPost(payload, url, klass, true);
    }

	public <T> T doPost(Object payload, String url, Class<T> klass, boolean list) throws JsonProcessingException {
        HttpPost post = new HttpPost(url);
        post.addHeader("content-type", "application/json");
        String payloadAsString = mapper.writeValueAsString(payload);
        post.setEntity(new ByteArrayEntity(payloadAsString.getBytes()));
        return (T) execute(post, klass, list);
    }

    private <T> Object execute(HttpRequestBase request, Class<T> klass, boolean list) {
        String content = null;
        try {
            HttpResponse response = this.client.execute(request);
            if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
                LOGGER.error("Error response status='{}'", response.getStatusLine().getStatusCode());
                LOGGER.error("Error response='{}'", new BasicResponseHandler().handleResponse(response),
                		new RuntimeException("Error executing url=" + request.getURI()));
            }
            content = new BasicResponseHandler().handleResponse(response);
            if (list) return mapper.readValue(content,  mapper.getTypeFactory().constructCollectionType(List.class, klass));
            else return mapper.readValue(content, klass);
        } catch (Exception e) {
            LOGGER.error("Error parsing content='{}'", content,
            		new RuntimeException("Error executing url: " + request.getURI(), e));
            return null;
        }
    }
}
