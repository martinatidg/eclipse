package com.citi.reghub.core.cache.client;

import java.util.Map;

public interface CacheClient {
	
	public static final String CACHE_COLLECTION_TYPE = "cache.collection.type";
	public static final String CACHE_COLLECTION_NAME = "cache.collection.name";
	public static final String LOCK_TIMEOUT_VALUE = "cache.lock.timeout.value"; 
	public static final String LOCK_LEASE_TIME = "cache.lock.lease.time";
	public static final String PUT_IF_ABSENT = "putIfAbsent";
	public Object filter(String query, Map config);
	public Object get(Object key,Map config );
	public void put(Object key, Object value, Map config );
	public void destroy();
	public boolean tryLock(Object key, Map config);
	public void unlock(Object key, Map config) ;
	public boolean evictObject( Object key, Map config);
	public void evictCollection(Map config);

}
