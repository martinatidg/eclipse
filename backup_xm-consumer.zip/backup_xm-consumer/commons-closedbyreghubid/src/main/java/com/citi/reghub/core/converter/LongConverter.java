package com.citi.reghub.core.converter;

public class LongConverter implements TypeConverter<String, Long>{

	public Long convert(String obj,String format) {
		// TODO Auto-generated method stub
		return new Long(obj);
	}

}
