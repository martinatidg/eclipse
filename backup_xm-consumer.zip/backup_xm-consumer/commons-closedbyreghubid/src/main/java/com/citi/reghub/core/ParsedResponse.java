package com.citi.reghub.core;

import java.io.Serializable;

public class ParsedResponse implements Serializable {
	
	private static final long serialVersionUID = -4257290001467612407L;
	public String sourceId;
	public String ackId;
	public Integer trdRptStatus;
	public String stream;
	public String flow;
	public String rejectReasonCode;
	public String msgType;
	public Long sendTs;
	public String regReportingRef;
	public String rejectionMessage;
	public String rejectReason;
	public String tradeId;
	public String msgSeqNum;

	@Override
	public String toString() {
		return "ParsedResponse [sourceId=" + sourceId + ", ackId=" + ackId + ", trdRptStatus=" + trdRptStatus
				+ ", stream=" + stream + ", flow=" + flow + ", rejectReasonCode=" + rejectReasonCode + ", msgType="
				+ msgType + ", sendTs=" + sendTs + ", regReportingRef=" + regReportingRef + ", rejectionMessage="
				+ rejectionMessage + ", rejectReason=" + rejectReason + ", tradeId=" + tradeId + ", msgSeqNum="
				+ msgSeqNum + "]";
	}
}
