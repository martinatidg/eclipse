package com.citi.reghub.core.event.exception;

public enum NoteSource {
	CORE_UI("core-ui"),
	XSTREAM("xstream");

	final String value;

	NoteSource(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static NoteSource fromValue(String v) {
		for (NoteSource c : NoteSource.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
