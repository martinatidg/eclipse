package com.citi.reghub.core;

import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.CompatibleFieldSerializer;

public class EntityKafkaSerializerDeserializerTest {

	private StreamFactory sf;
	private Kryo kryo;

	@Before
	public void setup() {
		kryo = new Kryo();
		sf = new StreamFactory() {
			public Output createOutput(OutputStream os) {
				return new Output(os);
			}

			public Output createOutput(OutputStream os, int size) {
				return new Output(os, size);
			}

			public Output createOutput(int size, int limit) {
				return new Output(size, limit);
			}

			public Input createInput(InputStream os, int size) {
				return new Input(os, size);
			}

			public Input createInput(byte[] buffer) {
				return new Input(buffer);
			}
		};
	}

	@Test
	public void testSerializationDeserialization() {
		Entity entity = new EntityBuilder().build();
		entity.regHubId = "M2TRCSHEQ110789";

		EntityKafkaSerializerDeserializer serde = new EntityKafkaSerializerDeserializer();
		byte[] serBytes = serde.serialize("test_topic", entity);
		Entity newEntity = serde.deserialize("test_topic", serBytes);
		assertEquals(entity.regHubId, newEntity.regHubId);
	}

	@Test
	public void testEntityBackwardCompatibility() {
		CompatibleFieldSerializer<Entity> serializer = new CompatibleFieldSerializer<Entity>(kryo, Entity.class);

		Entity entity = new EntityBuilder().build();
		serializer.removeField("regHubId");
		kryo.register(Entity.class, serializer);

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		Output output = sf.createOutput(outStream, 4096);
		kryo.writeClassAndObject(output, entity);
		output.flush();

		byte[] out = outStream.toByteArray();
		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		Entity newEntity = (Entity) kryo.readClassAndObject(input);

		assertThat(entity.regHubId, not(newEntity.regHubId));

	}

	@Test
	public void testEntityBackwardCompatibilityUsingTwoEntities() {
		EntityOld entityOld = new EntityOld();
		entityOld.regHubId = "M2TRCSHEQ110789";

		// Serialize using Old Entity
		CompatibleFieldSerializer<EntityOld> serializerOld = new CompatibleFieldSerializer<EntityOld>(kryo,
				EntityOld.class);
		kryo.register(EntityOld.class, serializerOld);
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		Output output = sf.createOutput(outStream, 4096);
		kryo.writeObject(output, entityOld);
		output.flush();

		// Deserialize using new Entity
		CompatibleFieldSerializer<Entity> serializer = new CompatibleFieldSerializer<Entity>(kryo, Entity.class);
		kryo.register(Entity.class, serializer);
		byte[] out = outStream.toByteArray();
		Input input = sf.createInput(new ByteArrayInputStream(outStream.toByteArray()), 4096);
		Entity entityNew = (Entity) kryo.readObject(input, Entity.class);

		assertEquals(entityOld.regHubId, entityNew.regHubId);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEntityDeserilizationException() {
		Entity entity = new EntityBuilder().build();
		entity.regHubId = "M2TRCSHEQ110789";

		EntityKafkaSerializerDeserializer serde = new EntityKafkaSerializerDeserializer();
		byte[] serBytes = serde.serialize("test_topic", entity);
		Entity newEntity = serde.deserialize("test_topic",  new byte[4096]);
		assertEquals(entity.regHubId, newEntity.regHubId);

	}

	static interface StreamFactory {
		public Output createOutput(OutputStream os);

		public Output createOutput(OutputStream os, int size);

		public Output createOutput(int size, int limit);

		public Input createInput(InputStream os, int size);

		public Input createInput(byte[] buffer);
	}
}
