package com.citi.reghub.core.exception.client;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.fasterxml.jackson.core.JsonProcessingException;

public class ExceptionClientTest {
	
	static ExceptionClient client;
	static ExceptionClientConfig xmClientConfig;
	static RestClient restClient;
	
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
		restClient = mock(RestClient.class);
		xmClientConfig = new ExceptionClientConfig();
		xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, "http://localhost:8090/exceptions");
		xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, restClient);
		client = new ExceptionClient(xmClientConfig);
			
	}

		
	@Test
	public void getExceptionsFromServiceTest() {
		List<ExceptionMessage> exceptions = new ArrayList<>();
		exceptions.add(new ExceptionMessage());
		ExceptionsViewWrapper evw = new ExceptionsViewWrapper();
		evw.setExceptionsList(exceptions);
		evw.setTotalRecords(1);
		when(restClient.get("http://localhost:8090/exceptions",ExceptionsViewWrapper.class))
        .thenReturn(evw);
		List<ExceptionMessage> exceptionsResult = client.getExceptionsFromService();
		assertTrue(exceptionsResult.size() > 0);
	}

	@Test
	public void getExceptionsFromServiceById() throws JsonProcessingException {
		List<ExceptionMessage> exceptions = new ArrayList<ExceptionMessage>();
		ExceptionMessage exceptions1 = new ExceptionMessage();
		exceptions1.setId("1");
		exceptions.add(exceptions1);
		ExceptionsViewWrapper evw = new ExceptionsViewWrapper();
		evw.setExceptionsList(exceptions);
		evw.setTotalRecords(1);
		Map<String,String> map = new HashMap<>();
		map.put("id", "1");
		when(restClient.doPost(map,"http://localhost:8090/exceptions",ExceptionsViewWrapper.class,false))
        .thenReturn(evw);
		ExceptionMessage exceptionsResult;
		try {
			exceptionsResult = client.getExceptionsFromServiceById("1");
			assertTrue(exceptionsResult.getId().equals("1"));
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void getExceptionsFromServiceByFilter() {
		List<ExceptionMessage> exceptions = new ArrayList<>();
		ExceptionsViewWrapper evw = new ExceptionsViewWrapper();
		evw.setExceptionsList(exceptions);
		evw.setTotalRecords(0);
		List<ExceptionMessage> exceptionsResult;
		try {
			List<String> status = new ArrayList<>();
			status.add("CLOSED");
			Map<String, Object> filterBy = new HashMap<>();
			filterBy.put("status", status);
			when(restClient.doPost(filterBy,"http://localhost:8090/exceptions",ExceptionsViewWrapper.class, false))
	        .thenReturn(evw);
			exceptionsResult = client.getExceptionsByFilter(filterBy);
			assertTrue(exceptionsResult.isEmpty());
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void getExceptionsCountFromServiceByFilter() {
		
		ExceptionsViewWrapper evw = new ExceptionsViewWrapper();
		evw.setExceptionsList(null);
		evw.setTotalRecords(1);
		
		try {
			List<String> status = new ArrayList<>();
			status.add("CLOSED");
			Map<String, Object> filterBy = new HashMap<>();
			filterBy.put("status", status);
			when(restClient.doPost(filterBy,"http://localhost:8090/exceptions/count",ExceptionsViewWrapper.class, false))
	        .thenReturn(evw);
			long evwResult = client.getExceptionsCountByFilter(filterBy);
			assertTrue(evwResult == 1);
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void updateExceptionsStatusTest() {
		
		StatusUpdatePostResponse response = new StatusUpdatePostResponse();
		response.setSuccess(true);
		
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id","1");
			query.put("newStatus", "CLOSED");
			query.put("eventSource", "UI");
			
			when(restClient.doPost(query,"http://localhost:8090/exceptions/status",StatusUpdatePostResponse.class, false))
	        .thenReturn(response);
			boolean result = client.updateExceptionStatus("1", "CLOSED", "UI");
			assertTrue(result == true);
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}

	@Test(expected = RuntimeException.class)
	public void updateExceptionsStatusTestInvalid() {
		
		StatusUpdatePostResponse response = new StatusUpdatePostResponse();
		response.setSuccess(true);
		
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id","1");
			query.put("newStatus", "CLOSED");
			query.put("eventSource", "UI");
			
			when(restClient.doPost(query,"http://localhost:8090/exceptions/status",StatusUpdatePostResponse.class, false))
	        .thenReturn(null);

			boolean result = client.updateExceptionStatus("99999999", "CLOSED", "UI");
			
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void addExceptionNoteTest() {
		
		NotesUpdatePostResponse response = new NotesUpdatePostResponse();
		response.setSuccess(true);
		
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id","1");
			query.put("add", "true");
			query.put("note", "This is a note");
			query.put("source", "UI");
			query.put("createdBy", "Elan");
			
			when(restClient.doPost(query,"http://localhost:8090/exceptions/notes",NotesUpdatePostResponse.class, false))
	        .thenReturn(response);
			boolean result = client.addExceptionNote("1", "This is a note", "UI", "Elan");
			assertTrue(result == true);
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void deleteExceptionNoteTest() {
		
		NotesUpdatePostResponse response = new NotesUpdatePostResponse();
		response.setSuccess(true);
		
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id","1");
			query.put("add", "false");
			query.put("source", "UI");
			query.put("createdBy", "Elan");
			query.put("createdTS", "12345678");
			when(restClient.doPost(query,"http://localhost:8090/exceptions/notes",NotesUpdatePostResponse.class, false))
	        .thenReturn(response);
			boolean result = client.deleteExceptionNote("1", "UI", "Elan", 12345678);
			assertTrue(result == true);
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}
	
	@Test(expected = RuntimeException.class)
	public void addExceptionNoteInvalidIdTest() {
		
				
		try {
			Map<String, String> query = new HashMap<>();
			query.put("id","99999999");
			query.put("add", "true");
			query.put("note", "This is a note");
			query.put("source", "UI");
			query.put("createdBy", "Elan");
			
			when(restClient.doPost(query,"http://localhost:8090/exceptions/notes",NotesUpdatePostResponse.class, false))
	        .thenReturn(null);
			boolean result = client.addExceptionNote("99999999", "This is a note", "UI", "Elan");
			
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}

}
