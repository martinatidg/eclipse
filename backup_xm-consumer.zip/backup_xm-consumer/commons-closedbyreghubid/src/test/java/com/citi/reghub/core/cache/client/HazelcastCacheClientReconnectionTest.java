package com.citi.reghub.core.cache.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

public class HazelcastCacheClientReconnectionTest {
	
	HazelcastInstance instance;
	HashMap<String, String> config;
	long connectionAttemptDuration;
	long connectionAttemptLimit;
	
	@Before
	public void setup() throws IOException{
		System.out.println("Setup");
		instance = Hazelcast.newHazelcastInstance();
		Properties properties = new Properties();
		properties.load(HazelcastCacheClient.class.getClassLoader().getResourceAsStream("hazelcast-test.properties"));
		config = new HashMap<>();
		properties.entrySet().forEach(entry->{
			config.put((String) entry.getKey(), (String) entry.getValue());
		});
		connectionAttemptDuration = Long.parseLong(config.get("hazelcast.client.connection.attempt.period"));
		connectionAttemptLimit = Long.parseLong(config.get("hazelcast.client.connection.attempt.limit"));
	}
	
	//When Client is able to connect to cache within number of tries
	@Test
	public void testCacheClientInitialConnectionObtainedWithinSetTries(){
		System.out.println("Started Test 1");
		ExecutorService service = Executors.newFixedThreadPool(1);
		Future<HazelcastInstance> future = service.submit(new ParallelRunnable(instance, connectionAttemptDuration));
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states",states,  config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		try {
			instance = future.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Completed Test 1");
	}
	
	
	//When on startup Client is unable to connect to cache within number of tries and on reconnection cache is not up 
	//but in second reconnect attempt cache is up
	@Test
	public void testCacheClientInitialConnectionNotObtainedWithinSetTries(){
		System.out.println("Started Test 2");
		ExecutorService service = Executors.newFixedThreadPool(1);
		Future<HazelcastInstance> future = service.submit(new ParallelRunnable(instance, connectionAttemptDuration*connectionAttemptLimit*5));
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states",states,  config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(null,retrievedStates);
		try {
			instance = future.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cacheClient.put("states",states,  config);
		retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		System.out.println("Completed Test 2");
	}
	
		//When Client is able to connect to cache within number of tries
		@Test
		public void testCacheClientConnectionObtainedWithinSetTries(){
			System.out.println("Started Test 3");
			CacheClient cacheClient = CacheClientFactory.getInstance(config);
			ExecutorService service = Executors.newFixedThreadPool(1);
			Future<HazelcastInstance> future = service.submit(new ParallelRunnable(instance, connectionAttemptDuration));
			List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
			Map config = new HashMap<>();
			config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
			config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
			try {
				Thread.sleep(connectionAttemptDuration*3);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			cacheClient.put("states",states,  config);
			List retrievedStates = (List) cacheClient.get("states", config);
			assertEquals(states,retrievedStates);
			try {
				instance = future.get();
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Completed Test 3");
		}
	
		//When later on Client is unable to connect to cache within number of tries and on reconnection cache is not up 
		//but in second reconnect attempt cache is up
		@Test
		public void testCacheClientConnectionNotObtainedWithinSetTries(){
			System.out.println("Started Test 4");
			CacheClient cacheClient = CacheClientFactory.getInstance(config);
			List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
			Map config = new HashMap<>();
			config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
			config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
			ExecutorService service = Executors.newFixedThreadPool(1);
			Future<HazelcastInstance> future = service.submit(new ParallelRunnable(instance, connectionAttemptDuration*connectionAttemptLimit*5));
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			cacheClient.put("states",states,  config);
			List retrievedStates = (List) cacheClient.get("states", config);
			assertEquals(null,retrievedStates);
			try {
				instance = future.get();
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			cacheClient.put("states",states,  config);
			retrievedStates = (List) cacheClient.get("states", config);
			assertEquals(states,retrievedStates);
			System.out.println("Completed Test 4");
		}
			
			
	@Test
	public void testClientAliveOnInitialConnectionWhenClusterisDown(){
		System.out.println("Started Test 5");
		instance.shutdown();
		HazelcastCacheClient cacheClient = (HazelcastCacheClient) CacheClientFactory.getInstance(config);
		assertFalse(cacheClient.isAlive());
		System.out.println("Completed Test 5");
	}
	
	@Test
	public void testClientAliveOnConnectionWhenClusterisDownAndTriesNotExhausted(){
		System.out.println("Started Test 6");
		HazelcastCacheClient cacheClient = (HazelcastCacheClient) CacheClientFactory.getInstance(config);
		instance.shutdown();
		assertTrue(cacheClient.isAlive());
		System.out.println("Completed Test 6");
	}
	
	@Test
	public void testClientAliveOnConnectionWhenClusterisDownAndTriesExhausted(){
		System.out.println("Started Test 7");
		HazelcastCacheClient cacheClient = (HazelcastCacheClient) CacheClientFactory.getInstance(config);
		instance.shutdown();
		try {
			Thread.sleep(connectionAttemptDuration*connectionAttemptLimit*5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertFalse(cacheClient.isAlive());
		System.out.println("Completed Test 7");
	}

	
	@After
	public void tearDown(){
		instance.shutdown();
		System.out.println("teardown");
	}

}

class ParallelRunnable implements Callable<HazelcastInstance>{
	
	public ParallelRunnable (HazelcastInstance instance, long sleepTime){
		this.instance = instance;
		this.sleepTime = sleepTime;
	}
	
	private HazelcastInstance instance;
	
	private long sleepTime;

	@Override
	public HazelcastInstance call() {
		// TODO Auto-generated method stub
		System.out.println("Start MS = "+System.currentTimeMillis());
		instance.shutdown();
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("End MS = "+System.currentTimeMillis());
		instance = Hazelcast.newHazelcastInstance();
		return instance;
	}
	
}
