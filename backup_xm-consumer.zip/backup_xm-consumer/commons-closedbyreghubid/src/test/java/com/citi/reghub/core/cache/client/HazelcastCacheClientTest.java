package com.citi.reghub.core.cache.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

public class HazelcastCacheClientTest {
	
	HazelcastInstance instance;
	HashMap<String, String> config;
	long connectionAttemptDuration;
	long connectionAttemptLimit;
	
	@Before
	public void setup() throws IOException{
		instance = Hazelcast.newHazelcastInstance();
		Properties properties = new Properties();
		properties.load(HazelcastCacheClient.class.getClassLoader().getResourceAsStream("hazelcast-test.properties"));
		config = new HashMap<>();
		properties.entrySet().forEach(entry->{
			config.put((String) entry.getKey(), (String) entry.getValue());
		});
		connectionAttemptDuration = Long.parseLong(config.get("hazelcast.client.connection.attempt.period"));
		connectionAttemptLimit = Long.parseLong(config.get("hazelcast.client.connection.attempt.limit"));
	}
	
	@Test(expected=InvalidConfigurationException.class)
	public void shouldThrowExceptionForInvalidCacheProvider(){
		HashMap<String, String> props = new HashMap<>();
		config.put("cache.provider", "ghggk");
		CacheClient cacheClient = CacheClientFactory.getInstance(props);
	}
	
	@Test
	public void shouldCreateCacheClientObject(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		assertNotNull(cacheClient);
		assertTrue(cacheClient instanceof HazelcastCacheClient);
		cacheClient.destroy();
	}
	
	@Test
	public void shouldCreateAndSetCacheClientObject(){
		SingletonCacheClient.setInstance(config);
		assertNotNull(SingletonCacheClient.getInstance());
		assertTrue(SingletonCacheClient.getInstance() instanceof HazelcastCacheClient);
		SingletonCacheClient.getInstance().destroy();
	}
	
	@Test
	public void shouldSetCacheClientObject(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		SingletonCacheClient.setInstance(cacheClient);
		assertNotNull(SingletonCacheClient.getInstance());
		assertTrue(SingletonCacheClient.getInstance() instanceof HazelcastCacheClient);
		SingletonCacheClient.getInstance().destroy();
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testAddToHazelcastMapAndGet(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
		List retrievedList = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedList);
		cacheClient.destroy();
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testGetFromHazelcastMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
		
		Map getconfig = new HashMap<>();
		getconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		List retrievedList = (List) cacheClient.get("states", getconfig);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testGetFromHazelcastMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
		Map getconfig = new HashMap<>();
		getconfig.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		List retrievedList = (List) cacheClient.get("states", getconfig);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testAddToHazelcastMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testAddToHazelcastMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testTryLockFromHazelcastMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		boolean lockStatus = cacheClient.tryLock("states", config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testTryLockFromHazelcastMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		boolean lockStatus = cacheClient.tryLock("states", config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testUnlockFromHazelcastMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.unlock("states", config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testUnlockFromHazelcastMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		cacheClient.unlock("states", config);
	}
	
	
	@Test
	public void testTryLockUnlockOnHazelcastMap(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
		boolean lockStatus1 = cacheClient.tryLock("states", config);
		assertTrue(lockStatus1);
		Callable parallelCallable = new ParallelCallable(cacheClient, "states", config);
		ExecutorService service = Executors.newFixedThreadPool(1);
		Future<Boolean> future = service.submit(parallelCallable);
		try {
			assertFalse(future.get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean lockStatus3 = cacheClient.tryLock("capitals", config);
		assertTrue(lockStatus3);
		cacheClient.unlock("states", config);
		boolean lockStatus4 = cacheClient.tryLock("states", config);
		assertTrue(lockStatus4);
	}
	
	@Test
	public void testTryLockUnlockOnHazelcastMultiMap(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states,  config);
		boolean lockStatus1 = cacheClient.tryLock("states", config);
		assertTrue(lockStatus1);
		Callable parallelCallable = new ParallelCallable(cacheClient, "states", config);
		ExecutorService service = Executors.newFixedThreadPool(1);
		Future<Boolean> future = service.submit(parallelCallable);
		try {
			assertFalse(future.get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean lockStatus3 = cacheClient.tryLock("capitals", config);
		assertTrue(lockStatus3);
		cacheClient.unlock("states", config);
		boolean lockStatus4 = cacheClient.tryLock("states", config);
		assertTrue(lockStatus4);
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testAddToHazelcastMultiMapAndGet(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Daman"});
		cacheClient.put("testMap", states1,  config);
		cacheClient.put("testMap", states2,  config);
		List retrievedSet = (List) cacheClient.get("testMap", config);
		assertTrue(retrievedSet.contains(states1));
		assertTrue(retrievedSet.contains(states2));
		cacheClient.destroy();
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testAddToHazelcastMultiMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("testMap", states1,  config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testAddToHazelcastMultiMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("testMap", states1,  config);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testGetFromHazelcastMultiMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Daman"});
		cacheClient.put("testMap", states1,  config);
		cacheClient.put("testMap", states2,  config);
		Map getconfig = new HashMap<>();
		getconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List retrievedSet = (List) cacheClient.get("testMap", getconfig);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testGetFromHazelcastMultiMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Daman"});
		cacheClient.put("testMap", states1,  config);
		cacheClient.put("testMap", states2,  config);
		Map getconfig = new HashMap<>();
		getconfig.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		List retrievedSet = (List) cacheClient.get("testMap", getconfig);
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testEvictKeyFromHazelcastMap(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List capitals = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		
		cacheClient.put("states", states, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		cacheClient.put("capitals", capitals, config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertEquals(capitals,retrievedCapitals);
		cacheClient.evictObject("capitals", config);
		assertEquals(states,cacheClient.get("states", config));
		assertEquals(null,cacheClient.get("capitals", config));
		cacheClient.destroy();
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testEvictKeyFromHazelcastMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List capitals = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		
		cacheClient.put("states", states, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		cacheClient.put("capitals", capitals, config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertEquals(capitals,retrievedCapitals);
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.evictObject("capitals", evictconfig);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testEvictKeyFromHazelcastMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List capitals = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		
		cacheClient.put("states", states, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		cacheClient.put("capitals", capitals, config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertEquals(capitals,retrievedCapitals);
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		cacheClient.evictObject("capitals", evictconfig);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testEvictAllFromHazelcastMap(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List capitals = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states", states, config);
		
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		cacheClient.put("capitals", capitals,config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertEquals(capitals,retrievedCapitals);
		cacheClient.evictCollection(config);
		assertEquals(null,cacheClient.get("states", config));
		assertEquals(null,cacheClient.get("capitals", config));
		cacheClient.destroy();
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected=InvalidConfigurationException.class)
	public void testEvictAllFromHazelcastMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List capitals = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states", states, config);
		
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		cacheClient.put("capitals", capitals,config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertEquals(capitals,retrievedCapitals);
		cacheClient.put("states", states, config);
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.evictCollection(evictconfig);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected=InvalidConfigurationException.class)
	public void testEvictAllFromHazelcastMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List capitals = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states", states, config);
		
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(states,retrievedStates);
		cacheClient.put("capitals", capitals,config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertEquals(capitals,retrievedCapitals);
		cacheClient.put("states", states, config);
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		cacheClient.evictCollection(evictconfig);
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testEvictKeyFromHazelcastMultiMap(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Orissa"});
		List capitals1 = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		List capitals2 = Arrays.asList(new String[]{"Delhi","Kolkata","Chandigarh"});
		
		cacheClient.put("states", states1, config);
		cacheClient.put("states", states2, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertTrue(retrievedStates.contains(states1));
		assertTrue(retrievedStates.contains(states2));
		cacheClient.put("capitals", capitals1, config);
		cacheClient.put("capitals", capitals2, config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertTrue(retrievedCapitals.contains(capitals1));
		assertTrue(retrievedCapitals.contains(capitals2));
		cacheClient.evictObject("capitals", config);
		assertTrue(((List)cacheClient.get("states", config)).contains(states1));
		assertTrue(((List)cacheClient.get("states", config)).contains(states2));
		assertEquals(null,cacheClient.get("capitals", config));
		cacheClient.destroy();
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testEvictKeyFromHazelcastMultiMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Orissa"});
		List capitals1 = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		List capitals2 = Arrays.asList(new String[]{"Delhi","Kolkata","Chandigarh"});
		
		cacheClient.put("states", states1, config);
		cacheClient.put("states", states2, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertTrue(retrievedStates.contains(states1));
		assertTrue(retrievedStates.contains(states2));
		cacheClient.put("capitals", capitals1, config);
		cacheClient.put("capitals", capitals2, config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertTrue(retrievedCapitals.contains(capitals1));
		assertTrue(retrievedCapitals.contains(capitals2));
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		cacheClient.evictObject("capitals", evictconfig);
	}
	
	@Test(expected=InvalidConfigurationException.class)
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testEvictKeyFromHazelcastMultiMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Orissa"});
		List capitals1 = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		List capitals2 = Arrays.asList(new String[]{"Delhi","Kolkata","Chandigarh"});
		
		cacheClient.put("states", states1, config);
		cacheClient.put("states", states2, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertTrue(retrievedStates.contains(states1));
		assertTrue(retrievedStates.contains(states2));
		cacheClient.put("capitals", capitals1, config);
		cacheClient.put("capitals", capitals2, config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertTrue(retrievedCapitals.contains(capitals1));
		assertTrue(retrievedCapitals.contains(capitals2));
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		cacheClient.evictObject("capitals", evictconfig);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testEvictAllFromHazelcastMultiMap(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Orissa"});
		List capitals1 = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		List capitals2 = Arrays.asList(new String[]{"Delhi","Kolkata","Chandigarh"});
		
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		cacheClient.put("states", states1, config);
		cacheClient.put("states", states2, config);
		
		List retrievedStates = (List) cacheClient.get("states", config);
		assertTrue(retrievedStates.contains(states1));
		assertTrue(retrievedStates.contains(states2));
		cacheClient.put("capitals", capitals1,config);
		cacheClient.put("capitals", capitals2,config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertTrue(retrievedCapitals.contains(capitals1));
		assertTrue(retrievedCapitals.contains(capitals2));
		cacheClient.evictCollection(config);
		assertEquals(null,cacheClient.get("states", config));
		assertEquals(null,cacheClient.get("capitals", config));
		cacheClient.destroy();
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected=InvalidConfigurationException.class)
	public void testEvictAllFromHazelcastMultiMapMissingCollectionName(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Orissa"});
		List capitals1 = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		List capitals2 = Arrays.asList(new String[]{"Delhi","Kolkata","Chandigarh"});
		
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		cacheClient.put("states", states1, config);
		cacheClient.put("states", states2, config);
		
		List retrievedStates = (List) cacheClient.get("states", config);
		assertTrue(retrievedStates.contains(states1));
		assertTrue(retrievedStates.contains(states2));
		cacheClient.put("capitals", capitals1,config);
		cacheClient.put("capitals", capitals2,config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertTrue(retrievedCapitals.contains(capitals1));
		assertTrue(retrievedCapitals.contains(capitals2));
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		cacheClient.evictCollection(evictconfig);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test(expected=InvalidConfigurationException.class)
	public void testEvictAllFromHazelcastMultiMapMissingCollectionType(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		List states2 = Arrays.asList(new String[]{"Himachal Pradesh","Kerela","Orissa"});
		List capitals1 = Arrays.asList(new String[]{"Mumbai","Bangalore","Panjim"});
		List capitals2 = Arrays.asList(new String[]{"Delhi","Kolkata","Chandigarh"});
		
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "MultiMap");
		cacheClient.put("states", states1, config);
		cacheClient.put("states", states2, config);
		
		List retrievedStates = (List) cacheClient.get("states", config);
		assertTrue(retrievedStates.contains(states1));
		assertTrue(retrievedStates.contains(states2));
		cacheClient.put("capitals", capitals1,config);
		cacheClient.put("capitals", capitals2,config);
		List retrievedCapitals = (List) cacheClient.get("capitals", config);
		assertTrue(retrievedCapitals.contains(capitals1));
		assertTrue(retrievedCapitals.contains(capitals2));
		
		Map evictconfig = new HashMap<>();
		evictconfig.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		cacheClient.evictCollection(evictconfig);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testCacheClientWhenCacheServerIsDown(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		HazelcastInstance instance = null;
		cacheClient = new HazelcastCacheClient(instance);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states", states, config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(null,retrievedStates);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testCacheClientEvictWhenCacheServerIsDown(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		HazelcastInstance instance = null;
		cacheClient = new HazelcastCacheClient(instance);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		assertFalse(cacheClient.evictObject("key", config));
		cacheClient.evictCollection(config);
		cacheClient.destroy();
	}
	
	@Test(expected = InvalidConfigurationException.class)
	public void testInvalidCollectionTypeWhilePut(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "ABC");
		cacheClient.put("key", "value", config);
	}
	
	@Test(expected = InvalidConfigurationException.class)
	public void testInvalidCollectionTypeWhileGet(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "ABC");
		cacheClient.get("key", config);
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testPutIfAbsentTrue(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		config.put(CacheClient.PUT_IF_ABSENT, "true");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states1,  config);
		List retrievedList = (List) cacheClient.get("states", config);
		assertEquals(states1,retrievedList);
		List states2 = Arrays.asList(new String[]{"Madhya Pradesh","Kerela","Gujrat"});
		cacheClient.put("states", states2,  config);
		List retrievedList2 = (List) cacheClient.get("states", config);
		assertEquals(states1,retrievedList2);
		cacheClient.destroy();
	}
	
	@Test
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void testPutIfAbsentFalse(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		config.put(CacheClient.PUT_IF_ABSENT, "false");
		List states1 = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		cacheClient.put("states", states1,  config);
		List retrievedList = (List) cacheClient.get("states", config);
		assertEquals(states1,retrievedList);
		List states2 = Arrays.asList(new String[]{"Madhya Pradesh","Kerela","Gujrat"});
		cacheClient.put("states", states2,  config);
		List retrievedList2 = (List) cacheClient.get("states", config);
		assertEquals(states2,retrievedList2);
		cacheClient.destroy();
	}
	
	@Test
	public void testSerializer(){
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		Trade trade = new Trade();
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Trade");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("testTrade",trade,  config);
		Trade retrievedTrade = (Trade) cacheClient.get("testTrade", config);
		assertEquals(trade,retrievedTrade);
	}
	
	@Test
	public void testCacheClientWhenUnableToAuthenticateCacheServer(){
		config.put("hazelcast.group.name", "jkj;j.l");
		CacheClient cacheClient = CacheClientFactory.getInstance(config);
		List states = Arrays.asList(new String[]{"Maharashtra","Karnataka","Goa"});
		Map config = new HashMap<>();
		config.put(CacheClient.CACHE_COLLECTION_NAME, "Test");
		config.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.put("states",states,  config);
		List retrievedStates = (List) cacheClient.get("states", config);
		assertEquals(null,retrievedStates);
	}
	
	@After
	public void tearDown(){
		instance.shutdown();
	}

}

class ParallelCallable implements Callable<Boolean>{
	
	public ParallelCallable (CacheClient cacheClient,String key, Map config){
		this.config = config;
		this.cacheClient = cacheClient;
		this.key = key;
	}
	
	private Map config;
	
	private String key;
	
	private CacheClient cacheClient;

	@Override
	public Boolean call() throws Exception {
		// TODO Auto-generated method stub
		return cacheClient.tryLock(key, config);
	}
	
}

