package com.citi.reghub.core.enrichment.client;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.citi.reghub.core.enrichment.client.enricher.HRMSTraderEnricher;
import com.citi.reghub.core.enrichment.client.enricher.MetadataEnricher;
import com.citi.reghub.core.enrichment.client.enricher.RefDataEnricher;

public class EnricherFactoryTest {
	
	@Test
	public void getMetadataEnricherByTypeTest() {
		assertThat(EnricherFactory.getEnricher(EnricherFactory.METADATA), instanceOf(MetadataEnricher.class));
	}
	
	@Test
	public void getRefDataEnricherByTypeTest() {
		assertThat(EnricherFactory.getEnricher(EnricherFactory.REFDATA), instanceOf(RefDataEnricher.class));
	}
	
	@Test
	public void getHrmsDataEnricherByTypeTest() {
		assertThat(EnricherFactory.getEnricher(EnricherFactory.HRMS_TRADER), instanceOf(HRMSTraderEnricher.class));
	}
	
}
