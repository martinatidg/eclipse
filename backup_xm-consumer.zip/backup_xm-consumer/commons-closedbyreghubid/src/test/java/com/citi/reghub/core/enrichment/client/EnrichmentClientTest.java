package com.citi.reghub.core.enrichment.client;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.hrmstrader.client.HrmsTraderClient;
import com.citi.reghub.core.metadata.client.MetadataClient;
import com.citi.reghub.core.refdata.client.Refdata;
import com.citi.reghub.core.refdata.client.Refdata.RefdataType;
import com.citi.reghub.core.refdata.client.RefdataClient;

public class EnrichmentClientTest {
	
	private RestClient restClient;
	private MetadataClient metadataClient;
	private RefdataClient refDataClient;
	private EnrichmentClientConfig eClientConfig;
	private CacheClient cacheClient;
	private HrmsTraderClient hrmsTraderClient;
	
	private String encode(String fileName) {
        try {
        	Path resourcePath = Paths.get(getClass().getClassLoader().getResource("enrichment/"+ fileName).toURI());
            byte[] ruleDefinition = Files.readAllBytes(resourcePath);
            byte[] encodedRule = Base64.getEncoder().encode(ruleDefinition);
            return new String(encodedRule);
        } catch (Exception e) {
            throw new RuntimeException("Error loading drools rule file: " + fileName, e);
        }
    }
	
	@SuppressWarnings("serial")
	@Before
	public void setup() {
		
		String enrichmentServiceUrl = "http://localhost:8081/reghub-api/enricher-service/enricher-graphs/%s/details";
		restClient = mock(RestClient.class);
		metadataClient = mock(MetadataClient.class);
		refDataClient = mock(RefdataClient.class);
		cacheClient = mock(CacheClient.class);
		hrmsTraderClient = mock(HrmsTraderClient.class);
		
		eClientConfig = new EnrichmentClientConfig()
						.set(EnrichmentClientConfig.REST_CLIENT, restClient)
						.set(EnrichmentClientConfig.ENRICHMENT_PLAN_SERVICE_URL, enrichmentServiceUrl)
						.set(EnrichmentClientConfig.METADATA_CLIENT, metadataClient)
						.set(EnrichmentClientConfig.REFDATA_CLIENT, refDataClient)
						.set(EnrichmentClientConfig.CACHE_CLIENT, cacheClient)
						.set(EnrichmentClientConfig.HRMS_TRADER_CLIENT, hrmsTraderClient);
		
		
		Map<String, Object> buySellConfigMap = new HashMap<>();
		buySellConfigMap.put("lookupKey", "buy_sell_indicator");
		buySellConfigMap.put("updateDefinition", encode("buy_sell_indicator.drl"));
		
		Map<String, Object> tradeExecTypeConfigMap = new HashMap<>();
		tradeExecTypeConfigMap.put("lookupKey", "tradeExecType");
		tradeExecTypeConfigMap.put("updateDefinition", encode("normalize_transaction_status.drl"));
		
		Map<String, Object> firmAccConfigMap = new HashMap<>();
		firmAccConfigMap.put("lookupType", "account");
		firmAccConfigMap.put("lookupKeyDefinition", encode("firm_acc_enrichment_key_lookup.drl"));
		firmAccConfigMap.put("updateDefinition", encode("firm_acc_enrichment.drl"));
		
		Map<String, Object> cptyAccConfigMap = new HashMap<>();
		cptyAccConfigMap.put("lookupType", "account");
		cptyAccConfigMap.put("lookupKeyDefinition", encode("cpty_acc_enrichment_key_lookup.drl"));
		cptyAccConfigMap.put("updateDefinition", encode("cpty_acc_enrichment.drl"));
		
		
		Map<String, Object> firmLEIConfigMap = new HashMap<>();
		firmLEIConfigMap.put("lookupKey", "firmLECode");
		firmLEIConfigMap.put("updateDefinition", encode("firm_lei_enrichment.drl"));
		
		Map<String, Object> buyerIdentificationConfigMap = new HashMap<>();
		buyerIdentificationConfigMap.put("lookupKey", "");
		buyerIdentificationConfigMap.put("updateDefinition", encode("buyer_identification_enrichment.drl"));
		
		Map<String, Object> sellerIdentificationConfigMap = new HashMap<>();
		sellerIdentificationConfigMap.put("lookupKey", "");
		sellerIdentificationConfigMap.put("updateDefinition", encode("seller_identification_enrichment.drl"));
		
		Map<String, Object> fxRateConfigMap = new HashMap<>();
		fxRateConfigMap.put("lookupKey", "fxRate");
		fxRateConfigMap.put("updateDefinition", encode("fx_rate.drl"));
		
		EnrichmentPlan enrichmentPlan = new EnrichmentPlanBuilder()
											.id("EP123456789")
											.name("cash_eq_enrichment_plan")
											.description("CASH_EQ_ENRICHMENT_PLAN")
											.enricher(new EnricherConfig("EC125", "Buy_Sell_Enricher", EnricherFactory.METADATA, buySellConfigMap))
											.enricher(new EnricherConfig("EC126", "Firm_Acc_Enricher", EnricherFactory.REFDATA, firmAccConfigMap))
											.enricher(new EnricherConfig("EC127", "Counterparty_Acc_Enricher", EnricherFactory.REFDATA, cptyAccConfigMap))
											.enricher(new EnricherConfig("EC128", "Firm_LEI_Enricher", EnricherFactory.METADATA, firmLEIConfigMap))
											.enricher(new EnricherConfig("EC129", "Buyer_Id_Enricher", EnricherFactory.METADATA, buyerIdentificationConfigMap))
											.enricher(new EnricherConfig("EC130", "Trade_Exec_Type_Normalizer", EnricherFactory.METADATA, tradeExecTypeConfigMap))
											.enricher(new EnricherConfig("EC131", "Seller_Id_Enricher", EnricherFactory.METADATA, sellerIdentificationConfigMap))
											.enricher(new EnricherConfig("EX132", "FXRate", EnricherFactory.FXRATE, fxRateConfigMap))
											.build();
		
		when(restClient.get(enrichmentServiceUrl, EnrichmentPlan.class))
		.thenReturn(enrichmentPlan);
		
		Map<String, Object> buySellMetadata = new HashMap<String, Object>(){{ put("BUY", "B"); put("SELL", "S");}};
		
		when(metadataClient.get("buy_sell_indicator"))
		.thenReturn(buySellMetadata);
		
		Map<String, Object> fxRateMetadata = new HashMap<String, Object>(){{ put("USD", "75.33"); put("EUR", "76.45");}};
		
		when(metadataClient.get("fxRate","all","all"))
		.thenReturn(fxRateMetadata);
		
		Map<String, Object> tradeExecTypeMetadata = new HashMap<String, Object>(){{ put("New", "NEW"); put("Replaced", "AMEND"); put("Canceled", "CANCEL");put("DEFAULT", "DEFAULT");}};
		
		when(metadataClient.get("tradeExecType"))
		.thenReturn(tradeExecTypeMetadata);
		
		Map<String, Object> leToLeiMetadata = new HashMap<String, Object>(){{ 
			put("02", "XKZZ2JZF41MRHTR1V493"); 
			put("2", "XKZZ2JZF41MRHTR1V493");
			put("002", "XKZZ2JZF41MRHTR1V493");
			}};
			
		when(metadataClient.get("firmLECode"))
		.thenReturn(leToLeiMetadata);
		
		
		Map<String, String> firmData = new HashMap<String, String>(){{
			put("ACCOUNT_ID", "2024118");
			put("FIRM_CODE", "002");
			put("GFCID", "1000242191");
			put("DOMICILE_CNTRY", "GB");
		}};
		
		Map<String, String> firmAccountId = new HashMap<String, String>(){{
			put("ACCOUNT_ID", "2024118");
			put("IS_RESTRICTED", "N");
			put("ACCOUNT_ID", "2024118");
			put("FIRM_CODE", "002");
			put("GFCID", "1000242191");
			put("DOMICILE_CNTRY", "GB");
		}};
		
		List firmAccountIdsList = new ArrayList<Map<String, String>>();
		firmAccountIdsList.add(firmAccountId);
		
		when(refDataClient.getDetails("account", "ACTID", 2024118L)).thenReturn(new Refdata(RefdataType.ACCOUNT, firmData));
		when(refDataClient.getDetails("account", "ACCOUNTMNEMONIC", "HKNY")).thenReturn(new Refdata(RefdataType.ACCOUNT, firmAccountIdsList));
		
		Map<String, String> cptyData = new HashMap<String, String>(){{
			put("ACCOUNT_ID", "1953077");
			put("ACC_SUB_ENT_CODE", "CUST");
			put("FIRM_CODE", "02");
			put("GFCID", "1013116128");
			put("DOMICILE_CNTRY", "CN");
			put("LGL_ENTY_ID", null);
		}};
		
		Map<String, String> cptyAccountId = new HashMap<String, String>(){{
			put("ACCOUNT_ID", "1953077");
			put("IS_RESTRICTED", "N");
			put("ACCOUNT_ID", "1953077");
			put("ACC_SUB_ENT_CODE", "CUST");
			put("FIRM_CODE", "02");
			put("GFCID", "1013116128");
			put("DOMICILE_CNTRY", "CN");
			put("LGL_ENTY_ID", null);
		}};
		
		List cptyAccountIdsList = new ArrayList<Map<String, String>>();
		cptyAccountIdsList.add(cptyAccountId);
		
		when(refDataClient.getDetails("account", "ACTID", 1953077L)).thenReturn(new Refdata(RefdataType.ACCOUNT, cptyData));
		when(refDataClient.getDetails("account", "ACCOUNTMNEMONIC","JFSHGHSU")).thenReturn(new Refdata(RefdataType.ACCOUNT, cptyAccountIdsList));
	
		Map<String, Object> traderEnrichmentMap = new HashMap<>();
		traderEnrichmentMap.put("lookupKeyDefinition", encode("hrms_trader_enrichment_lookup.drl"));
		traderEnrichmentMap.put("updateDefinition", encode("hrms_trader_enrichment.drl"));
		
		EnrichmentPlan hrmsEnrichmentPlan = new EnrichmentPlanBuilder()
				.id("EP123456789")
				.name("trader_details_enrichment_plan")
				.description("Test description..")
				.enricher(new EnricherConfig("EC132", "HRMS_Trader_Enricher", EnricherFactory.HRMS_TRADER, traderEnrichmentMap))
				.build();
		hrmsEnrichmentPlan.group = EnricherFactory.HRMS_TRADER;
		
		when(restClient.get("http://localhost:8081/reghub-api/enricher-service/enricher-graphs/trader_details_enrichment_plan/details", EnrichmentPlan.class)).thenReturn(hrmsEnrichmentPlan);
		when(restClient.get("http://localhost:8081/reghub-api/enricher-service/enricher-graphs/cash_eq_enrichment_plan/details", EnrichmentPlan.class)).thenReturn(enrichmentPlan);
	}	
	
	@Test
	public void EnrichmentClientWithNullConfigTest() {
		assertThat(new EnrichmentClient(null).enrichmentClientConfig, org.hamcrest.CoreMatchers.notNullValue());
	}
	
	@Test(expected = RuntimeException.class)
	public void InvalidEnrichmentPlanLoadTest() {
		new EnrichmentClient(new EnrichmentClientConfig()).load(null);
	}
	
	@Test
	public void shouldBeAbleToLoadMetadataAndEnrichTrade() {
		
		@SuppressWarnings("serial")
		Entity trade = new Entity(){{
				this.regHubId = "csheq14072016";
	            this.status = "REPORTABLE";
	            this.info = new HashMap<String,Object>(){{ 
	            	put("buySellIndicator","buy");
	            	put("firm_acct_id","HKNY");
	            	put("firm_acct_id_type", "ACCOUNTMNEMONIC");
	            	put("cpty_acct_id","JFSHGHSU");
	            	put("cpty_acct_id_type", "ACCOUNTMNEMONIC");
	            	put("firmLECode","002");	
	            	put("tradeExecType", "Replaced");
	            	}};
	        }};
	        
        String resultComment = "buySellIndicator updated to B for trade id " + trade.regHubId;
        
        EnrichmentResult enrichmentResult = new EnrichmentClient(eClientConfig).load("cash_eq_enrichment_plan").execute(trade,true);
        
        assertThat(trade.info.get("buySellIndicator"), equalTo("B"));
        assertThat(enrichmentResult.getEnricherResult().get(0).comments, equalTo(resultComment));
        
        String firmEnrichmentResultComment = "Firm account enrichment complete for trade id" + trade.regHubId;
        assertThat(enrichmentResult.getEnricherResult().get(1).comments, equalTo(firmEnrichmentResultComment));
        assertThat(trade.info.get("firmAccountId"), equalTo("2024118"));
        assertThat(trade.info.get("firmLECode"), equalTo("002"));
        assertThat(trade.info.get("firmGfcid"), equalTo("1000242191"));
        assertThat(trade.info.get("firmDomicileCountry"), equalTo("GB"));
        assertThat(trade.info.get("countryOfTheBranchMembership"), equalTo("GB"));
        assertThat(trade.info.get("countryOfTheBranchForTheBuyer"), equalTo("GB"));
        assertThat(trade.info.get("countryOfBranchForTheSeller"), equalTo("GB"));
        
        String counterpartyEnrichmentResultComment = "Counterparty account enrichment complete for trade id" + trade.regHubId;
        assertThat(enrichmentResult.getEnricherResult().get(2).comments, equalTo(counterpartyEnrichmentResultComment));
        assertThat(trade.info.get("counterpartyAccountId"), equalTo("1953077"));
        assertThat(trade.info.get("counterpartySubEntityCode"), equalTo("CUST"));
        assertThat(trade.info.get("counterpartyFirmLECode"), equalTo("02"));
        assertThat(trade.info.get("counterpartyGfcid"), equalTo("1013116128"));
        assertThat(trade.info.get("counterpartyDomicileCountry"), equalTo("CN"));
        assertThat(trade.info.get("counterpartyLEI"), equalTo(null));
        
        String firmLEIEnrichmentResult = "firmLEI enriched for trade id " + trade.regHubId;
        assertThat(enrichmentResult.getEnricherResult().get(3).comments, equalTo(firmLEIEnrichmentResult));
        assertThat(trade.info.get("firmLEI"), equalTo("XKZZ2JZF41MRHTR1V493"));
        
        String buyerIdentificationEnrichmentResult = "Buyer identification code enriched for trade id " + trade.regHubId;
        assertThat(enrichmentResult.getEnricherResult().get(4).comments, equalTo(buyerIdentificationEnrichmentResult));
        assertThat(trade.info.get("buyerDecisionMakerCode"), equalTo("XKZZ2JZF41MRHTR1V493"));
        assertThat(trade.info.get("sellerIdentificationCode"), equalTo(null));
        
        
        String tradeStatusNormalizationstatus = "regTradeStatus updated to AMEND for trade id " + trade.regHubId;
        assertThat(trade.info.get("regTradeStatus"), equalTo("AMEND"));
        assertThat(enrichmentResult.getEnricherResult().get(5).comments, equalTo(tradeStatusNormalizationstatus));
    }
	
	@Test
	public void shouldBeAbleToLoadTraderDataAndEnrich() {
		Entity entity = new EntityBuilder()
				.info("partyId", "cl38897")
				.info("algoRole", "EXECUTION")
				.build();
		
		
		Map<String, Object> hrmsTraderView = new HashMap<>();
		hrmsTraderView.put(HrmsTraderClient.HRMS_TRADER_MAP_KEY, new HashMap<String, String>() {{
			put("firstName", "EwFh6TPTIuQlXPOfajZMPQ==");
			put("surname", "9NxqAX9XOZcRJQUwy8hKLQ==");
			put("nationality", "KruMxY0p2j+Ha9ij4SGo+Q==");
			put("dob", null);
			put("geId", "MIVG1YC0okQXdHbRa31IvA==");
			put("soeId", "5NEVQHDJOwmRWgpd725NcQ==");
			put("decrGeId", "1");
			put("decrSoeId", "JO25180");
			put("nationalityCountryCode", "IE");
			put("reportableM2NCI", "C");
			put("decrRcvdDateTime", "2017-09-05T17:05:34.584");
			put("rcvdDateTime", "6agxHpapyAAZ0ndQW5H+MK8sdTPp31Q72G6uhdEzK0w=");
			put("nationalId", "LnXtQCP7hnJBIZwWk8P3Hg==");
			put("m2Concat", "h86v3Ul1XSrYcvIhRxKZZSQmdPNp5EN5qcxf3+f8fA0=");
			put("jobTitleDesc", "9wZtdVJF7ba1EyPkhBt59VD0avr/hk+eBNAU7q/fTts=");
			put("workCountry", "+XdOdu+1uENFVE5oKNe9sxQHqJD3tFYHVR3A8baeY+g=");
			put("dirMgrLvl04Name", "tl5ixIoB9H9aPJt0AvN/1Q==");
			put("dirMgrLvl04JobTitleDesc", "QC2NwmTCFA9RTA56AMz9uLYAs60oEZ+goGUUWKQt2qHBaK3CoBrZy1ki5A211vNi");
			put("dirMgrLvl05Name", "KTbDG21EqkM34Rn4y4JDMA==");
			put("dirMgrLvl05JobTitleDesc", "zsl976ayeKjZsybmi4zlE3lS/jVV+1p9wYZ+jkVkIxijUCP0EWdCvklyBmnuTUHd");
			put("dirMgrLvl06Name", "ivntWRd0eofmO8kFvfooHQ==");
			put("dirMgrLvl06JobTitleDesc", "H/2CakhgVfOjl+d2Mg4HnQ==");
		}});
		when(hrmsTraderClient.getTrader("cl38897")).thenReturn(hrmsTraderView );
		
		EnrichmentResult enrichmentResult = new EnrichmentClient(eClientConfig).load("trader_details_enrichment_plan").execute(entity,true);
		 
		assertNotNull(enrichmentResult);
		assertNotNull(enrichmentResult.getEnricherResult().get(0).comments);
		
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("m2Concat"), entity.getString("refM2Concat"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("nationalId"), entity.getString("refNationalId"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("reportableM2NCI"), entity.getString("refFirmExecFlag"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("workCountry"), entity.getString("refWorkCountry"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dirMgrLvl05Name"), entity.getString("refDirMgrLvl05Name"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("geId"), entity.getString("refGeId"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("soeId"), entity.getString("refSoeId"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("firstName"), entity.getString("refFirstName"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dirMgrLvl04Name"), entity.getString("refDirMgrLvl04Name"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("receivedDateTime"), entity.getString("refReceivedDateTime"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dirMgrLvl04JobTitleDesc"), entity.getString("refDirMgrLvl04JobTitleDesc"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dirMgrLvl06JobTitleDesc"), entity.getString("refDirMgrLvl06JobTitleDesc"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("nationality"), entity.getString("refNationality"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("surname"), entity.getString("refSurname"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dateOfBirth"), entity.getString("refDob"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dirMgrLvl06Name"), entity.getString("refDirMgrLvl06Name"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("jobTitleDesc"), entity.getString("refJobTitleDesc"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("dirMgrLvl05JobTitleDesc"), entity.getString("refDirMgrLvl05JobTitleDesc"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("nationality"), entity.getString("refNationalityCountryCode"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("decrGeId"), entity.getString("refGeIdReadable"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("decrSoeId"), entity.getString("refSoeIdReadable"));
		assertEquals(((Map)hrmsTraderView.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY)).get("decrRcvdDateTime"), entity.getString("refReceivedDateTimeReadable"));
	}
	
	@Test
	public void shouldBeAbleToReturnAuditObject() {
		
		@SuppressWarnings("serial")
		Entity trade = new Entity(){{
				this.regHubId = "csheq14072016";
	            this.status = "REPORTABLE";
	            this.info = new HashMap<String,Object>(){{ 
	            	put("buySellIndicator","buy");
	            	put("firm_acct_id","HKNY");
	            	put("firm_acct_id_type", "ACCOUNTMNEMONIC");
	            	put("cpty_acct_id","JFSHGHSU");
	            	put("cpty_acct_id_type", "ACCOUNTMNEMONIC");
	            	}};
	        }};
	        
        
        EnrichmentResult enrichmentResult = new EnrichmentClient(eClientConfig).load("cash_eq_enrichment_plan").execute(trade,true);
        
        Audit audit = trade.toAudit();
        enrichmentResult.toAudit(audit);
        
        assertThat(audit.regHubId, equalTo(trade.regHubId));
        assertThat(audit.info.isEmpty(), is(false));
       
               
	}  
	
	@Test
    public void shouldGetLastLoadTimeWhenPresentInCache(){
    	Map props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, "enrichment_plan");
		props.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		props.put(CacheClient.PUT_IF_ABSENT, "true");
    	when(cacheClient.get("myEnrichmentPlan", props)).thenReturn(1002345L);
    	EnrichmentClient enrichmentClient = new EnrichmentClient(eClientConfig);
    	long lastLoadTime = enrichmentClient.getLastLoadTime("myEnrichmentPlan");
    	assertEquals(1002345L,lastLoadTime);
    }
    
    @Test
    public void shouldGetLastLoadTimeWhenNotPresentInCache(){
    	Map props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, "enrichment_plan");
		props.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		props.put(CacheClient.PUT_IF_ABSENT, "true");
    	when(cacheClient.get("myEnrichmentPlan", props)).thenReturn(null);
    	EnrichmentClient enrichmentClient = new EnrichmentClient(eClientConfig);
    	long lastLoadTime = enrichmentClient.getLastLoadTime("myEnrichmentPlan");
    	assertEquals(0L,lastLoadTime);
    }
    
    @Test
	public void shouldBeAbleToLoadFxRateAndEnrichTrade() {
		
		@SuppressWarnings("serial")
		Entity trade = new Entity(){{
				this.regHubId = "csheq14072016";
	            this.status = "REPORTABLE";
	            this.info = new HashMap<String,Object>(){{ 
	            	put("buySellIndicator","buy");
	            	put("firm_acct_id","HKNY");
	            	put("firm_acct_id_type", "ACCOUNTMNEMONIC");
	            	put("cpty_acct_id","JFSHGHSU");
	            	put("cpty_acct_id_type", "ACCOUNTMNEMONIC");
	            	put("firmLECode","002");	
	            	put("tradeExecType", "Replaced");
	            	put("priceCcy", "EUR");
	            	}};
	        }};
        
        EnrichmentResult enrichmentResult = new EnrichmentClient(eClientConfig).load("cash_eq_enrichment_plan").execute(trade,true);
        assertNotNull(enrichmentResult);
        assertNotNull(enrichmentResult.getEnricherResult().get(7));
        assertNotNull(enrichmentResult.getEnricherResult().get(7).comments);
        assertEquals(trade.getString("fxRate"), "76.45");
        
    }
    
	
}
