package com.citi.reghub.core;

import java.time.LocalDateTime;

public class EntityOld extends InfoablePojo {
	
	public String regHubId;				// reghub generated unique id for each message
	public String status;				// reghub reporting status e.g. REPORTABLE, NON_REPORTABLE, EXCEPTION, PENDING, REPORTED, REJECTED 
	public String stream;				// reporting stream (always 4 char) e.g. M2TR, M2PR, M2PO
	public String flow;					// reporting asset class / product (always 3 char) e.g. CEQ (cash equities), CFI (cash fixed income)
	
	public String sourceUId;			// unique id for a message received from source e.g. OceanId for transaction reporting
	public String sourceId;				// trade/quote/order id
	public String sourceVersion;		// trade/quote/order version
	public String sourceStatus;			// always normalised to NEW, AMEND and CANCEL
	public String sourceSystem;			// upstream source system generated the message e.g. TPS, PRIMO
	public String regReportingRef;		// used as reporting id for trade/quote/order/transaction e.g. stream + flow + sourceId
	
	public LocalDateTime receivedTs;	// Time when entity is received in reghub
	public LocalDateTime publishedTs;	// trade activity time .i.r when this trade version was created
	public LocalDateTime executionTs;	// trade origination time
	public LocalDateTime lastUpdatedTs;	// timestamp of last activity in reghub, classical updated timestamp for reghub

}
