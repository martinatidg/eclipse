package com.citi.reghub.core.metadata.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.impl.client.HttpClients;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.CacheClientFactory;
import com.citi.reghub.core.client.RestClient;

public class MetadataServiceIntegrationTest {
	
	RestClient restClient;
	
	MetadataClientConfig metadataClientConfig;
	
	MetadataClient metadataClient;
	
	CacheClient cacheClient;
	
	@Before
	public void setUp() throws IOException{
		restClient = new RestClient(HttpClients.createDefault());
		Map map = new HashMap<>();
		map.put("cache.provider", "hazelcast");
		cacheClient = CacheClientFactory.getInstance(map);
		metadataClientConfig = new MetadataClientConfig().set(MetadataClientConfig.REST_CLIENT, restClient).setDefaultMetadataUrl()
				.set(MetadataClientConfig.CACHE_CLIENT, cacheClient).set(MetadataClientConfig.FLOW_CODE, "FLOW2");
		metadataClient = new MetadataClient(metadataClientConfig);
	}
	
	@Test
	@Ignore
	public void testMetadataClient(){
		Object obj = metadataClient.get("preMifidDate");
		assertTrue(obj instanceof LocalDate);
		assertEquals(LocalDate.of(2007, 11, 5),(LocalDate) obj);
	}

}
