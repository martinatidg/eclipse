package quickfix.custom.field;

import quickfix.IntField;

public class TrdRegPublicationReason extends IntField{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5368408571942096721L;
	public static final int FIELD = 2670;
	
	public TrdRegPublicationReason() {
		super(FIELD);
	}

	public TrdRegPublicationReason(int data) {
		super(FIELD, data);
	}
	
}
