package quickfix.custom.field;

import quickfix.StringField;

public class TradePriceCondition extends StringField{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2588559703560017952L;
	
	public static final int FIELD = 1839;

	public TradePriceCondition() {
		super(FIELD);
	}

	public TradePriceCondition(String data) {
		super(FIELD, data);
	}
	
	
}
