package quickfix.custom.field;

import quickfix.IntField;

public class TrdRegPublicationType extends IntField{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6759869597092560637L;
	public static final int FIELD = 2669;
	
	public TrdRegPublicationType() {
		super(FIELD);
	}

	public TrdRegPublicationType(int data) {
		super(FIELD, data);
	}
	

}
