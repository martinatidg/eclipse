package quickfix.custom.field;

import quickfix.StringField;

public class RegulatoryReportType extends StringField{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7234458237531404406L;
	
	public static final int FIELD = 1934;

	public RegulatoryReportType() {
		super(FIELD);
	}

	public RegulatoryReportType(String data) {
		super(FIELD, data);
	}
	
}
