package quickfix.custom.field;

import quickfix.IntField;

public class ExecMethod extends IntField {

	private static final long serialVersionUID = 2364361024439139331L;
	
	public static final int FIELD = 2405;
	
	public ExecMethod() {
		super(FIELD);
	}

	public ExecMethod(int data) {
		super(FIELD, data);
	}
	
}
