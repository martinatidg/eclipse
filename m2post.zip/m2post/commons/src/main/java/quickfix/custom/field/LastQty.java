package quickfix.custom.field;

import java.math.BigDecimal;

import quickfix.DecimalField;


public class LastQty extends DecimalField {

	static final long serialVersionUID = 20050617;

	public static final int FIELD = 32;
	
	public LastQty() {
		super(32);
	}

	public LastQty(BigDecimal data) {
		super(32, data);
	}
	
}
