package quickfix.custom.field;

import java.math.BigDecimal;

import quickfix.DecimalField;


public class UnitOfMeasureQty extends DecimalField {

	static final long serialVersionUID = 20050617;

	public static final int FIELD = 1147;
	
	public UnitOfMeasureQty() {
		super(1147);
	}

	public UnitOfMeasureQty(BigDecimal data) {
		super(1147, data);
	}
	
}
