package quickfix.custom.field;

import quickfix.CharField;

public class PxQtyReviewed extends CharField{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 6876629099816626548L;
	
	public static final int FIELD = 7596;

	public PxQtyReviewed() {
		super(FIELD);
	}

	public PxQtyReviewed(Character data) {
		super(FIELD, data);
	}	
	

}
