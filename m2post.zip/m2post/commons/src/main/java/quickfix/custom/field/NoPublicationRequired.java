package quickfix.custom.field;

import quickfix.CharField;

public class NoPublicationRequired extends CharField{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8042602626132679161L;
	
	public static final int FIELD = 25003;

	public NoPublicationRequired() {
		super(FIELD);
	}

	public NoPublicationRequired(Character data) {
		super(FIELD, data);
	}
	
}
