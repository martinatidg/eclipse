package quickfix.custom.field;

import quickfix.StringField;

public class EmissionAllowanceType extends StringField {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8698905937464336076L;
	
	public static final int FIELD = 25015;

	public EmissionAllowanceType() {
		super(FIELD);
	}

	public EmissionAllowanceType(String data) {
		super(FIELD, data);
	}
}
