package quickfix.custom.field;

import quickfix.CharField;

public class ClearingIntention extends CharField{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6091248831484164039L;
	
	public static final int FIELD = 1924;

	public ClearingIntention() {
		super(FIELD);
	}

	public ClearingIntention(Character data) {
		super(FIELD, data);
	}
}
