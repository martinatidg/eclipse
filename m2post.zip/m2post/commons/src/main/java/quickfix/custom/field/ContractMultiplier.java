package quickfix.custom.field;

import java.math.BigDecimal;

import quickfix.DecimalField;


public class ContractMultiplier extends DecimalField {

	static final long serialVersionUID = 20050617;

	public static final int FIELD = 231;
	
	public ContractMultiplier() {
		super(231);
	}

	public ContractMultiplier(BigDecimal data) {
		super(231, data);
	}
	
}
