package quickfix.custom.field;

import quickfix.StringField;

public class NotionalCurrency extends StringField{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 318061466611067236L;
	
	public static final int FIELD = 25015;
	
	public NotionalCurrency() {
		super(FIELD);
	}

	public NotionalCurrency(String data) {
		super(FIELD, data);
	}
	
}
