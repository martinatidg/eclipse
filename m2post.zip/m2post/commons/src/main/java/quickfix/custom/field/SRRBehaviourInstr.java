package quickfix.custom.field;

import quickfix.CharField;

public class SRRBehaviourInstr extends CharField{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2093536529535905830L;
	
	public static final int FIELD = 25001;

	
	public SRRBehaviourInstr() {
		super(FIELD);
	}
	
	public SRRBehaviourInstr(Character data) {
		super(FIELD, data);
	}

}
