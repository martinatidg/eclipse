package quickfix.custom.field;

import quickfix.StringField;

public class TotalNumTradeReports extends StringField{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1542733885878301184L;
	
	public static final int FIELD = 748;

	public TotalNumTradeReports() {
		super(FIELD);
	}

	public TotalNumTradeReports(String data) {
		super(FIELD, data);
	}
	
}
