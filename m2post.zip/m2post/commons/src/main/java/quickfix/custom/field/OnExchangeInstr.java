package quickfix.custom.field;

import quickfix.CharField;

public class OnExchangeInstr extends CharField {
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 117691442364491679L;
	
	public static final int FIELD = 25002;

	public OnExchangeInstr() {
		super(FIELD);
	}

	public OnExchangeInstr(Character data) {
		super(FIELD, data);
	}
	

}
