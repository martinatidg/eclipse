package quickfix.custom.field;

import quickfix.StringField;

public class ExemptTransactionCode extends StringField{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5249160945722302447L;
	
	public static final int FIELD = 25013;

	public ExemptTransactionCode() {
		super(FIELD);
	}

	public ExemptTransactionCode(String data) {
		super(FIELD, data);
	}

}
