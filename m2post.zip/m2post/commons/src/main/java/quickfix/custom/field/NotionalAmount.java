package quickfix.custom.field;

import java.math.BigDecimal;

import quickfix.DecimalField;

public class NotionalAmount extends DecimalField{

	/**
	 * 
	 */
	private static final long serialVersionUID = 356855504612281821L;
	
	public static final int FIELD = 25014;
	
	public NotionalAmount() {
		super(FIELD);
	}
	
	public NotionalAmount( BigDecimal data) {
		super(FIELD, data);
	}
	
	
}
