package quickfix.custom.field;

import quickfix.IntField;

public class AlgorithmicTradeIndicator extends IntField {

	private static final long serialVersionUID = 2364361024439139331L;
	
	public static final int FIELD = 2667;
	
	public AlgorithmicTradeIndicator() {
		super(FIELD);
	}

	public AlgorithmicTradeIndicator(int data) {
		super(FIELD, data);
	}
	
}
