package quickfix.custom.field;

import quickfix.StringField;

public class TradeNumber extends StringField{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -682649425381153121L;
	
	public static final int FIELD = 2890;

	public TradeNumber() {
		super(FIELD);
	}

	public TradeNumber(String data) {
		super(FIELD, data);
	}	
	
	
	
}
