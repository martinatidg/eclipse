package quickfix.custom.field;

import quickfix.IntField;

public class SideTradeReportingIndicator extends IntField{
	
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9213497821800927123L;
	public static final int FIELD = 2671;
	
	public SideTradeReportingIndicator() {
		super(FIELD);
	}

	public SideTradeReportingIndicator(int data) {
		super(FIELD, data);
	}

}
