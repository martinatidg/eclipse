package quickfix.custom.field;

import quickfix.IntField;

public class NoTradePriceConditions extends IntField{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7090205931334241679L;
	
	public static final int FIELD = 1838;
	
	public NoTradePriceConditions() {
		super(FIELD);
	}

	public NoTradePriceConditions(int data) {
		super(FIELD, data);
	}
	
}
