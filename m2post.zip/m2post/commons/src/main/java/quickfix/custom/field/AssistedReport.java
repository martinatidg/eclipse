package quickfix.custom.field;

import quickfix.CharField;

public class AssistedReport extends CharField{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1836686796782554466L;

	public static final int FIELD = 25018;
	
	public AssistedReport() {
		super(FIELD);
	}
	
	public AssistedReport(Character data) {
		super(FIELD, data);
	}

}
