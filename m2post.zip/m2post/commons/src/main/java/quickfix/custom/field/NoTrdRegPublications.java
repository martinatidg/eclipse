package quickfix.custom.field;

import quickfix.IntField;

public class NoTrdRegPublications extends IntField{
	
/**
	 * 
	 */
private static final long serialVersionUID = 1002069934328400563L;

public static final int FIELD = 2668;
	
	public NoTrdRegPublications() {
		super(FIELD);
	}

	public NoTrdRegPublications(int data) {
		super(FIELD, data);
	}

}
