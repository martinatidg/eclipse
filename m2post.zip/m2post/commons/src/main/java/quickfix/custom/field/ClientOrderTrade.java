package quickfix.custom.field;

import quickfix.CharField;

public class ClientOrderTrade extends CharField{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1085113742470556713L;
	
	public static final int FIELD = 25016;

	public ClientOrderTrade() {
		super(FIELD);
	}

	public ClientOrderTrade(Character data) {
		super(FIELD, data);
	}
	

}
