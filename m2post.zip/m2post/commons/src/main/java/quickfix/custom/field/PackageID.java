package quickfix.custom.field;

import quickfix.StringField;

public class PackageID extends StringField {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2804632594851751562L;
	
	public static final int FIELD = 2489;

	public PackageID() {
		super(FIELD);
	}

	public PackageID(String data) {
		super(FIELD, data);
	}	
	
	
}
