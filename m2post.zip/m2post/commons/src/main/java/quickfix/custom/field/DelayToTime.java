package quickfix.custom.field;

import quickfix.StringField;

public class DelayToTime extends StringField{

		
	/**
	 * 
	 */
	private static final long serialVersionUID = -4393074084542861322L;
	
	public static final int FIELD = 7552;

	public DelayToTime() {
		super(FIELD);
	}

	public DelayToTime(String data) {
		super(FIELD, data);
	}	

}
