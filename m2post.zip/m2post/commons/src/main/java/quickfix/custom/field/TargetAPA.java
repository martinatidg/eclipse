package quickfix.custom.field;

import quickfix.StringField;

public class TargetAPA extends StringField{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6036033737471176766L;
	
	public static final int FIELD = 25011;
	
	public TargetAPA() {
		super(FIELD);
	}

	public TargetAPA(String data) {
		super(FIELD, data);
	}
	

}
