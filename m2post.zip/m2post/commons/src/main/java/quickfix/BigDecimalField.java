package quickfix;

import java.math.BigDecimal;

/**
 * A BigDecimal-values message field.
 */
public class BigDecimalField extends Field<BigDecimal> {

    /**
	 * 
	 */
	private static final long serialVersionUID = -5589938239178834153L;
	private int padding = 0;

    public BigDecimalField(int field) {
        super(field, BigDecimal.ZERO);
    }

    

    public BigDecimalField(int field, BigDecimal data) {
        super(field, data);
    }

    public BigDecimalField(int field, BigDecimal data, int padding) {
        super(field, data);
        this.padding = padding;
    }

    public void setValue(BigDecimal value) {
        setObject(value);
    }

    public BigDecimal getValue() {
        return getObject();
    }

    public int getPadding() {
        return padding;
    }

    public boolean valueEquals(BigDecimal value) {
        return getObject().equals(value);
    }

}
