package com.citi.reghub.m2post.utils.constants;

public interface KafkaStormTopologyConstants {

	public static final String STREAM = "m2post";
	public static final String COM_FLOW = "comderv";
	public static final String CSH_EQ_FLOW = "csheq";
	public static final String CSH_FI_FLOW = "cshfi";
	public static final String FX_OPTS_FLOW = "ofx";
	public static final String MUNI_DERV_FLOW = "muniderv";
	public static final String RATES = "rates";
	public static final String CREDITS = "credit";
	public static final String TPS_DERV_FLOW = "tpsderv";
	public static final String FX_DER_FLOW = "fxd";
	public static final String CSH_FX_FLOW = "cshfx";
	public static final String FUTURES_FLOW = "futures";
	public static final String EQUITYDR = "eqderv";
	public static final String MUREX_FLOW = "murex";
	public static final String EDL_FI_FLOW = "edlfi";
	public static final String BOLT_THREAD_COUNT = "bolt.thread.count";

	// COMMON CONSTANTS USED ACROSS TOPOLOGIES
	public static final String AUDIT_BOLT_NAME = "audit-bolt";
	public static final String AUDIT_BOLT_ID = "audit-bolt-id";
	public static final String EXCEPTION_BOLT_NAME = "exception-bolt";
	public static final String EXCEPTION_BOLT_ID = "exception-bolt-id";
	public static final String EXCEPTION_TOPIC_NAME = EXCEPTION_BOLT_NAME + ".kafka.topic.names";
	public static final String AUDIT_TOPIC_NAME = AUDIT_BOLT_NAME + ".kafka.topic.names";
	public static final String KAFKA_TOPIC_NAMES = "kafka.input.topic.names";

	public static final String REPORTABLE_OUTBOUND_BOLT_ID = "reportable-outbound-bolt-id";
	public static final String REPORTABLE_OUTBOUND_BOLT_NAME = "reportable-outbound-bolt";
	public static final String REPORTABLE_OUTBOUND_TOPIC_NAME = REPORTABLE_OUTBOUND_BOLT_NAME + ".kafka.topic.names";

	public static final String SEQUENCED_OUTBOUND_BOLT_ID = "sequenced-outbound-bolt-id";
	public static final String SEQUENCED_OUTBOUND_BOLT_NAME = "sequenced-outbound-bolt";

	// SOURCE
	public static final String RIO_SPOUT_ID = "rio-spout-id";
	public static final String REPLAY_SPOUT_ID = "replay-spout-id";
	public static final String RIO_SPOUT_NAME = "rio-spout";
	public static final String KAFKA_SPOUT_NAME = "kafka-spout";
	public static final String INBOUND_M2POST_SOURCE_STORM_STREAM= "inbound-m2post-source-storm-stream";
	public static final String INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM= "inbound-m2post-source-replay-storm-stream";
	public static final String RAW_MSG_BOLT_ID = "raw-msg-bolt-id";
	public static final String RAW_MSG_BOLT_NAME = "raw-inbound-kafka-bolt";
	public static final String CITIML_PARSER_BOLT_ID = "parse-citiml-msg-bolt-id";
	public static final String CITIFIX_PARSER_BOLT_ID = "parse-citifix-msg-bolt-id";
	public static final String PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID = "parse-fix-message-for-replay-bolt-id";
	public static final String MAP_TO_ENTITY_BOLT_ID = "map-to-entity-bolt-id";
	public static final String MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID = "map-to-entity-for-replay-bolt-id";
	public static final String MERGE_ENTITY_FOR_REPLAY_BOLT_ID = "merge-entity-for-replay-bolt-id";
	public static final String DOMAIN_BOLT_ID = "domain-bolt-id";
	public static final String DOMAIN_BOLT_NAME = "domain-bolt";
	public static final String REPLAY_DMN_BOLT_ID = "replay-domain-bolt-id";
	public static final String RAW_MSG_TOPIC_NAME = RAW_MSG_BOLT_NAME + ".kafka.topic.names";
	public static final String DOMAIN_TOPIC_NAME = DOMAIN_BOLT_NAME + ".kafka.topic.names";
	public static final String REPLAY_TOPIC_NAME = "replay.entity.topic.name";

	
	
	public static final String RIO_SPOUTE_EDEALER_LDN_ID = "rio-spout-edealer_ldn-id";
	public static final String RIO_SPOUTE_TPS_ID = "rio-spout-tps-id";
	public static final String REPLAY_EDEALER_LDN_SPOUT_ID = "replay-edealer-ldn-spout-id";
	public static final String REPLAY_TPS_SPOUT_ID = "replay-tps-spout-id";
	public static final String RIO_SPOUT_EDEALER_LDN_NAME = "rio-edealer-ldn-spout";
	public static final String RIO_SPOUT_TPS_NAME = "rio-tps-spout";
	

	public static final String SOURCE_TOPIC_NAME = KAFKA_SPOUT_NAME + ".kafka.topic.names";

	
	// TODO: TO BE REMOVED
	public static final String PRE_ELIGIBILITY_BOLT_ID = "pre-eligibility-bolt-id";

	// DOMAIN
	public static final String DOMAIN_SPOUT_ID = "domain-spout-id";
	public static final String INBOUND_M2POST_DOMAIN_STORM_STREAM = "inbound-m2post-domain-storm-stream";
	public static final String PRE_ELIGIBILITY_RULES_BOLT_ID = "pre-eligibility-rules-bolt-id";
	public static final String ENRICHMENT_RULES_BOLT_ID = "enrichment-rules-bolt-id";
	public static final String POST_ENRICHMENT_RULES_BOLT_ID = "non-reportable-rules-bolt-id";
	public static final String BIZ_EXCEPTION_RULES_BOLT_ID = "biz-exception-rules-bolt-id";
	public static final String TECH_EXCEPTION_RULES_BOLT_ID = "tech-exception-rules-bolt-id";
	public static final String NON_REPORTABLE_BOLT_ID = "non-reportable-bolt-id";
	public static final String NON_REPORTABLE_BOLT_NAME = "non-reportable-bolt";
	public static final String NON_REPORTABLE_TOPIC_NAME = NON_REPORTABLE_BOLT_NAME + ".kafka.topic.names";

	// SEQUENCER
	public static final String SEQUENCER_SPOUT_ID = "sequencer-spout-id";
	public static final String INBOUND_M2POST_SEQUENCER_STORM_STREAM = "inbound-m2post-sequencer-storm-stream";
	public static final String TRADE_STATUS_TRANSLATION_BOLT_ID = "trad-stat-xlation-bolt-id";
	public static final String SEQUENCER_BOLT_ID = "sequencer-bolt-id";
	public static final String REPORTABLE_BOLT_ID = "reportable-bolt-id";
	public static final String REPORTABLE_BOLT_NAME = "reportable-bolt";
	public static final String COMMON_REPORTABLE_BOLT_ID = "common_reportable-bolt-id";
	public static final String COMMON_REPORTABLE_BOLT_NAME = "common_reportable-bolt";
	public static final String SEQUENCED_OUTBOUND_TOPIC_NAME = SEQUENCED_OUTBOUND_BOLT_NAME + ".kafka.topic.names";
	public static final String REPORTABLE_TOPIC_NAME = REPORTABLE_BOLT_NAME + ".kafka.topic.names";
	public static final String SEQUECNER_CACHE_COLLECTION_NAME = "cache.collection.name";

	// SENDER
	public static final String SENDER_SPOUT_ID = "sender-spout-id";
	public static final String INBOUND_M2POST_SENDER_STORM_STREAM = "inbound-m2post-sender-storm-stream";
	public static final String FIX_MSG_GEN_BOLT_ID = "fix-msg-gen-bolt-id";
	public static final String FIX_PUBLISH_BOLT_ID = "fix-publish-bolt-id";
	public static final String FIX_PUBLLISH_BOLT_NAME = "fix-msg-bolt";
	public static final String RAW_MSG_OUTBOUND_BOLT_ID = "raw-msg-outbound-bolt-id";
	public static final String RAW_MSG_OUTBOUND_BOLT_NAME = "raw-msg-outbound-bolt";
	public static final String FIX_MSG_TOPIC_NAME = FIX_PUBLLISH_BOLT_NAME + ".kafka.topic.names";
	public static final String RAW_OUTBOUND_TOPIC_NAME = RAW_MSG_OUTBOUND_BOLT_NAME + ".kafka.topic.names";
	public static final String RAW_OUTBOUND_SERVICE_URL = "raw.outbound.service.url";

	// All KAFKA Bolt Constants.

	public static final String APA_SENDER_BOLT_ID = "apaSenderBoltId";

	// APATradeIdEnrichmentBolt
	public static final String APA_TRADE_ID_ENRICHMENT_BOLT_ID = "APATradeIdEnrichmentBoltId";
	public static final String APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_ID = "APATradeIdNonAcknowledgedBoltId";
	public static final String APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_NAME = "non-acknowledged-bolt";

}
