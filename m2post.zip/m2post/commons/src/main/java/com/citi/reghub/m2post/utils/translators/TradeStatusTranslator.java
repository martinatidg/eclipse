package com.citi.reghub.m2post.utils.translators;

import java.util.List;

import com.citi.reghub.core.Entity;

/**
 * @author dk77005
 *
 */
public interface TradeStatusTranslator {
	public List<Entity> translateTradeStatus(Entity currEntity, Entity prevEntity);
}
