package com.citi.reghub.m2post.utils.custombolts;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.converter.ConvertRecordToString;



public class FixMsgGenerationBolt extends RegHubBolt {

	private final Logger logger = LoggerFactory.getLogger(FixMsgGenerationBolt.class);
	private static final long serialVersionUID = 1L;
	private OutputCollector _collector;
	private ConvertRecordToString convertToFix;
	private String msgType;
	private String sendTo;
	private String senderCompId;
	private String targetCompId;

	public FixMsgGenerationBolt(String msgType, String sentTo, ConvertRecordToString convertToFix) {
		super();
		this.msgType = msgType;
		this.sendTo = sentTo;
		this.convertToFix = convertToFix;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		targetCompId=topologyConfig.get("target.compId");
		senderCompId=topologyConfig.get("sender.compId");
	}

	@Override
	public void process(Tuple input) throws Exception {
		Entity message = (Entity) input.getValueByField(TUPLE_MESSAGE);
		String key = message.sourceId;
		LocalDateTime currentTs = LocalDateTime.now(Clock.systemUTC());
		Long nanoTime = convertLocalDateTimeToEpoch(currentTs);
		String firmTradeId = message.stream + "-" + message.flow + "-" + message.sourceId + "-"+ nanoTime;
		message.sourceId = firmTradeId;
		message.info.put(SENDER_COMP_ID, senderCompId);
		message.info.put(TARGET_COMP_ID, targetCompId);
		message.info.put(MSGSEGNUM, 1);
		message.info.put(SENDINGTIME, LocalDateTime.now());
		String auditResult;
		logger.info("Recieved entity object in Sender-{}", message);
		String fixMsg = "";
		List<Entity> messages = new ArrayList<Entity>();
		RawOutboundRecord raw = new RawOutboundRecord();
		messages.add(message);
		fixMsg = convertToFix.convert(messages);
		auditResult = fixMsg;
		if (!fixMsg.equals("")) {
			raw.regHubId = message.regHubId;
			raw.sourceId = key;
			raw.stream = message.stream;
			raw.flow = message.flow;
			raw.message = new String(Base64.getEncoder().encode(fixMsg.getBytes()));
			raw.messageType = msgType;
			raw.sendTo = sendTo;
			raw.sendTs = currentTs;
			logger.info("Publishing fix message-" + fixMsg);
			_collector.emit(StormStreams.FIX_MSG, new Values(message.regHubId, fixMsg, message.sourceId));
			logger.info("Publishing raw outbound object-" + raw.toString());
			_collector.emit(StormStreams.RAW_OUTBOUND_OBJECT, new Values(raw._id, raw));
		}
		pushMessageToAuditStream(message, auditResult);
		_collector.ack(input);
	}

	private Long convertLocalDateTimeToEpoch(LocalDateTime currentTs) {
		long epochSec = currentTs.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
		Integer nanos = currentTs.getNano();
		Long nanoTime = (epochSec * 1000000000) + nanos;
		return nanoTime;
	}

	public void pushMessageToAuditStream(Entity message, String auditResult) {
		Audit audit = message.toAudit();
		audit.event = "FIX MESSAGE GENERATION";
		audit.result = "FIX MESSAGE GENERATED SUCCESSFULLY";
		logger.info("Publishing audit message-" + audit.toString());
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.FIX_MSG, new Fields(TUPLE_KEY, TUPLE_MESSAGE, "sourceId"));
		declarer.declareStream(StormStreams.RAW_OUTBOUND_OBJECT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.AUDIT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.SEQUENCED_OUTBOUND_STREAM, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	public ConvertRecordToString getConvertRecordToString() {
		return convertToFix;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SENDER_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SENDER);
		exceptionTags.add(StormConstants.FIX_MSG_GENERATION_EXCEPTION);
		return exceptionTags;
	}

}
