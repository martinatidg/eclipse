package com.citi.reghub.m2post.utils.sourcetoentitymappers;

import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.*;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.m2post.utils.xpath.XPathUtils;

/**
 * This is an abstract for transforming the incoming CITIML XML to Entity Domain Object.
 * It provide Impls for the common attributes, specific ones needs to be overridden.
 * @author pg60809
 *
 */
public abstract class AbstractCitiMLToEntityMapper implements EntityMapper {

	protected static final long serialVersionUID = 6238258165025606916L;

	protected static final Logger LOG = LoggerFactory.getLogger(AbstractCitiMLToEntityMapper.class);
	
	protected Document xmlDocument;
	protected Entity entity;
	protected String flow;
	protected String stream;
	protected XPath xPath ;
	protected XPathUtils xPathUtilInstance;
	
	/**
	 * Public constructor to set the Flow and Stream
	 * @param flow
	 * @param stream
	 */
	public AbstractCitiMLToEntityMapper(String flow, String stream) {
		this.flow = flow;
		this.stream = stream;
	}
	
	/**
	 * This menthod populates the mandatory attributes in Entity Object
	 * which is required for all Asset Classes.
	 * 
	 * @param message
	 * @param entity
	 * @return Entity
	 * 
	 */
	@Override
	public Entity mapToEntity(Object message, Entity entity) {
		
		xPathUtilInstance = new XPathUtils();
		xPath = XPathFactory.newInstance().newXPath();
		xmlDocument = (Document) message;
		this.entity = entity;
		
		try {
			populateMandatoryFeildsInEntityObject();

			setReportStatus();
			setTradeVenueTransactionId();
			setTradeExecutionTs();
			setInstrumentClassification();
			setTransactionToClear();
			setExecutionVenueType();
			setVenueOfExecution();
			setWaiverIndicator();
			setOtcPostTradeIndicator();
			setCommoditiesDerivativeIndicator();
			setQtyInMeasurementUnit();
			setNotationOfQtyInMeasurementUnit();
			setNotationalAmount();
			setEmissionAllowanceType();
			setInstrIdentTypeCode();
			setPriceCurrency();
			setNotionalCurrency();
			setPriceNotation();
			setPrice();
			setTradedQuantity();
			setNoPartyIds();
			setPartyIds();
			setPartyIDSource();
			setAllocationTrades();
			setNonToTvInstrument();
			setPortfolioCompressionTrades();
			setVenueTrade();
			setPriceDiscoveryAndNegotiatedTransaction();
			setProductDeliveryType();
			setEventType();
			setActionType();
			
		} catch (XPathExpressionException e) {
			LOG.error(String.format("Exception Occurred for Stream %s and Flow %s while Mapping Entity Object, exception is : %s", stream, flow, e.getMessage()));
			throw new RuntimeException(e);
		}
		
		return entity;
	}
	
	/**
	 * This method populates the Report Status in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setReportStatus() throws XPathExpressionException {
		populateEntityInfoForStringValues(REPORT_STATUS, REPORT_STATUS_XPATH);
	}
	
	/**
	 * This method populates the ExecutionVenueType in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setExecutionVenueType() throws XPathExpressionException {
		populateEntityInfoForStringValues(EXECUTION_VENUE_TYPE, EXECUTION_VENUE_TYPE_XPATH);
	}

	/**
	 * This method populates the TransactionToClear in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setTransactionToClear() throws XPathExpressionException {
		populateEntityInfoForStringValues(TRANSACTION_TO_CLEAR, TRANSACTION_TO_CLEAR_XPATH);
	}

	/**
	 * This method populates the Party Ids for all the Partys in Entity Domain
	 * Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setExecutingEntityIdentityficationCode() throws XPathExpressionException {

		String executingEntity_acctmnemonic = getNodeValue(String.format(PARTY_XPATH, EXECUTING_ENTITY, ACCT_MNEMONIC));
		String executingEntity_gfcid = getNodeValue(String.format(PARTY_XPATH, EXECUTING_ENTITY, GFCID));
		
		if(!StringUtils.isBlank(executingEntity_acctmnemonic)) {
			populateEntityInfoMap(EXECENTITY_ACCTMNEMONIC, executingEntity_acctmnemonic);
		}
		
		if(!StringUtils.isBlank(executingEntity_gfcid)) {
			populateEntityInfoMap(EXECENTITY_GFCID, executingEntity_gfcid);
		}
	}
	
	/**
	 * This method populates the InstrumentClassification in Entity Domain
	 * Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setInstrumentClassification() throws XPathExpressionException {
		populateEntityInfoForStringValues(INSTRUMENT_CLASSIFICATION, INSTRUMENT_CLASSIFICATION_XPATH);
	}

	/**
	 * This method populates the InstrumentIdentification in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setInstrumentIdentification() throws XPathExpressionException {
		populateEntityInfoForStringValues(INSTRUMENT_IDENTIFICATION, INSTRUMENT_IDENTIFICATION_XPATH);
	}
	
	/**
	 * This method populates the TradeExecutionTs in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setTradeExecutionTs() throws XPathExpressionException {
		
		populateEntityInfoForDateTimeValues(TRADE_DATE, TRADING_DATE_TIME_XPATH);
		
		if (entity.info.get(TRADE_DATE) != null){
			
			populateEntityInfoMap(TRADE_EXECUTION_TS, entity.info.get(TRADE_DATE));
			entity.executionTs = (LocalDateTime) entity.info.get(TRADE_DATE);
			entity.info.put(TRADE_DATE, ((LocalDateTime)entity.info.get(TRADE_DATE)).toLocalDate());
			
			entity.generateRegReportingRef();
		}
	}

	/**
	 * This method populates the WaiverIndicator in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setWaiverIndicator() throws XPathExpressionException {
		populateEntityInfoForStringValues(WAIVER_INDICATOR, WAIVER_INDICATOR_XPATH);
	}

	/**
	 * This method populates the OtcPostTradeIndicator in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setOtcPostTradeIndicator() throws XPathExpressionException {
		populateEntityInfoForStringValues(OTC_POST_TRADE_INDICATOR, OTC_POST_TRADE_INDICATOR_XPATH);
	}

	/**
	 * This method populates the ommoditiesDerivativeIndicator in Entity Domain
	 * Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setCommoditiesDerivativeIndicator() throws XPathExpressionException {
		populateEntityInfoForStringValues(COMMODITIES_DERIVATIVE_INDICATOR, COMMODITIES_DERIVATIVE_INDICATOR_XPATH);
	}

	/**
	 * This method populates the QtyInMeasurementUnit in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setQtyInMeasurementUnit() throws XPathExpressionException {
		populateEntityInfoForDoubleValues(QTY_IN_MESAUREMENT_UNIT, QTY_IN_MESAUREMENT_UNIT_XPATH);
	}

	/**
	 * This method sets the Last Capacity In Entity Object 
	 * @throws XPathExpressionException
	 */
	protected void setLastCapacity() throws XPathExpressionException {
		String tradingCapacity = getNodeValue(TRADE_CAPACITY_XPATH);
		if (StringUtils.isBlank(tradingCapacity)) {
			populateEntityInfoMap(LAST_CAPACITY, AOTC);
		} else if (StringUtils.equals(tradingCapacity, "MatchedPrincipal")) {
			populateEntityInfoMap(LAST_CAPACITY, MTCH);
		} else if (StringUtils.equals(tradingCapacity, "Principal")) {
			populateEntityInfoMap(LAST_CAPACITY, DEAL);
		}
	}

	
	/**
	 * This method populates the NotationOfQtyInMeasurementUnit in Entity Domain
	 * Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setNotationOfQtyInMeasurementUnit() throws XPathExpressionException {
		populateEntityInfoForStringValues(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT, NOTATION_OF_QTY_IN_MEASUREMENT_UNIT_XPATH);
	}

	/**
	 * This method populates the NotationalAmount in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setNotationalAmount() throws XPathExpressionException {
		populateEntityInfoForDoubleValues(NOTATIONAL_AMOUNT, NOTATIONAL_AMOUNT_XPATH);
	}

	/**
	 * This method populates the EmissionAllowanceType in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setEmissionAllowanceType() throws XPathExpressionException {
		populateEntityInfoForStringValues(EMISSION_ALLOWANCE_TYPE, EMISSION_ALLOWANCE_TYPE_XPATH);
	}

	/**
	 * This method populates the InstrIdentTypeCode in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setInstrIdentTypeCode() throws XPathExpressionException {

		String isinPrdType = getNodeValue(INSTRUMENT_CLASSIFICATION_XPATH);

		if (!StringUtils.isBlank(isinPrdType)) {
			entity.info.put(INSTR_IDENT_CODE_TYPE, ISIN_CD);
			entity.info.put(INSTR_IDENT_CODE, isinPrdType);
			entity.info.put(SECURITY_ISIN, isinPrdType);
		}
	}

	/**
	 * This method populates the PRICE_CURRENCY in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setPriceCurrency() throws XPathExpressionException {
		populateEntityInfoForStringValues(PRICE_CURRENCY, PRICE_CURRENCY_XPATH);
	}

	/**
	 * This method populates the NOTIONAL_CURRENCY in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setNotionalCurrency() throws XPathExpressionException {

		setNotionalCurrency1();

		if (null == entity.info.get(NOTIONAL_CURRENCY)) {
			populateEntityInfoForStringValues(NOTIONAL_CURRENCY, NOTIONAL_CURRENCY_XPATH);
		}
	}

	/**
	 * This method populates the setUnderlyingIndexName in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setUnderlyingIndexName() throws XPathExpressionException {
		populateEntityInfoForDoubleValues(UNDERLYING_INDEX_NAME, UNDERLYING_INDEX_NAME_XPATH);

	}
	
	/**
	 * This method populates the optionType in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setOptionType() throws XPathExpressionException {
		populateEntityInfoForStringValues(OPTION_TYPE, OPTION_TYPE_XPATH);
		
	}
	
	/**
	 * This method populates the optionType in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setStrikePrice() throws XPathExpressionException {
		
		String strikePrice = getNodeValue(STRIKE_PRICE_XPATH);
		String strikePricePerUnitAmount = getNodeValue(STRIKE_PRICE_PER_UNIT_AMOUNT_XPATH);
		
		if(!StringUtils.isBlank(strikePrice)) {
			getDoubleValue(STRIKE_PRICE, strikePrice);
		} else if (!StringUtils.isBlank(strikePricePerUnitAmount)) {
			getDoubleValue(STRIKE_PRICE, strikePricePerUnitAmount);
		}
	}
	
	/**
	 * This method populates the optionExerciseStyle in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setOptionExerciseStyle() throws XPathExpressionException {
		populateEntityInfoForStringValues(OPTION_EXERCISE_STYLE, OPTION_EXERCISE_STYLE_XPATH);
		
	}
	
	/**
	 * This method populates the deliveryType in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setDeliveryType() throws XPathExpressionException {
		populateEntityInfoForStringValues(DELIVERY_TYPE, DELIVERY_TYPE_XPATH);
		
	}
	
	/**
	 * This method populates the optionType in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setStrikePriceCurrency() throws XPathExpressionException {
		
		String strikePriceCurrency = getNodeValue(STRIKE_PRICE_CURRENCY_XPATH);
		String strikePricePerUnitCurrency = getNodeValue(STRIKE_PRICE_PER_UNIT_CURRENCY_XPATH);
		
		if(!StringUtils.isBlank(strikePriceCurrency)) {
			populateEntityInfoMap(STRIKE_PRICE_CURRENCY, strikePriceCurrency);
		} else if (!StringUtils.isBlank(strikePricePerUnitCurrency)) {
			populateEntityInfoMap(STRIKE_PRICE_CURRENCY, strikePricePerUnitCurrency);
		}
	}
	
	/**
	 * This method populates the setTermOfUnderlyingIndex in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setTermOfUnderlyingIndex() throws XPathExpressionException {
		
		String periodMultiplier = getNodeValue(PERIOD_MULTIPLIER_XPATH);
		String period = getNodeValue(PERIOD_XPATH);
		
		if(!StringUtils.isBlank(periodMultiplier)) {
			populateEntityInfoMap(TERM_OF_UNDERLYING_INDEX, periodMultiplier);
		} else if (!StringUtils.isBlank(period)) {
			populateEntityInfoMap(TERM_OF_UNDERLYING_INDEX, period);
		}
		
	}
	
	/**
	 * This method populates the contract Multiplier in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setNotionalCurrency2() throws XPathExpressionException {
		populateEntityInfoForStringValues(NOTIONAL_CURRENCY2, NOTIONAL_CURRENCY_XPATH);

	}
	
	/**
	 * This method populates the NOTIONAL_CURRENCY 1 in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setNotionalCurrency1() throws XPathExpressionException {

		populateEntityInfoForStringValues(NOTIONAL_CURRENCY, NOTIONAL_CURRENCY_XPATH_1);

	}
	
	/**
	 * This method populates the PRICE_NOTATION in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setPriceNotation() throws XPathExpressionException {

		String amount = getNodeValue(PRICE_NOTATION_AMT_XPATH);
		String priceRate = getNodeValue(PRICE_NOTATION_PRC_RATE_XPATH);

		if (!StringUtils.isBlank(amount)) {
			populateEntityInfoMap(PRICE_NOTATION, MONE);
		} else if (!StringUtils.isBlank(priceRate)) {
			populateEntityInfoMap(PRICE_NOTATION, PERC);
		}

	}

	/**
	 * This method populates the TradeVenueTransactionId in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setTradeVenueTransactionId() throws XPathExpressionException {
		
		String uitid1 = getNodeValue(String.format(UITID_XPATH, UITID1));
		String uitid2 = getNodeValue(String.format(UITID_XPATH, UITID2));
		String uitid3 = getNodeValue(String.format(UITID_XPATH, UITID3));
		
		if(!StringUtils.isBlank(uitid1)) {
			populateEntityInfoMap(TRADE_VENUE_TRANSACT_ID, uitid1);
		} else if(!StringUtils.isBlank(uitid2)) {
			populateEntityInfoMap(TRADE_VENUE_TRANSACT_ID, uitid2);
		} else if(!StringUtils.isBlank(uitid3)) {
			populateEntityInfoMap(TRADE_VENUE_TRANSACT_ID, uitid3);
		}
		
		if(null != entity.info.get(TRADE_VENUE_TRANSACT_ID)) {
			
			entity.sourceId = (String) entity.info.get(TRADE_VENUE_TRANSACT_ID);
			
			String tradeVersion = getNodeValue(TRADE_VERSION_XPATH);
			String tradeSubVersion = getNodeValue(TRADE_SUBVERSION_XPATH);
			populateEntityInfoMap(TRADE_VERSION, tradeVersion);
			populateEntityInfoMap(TRADE_SUBVERSION, tradeSubVersion);
			
			entity.sourceVersion = tradeVersion;
			entity.sourceUId = stream+"-"+flow+"-"+entity.sourceId+"-"+tradeVersion+"-"+tradeSubVersion;
			
		}
		
	}

	/**
	 * This method populates the TradeVenueTransactionId in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setTradedQuantity() throws XPathExpressionException {

		String quantity = getNodeValue(QTY_IN_MESAUREMENT_UNIT_XPATH);
		String amount = getNodeValue(NOTATIONAL_AMOUNT_XPATH);

		if (!StringUtils.isBlank(quantity)) {
			getDoubleValue(TRADED_QTY, quantity);
		} else if (!StringUtils.isBlank(amount)) {
			getDoubleValue(TRADED_QTY, amount);
		}
	}
	
	/**
	 * This method populates the Number of Party Ids in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setNoPartyIds() throws XPathExpressionException {
		populateEntityInfoMap(NO_PARTY_IDS, 2);
	}
	
	/**
	 * This method populates the Party Ids for all the Partys in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	/*protected void setPartyIds() throws XPathExpressionException {
		
		String execFirmAccMnemonic = null;
		String execFirmGfcid = null;
		String cptyFirmAccMnemonic = null;
		String cptyFirmGfcid = null;
		
		String partyAPartyType = getNodeValue(String.format(PARTY_XPATH, PARTY_A, PARTY_TYPE));
		String partyBPartyType = getNodeValue(String.format(PARTY_XPATH, PARTY_B, PARTY_TYPE));
		
		String partyA_AccountMnemonic = getNodeValue(String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC));
		String partyA_GFCID = getNodeValue(String.format(PARTY_XPATH, PARTY_A, GFCID));
		
		String partyB_AccountMnemonic = getNodeValue(String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC)); ;
		String partyB_GFCID = getNodeValue(String.format(PARTY_XPATH, PARTY_B, GFCID));
		
		if(!StringUtils.isBlank(partyAPartyType) && partyAPartyType.startsWith("Executing")) {
			
			execFirmAccMnemonic = partyA_AccountMnemonic;
			execFirmGfcid = partyA_GFCID;
			cptyFirmAccMnemonic = partyB_AccountMnemonic;
			cptyFirmGfcid = partyB_GFCID;
			
		} else if (!StringUtils.isBlank(partyBPartyType) && partyBPartyType.startsWith("Executing")) {
			
			cptyFirmAccMnemonic = partyA_AccountMnemonic;
			cptyFirmGfcid = partyA_GFCID;
			execFirmAccMnemonic = partyB_AccountMnemonic;
			execFirmGfcid = partyB_GFCID;
			
		}
		
		if(!StringUtils.isBlank(execFirmAccMnemonic)) {
			populateEntityInfoMap(EXEC_FIRM_ACCT_MNEMONIC, execFirmAccMnemonic);
		}
		if(!StringUtils.isBlank(execFirmGfcid)) {
			populateEntityInfoMap(EXEC_FIRM_GFCID, execFirmGfcid);
		}
		if(!StringUtils.isBlank(cptyFirmAccMnemonic)) {
			populateEntityInfoMap(CPTY_FIRM_ACCT_MNEMONIC, cptyFirmAccMnemonic);
		}
		if(!StringUtils.isBlank(cptyFirmGfcid)) {
			populateEntityInfoMap(CPTY_FIRM_GFCID, cptyFirmGfcid);
		}

		
	}*/

	protected void setPartyIds() throws XPathExpressionException {
		
		String partyA_AccountMnemonic = getNodeValue(String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC));
		String partyA_GFCID = getNodeValue(String.format(PARTY_XPATH, PARTY_A, GFCID));
		
		String partyB_AccountMnemonic = getNodeValue(String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC)); ;
		String partyB_GFCID = getNodeValue(String.format(PARTY_XPATH, PARTY_B, GFCID));
		
		if(!StringUtils.isBlank(partyA_AccountMnemonic)) {
			populateEntityInfoMap(EXEC_FIRM_ACCT_MNEMONIC, partyA_AccountMnemonic);
			//populateEntityInfoMap(EXEC_FIRM_ACCT_MNEMONIC_TYPE, ACCT_MNEMONIC_TYPE);
		}
		if(!StringUtils.isBlank(partyA_GFCID)) {
			populateEntityInfoMap(EXEC_FIRM_GFCID, partyA_GFCID);
		}
		if(!StringUtils.isBlank(partyB_AccountMnemonic)) {
			populateEntityInfoMap(CPTY_FIRM_ACCT_MNEMONIC, partyB_AccountMnemonic);
			//populateEntityInfoMap(CPTY_FIRM_ACCT_MNEMONIC_TYPE, ACCT_MNEMONIC_TYPE);
		}
		if(!StringUtils.isBlank(partyB_GFCID)) {
			populateEntityInfoMap(CPTY_FIRM_GFCID, partyB_GFCID);
		}
	}
	
	/**
	 * This method sets the Venue Type In Entity Object 
	 * @throws XPathExpressionException
	 */
	protected void setVenueTrade() throws XPathExpressionException {
		populateEntityInfoForStringValues(VENUE_TRADE, VENUE_TRADE_XPATH);
	}
	
	/**
	 * This method populates the Party ID Source (defaulted to String 'N') in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setPartyIDSource() throws XPathExpressionException {
		populateEntityInfoMap(PARTY_ID_SOURCE, N);
	}
	
	/**
	 * This method populates the PORTFOLIO_COMPRESSION_TRADES in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setPortfolioCompressionTrades() throws XPathExpressionException {
		populateEntityInfoForStringValues(PORTFOLIO_COMPRESSION_TRADES, PORTFOLIO_COMPRESSION_TRADES_XPATH);
	}
	
	/**
	 * This method populates the FXSpots in Entity Domain Object
	 * @throws XPathExpressionException
	 */
	protected void setProductDeliveryType() throws XPathExpressionException {
		populateEntityInfoForStringValues(PRODUCT_DELIVERY_TYPE, PRODUCT_DELIVERY_TYPE_XPATH);
	}
	
	/**
	 * This method sets theTrade Report Trans Type In Entity Object 
	 * @throws XPathExpressionException
	 */
	protected void setTradeReportTransType() throws XPathExpressionException {
		populateEntityInfoForStringValues(TRADE_REPORT_TRANS_TYPE, REPORT_STATUS_XPATH);
	}
	
	/**
	 * This method populates the contract Multiplier in Entity Domain Object
	 * 
	 * @throws XPathExpressionException
	 */
	protected void setContractMultiplier() throws XPathExpressionException {
		populateEntityInfoForDoubleValues(CONTRACT_MULTIPLIER, CONTRACT_MULTIPLIER_XPATH);
	}
	
	/**
	 * This methods process all the String attributes in the given XPATH, and
	 * fill the Entity Domain Object
	 * 
	 * @param entityInfoKey
	 * @param xPathMapKey
	 * @throws XPathExpressionException
	 */
	protected void populateEntityInfoForStringValues(String entityInfoKey, String xPathMapKey)
			throws XPathExpressionException {

		String nodeValue = getNodeValue(xPathMapKey);

		if (null != nodeValue) {
			populateEntityInfoMap(entityInfoKey, nodeValue);
		}
	}

	/**
	 * This methods process all the Double attributes in the given XPATH,
	 * converts them to Double format and fill the Entity Domain Object
	 * 
	 * @param entityInfoKey
	 * @param xPathMapKey
	 * @throws XPathExpressionException
	 */
	protected void populateEntityInfoForDoubleValues(String entityInfoKey, String xPathMapKey)
			throws XPathExpressionException {

		String nodeValue = getNodeValue(xPathMapKey);

		if (null != nodeValue) {
			getDoubleValue(entityInfoKey, nodeValue);
		}

	}

	/**
	 * This utility methods converts the String representation to Double format.
	 * 
	 * @param entityInfoKey
	 * @param nodeValue
	 */
	protected void getDoubleValue(String entityInfoKey, String nodeValueInStr) {
		BigDecimal nodeValueBigD = new BigDecimal(nodeValueInStr);
		//Double nodeValue = Double.valueOf(nodeValueInStr);
		populateEntityInfoMap(entityInfoKey, nodeValueBigD);
	}

	/**
	 * This methods process all the DateTime attributes in the given XPATH,
	 * converts them to Date time and fill the Entity Domain Object
	 * 
	 * @param entityInfoKey
	 * @param xPathMapKey
	 * @throws XPathExpressionException
	 */
	protected void populateEntityInfoForDateTimeValues(String entityInfoKey, String xPathMapKey)
			throws XPathExpressionException {

		String nodeValue = getNodeValue(xPathMapKey);

		if (null != nodeValue) {
			getLocalTimeStampValue(entityInfoKey, nodeValue);
		}

	}

	/**
	 * This is a utility method that converts the String representation fo Time
	 * to LocalDateTime and populates the Entity object.
	 * 
	 * @param entityInfoKey
	 * @param nodeValue
	 */
	protected void getLocalTimeStampValue(String entityInfoKey, String nodeValueInStr) {
		LocalDateTime nodeValue = LocalDateTime.parse(nodeValueInStr, DateTimeFormatter.ISO_DATE_TIME);
		populateEntityInfoMap(entityInfoKey, nodeValue);
	}

	/**
	 * This method returns the Value present in the XML DOM for the given XPATH.
	 * 
	 * @param xPathMapKey
	 * @return
	 * @throws XPathExpressionException
	 */
	protected String getNodeValue(String xPathMapKey) throws XPathExpressionException {
		
		String nodeValue = xPathUtilInstance.getNodeValueFromXpathExpression(xPath, xPathMapKey, xmlDocument);
		LOG.debug(String.format("Node value %s returned for input xpath is %s", nodeValue, xPathMapKey));
		return nodeValue;
	}

	/**
	 * Populates the Entity Info Map
	 * @param entityInfoKey
	 * @param nodeValue
	 */
	protected void populateEntityInfoMap(String entityInfoKey, Object nodeValue) {
		entity.info.put(entityInfoKey, nodeValue);
	}
	
	/**
	 * Populates the Entity Info Map
	 * @param entityInfoKey
	 * @param nodeValue
	 */
	protected void populateEntityFlagList(String flagToAdd) {
		entity.flags.add(flagToAdd);
	}
	
	/**
	 * Populates EventType for Trade
	 * @throws XPathExpressionException 
	 * 
	 */
	protected void setEventType() throws XPathExpressionException {
		populateEntityInfoForStringValues(EVENT_TYPE, EVENT_TYPE_XPATH);
		
	}
	
	/**
	 * Populates Action for Trade Lifecycle
	 * @throws XPathExpressionException 
	 * 
	 */
	protected void setActionType() throws XPathExpressionException {
		populateEntityInfoForStringValues(ACTION_TYPE, ACTION_TYPE_XPATH);		
	}
	
	/**
	 * @throws XPathExpressionException 
	 * 
	 */
	protected void populateMandatoryFeildsInEntityObject() throws XPathExpressionException {

		entity.status = EntityStatus.REPORTABLE;
		entity.stream = stream;
		entity.flow = flow;
		entity.receivedTs = LocalDateTime.now();
		entity.lastUpdatedTs = LocalDateTime.now();
		
		//this is creation TimeStamp in the CITIML XML
		entity.publishedTs = getPublishedTimeStamp();
		entity.sourceSystem = getNodeValue(SOURCE_SYSTEM_XPATH);
		entity.sourceStatus = "NEW";
		
	}

	/**
	 * 
	 * @return
	 * @throws XPathExpressionException
	 */
	protected LocalDateTime getPublishedTimeStamp() throws XPathExpressionException {
		
		String publishTsString = getNodeValue(PUBLISH_TS_XPATH);
		
		if(!StringUtils.isBlank(publishTsString)) {
			return LocalDateTime.parse(publishTsString, DateTimeFormatter.ISO_DATE_TIME);
		}
		
		return null;
	}

	protected void setAllocationTrades() throws XPathExpressionException {
		//TODO : XPATH is yet to be finalised by BA.
		populateEntityInfoForStringValues(ALLOC_TRADE_STATUS, ALLOCATION_TRADES_XPATH);
	}

	protected void setNonToTvInstrument() throws XPathExpressionException {
		//TODO : XPATH is yet to be finalised by BA.
		populateEntityInfoForStringValues(NON_TOTV_INSTRUMENT, NON_TOTV_INSTRUMENT_XPATH);
	}

	protected void setPriceDiscoveryAndNegotiatedTransaction() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
		populateEntityInfoForStringValues(PRICE_DISC_N_NEGO_TXN, PRICE_DISCOVERY_AND_NEGOTIIATED_TRANS_XPATH);
	}

	protected void setPartyRole() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setTradeType() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setOrderCategory() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setTradeSubtype() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setBuyerIdentificationCode() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setFirmTrade() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setQuantityType() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setUnitOfMeasureQty() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}
	
	protected void setSecondaryTrdType() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setAlgorithmicTradeIndicator() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setTradePublishIndicator() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}

	protected void setSellerIdentificationCode() throws XPathExpressionException {
		//TODO : Once XPATH is finalised by BA.
	}
	
	/**
	 * This method populates the Price in Entity Domain Object
	 * Needs to be Overridden by IMPL classes
	 * @throws XPathExpressionException
	 */
	protected abstract void setPrice() throws XPathExpressionException;
	
	/**
	 * This method populates the VenueOfExecution in Entity Domain Object
	 * Needs to be Overridden by IMPL classes
	 * @throws XPathExpressionException
	 */
	protected abstract void setVenueOfExecution() throws XPathExpressionException;
	
}
