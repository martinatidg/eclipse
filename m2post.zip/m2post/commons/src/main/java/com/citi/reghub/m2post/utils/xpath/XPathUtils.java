package com.citi.reghub.m2post.utils.xpath;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;

import org.w3c.dom.Document;

/**
 * This is a utility class for XPATH related processing for M2POST.
 * @author pg60809
 *
 */
public class XPathUtils {

	
	/**
	 * This method extracts the values from the input DOM using the provided XPATH expression. 
	 * @param xPath
	 * @param xPathExpression
	 * @param xmlDocument
	 * @return Object
	 * @throws XPathExpressionException
	 */
	public String getNodeValueFromXpathExpression (XPath xPath, String xPathExpression, Document xmlDocument) throws XPathExpressionException {
		
		String nodeValue = null;
		
		if(isValidXpathAndXpathExpression(xPath, xPathExpression)) {
			
			nodeValue = (String) xPath.compile(xPathExpression).evaluate(xmlDocument, XPathConstants.STRING);
			
			if (validateString(nodeValue)) {
				nodeValue = null;
			}
		}
		return nodeValue;
	}

	/**
	 * This method validates Xpath and xpath expression
	 * @param xPath
	 * @param xPathExpression
	 * @return
	 */
	private boolean isValidXpathAndXpathExpression(XPath xPath, String xPathExpression) {
		if(null == xPath || validateString(xPathExpression)) {
			return false;
		}
		return true;
	}

	/**
	 * This is an utility method to validate String
	 * @param inputString
	 * @return
	 */
	private boolean validateString(String inputString) {
		return null == inputString || inputString.isEmpty();
	}
	
}
