package com.citi.reghub.m2post.utils.custombolts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityCacheSeqDetails;
import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;

public class SequencerRealTimeBolt extends RegHubBolt {

	private static final long serialVersionUID = 1L;
	protected static final Logger LOG = LoggerFactory.getLogger(SequencerRealTimeBolt.class);
	public static final String SEQUECNER_CACHE_COLLECTION_NAME = "cache.collection.name";
	
	public OutputCollector _collector;
	public CacheClient cacheClient;
	public Map<String, String> SeqCacheconfig;
	//String hazelcastLockPeriod = "1000";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		setCacheClient(topologyConfig);
		SeqCacheconfig = getMapInstance();
		SeqCacheconfig.put(CacheClient.CACHE_COLLECTION_NAME,topologyConfig.get(SEQUECNER_CACHE_COLLECTION_NAME));
		SeqCacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient = getCacheInstance();
	}
	
	protected CacheClient getCacheInstance() {
		return SingletonCacheClient.getInstance();
	}

	public HashMap<String, String> getMapInstance() {
		return new HashMap<>();
	}
	
	public void process(Tuple input) {
		Entity message = (Entity) input.getValueByField("message");
		LOG.info("Entity Inside Sequencer Real Time Bolt : {}",message);
		String auditResult;
		String key = message.sourceId;
		String sourceStatus = message.sourceStatus;
		if (cacheClient.tryLock(key, SeqCacheconfig)) {
			LOG.info("Lock Acquired successfully !");
			try {
				EntityCacheSeqDetails seqObjWithSameKey=(EntityCacheSeqDetails)cacheClient.get(key, SeqCacheconfig);
				if((seqObjWithSameKey == null) && ((sourceStatus.equalsIgnoreCase(SourceStatus.NEW)) || (sourceStatus.equalsIgnoreCase(SourceStatus.AMEND)))) {
						LOG.info("Cache is Empty and Source Status is Either NEW or AMEND for regHubID : {}",message.regHubId);
						message.status = EntityStatus.REPORTABLE;
						message.sourceStatus = SourceStatus.NEW;
						storeMessageInCacheAndPushToSequencerOutbound(message);
				}
				else if((seqObjWithSameKey != null) && ((seqObjWithSameKey.publishedTs.isBefore(message.publishedTs)) || 
						(seqObjWithSameKey.publishedTs.isEqual(message.publishedTs)))) {
					LOG.info("Cache is Not Empty and Cached Time Stamp is Before Input Message Ts for reghubid : {}",message.regHubId);
					if((sourceStatus.equalsIgnoreCase(SourceStatus.NEW)) ||  ((sourceStatus.equalsIgnoreCase(SourceStatus.AMEND)) && (seqObjWithSameKey.sourceStatus.equalsIgnoreCase(SourceStatus.CANCEL)))){
						LOG.info("Source Status is NEW or AMEND and cached soruce Status is Cancel for regHubId : {}",message.regHubId);
						message.status = EntityStatus.PENDING;
					}
					else {
						LOG.info("Source Status is NOT NEW or AMEND OR cached soruce Status is Not Cancel for regHubId : {}",message.regHubId);
						message.status =EntityStatus.REPORTABLE;
						storeMessageInCacheAndPushToSequencerOutbound(message);
					}
				}
				else {
					LOG.info("Cache is Not Empty and Cached Time Stamp is After Input Message Ts for reghubid : {}",message.regHubId);
					message.status = EntityStatus.PENDING;
				}
			}
			finally {
				LOG.info("Trying to unlock after processing : "+message.regHubId);
				cacheClient.unlock(key, SeqCacheconfig);
				LOG.info("Unlock Successful after processing : "+message.regHubId);
			}
			LOG.info("Processing Completed after Locking for reghubid : "+message.regHubId);
			auditResult = message.status;
			_collector.emit(StormStreams.COMMON_REPORTABLE_STREAM, new Values(message.regHubId, message));
		}
		else {
			LOG.info("Cannot Acquire lock hence pushing back for reghubid : "+message.regHubId);
			auditResult = "NO-LOCK";
			_collector.emit(StormStreams.PUSHBACK_REPORTABLE_STREAM, new Values(message.regHubId, message));
		}
		_collector.ack(input);
		pushMessageToAuditStream(message, auditResult);
	}
	
	public void storeMessageInCacheAndPushToSequencerOutbound(Entity message){
		LOG.info("Storing message into hazelcast and publsihing to Sequenced Outound Stream "+ message);
		EntityCacheSeqDetails seqObj = 	new EntityCacheSeqDetails(message);
		String key = message.sourceId;
		cacheClient.put(key, seqObj, SeqCacheconfig);
		_collector.emit(StormStreams.SEQUENCED_OUTBOUND_STREAM, new Values(message.sourceId, message));
	}
	
	public void pushMessageToAuditStream(Entity message, String auditResult){
		LOG.info("Publsihing to Audit Stream "+ message);
		Audit audit = message.toAudit();
		audit.event = "SEQUENCING";
		audit.result = auditResult;
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}

	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.PUSHBACK_REPORTABLE_STREAM, new Fields("key", "message"));
		declarer.declareStream(StormStreams.SEQUENCED_OUTBOUND_STREAM, new Fields("key", "message"));
		declarer.declareStream(StormStreams.COMMON_REPORTABLE_STREAM, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SEQUENCER_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SEQUENCER);
		return exceptionTags;
	}
}

