package com.citi.reghub.m2post.utils.xpath;

/**
 * Constants to hold all the XPATHs associated with CITIML message
 * @author pg60809
 *
 */
public interface XPathExpressions {

	
	//Mandtory Entity Object XAPTHs CITIML Message
	public static final String SOURCE_SYSTEM_XPATH = "/citimlTradeNotification/citimlTradeNotificationMessageHeader/citimlOriginatingSystemName";
	public static final String SOURCE_UNIQUE_ID_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent/nonpublicExecutionReport/header/messageId";
	public static final String PUBLISH_TS_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent/nonpublicExecutionReport/header/creationTimestamp";
	public static final String TRADE_VERSION_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeIdentifier/versionedTradeId[tradeId[@tradeIdScheme = 'InternalTradeID']]/version";
	public static final String TRADE_SUBVERSION_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeIdentifier/versionedTradeId[tradeId[@tradeIdScheme = 'InternalTradeIdSubversion']]/version";
	
	public static final String UITID_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeIdentifier/tradeId[@tradeIdScheme='%s']";
	
	public static final String EXECUTION_VENUE_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeInformation/executionVenueType";
	public static final String TRANSACTION_TO_CLEAR_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeInformation/intentToClear";
	public static final String TRADING_DATE_TIME_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeInformation/executionDateTime";
	public static final String TRADE_VENUE_TRANSACT_ID_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/tradeHeader/partyTradeIdentifier[partyReference[@href='PartyA']]/tradeId[@tradeIdScheme='http://www.dtcc.com/internal_Referenceid']";
	public static final String INSTRUMENT_CLASSIFICATION_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/productId[@productIdScheme= 'http://www.fpml.org/coding-scheme/external/iso6166']";
	public static final String WAIVER_INDICATOR_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlTradingWaiver";
	public static final String OTC_POST_TRADE_INDICATOR_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlOTCClassification";
	public static final String COMMODITIES_DERIVATIVE_INDICATOR_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlIsCommodityHedge";
	public static final String QTY_IN_MESAUREMENT_UNIT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedInstrumentQuantity/quantity";
	public static final String NOTATION_OF_QTY_IN_MEASUREMENT_UNIT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedInstrumentQuantity/quantityUnit";
	public static final String NOTATIONAL_AMOUNT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/amount";
	public static final String EMISSION_ALLOWANCE_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/productType[@productTypeScheme=\"http://www.fpml.org/coding-scheme/esma-product-classification\"]";
	public static final String PRICE_CURRENCY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradePrice/priceAmount/currency";
	public static final String NOTIONAL_CURRENCY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/currency";
	public static final String NOTIONAL_CURRENCY_XPATH_1 = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/currency";
	public static final String PRICE_NOTATION_AMT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradePrice/priceAmount/amount";
	public static final String PRICE_NOTATION_PRC_RATE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradePrice/priceAmount/priceRate";
	public static final String PRICE_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradePrice/citimlFixedPrice/priceType";
	public static final String PARTY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlParties/party[@id='%s']/partyId[@partyIdScheme='%s']";
	public static final String INSTRUMENT_IDENTIFICATION_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/productId[@productIdScheme= 'http://www.fpml.org/coding-scheme/external/iso6166']";
	public static final String FX_TRADE_VENUE_TRANSACT_ID_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent/nonpublicExecutionReport/trade/tradeHeader/partyTradeIdentifier[2][partyReference[@href='ExecutionFacility']]/tradeId[@tradeIdScheme='http://www.dtcc.com/internal_Referenceid']";
	public static final String VENUE_TRADE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlParties/party[@id='ExecutionFacility']/partyId[@partyIdScheme='http://www.fpml.org/coding-scheme/external/iso10383']";
	public static final String TRADE_CAPACITY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/PartyTradeInformation/category[@categoryScheme='http://www.fpml.org/coding-scheme/external/esma/mifir/trading-capacity']";
	public static final String MONETARY_BASED_AMOUNT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/amount";
	public static final String FX_TRANSACTIONS_AMOUNT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/amount";
	public static final String MONETARY_BASED_NOTATION_OF_QUANTITY_IN_MEASUREMENT_UNIT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/currency";
	public static final String FX_TRANSACTIONS_NOTATION_OF_QUANTITY_IN_MEASUREMENT_UNIT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/citimlFixedNotionalAmount/currency";
	public static final String PRODUCT_DELIVERY_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlFxExtendedTradeDetails/productDeliveryType";
	public static final String REPORT_STATUS_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlTradeState";
	public static final String CONTRACT_MULTIPLIER_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlContractualFixedTradeSize/contractMultiplier";
	public static final String INSTRUMENT_CLASSIFICATION__WILDCARD_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/productId[@productIdScheme[starts-with(.,'http://www.fpml.org/coding-scheme/external/iso')]]";
	public static final String INSTRUMENT_CLASSIFICATION__TAXONOMY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/productId[@productIdScheme='http://www.fpml.org/coding-scheme/product-taxonomy']";
	public static final String UNDERLYING_INDEX_NAME_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/floatingRateIndex";
	public static final String PERIOD_MULTIPLIER_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/indexTenor/periodMultiplier";
	public static final String PERIOD_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/indexTenor/period";
	public static final String OPTION_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/optionType";
	public static final String STRIKE_PRICE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/strike/strikePrice";
	public static final String STRIKE_PRICE_PER_UNIT_AMOUNT_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/strikePricePerUnit/amount";
	public static final String STRIKE_PRICE_CURRENCY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/strike/currency";
	public static final String STRIKE_PRICE_PER_UNIT_CURRENCY_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/strikePricePerUnit/currency";
	public static final String OPTION_EXERCISE_STYLE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/genericProduct/exerciseStyle";
	public static final String DELIVERY_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlSettlementType";
	
	//TODO :  All below XPATHS are not yet defined by BA, hence keeping them empty
	public static final String ALLOCATION_TRADES_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlCustomerBusinessType";
	public static final String NON_TOTV_INSTRUMENT_XPATH = "";
	public static final String FX_SPOT_XPATH = "";
	public static final String PRICE_DISCOVERY_AND_NEGOTIIATED_TRANS_XPATH = "";
	public static final String PARTY_ROLE_XPATH = "";
	public static final String TRADE_TYPE_XPATH = "";
	public static final String ORDER_CATEGORY_XPATH = "";
	public static final String TRADE_SUBTYPE_XPATH = "";
	public static final String FIRM_TRADE_ID_XPATH = "";
	public static final String QUANTITY_TYPE_XPATH = "";
	public static final String UNIT_OF_MEASURE_XPATH = "";
	public static final String SECONDARY_TRADE_TYPE_XPATH = "";
	public static final String ALGORITHMIC_TRADE_INDICATOR_XPATH = "";
	public static final String TRADE_PUBLISH_INDICATOR = "";
	public static final String PORTFOLIO_COMPRESSION_TRADES_XPATH = "";
	
	
	 public static final String BUY_SELL_INDICATOR_XPATH="/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlFxExtendedTradeDetails/BuySellInd";
	 public static final String BUYER_PARTY_REFERENCE_XPATH ="/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/postEventTrade/{Product}/buyerPartyReference[@href='PartyA']";
			  
	 public static final String PRICE_RATE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade[i]/citiml:citimlTradeExtensionData/citiml:citimlTradeProcessing/citimlContractualFixedTradePrice/priceRate";
	 public static final String EXCERCISE_DATE_XPATH ="/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade[i]/citiml:citimlTradeExtensionData/citiml:citimlTradeProcessing/citimlTerminationDate";
	 public static final String EMISSION_ALLOWANCE_TRADE_TYPE_XPATH ="/citimlTradeNotificationList/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlComExtendedTradeDetails/citimlComInstruments/citimlComInstrument/citimlProduct/commoditySwaption/parameters/parameter[2]";
	 
	 public static final String EVENT_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlEvents/citimlEvent/nonpublicExecutionReport/tradingEvent/eventType";
	 public static final String ACTION_TYPE_XPATH = "/citimlTradeNotification/citimlNotificationBundleDetails/citimlPostEventTrades/citimlPostEventTrade/citimlTradeExtensionData/citimlTradeProcessing/citimlLifeCycleAction/citimlAction";

}
