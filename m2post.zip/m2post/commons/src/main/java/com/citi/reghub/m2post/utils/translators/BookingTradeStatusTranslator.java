package com.citi.reghub.m2post.utils.translators;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.SourceStatus;

public class BookingTradeStatusTranslator implements TradeStatusTranslator {
	
	private static final Logger LOG = LoggerFactory.getLogger(BookingTradeStatusTranslator.class);
	
	public List<Entity> translateTradeStatus(Entity currEntity, Entity prevEntity) {
		LOG.info("Chaning Entity Status to NEW as its a BOOKING tarde");
		currEntity.sourceStatus = SourceStatus.NEW;
		return null;
	}
}