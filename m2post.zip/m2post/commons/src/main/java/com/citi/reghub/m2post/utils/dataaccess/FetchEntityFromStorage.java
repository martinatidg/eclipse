package com.citi.reghub.m2post.utils.dataaccess;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;

public class FetchEntityFromStorage {

	protected static final Logger LOG = LoggerFactory.getLogger(FetchEntityFromStorage.class);
	
	public Entity fetchEntityFromCacheOrDb(RestClient restClient, CacheClient cacheClient, 
				String cacheKey, Map<String, String> cacheConfig, String serviceUrl){
		
		LOG.info("Fetching Entity From Storage for SourceId "+cacheKey);
		
		Entity entityToReturn = null;
		
		entityToReturn = (Entity)cacheClient.get(cacheKey, cacheConfig);
		
		if(null == entityToReturn){
			LOG.info("Entity not found in Cache, hitting db for SourceId - "+cacheKey);
			List<Entity> entityToReturnList = restClient.getValues(serviceUrl, Entity.class);
			entityToReturn = (entityToReturnList != null && !entityToReturnList.isEmpty()) ? entityToReturnList.get(0) : null;
		}
		
		LOG.info("Entity Fetched from Storage - "+entityToReturn);
		
		return entityToReturn;
	}
	
}
