/**
 * 
 */
package com.citi.reghub.m2post.utils.translators;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;

/**
 * @author dk77005
 *
 */
public class AmendmentTradeStatusTranslator implements TradeStatusTranslator {
	
	private static final Logger LOG = LoggerFactory.getLogger(AmendmentTradeStatusTranslator.class);
	
	public List<Entity> translateTradeStatus(Entity currEntity, Entity prevEntity) {
		
		List<Entity> entities = new ArrayList<>();
		
		if(isNotionalPriceUnitAmended(currEntity, prevEntity)) {
			
			BigDecimal inputNotional = currEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
			BigDecimal dbNotional = prevEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
			BigDecimal deltaNotional = inputNotional.subtract(dbNotional);
			
			currEntity.info.put(InfoMapKeyStringConstants.NOTIONAL_AMOUNT, deltaNotional);
			currEntity.info.put(InfoMapKeyStringConstants.REF_REG_HUBID, prevEntity.regHubId);
			currEntity.executionTs = prevEntity.executionTs;
			currEntity.sourceStatus = SourceStatus.NEW;
			entities.add(currEntity);
		} else {
			// Cancel previous transaction
			prevEntity.sourceStatus = SourceStatus.CANCEL;
			entities.add(prevEntity);
			
			// Add current transaction as NEW
			currEntity.info.put(InfoMapKeyStringConstants.REF_REG_HUBID, prevEntity.regHubId);
			currEntity.executionTs = prevEntity.executionTs;
			currEntity.sourceStatus = SourceStatus.NEW;
			entities.add(currEntity);
		}
		
		return entities;
		
	}
	
	private boolean isNotionalPriceUnitAmended(Entity inputEntity, Entity dbEntity) {
		return isNotionalChanged(inputEntity, dbEntity) || isPriceChanged(inputEntity, dbEntity) || isUnitChanged(inputEntity, dbEntity);
	}
	
	private boolean isPriceChanged(Entity inputEntity, Entity dbEntity) {
		// TODO: (dk77005) Remove the local variable later 
		BigDecimal inputPrice = inputEntity.getBigDecimal(InfoMapKeyStringConstants.PRICE);
		BigDecimal dbPrice = dbEntity.getBigDecimal(InfoMapKeyStringConstants.PRICE);
		LOG.debug("New Price = " + inputPrice + ", Old Price = " + dbPrice);
		return inputPrice.compareTo(dbPrice)!=0?true:false;
		//return inputPrice != dbPrice;
	}

	private boolean isUnitChanged(Entity inputEntity, Entity dbEntity) {
		// TODO: (dk77005) Remove the local variable later
		BigDecimal inputUnit = inputEntity.getBigDecimal(InfoMapKeyStringConstants.TRADED_QTY);
		BigDecimal dbUnit = dbEntity.getBigDecimal(InfoMapKeyStringConstants.TRADED_QTY);
		LOG.debug("New Qty = " + inputUnit + ", Old Qty = " + dbUnit);
		return inputUnit.compareTo(dbUnit)!=0?true:false;
	}

	private boolean isNotionalChanged(Entity inputEntity, Entity dbEntity) {
		// TODO: (dk77005) Remove the local variable later
		BigDecimal inputNotional = inputEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
		BigDecimal dbNotional = dbEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
		LOG.debug("New Notional = " + inputNotional + ", Old Notional = " + dbNotional);
		return inputNotional.compareTo(dbNotional)!=0?true:false;
	}
}
