package com.citi.reghub.m2post.utils.translators;

import java.math.BigDecimal;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;
import com.esotericsoftware.minlog.Log;

public class TradeStatusTranslationProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(TradeStatusTranslationProcessor.class);

	public void enhanceTradeStatus(Entity inputEntity, Entity dbEntity) {

		if (null == dbEntity) {
			inputEntity.sourceStatus = SourceStatus.NEW;
			return;
		}

		compareNotionalDeltaAndUpdateInputEntity(inputEntity, dbEntity);
	}

	private void compareNotionalDeltaAndUpdateInputEntity(Entity inputEntity, Entity dbEntity) {
		// if any of the (reporting) MIFID fields is changed go in the loop
		if (isCriticalFieldChanged(inputEntity, dbEntity)) {
			Log.debug("Change in critical MIFID fields detected.");
			if(isAmendment(inputEntity, dbEntity)) {
				updateInputEntityData(inputEntity, dbEntity);
			} else {
				// Cancel New Scenario
			}
		}
	}

	private void updateInputEntityData(Entity inputEntity, Entity dbEntity) {
		BigDecimal inputNotional = inputEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
		BigDecimal dbNotional = dbEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
		BigDecimal deltaNotional = inputNotional.subtract(dbNotional);
		
		inputEntity.info.put(InfoMapKeyStringConstants.NOTIONAL_AMOUNT, deltaNotional);
		inputEntity.info.put(InfoMapKeyStringConstants.REF_REG_HUBID, dbEntity.regHubId);
		inputEntity.executionTs = dbEntity.executionTs;
		inputEntity.sourceStatus = SourceStatus.NEW;
	}
	
	private boolean isAmendment(Entity inputEntity, Entity dbEntity) {
		return isNotionalChanged(inputEntity, dbEntity) || isPriceChanged(inputEntity, dbEntity) || isUnitChanged(inputEntity, dbEntity);
	}

	// Iterate on all MIFID (Reportable) fields see if any is changed.
	private boolean isCriticalFieldChanged(Entity inputEntity, Entity dbEntity) {
		
		Set<String> keyset = inputEntity.info.keySet();
		for (String key : keyset) {
			Object inputEntityValue = inputEntity.info.get(key);
			Object dbEntityValue = dbEntity.info.get(key);
			
			return ObjectUtils.equals(inputEntityValue, dbEntityValue);
					
			/*if(null == inputEntityValue && null != dbEntityValue) {
				return true;
			} else if(null != inputEntityValue && null == dbEntityValue) {
				return true;
			} else if(null != inputEntityValue && null != dbEntityValue && !inputEntityValue.equals(dbEntityValue)) {
				return true;
			}*/
		}		
		return false;
	}

	private boolean isPriceChanged(Entity inputEntity, Entity dbEntity) {
		// TODO: (dk77005) Remove the local variable later 
		BigDecimal inputPrice = inputEntity.getBigDecimal(InfoMapKeyStringConstants.PRICE);
		BigDecimal dbPrice = dbEntity.getBigDecimal(InfoMapKeyStringConstants.PRICE);
		LOG.debug("New Price = " + inputPrice + ", Old Price = " + dbPrice);
		return inputPrice != dbPrice;
	}

	private boolean isUnitChanged(Entity inputEntity, Entity dbEntity) {
		// TODO: (dk77005) Remove the local variable later
		BigDecimal inputUnit = inputEntity.getBigDecimal(InfoMapKeyStringConstants.TRADED_QTY);
		BigDecimal dbUnit = dbEntity.getBigDecimal(InfoMapKeyStringConstants.TRADED_QTY);
		LOG.debug("New Qty = " + inputUnit + ", Old Qty = " + dbUnit);
		return inputUnit != dbUnit;
	}

	private boolean isNotionalChanged(Entity inputEntity, Entity dbEntity) {
		// TODO: (dk77005) Remove the local variable later
		BigDecimal inputNotional = inputEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
		BigDecimal dbNotional = dbEntity.getBigDecimal(InfoMapKeyStringConstants.NOTIONAL_AMOUNT);
		LOG.debug("New Notional = " + inputNotional + ", Old Notional = " + dbNotional);
		return inputNotional != dbNotional;
	}
}