package com.citi.reghub.m2post.utils.constants;

public interface M2PostConstants {

	public static final String Z_EXEC_ID = "zExecID";
	public static final String CLO_RD_ID = "CLOrdID";
	public static final String EXEC_TYPE = "execType";
	public static final String EX_DESTINATION = "exDestination";
	public static final String EXEC_LINK_ID = "execLinkID";
	public static final String EXEC_ID = "execID";
	public static final String EXEC_REF_ID = "execRefID";
	public static final String LAST_PX = "lastPx";
	public static final String LAST_QTY = "lastQty";
	public static final String ORDER_CAPACITY = "orderCapacity";
	public static final String ORDER_ID = "orderID";
	public static final String SETTL_DATE = "settlDate";
	public static final String TRADER_ID = "traderID";
	public static final String TRADING_ACCT = "tradingAcct";
	public static final String BARGAIN_CONDITIONS = "bargainConditions";
	public static final String CONTRA_ACCOUNT = "contraAccount";
	public static final String SENDER_COMP_ID = "senderCompID";
	public static final String TARGET_COMP_ID = "targetCompID";
	public static final String TARGET_SUB_ID = "targetSubID";
	public static final String ORD_STATUS = "ordStatus";
	public static final String LAST_CAPACITY = "lastCapacity";
	public static final String SYMBOL = "symbol";
	public static final String ACCEPTED_TIMESTAMP = "acceptedTimeStamp";
	public static final String NO_CONTRA_BROKERS = "noContraBrokers";
	public static final String CONTRA_BROKER = "contraBrokers";
	public static final String SRC_SYSTEM_ID = "srcSystemID";
	public static final String SECURITY_ID = "securityID";
	public static final String SECURITY_ID_SOURCE = "securityIDSource";
	public static final String SIDE = "side";
	public static final String LAST_MKT = "lastMkt";
	public static final String PRICE = "price";
	public static final String TRADE_DATE = "tradeDate";
	public static final String TRANSACT_TIME = "transactTime";
	public static final String ORDER_QTY = "orderQty";
	public static final String SECURITY_ALT_ID = "securityAltID";
	public static final String SECURITY_ALT_ID_SOURCE = "securityAltIDSource";
	public static final String CURRENCY = "currency";
	public static final String NOTEMPCONTRABROKERS = "notempcontrabrokers";
	public static final String EXEC_COMMENTS = "execComments";
	public static final String AVG_PRICE_ACCT = "avgPriceAcct";
	public static final String SALES_PERSON_ID = "salesPersonID";
	public static final String EXECUTED_BY = "executedBy";
	public static final String OVERRIDE_FLAG = "overrideFlag";
	public static final String RELATED_MARKET_CENTER = "relatedMarketCenter";
	public static final String CROSS_ID = "crossID";
	public static final String CLEARING_ACCOUNT = "clearingAccount";
	public static final String SECURITY_EXCHANGE = "securityExchange";
	public static final String SETTL_CURRENCY = "settlCurrency";
	public static final String REPORT_TO_EXCH = "reportToExch";
	public static final String SYMBOLS_FX = "symbolsFx";
	public static final String SENDER_SUB_ID = "senderSubID";
	public static final String ACCOUNT = "account";
	public static final String NO_PARTY_IDS = "NoPartyIDs";
	public static final String PARTY_ID = "PartyID";
	public static final String PARTY_ID_SOURCE = "PartyIDSource";
	public static final String PARTY_ROLE = "partyRole";
	public static final String NO_SIDES = "noSides";
	public static final String Trade_Report_Trans_Type="TradeReportTransType";
	public static final String Trade_Report_Type="TradeReportType";
	public static final String Venue_Type="VenueType";
	public static final String Trade_Type="TrdType";
	public static final String Trade_Publish_indicator="TradePublishIndicator";
	public static final String Trade_Handling_Instr="TradeHandlingInstr";
	public static final String Match_Type="MatchType";
	public static final String Trade_SubType="TrdSubType";
	public static final String Secondary_Trade_Type="SecondaryTrdType";
	public static final String MSGSEGNUM="MsgSeqNum";
	public static final String BEGIN_STRING="BeginString";
	public static final String BODY_LENGTH="BodyLength";
	public static final String CHECKSUM="CheckSum";
	public static final String SENDINGTIME="SendingTime";
	public static final String GROSS_TRADE_AMT="GrossTradeAmount";
	public static final String NO_TRD_PRC_CONDITION="NoTradePriceConditions";
	public static final String ALGORITHMIC_TRD_INDICATOR="AlgorithmicTradeIndicator";
	public static final String EXECMETHOD="ExecMethod";
	public static final String TRD_PRC_CONDITION="TradePriceCondition";
	public static final String TRD_REG_PUBLICATION_REASONS="TrdRegPublicationReasons";
	public static final String TRADEID="TradeID";
	public static final String MSG_TYPE="MsgType";
	public static final String TRADINGSESSIONSUBID="TradingSessionSubID";
	public static final String EXECINST="ExecInst";
	public static final String SETTLTYPE="SettlType";
	public static final String FIRM_TRADE_ID="firmTradeID";
	public static final String ON_EXCHANGE_INSTR="OnExchangeInstr";
	public static final String COUNTRY_OF_ISSUE="countryOfIssue";
	public static final String QUANTITY_TYPE="qtytype";
	public static final String CONTRACT_MULTIPLIER="contractMultiplier";
	public static final String UNIT_OF_MEASURE="unitOfMeasure";
	public static final String TIME_UNIT="timeUnit";
	public static final String UNIT_MEASURE_OF_QUANTITY="unitOfMeasureQty";
	public static final String PRICE_TYPE="priceType";
	public static final String QUANTITY="quantity";
	public static final String TRADE_EXEC_TYPE="tradeExecType";
	public static final String PREVIOUSLY_REPORTED="previouslyReported";	
	public static final String TRADE_REPORT_ID="tradeReportID";
	public static final String SRR_BEHAVIOUR_INSTR="SRRBehaviourInstr";
	public static final String NO_PUBLICATION_REQUIRED="NoPublicationRequired";
	public static final String EXEMPT_TRANSACTION_CODE="exemptTransactionCode";
	public static final String CLIENT_ORDER_TRADE="clientOrderTrade";
	public static final String CLEARING_INTENTION="clearingIntention";
	public static final String TEXT="text";
	public static final String PX_QTY_REVIEWED="pxQtyReviewed";
	public static final String DELAY_TO_TIME="delayToTime";
	public static final String PACKAGEID="packageID";
	public static final String TRADENUMBER="tradeNumber";
	public static final String TOTAL_NUM_TRADE_REPORTS="totalNumTradeReports";
	public static final String ORDER_CATEGORY="orderCategory";
	public static final String REGULATORY_REPORT_TYPE="regulatoryReportType";
	public static final String NO_TRADE_REG_PUBLICATION="NoTrdRegPublications";
	public static final String TRADE_REG_PUBLICATION_TYPE="TrdRegPublicationType";
	public static final String EMISSION_ALLOWANCE_TYPE="emissionAllowanceType";
	public static final String NOTIONAL_CURRENCY="notionalCurrency";
	public static final String NOTIONAL_AMOUNT="notionalAmount";
	public static final String TARGET_APA="targetAPA";
	public static final String ASSISTED_REPORT="assistedReport";
	public static final String SIDE_TRADE_REPORTING_INDICATOR="sideTradeReportingIndicator";
	public static final String ACCOUNT_TYPE="accountType";
	public static final String CONTRA_PARTYID="contra.partyId";
	public static final String EXECUTING_FIRM_PARTYID="exec.partyId";
	public static final String TIMEZONE_UTC = "UTC";
	public static final String _SRCSYS_ID="_SRCSYS_ID";
	public static final String ACCEPTED_TIMESTAMP_FORMAT="yyyyMMdd-hh:mm:ss";
	public static final String TIMEZONE_UTC_1 = "UTC+1";
	
	
	//accountType
	//sideTradeReportingIndicator
	//targetAPA
	//notionalAmount
	//emissionAllowanceType
	//TrdRegPublicationType
	//NoTrdRegPublications
	//OrderCategory
	//RegulatoryReportType
	//notionalCurrency
}
