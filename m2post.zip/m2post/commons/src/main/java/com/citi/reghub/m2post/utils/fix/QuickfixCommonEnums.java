package com.citi.reghub.m2post.utils.fix;

public class QuickfixCommonEnums {

	public enum AssistedReport {

		YES('Y'), NO('N');

		private final char value;

		private AssistedReport(char value) {
			this.value = value;
		}

		public char getValue() {
			return value;
		}

		public static String getEnumByString(char code) {
			for (AssistedReport e : AssistedReport.values()) {
				if (code == e.getValue())
					return e.name();
			}
			return null;
		}

	}

	/*
	 * public static void main(String args []){
	 * 
	 * System.out.println(AssistedReport.getEnumByString('Y')); }
	 */

	public enum SRRBehaviourInstr {

		PERSIST('0'), REVIEW('1'), OVERRIDE('2');

		private final int value;

		private SRRBehaviourInstr(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}

		public static String getEnumByString(int code) {
			for (SRRBehaviourInstr e : SRRBehaviourInstr.values()) {
				if (code == e.getValue())
					return e.name();
			}
			return null;
		}

	}

	public enum OnExchangeInstr {

		ON_EXCHANGE('0'), NO_ON_EXCHANGE('1'), ON_EXCHANGE_BY_COUNTERPARTY('2');

		private final char value;

		private OnExchangeInstr(char value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}

		public static String getEnumByString(char code) {
			for (OnExchangeInstr e : OnExchangeInstr.values()) {
				if (code == e.getValue())
					return e.name();
			}
			return null;
		}

	}
	
	public enum ExemptTransactioCode {

		CLEARING_CONTRACT("CLC"), SETTLEMENT_CONTRACT("SLC"),	SECURITIES_FINANCING_TRANSACTION("SFB"),
		CUSTODY_CONTRACT("CUC"), EUROPEAN_CENTRAL_BANK("ECB"),SETTLEMENT_OF_MUTUAL_OBLIGATION("SMO"),
		POSTTRADE_ASSIGNMENT_NOVATION("PAN"),PORTFOLIO_CONPRESSION("POC"), CREATION_REDEMPTION_ADMINISTRATOR("CRA"),
		EXERCISE("EXE"),CONVERSION("CON"),CREATION_EXPIRATION_REDEMPTION("CER"), INCREASEDECREASE_NOTIONALDERIVATIVE("IDD"),
		INDEX_BASKET_COMPOSITION("IBC"),DIVIDEND_REINVESTMENT("DRI"),EMPLOYEE_SHARE_INCENTIVE("ESI"),EXCHANGE_TRADE_OFFER("ETO"),
		MANAGEMENT_TRADE_TRANSACTIONS("MCT"),GIVEUP_GIVEIN("GIV"),COLLATERAL_TRANSFER("COT");

		private final String value;

		private ExemptTransactioCode(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}

		public static String getEnumByString(String code) {
			for (ExemptTransactioCode e : ExemptTransactioCode.values()) {
				if (code.equals(e.getValue()))
					return e.name();
			}
			return null;
		}

	}
	
	public enum QtyTyp {

		TOCD(2);
		private final int value;

		private QtyTyp(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}

		public static String getEnumByString(int code) {
			for (QtyTyp e : QtyTyp.values()) {
				if (code==e.value)
					return e.name();
			}
			return null;
		}
		
		public static boolean contains(String name) {
			for (QtyTyp e : QtyTyp.values()) {
				if (null!=e && e.name().equals(name))
					return true;
			}
			return false;
		}

	}

	public enum PriceType {

			 PCT(1), 
		     FIXEDCABINETTRADEPRICE(10), 
		     VARIABLECABINETTRADEPRICE(11), 
		     BASIC(12), 
		     GROSS(13), 
		     ALLIN(14), 
		     NETNET(15), 
		     NETLOCAL(16), 
		     VARIABLECOMMISSION(17), 
		     SPREAD(18), 
		     CPS(2), 
		     ABS(3), 
		     DISCOUNT(4), 
		     PREMIUM(5), 
		     BPSBENCHMARK(6), 
		     TEDPRICE(7), 
		     TEDYIELD(8), 
		     YIELD(9), 
		     DecimalUnitPrice(98), 
		     ContractAmount(99);
		     
		
		private final int value;

		private PriceType(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}

		public static String getEnumByString(int code) {
			for (PriceType e : PriceType.values()) {
				if (code==e.value)
					return e.name();
			}
			return null;
		}
		
		public static boolean contains(String name) {
			for (PriceType e : PriceType.values()) {
				if (null!=e && e.name().equals(name))
					return true;
			}
			return false;
		}
		
		public static int getValue(String name) {
			for (PriceType e : PriceType.values()) {
				if (null!=e && e.name().equals(name))
					return e.value;
			}
			return 0;
	}

	
	}	
	
}
