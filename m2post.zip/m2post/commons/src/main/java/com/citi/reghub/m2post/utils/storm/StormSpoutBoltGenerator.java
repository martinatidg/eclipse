package com.citi.reghub.m2post.utils.storm;

import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.kafka.bolt.KafkaBolt;
import org.apache.storm.kafka.spout.KafkaSpout;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.RawLineMsgObject;
import com.citi.reghub.core.RawLineMsgObjectSerializerDeserializer;
import com.citi.reghub.core.kafka.RegHubKafkaBolt;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;

public class StormSpoutBoltGenerator {

	public static KafkaSpout<String, Entity> generatekafkaSpout(String sourceKafkaTopics, String streamName, Map<String, String> topologyConfig){
		
		return RegHubKafkaSpout.builder(sourceKafkaTopics, streamName, topologyConfig)
					.setKeyDesClazz(StringDeserializer.class)
					.setValueDesClazz(EntityKafkaSerializerDeserializer.class)
					.build().getSpout();
		
	}
	
	public static KafkaSpout<String, RawLineMsgObject> generateRawLineMsgkafkaSpout(String sourceKafkaTopics, String streamName, Map<String, String> topologyConfig){
		
		return RegHubKafkaSpout.builder(sourceKafkaTopics, streamName, topologyConfig)
					.setKeyDesClazz(StringDeserializer.class)
					.setValueDesClazz(RawLineMsgObjectSerializerDeserializer.class)
					.build().getSpout();
		
	}
	
	public static KafkaBolt<Object, Object> generateKafkaBolt(String destinationTopicName, String producerName, Map<String, String> topologyConfig){
		
		return RegHubKafkaBolt.getKafkaBolt(topologyConfig, destinationTopicName, producerName);
		
	}
	
}
