/**
 * 
 */
package com.citi.reghub.m2post.utils.translators;

/**
 * @author dk77005
 *
 */
public enum TradeStatusTransalationProcess {
	AMENDMENT, BOOKING, CANCELLATION, NOVATION
}
