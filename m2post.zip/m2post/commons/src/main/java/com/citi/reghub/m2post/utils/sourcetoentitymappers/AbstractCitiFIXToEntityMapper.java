package com.citi.reghub.m2post.utils.sourcetoentitymappers;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.constants.EntityStatus;
import com.citigroup.get.quantum.intf.ParseException;
import com.citigroup.get.zcc.intf.AccountGrp;
import com.citigroup.get.zcc.intf.AltAccountGrp;
import com.citigroup.get.zcc.intf.MOTradeMessage;
import com.citigroup.get.zcc.intf.SecAltIDGrp;
import com.citigroup.get.zcc.intf.SecurityAltIDSource;
import com.citigroup.get.zcc.intf.TraderGrp;

/**
 * This is an abstract for transforming the incoming CITIFIX to Entity Domain Object.
 * It provide Impls for the common attributes, specific ones needs to be overridden.
 * 
 * @author pg60809
 *
 */
public abstract class AbstractCitiFIXToEntityMapper implements EntityMapper {

	private static final long serialVersionUID = 7541674854006811210L;

	private static final Logger LOG = LoggerFactory.getLogger(AbstractCitiFIXToEntityMapper.class);
	
	private String flow;
	private String stream;
	protected MOTradeMessage citifixTrade;
	
	/**
	 * This methods populates the Entity Objects and its a two step process:
	 * 1. Populates all the Entity Instance Feilds.
	 * 2. Populates the Embedded info Map object with corresponding key value pairs.
	 * 3. Populates the feilds in Entity using TAG objects
	 * @param stream
	 * @param flow
	 */
	public AbstractCitiFIXToEntityMapper(String stream, String flow){
		this.flow = flow;
		this.stream = stream;
	}
	
	/**
	 * 
	 */
	@Override
	public Entity mapToEntity(Object message, Entity entity) {
		
		citifixTrade = (MOTradeMessage) message;
		populateMandatoryEntityAttributesFromInputFixMessage(entity, citifixTrade);
		
		return entity;
	}
	
	/**
	 * This method maps all the required feilds in Entity Domain Object from input MOTradeMessage Object.
	 * @param entity
	 * @param citifixTrade
	 */
	protected void populateMandatoryEntityAttributesFromInputFixMessage(Entity entity, MOTradeMessage citifixTrade) {

		entity.status = EntityStatus.REPORTABLE;
		entity.flow = flow;
		entity.stream = stream;
		entity.receivedTs = LocalDateTime.now();
		entity.sourceId = citifixTrade.getTradeID();
		entity.publishedTs = citifixTrade.getRIOTransactTime() != null ? LocalDateTime.ofInstant(citifixTrade.getRIOTransactTime().toInstant(), ZoneId.of("UTC")) : null;
		entity.executionTs = citifixTrade.getTransactTime() != null	? LocalDateTime.ofInstant(citifixTrade.getTransactTime().toInstant(), ZoneId.of("UTC")) : null;
		entity.sourceSystem = citifixTrade.getSenderCompID();
		entity.sourceVersion = String.valueOf(citifixTrade.getZTradeVersion());
		
	}
	
	/**
	 * Set Symbol from CITI FX Message in Entity Object
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSymbolsFx(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, SYMBOLS_FX, 65);
	}

	/**
	 * Set sec exchange from CITI FX Message in Entity Object
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSecurityExchange(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, SECURITY_EXCHANGE, 207);
	}

	/**
	 * Set cross id from CITI FX Message in Entity Object
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setCrossId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, CROSS_ID, 548);
	}

	/**
	 * Set rel mkt center from CITI FX Message in Entity Object
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setRelatedmarketCenter(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, RELATED_MARKET_CENTER, 9277);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOverrrideFlag(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, OVERRIDE_FLAG, 9854);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecutedBy(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, EXECUTED_BY, 10021);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSalesPersonId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, SALES_PERSON_ID, 10036);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setAvgPriceAcct(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, AVG_PRICE_ACCT, 10051);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecComments(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, EXEC_COMMENTS, 10076);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setNoTempContraBrokers(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, NOTEMPCONTRABROKERS, 10533);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setContraBrokers(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, CONTRA_BROKER, 375);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setNoOfContarBrokers(Entity entity, MOTradeMessage citifixTrade) {
		if(!StringUtils.isBlank(citifixTrade.getTag(382))) {
			entity.info.put(NO_CONTRA_BROKERS, new Integer(citifixTrade.getTag(382)));
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrdStatus(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, ORD_STATUS, 39);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setContraAccount(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, CONTRA_ACCOUNT, 10514);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setBargainConditions(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, BARGAIN_CONDITIONS, 11303);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradingAcct(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, TRADING_ACCT, 10050);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrderId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, ORDER_ID, 37);
		if(StringUtils.isBlank(entity.sourceId) && (citifixTrade.getTag(37) != null && citifixTrade.getTag(37).length()>0)) {
			entity.sourceId = citifixTrade.getTag(37);
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrderCapacity(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, ORDER_CAPACITY, 528);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, EXEC_ID, 17);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecLinkId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, EXEC_LINK_ID, 11049);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExDestination(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, EX_DESTINATION, 100);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecType(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, EXEC_TYPE, 150);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setCloRdId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, CLO_RD_ID, 11);
	}

	/**
	 * Transforms the Accepted Time stamp to DateTime format
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setAcceptedTimeStamp(Entity entity, MOTradeMessage citifixTrade) {
		if(!StringUtils.isBlank(citifixTrade.getTag(11015))){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-hh:mm:ss");
			Date parsedDate;
			try {
				parsedDate = sdf.parse(citifixTrade.getTag(11015));
				Calendar convertedToCalendar = Calendar.getInstance();
				convertedToCalendar.setTime(parsedDate);
				entity.info.put(ACCEPTED_TIMESTAMP, LocalDateTime.ofInstant(convertedToCalendar.toInstant(), ZoneId.systemDefault()).toLocalDate());
			} catch (UnsupportedOperationException e) {
				LOG.error("UnsupportedOperationException occurred while parsing accepted Timestamp field : "+e);
				throw e;
			} catch (ParseException e) {
				LOG.error("ParseException occurred while parsing accepted Timestamp field : "+e);
				throw e;
			} catch (java.text.ParseException e) {
				LOG.error("java.text.ParseException occurred while parsing accepted Timestamp field : "+e);
				throw new RuntimeException("java.text.ParseException occurred while parsing accepted Timestamp field : "+e);
			}
		}
	}
	
	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setQty(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getQuantity(), QTY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setYield(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getYield(), YIELD);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setPreviousSrcSystemId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getPreviousSrcSystemID(), PREV_SRC_SYS_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setAccountGrpInfo(Entity entity, MOTradeMessage citifixTrade) {
		
		AtomicInteger noOfAccount = new AtomicInteger();
		
		Arrays.stream(Optional.ofNullable(citifixTrade.getAccountGrp()).orElse(new AccountGrp[0])).forEach(accountGroup -> {
			
			entity.info.put(NO_ACCOUNTS, noOfAccount.incrementAndGet());
			populateAccountMnemonicForCptyOrExecFirm(entity, accountGroup);
			
			Arrays.stream(Optional.ofNullable(accountGroup.getAltAccountGrp()).orElse(new AltAccountGrp[0])).forEach(altAccountGroup -> {
				if(null != altAccountGroup.getAltAcctIDSource() && GFC.equals(altAccountGroup.getAltAcctIDSource().toString())) {
					populateGfcidForCptyOrExecFirm(entity, accountGroup, altAccountGroup);
				}
			});
			
		});
	}

	private void populateAccountMnemonicForCptyOrExecFirm(Entity entity, AccountGrp accountGroup) {

		if(null != accountGroup.getAcctIDSource() && ACCT_MNEMONIC_TYPE.equals(accountGroup.getAcctIDSource().toString())) {
			
			String acctMnemonic = accountGroup.getAccount();

			if(!StringUtils.isBlank(acctMnemonic)) {
				
				if(null != accountGroup.getAccountRole()) {
					if(CPTY.equals(accountGroup.getAccountRole().toString())) {
						entity.info.put(CPTY_FIRM_ACCT_MNEMONIC, acctMnemonic);
					}	
					else if (FIRM.equalsIgnoreCase(accountGroup.getAccountRole().toString())) { 
						entity.info.put(EXEC_FIRM_ACCT_MNEMONIC, acctMnemonic);
					}
				}
			}
		}
		
	}

	private void populateGfcidForCptyOrExecFirm(Entity entity, AccountGrp accountGroup, AltAccountGrp altAccountGroup) {
		
		String gfcid = altAccountGroup.getAltAccount();
		
		if(null != accountGroup.getAccountRole()) {
			
			if(CPTY.equals(accountGroup.getAccountRole().toString())) {
				entity.info.put(CPTY_FIRM_GFCID, gfcid);
			}	
			else if (FIRM.equalsIgnoreCase(accountGroup.getAccountRole().toString())) { 
				entity.info.put(EXEC_FIRM_GFCID, gfcid);
			}
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setNoOfAccnts(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getAccountGrp()) {
			entity.info.put(NO_ACCOUNTS, citifixTrade.getAccountGrp().length);
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSenderSubId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSenderSubID(), SENDER_SUB_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setReportToExch(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getReportToExch()) {
			entity.info.put(REPORT_TO_EXCH, citifixTrade.getReportToExch().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSetlCurrency(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSettlCurrency(), SETTL_CURRENCY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setClearingAccount(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getClearingAccount(), CLEARING_ACCOUNT);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setCurrency(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getCurrency(), CURRENCY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSecAltIdDetails(Entity entity, MOTradeMessage citifixTrade) {
		Arrays.stream(Optional.ofNullable(citifixTrade.getSecAltIDGrp()).orElse(new SecAltIDGrp[0])).forEach(secAltIDGrp -> {
			
			if(null != secAltIDGrp.getSecurityAltIDSource()) {
				
				switch(secAltIDGrp.getSecurityAltIDSource()) {
					
				case CUSIP :
					entity.info.put(SECURITY_CUSIP, secAltIDGrp.getSecurityAltID());
					break;
				case ISIN :
					entity.info.put(SECURITY_ISIN, secAltIDGrp.getSecurityAltID());
					break;
				case RIC :	
					entity.info.put(SECURITY_RIC, secAltIDGrp.getSecurityAltID());
					break;
				case SMCP :	
					entity.info.put(SECURITY_SMCP, secAltIDGrp.getSecurityAltID());
					break;
				}
				
			}
			
		});
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrderQty(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getOrderQty(), ORDER_QTY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradeStatus(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getTradeStatus()) {
			entity.info.put(TRADE_STATUS, citifixTrade.getTradeStatus().toString());
			entity.sourceStatus = citifixTrade.getTradeStatus().toString();
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradeExecType(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getTradeExecType()) {
			entity.info.put(TRADE_EXEC_TYPE, citifixTrade.getTradeExecType().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradeSubType(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getTradeSubType()) {
			entity.info.put(TRADE_SUB_TYPE, citifixTrade.getTradeSubType().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradeDate(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getTradeDate()) {
			entity.info.put(TRADE_DATE, LocalDateTime.ofInstant(citifixTrade.getTradeDate().toInstant(), ZoneId.systemDefault()).toLocalDate());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setPriceType(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getPriceType()) {
			entity.info.put(PRICE_TYPE, citifixTrade.getPriceType().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setPrice(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getPrice(), PRICE);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastMkt(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getLastMkt(), VENUE_OF_EXECUTION);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSide(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getSide()) {
			entity.info.put(BUY_SELL_IND, citifixTrade.getSide().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setInstrIdentCodeType(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getSecurityIDSource()) {
			entity.info.put(INSTR_IDENT_CODE_TYPE, citifixTrade.getSecurityIDSource().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setInstrIdentCode(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSecurityID(), INSTR_IDENT_CODE);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSrcSystemId(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getSrcSystemID()) {
			entity.info.put(SRC_SYSTEM_ID, citifixTrade.getSrcSystemID().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSymbol(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSymbol(), SYMBOL);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastCapacity(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getLastCapacity()) {
			entity.info.put(TRADE_CAPACITY, citifixTrade.getLastCapacity().value());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTargetSubId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getTargetSubID(), TARGET_SUB_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTargetCompId(Entity entity, MOTradeMessage citifixTrade) {
		//TODO : To be HARDCODED as per environment SRRECHO or SRRECHOTEST
		//entity.info.put(TARGET_COMP_ID, citifixTrade.getTargetCompID());
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSenderCompId(Entity entity, MOTradeMessage citifixTrade) {
		//TODO : To be HARDCODED with M2POST TradeEcho User ID
		//entity.info.put(SENDER_COMP_ID, citifixTrade.getSenderCompID());
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTraderIdInfo(Entity entity, MOTradeMessage citifixTrade) {
		Arrays.stream(Optional.ofNullable(citifixTrade.getTraderGrp()).orElse(new TraderGrp[0])).forEach(traderGrp -> {
			entity.info.put(TRADER_ID+"~"+traderGrp.getTraderID(), traderGrp.getTraderID());
		});
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSetlDate(Entity entity, MOTradeMessage citifixTrade) {
		if(null != citifixTrade.getSettlDate()) {
			entity.info.put(SETTL_DATE, LocalDateTime.ofInstant(citifixTrade.getSettlDate().toInstant(), ZoneId.systemDefault()).toLocalDate());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastQty(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getLastQty(), LAST_QTY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastPx(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getLastPx(), LAST_PX);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecRefId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExecRefID(), EXEC_REF_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setZExecId(Entity entity, MOTradeMessage citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getZExecID(), Z_EXEC_ID);
	}

	private void populateEntiyInforUsingTagNumber(Entity entity, MOTradeMessage citifixTrade, String entityInfoKey, int tagNumber) {
		
		if(!StringUtils.isBlank(citifixTrade.getTag(tagNumber))){
			entity.info.put(entityInfoKey, citifixTrade.getTag(tagNumber));
		}
		
	}
	
	private void populateEntityInfoUsingFeildsFormTradeObject(Entity entity, Object inputFieldValue, String entityInfoKey) {
		
		if(null != inputFieldValue) {
			entity.info.put(entityInfoKey, inputFieldValue);
		}
		
	}
}
