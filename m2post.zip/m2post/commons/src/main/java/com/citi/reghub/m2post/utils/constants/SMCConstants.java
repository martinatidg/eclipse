package com.citi.reghub.m2post.utils.constants;

public class SMCConstants {

	
	public static final String SMC_ISIN	="smc-isin";
	public static final String SMC_INSTRUMENT_FULL_NAME = "smc-instrument-full-name";
	public static final String SMC_TRADE_VENUE ="smc-trade-venue";
	public static final String SMC_CFI_CODE = "smc-cfi-code";
	public static final String SMC_CUSIP = "smc-cusip";
	public static final String SMC_FII = "smc-fii";
	public static final String SMC_COUNTRY_OF_ISSUE ="smc-country-of-issue";
	public static final String SMC_NOTIONAL_CURRENCY = "smc-notional-currency";
	public static final String SMC_CURRENCY_OF_NOMINAL_VALUE = "smc-currency-of-nominal-value";
	public static final String SMC_EXPIRY_DATE = "smc-expiry-date";
	public static final String SMC_UNDERLYING_ISIN_CODE = "smc-underlying-isin-code";
	public static final String SMC_OPTION_TYPE = "smc-option-type";
	public static final String SMC_PUT_INDICATOR = "smc-put-indicator";
	public static final String SMC_DELIVERY_TYPE = "smc-delivery-type";
	public static final String SMC_SMCP = "smc-smcp";
	public static final String SMC_UNDERLYING_INSTRUMENT_NAME = "smc-underlying-instrument-name";
	public static final String SMC_SI_FLAG = "smc-si-flag";
	public static final String SMC_TO_TV= "smc-to-tv";
	public static final String SMC_TRADE_DON_EE_AVENUE = "smc-trade-don-ee-avenue";
	public static final String SMC_LIQUIDITY = "smc-liquidity";
	public static final String SMC_LIS = "smc-lis";
	public static final String SMC_SSTI = "smc-ssti";
	public static final String SMC_LISTED_IN_EEA_REGULATED_MARKET = "smc-listed-in-eea-regulated-market";
	public static final String SMC_MARKET_SEGMENT = "smc-market-segment";
	public static final String SMC_TAX_STATUS_CODE = "smc-tax-status-code";
	public static final String SMC_MIFID_COUNTRY_CODE = "smc-mifid-country-code";
	public static final String SMC_EXCHANGE_COUNTRY = "smc-exchange-country";

}
