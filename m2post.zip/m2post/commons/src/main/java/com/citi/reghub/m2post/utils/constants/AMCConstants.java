package com.citi.reghub.m2post.utils.constants;

public class AMCConstants {

	public static final String AMC_LEI= "amc-lei";
	public static final String AMC_ACCOUNT_MNEUMONIC = "amc-account-mneumonic";
	public static final String AMC_GFCID="amc-gfcid";
	public static final String AMC_FIRM_CODE="amc-firm-code";
	public static final String AMC_TRADING_VENUE_TYPE="amc-trading-venue-type";
	public static final String AMC_MIC_ID="amc-mic-id";
	public static final String AMC_ASSISTED_REPORTING_FLAG="amc-assisted-reporting-flag";
	public static final String AMC_EEA_FLAG="amc-eea-flag";
	public static final String AMC_COMMODITY_POSITION_REPORTING="amc-commodity-position-reporting";
	public static final String AMC_FX_EXTENTED_SPOT_FLAG="amc-fx-extended-spot-flag";
	

}
