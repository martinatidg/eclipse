package com.citi.reghub.m2post.utils.constants;

public interface InfoMapKeyStringConstants {

	//Party and Account Feilds
	public static final String EXEC_FIRM_ACCT_MNEMONIC = "firmAcctMnemonic";
	public static final String EXEC_FIRM_ACCT_MNEMONIC_TYPE = "firmAcctIdType";
	public static final String EXEC_FIRM_GFCID = "firmGFCID";		
	public static final String EXEC_FIRM_LEI = "firmLEI";		
	public static final String EXEC_FIRM_LEI_CODE = "firmLECode";
    public static final String EXEC_FIRM_SI = "execFirm_SI";
	public static final String CPTY_FIRM_ACCT_MNEMONIC = "cptyAcctMneomic";
	public static final String CPTY_FIRM_ACCT_MNEMONIC_TYPE = "cptyAcctIdType";
	public static final String CPTY_FIRM_GFCID = "cptyGFCID";		
	public static final String CPTY_FIRM_LEI = "cptyLEI"; 
	public static final String CPTY_FIRM_LEI_CODE = "counterpartyLECode";
    public static final String CPTY_FIRM_SI = "cptyFirm_SI"; 
    public static final String CPTY_REGION = "cptyFirm_Region";
    public static final String CPTY_SUB_ENTITY_CODE = "cptySubEntityCode";
	
    //Security and Instrument Feilds
    public static final String ISIN_CD = "ISIN";
    public static final String INSTRUMENT_CLASSIFICATION = "instrumentClassification";
    public static final String INSTR_IDENT_CODE_TYPE = "securityIdType";
	public static final String INSTR_IDENT_CODE = "securityId";
	public static final String INSTRUMENT_IDENTIFICATION = "instrumentID"; 
	public static final String SECURITY_ID = "securityId"; 				
	public static final String SECURITY_ID_SOURCE = "securityIdType"; 	
	public static final String UNDERLYING_INDEX_NAME = "underlyingIndex";	
	public static final String OPTION_EXERCISE_STYLE = "optionExerciseStyle";
	public static final String MATURITY_DATE = "maturityDate";
	public static final String EXPIRY_DATE = "expiryDate";
	public static final String SECURITY_ISIN = "securityISIN";
	public static final String SECURITY_RIC = "securityRIC";
	public static final String SECURITY_CUSIP = "securityCusip";
	public static final String SECURITY_SMCP = "securitySMCP";
	public static final String IS_BASKET_CONSTITUENT = "isBasketConstituent";
	public static final String PRODUCT_TYPE = "productType";
	
	//Quantity
	public static final String TRADE_QTY_UNIT = "tradeQtyUnit";
	
	//Price and Currency Feilds
	public static final String PRICE_CURRENCY = "priceCcy"; 
	public static final String PRICE_NOTATION = "priceNotation";
	public static final String PRICE_TYPE = "priceType";
	public static final String TRADE_CURRENCY = "tradeCurrency";
	public static final String NOTATIONAL_AMOUNT = "notationalAmount";
	public static final String CONTRACT_MULTIPLIER="priceMultiplier"; 
	public static final String FIXED_TRADE_PRICE_TYPE="fixedTradePriceType";
	public static final String FIXED_TRADE_PRICE_AMOUNT="fixedTradePriceAmount";
	public static final String FIXED_TRADE_PRICE_RATE="fixedTradePriceRate";
	
	//Trade Attributes
	public static final String TRADE_DATE = "tradeDate";
	public static final String TRADE_EXECUTION_TS = "tradeExecTs";
	public static final String REPORT_STATUS = "reportStatus";
	public static final String TRADE_TYPE="tradeType";
	public static final String Trade_Type="TrdType"; //TODO : Remove this Feild
	public static final String TRADE_SUB_TYPE = "tradeSubType";
	public static final String TRADE_EXEC_TYPE = "tradeExecType";
	public static final String TRADE_CAPACITY = "tradeCapacity";
	public static final String TRADED_QTY = "tradeQty";
	public static final String PRICE = "tradePrice";
	public static final String ORG_SRC_SYSTEM = "origSrcSys";
	public static final String BUY_SELL_IND = "buySellInd"; 	
	public static final String VENUE_OF_EXECUTION = "executionVenue";
	public static final String NOTIONAL_CURRENCY = "notionalCCY1"; 
	public static final String NOTIONAL_CURRENCY2 = "notionalCCY2";
	public static final String DELIVERY_TYPE = "deliveryType";
	public static final String WAIVER_INDICATOR = "waiverInd";
	public static final String OTC_POST_TRADE_INDICATOR = "otcPostTradeInd";
	public static final String PRIMARY_ASSET_CLASS = "primaryAssetClass";
	public static final String LIFE_CYCLE_STATE = "lifecycleState";
	public static final String ACTION_TYPE = "actionType";
	public static final String ALGORITHMIC_TRD_INDICATOR="algoID";
	public static final String EVENT_TYPE = "eventType";
	public static final String SETTL_DATE = "settlDate";
	public static final String YIELD="yield";
	public static final String CURRENCY = "currency";
	public static final String TRANSACTION_TO_CLEAR = "intentToClear";
	public static final String TRADE_STATUS = "tradeStatus";
	public static final String NO_ACCOUNTS = "noAccounts";
	
	
    public static final String MONE = "MONE";
	public static final String PERC = "PERC";
	public static final String FIXED_PRICE = "FixedPrice";
	public static final String PREMIUM = "Premium";
	public static final String PARTY_A = "PartyA";
	public static final String PARTY_B = "PartyB";
	public static final String ACCT_MNEMONIC_TYPE = "ACCOUNTMNEMONIC";
	public static final String ACCT_MNEMONIC = "AcctMnemonic";
	public static final String PARTY_TYPE = "PartyType";
	public static final String GFCID = "GFCID";
	public static final String EXEC_FACILITY = "ExecutionFacility";
	public static final String EXEC_FAC_ID_SCHEME = "http://www.fpml.org/coding-scheme/external/iso10383";
	public static final String N = "N";
	public static final String UITID1 = "http://www.fpml.org/coding-scheme/external/unique-transaction-identifier";
	public static final String UITID2 = "UniqueInternalTradeID";
	public static final String UITID3 = "http://www.dtcc.com/internal_Referenceid";
	public static final String GFC = "GFC";
	public static final String CPTY = "CPTY";
	public static final String FIRM = "FIRM";
	// XPATH and Entity Info Key Constants
	
	
	public static final String EXECUTION_VENUE_TYPE = "tradeVenueType";
	public static final String AMOUNT = "amount";
	public static final String TRADE_VENUE_TRANSACT_ID = "tradingVenueIdCode";		//APR: corrected from tradeVenueTransactionId
	public static final String COMMODITIES_DERIVATIVE_INDICATOR = "commodityDerivativeInd";		//APR: corrected from commoditiesDerivateIndicator
	public static final String QTY_IN_MESAUREMENT_UNIT = "qtyInMeasurementUnit";
	public static final String NOTATION_OF_QTY_IN_MEASUREMENT_UNIT = "notationOfQtyInMsrmntUnit";
	public static final String EMISSION_ALLOWANCE_TYPE = "emissionAllowanceType";
	public static final String NO_PARTY_IDS = "noPartyIds";
	public static final String PARTY_A_ACCT_MNEMONIC = "partyA_AccountMnemonic";
	public static final String PARTY_B_ACCT_MNEMONIC = "partyB_AccountMnemonic";
	public static final String PARTY_A_ACCT_GFCID = "partyA_GFCID";
	public static final String PARTY_B_ACCT_GFCID = "partyB_GFCID";
	public static final String PARTY_ID_SOURCE = "partyIDSource";
	public static final String EXCERCISE_DATE = "excercise_date";
	
	public static final String PNDG = "PNDG";
	
	public static final String Z_EXEC_ID = "zExecID";
	public static final String CLO_RD_ID = "CLOrdID";
	public static final String EXEC_TYPE = "execType";
	public static final String EX_DESTINATION = "exDestination";
	public static final String EXEC_LINK_ID = "execLinkID";
	public static final String EXEC_ID = "execID";
	public static final String EXEC_REF_ID = "execRefID";
	public static final String LAST_PX = "lastPx";
	public static final String LAST_QTY = "lastQty";
	public static final String ORDER_CAPACITY = "orderCapacity";
	public static final String ORDER_ID = "orderID";
	public static final String TRADER_ID = "traderId";
	public static final String TRADING_ACCT = "tradingAcct";
	public static final String BARGAIN_CONDITIONS = "bargainConditions";
	public static final String CONTRA_ACCOUNT = "contraAccount";
	public static final String SENDER_COMP_ID = "senderCompID";
	public static final String TARGET_COMP_ID = "targetCompID";
	public static final String TARGET_SUB_ID = "targetSubID";
	public static final String ORD_STATUS = "ordStatus";
	public static final String LAST_CAPACITY = "lastCapacity";
	public static final String SYMBOL = "symbol";
	public static final String ACCEPTED_TIMESTAMP = "acceptedTimeStamp";
	public static final String NO_CONTRA_BROKERS = "noContraBrokers";
	public static final String CONTRA_BROKER = "contraBrokers";
	public static final String SRC_SYSTEM_ID = "srcSystemID";
	public static final String SIDE = "side";
	public static final String LAST_MKT = "lastMkt";
	public static final String TRANSACT_TIME = "transactTime";
	public static final String ORDER_QTY = "orderQty";
	public static final String SECURITY_ALT_ID = "securityAltID";
	public static final String SECURITY_ALT_ID_SOURCE = "securityAltIDSource";
	public static final String NOTEMPCONTRABROKERS = "notempcontrabrokers";
	public static final String EXEC_COMMENTS = "execComments";
	public static final String AVG_PRICE_ACCT = "avgPriceAcct";
	public static final String SALES_PERSON_ID = "salesPersonID";
	public static final String EXECUTED_BY = "executedBy";
	public static final String OVERRIDE_FLAG = "overrideFlag";
	public static final String RELATED_MARKET_CENTER = "relatedMarketCenter";
	public static final String CROSS_ID = "crossID";
	public static final String CLEARING_ACCOUNT = "clearingAccount";
	public static final String SECURITY_EXCHANGE = "securityExchange";
	public static final String SETTL_CURRENCY = "settlCurrency";
	public static final String REPORT_TO_EXCH = "reportToExch";
	public static final String SYMBOLS_FX = "symbolsFx";
	public static final String SENDER_SUB_ID = "senderSubID";
	public static final String ACCOUNT = "account";
	public static final String PARTY_ID = "PartyID";
	public static final String PARTY_ROLE = "partyRole";			//APR: corrected from PartyRole
	public static final String NO_SIDES = "noSides";
	public static final String Trade_Report_Trans_Type="TradeReportTransType";
	public static final String Trade_Report_Type="TradeReportType";
	public static final String Venue_Type="VenueType";
	public static final String Trade_Publish_indicator="TradePublishIndicator";
	public static final String Trade_Handling_Instr="TradeHandlingInstr";
	public static final String Match_Type="MatchType";
	public static final String Trade_SubType="TrdSubType";
	public static final String Secondary_Trade_Type="SecondaryTrdType";
	public static final String MSGSEGNUM="MsgSeqNum";
	
	// FIX MESSAGE STRUCTURE
	public static final String BEGIN_STRING="BeginString";
	public static final String BODY_LENGTH="BodyLength";
	public static final String CHECKSUM="CheckSum";
	public static final String SENDINGTIME="SendingTime";
	
	public static final String GROSS_TRADE_AMT="GrossTradeAmount";
	public static final String NO_TRD_PRC_CONDITION="NoTradePriceConditions";
	public static final String EXECMETHOD="ExecMethod";
	public static final String TRD_PRC_CONDITION="TradePriceCondition";
	public static final String TRD_REG_PUBLICATION_REASONS="TrdRegPublicationReasons";
	public static final String TRADEID="TradeID";
	public static final String MSG_TYPE="MsgType";
	public static final String TRADINGSESSIONSUBID="TradingSessionSubID";
	public static final String EXECINST="ExecInst";
	public static final String SETTLTYPE="settlementType";		//APR: corrected from SettlType
	
	public static final String PREV_SRC_SYS_ID="previousSrcSystemId";
	public static final String QTY="quantity";
	
	public static final String XPATH_CONFIG_FILE = "xpath-expressions.properties";
	
	public static final String EXECUTING_ENTITY = "ExecutingEntity";
	public static final String EXECENTITY_ACCTMNEMONIC = "executingEntity_acctmnemonic";
	public static final String EXECENTITY_GFCID = "executingEntity_gfcid";
	public static final String VENUE_TRADE = "venueTrade";
	public static final String AOTC = "AOTC";
	public static final String MTCH = "MTCH";
	public static final String DEAL = "DEAL";
	public static final String MONETARY_BASED = "monetary-based";
	public static final String FX_TRANSACTIONS = "fx transactions";
	public static final String ALLOCATION_TRADES = "AllocationTrades";
	public static final String PRODUCT_DELIVERY_TYPE = "productDeliveryType";
	public static final String TRADE_REPORT_TRANS_TYPE="TradeReportTransType";
	public static final String TRADE_PRICE_CONDITION="TradePriceCondition";
	public static final String PORTFOLIO_COMPRESSION_TRADES="portFolioCompTrades";
	
	public static final String TERM_OF_UNDERLYING_INDEX = "termUnderlyingIndex"; // SRK: corrected from termOfunderlyingIndex
	public static final String OPTION_TYPE = "optionType"; // SRK: confirmed
	public static final String STRIKE_PRICE = "strikePrice"; // SRK: confirmed
	public static final String STRIKE_PRICE_CURRENCY = "strikePriceCCY"; // SRK: corrected from strikePriceCurrency
	public static final String REF_PRICE = "ReferencePrice";
	public static final String REF_RATE = "ReferenceRate";
	public static final String FORWARD_RATE = "ForwardRate";
	public static final String PERIODIC_RATE = "PeriodicRate";
	public static final String SPREAD = "Spread";
	public static final String FX_SPOT = "FXSpot";
	public static final String BUYER_IDENTIFICATION_CODE="BuyerIdentificationCode";
	public static final String CLEARING_INTENTION="clearingIntention";
	public static final String CONTRA_PARTYID="contra.partyId";
	public static final String EXECUTING_FIRM_PARTYID="exec.partyId";
	public static final String FIRM_TRADE_ID="firmTradeID";
	public static final String NOTIONAL_AMOUNT="notionalAmount1";		//APR: corrected from notionalAmount
	public static final String ORDER_CATEGORY="orderCategory";
	public static final String QUANTITY_TYPE="qtytype";
	public static final String REGULATORY_REPORT_TYPE="regulatoryReportType";
	public static final String SIDE_TRADE_REPORTING_INDICATOR="sideTradeReportingIndicator";
	public static final String UNIT_MEASURE_OF_QUANTITY="unitOfMeasureQty";
	public static final String UNIT_OF_MEASURE="unitOfMeasure";
	public static final String NON_TOTV_INSTRUMENT = "nonToTVInstrument";
	public static final String PRICE_DISC_N_NEGO_TXN = "priceDiscoveryAndNogoTxn";
	public static final String REF_REG_HUBID = "refRegHubId";
	
	
	//RULE Cionstants
	public static final String ALLOC_TRADE_STATUS = "allocationTradeStatus";
	public static final String JURISDICTION = "jurisdiction";
	
	public static final String NO_PUBLICATION_REQUIRED="NoPublicationRequired";
    public static final String TARGET_APA="targetAPA";//missing in mapping excel
    public static final String ASSISTED_REPORT="assistedReport";
    public static final String COUNTRY_OF_ISSUE="countryOfIssue";
    public static final String SRR_BEHAVIOUR_INSTR="SRRBehaviourInstr";
    public static final String ON_EXCHANGE_INSTR="OnExchangeInstr";
    public static final String EXEMPT_TRANSACTION_CODE="exemptTransactionCode";
    public static final String TEXT="text";
    public static final String DELAY_TO_TIME="delayToTime";
    public static final String PACKAGEID="packageID";
    public static final String TRADENUMBER="tradeNumber";
    public static final String TOTAL_NUM_TRADE_REPORTS="totalNumTradeReports";
    public static final String NO_TRADE_REG_PUBLICATION="NoTrdRegPublications";
    public static final String TRADE_REG_PUBLICATION_TYPE="TrdRegPublicationType";
    public static final String TIME_UNIT="timeUnit";
    public static final String CLIENT_ORDER_TRADE="clientOrderTrade";
    public static final String PX_QTY_REVIEWED="pxQtyReviewed";
    
    public static final String TRADE_VERSION = "tradeVersion" ;
    public static final String TRADE_SUBVERSION = "tradeSubVersion" ;
    
    public static final String EAA_MARKET_TRADE = "eeaRegMarketTrade"; // needs to be added to entity during enrichment
    
     
	// Constant Field for Murex object
	public static final String TRANSACTION_REFERENCE_NUMBER = "transactionReferenceNumber";
	public static final String EXECUTING_ENTITY_IDENTIFICATION_CODE = "executingEntityIdentificationCode";
	public static final String INVESTMENT_FIRM_COVERED_BY_DIRECTIVE = "investmentFirmCoveredByDirective";
	public static final String SUBMITTING_ENTITY_IDENTIFICATION_CODE = "submittingEntityIdentificationCode";
	public static final String COUNTRY_OF_THE_BRANCH_FOR_THE_BUYER = "countryOfTheBranchForTheBuyer";
	public static final String BUYER_DECISION_MAKER_CODE = "buyerDecisionMakerCode";
	public static final String SELLER_IDENTIFICATION_CODE = "sellerIdentificationCode";
	public static final String COUNTRY_OF_BRANCH_FOR_THE_SELLER = "countryOfBranchForTheSeller";
	public static final String SELL_DECISION_MAKER_CODE = "sellDecisionMakerCode";
	public static final String TRADING_DATE_TIME = "tradingDateTime";
	public static final String TRADING_CAPACITY = "tradingCapacity";
	public static final String TRADED_QUANTITY = "tradedQuantity";
	public static final String QUANTITY_CURRENCY = "quantityCurrency";
	public static final String DERIVATIVE_NOTIONAL_INCREASE_DECREASE = "derivativeNotionalIncreaseDecrease";
	public static final String NET_AMOUNT = "netAmount";
	public static final String COUNTRY_OF_THE_BRANCH_MEMBERSHIP = "countryOfTheBranchMembership";
	public static final String INSTRUMENT_FULL_NAME = "instrumentFullName";
	public static final String UNDERLYING_INSTRUMENT_CODE = "underlyingInstrumentCode";
	public static final String SECURITIES_FINANCING_TRANSACTION_INDICATOR = "securitiesFinancingTransactionIndicator";
	public static final String INSTRUMENT_IDENTIFICATION_CODE_TYPE = "instrumentIdentificationCodeType";
	public static final String TRANSACTION_TO_BE_CLEARED = "transactionToBeCleared";
	public static final String PUBLICATION_DATE_AND_TIME = "publicationDateAndTime";
	
	
	//TODO to confrom key value
	public static final String TRADE_REPORT_ID = "tradeReportID";
	public static final String EXEC_INST = "execInst";
	
	
	
	
	
	

}
