package com.citi.reghub.m2post.utils.translators;

import java.util.Set;

import com.citi.reghub.core.Entity;

public interface TradeStatusTranslationEligibilityFinder {

	public default boolean tradeEligibleForStatusTranslation(Entity currEntity, Entity prevEntity) {
		
		if(null == prevEntity) {
			return false;
		}
		
		Set<String> keyset = currEntity.info.keySet();
		for (String key : keyset) {
			Object inputEntityValue = currEntity.info.get(key);
			Object dbEntityValue = prevEntity.info.get(key);

			if (null == inputEntityValue && null != dbEntityValue) {
				return true;
			} else if (null != inputEntityValue && null == dbEntityValue) {
				return true;
			} else if (null != inputEntityValue && null != dbEntityValue && !inputEntityValue.equals(dbEntityValue)) {
				return true;
			}
		}
		return false;
	}
}
