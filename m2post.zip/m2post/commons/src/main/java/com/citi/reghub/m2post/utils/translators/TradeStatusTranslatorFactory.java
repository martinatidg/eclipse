package com.citi.reghub.m2post.utils.translators;

import java.util.HashMap;
import java.util.Map;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;

/**
 * @author dk77005
 *
 */
public class TradeStatusTranslatorFactory {
	private static TradeStatusTranslatorFactory TRADE_STATUS_TRANSLATOR_FACTORY;
	private Map<TradeStatusTransalationProcess, TradeStatusTranslator> TRADE_STATUS_TRANSATORS_MAP;
	
	private TradeStatusTranslatorFactory() {
		TRADE_STATUS_TRANSATORS_MAP = new HashMap<>();
		TRADE_STATUS_TRANSATORS_MAP.put(TradeStatusTransalationProcess.AMENDMENT, new AmendmentTradeStatusTranslator());
		TRADE_STATUS_TRANSATORS_MAP.put(TradeStatusTransalationProcess.NOVATION, new NovationTradeStatusTranslator());
		TRADE_STATUS_TRANSATORS_MAP.put(TradeStatusTransalationProcess.BOOKING, new BookingTradeStatusTranslator());
	}
	
	public static synchronized TradeStatusTranslatorFactory getInstance() {
		if(TRADE_STATUS_TRANSLATOR_FACTORY==null) {
			TRADE_STATUS_TRANSLATOR_FACTORY = new TradeStatusTranslatorFactory();
		}
		return TRADE_STATUS_TRANSLATOR_FACTORY;
	}
	
	public TradeStatusTranslator getTranslator(Entity inputEntity) {
		String inputProcessString = inputEntity.getString(InfoMapKeyStringConstants.EVENT_TYPE);
		TradeStatusTransalationProcess process = TradeStatusTransalationProcess.valueOf(inputProcessString.toUpperCase());
		return TRADE_STATUS_TRANSATORS_MAP.get(process);
	}
	
	public void addTranslator(TradeStatusTransalationProcess transalationProcess, TradeStatusTranslator statusTranslator) {
		TRADE_STATUS_TRANSATORS_MAP.put(transalationProcess, statusTranslator);
	}
}
