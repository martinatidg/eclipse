package com.citi.reghub.m2post.utils.constants;

public interface RuleGraphConstants {

	
	public static final String PRE_ELIGIBILITY_RULE_GRAPH = "m2post_all_eligibility_check";
	public static final String ENRICHMENT_PLAN_NAME = "m2tr-enrichment-plan";
	public static final String POST_ENRICHMENT_ELIGIBILITY_RULE_GRAPH = "m2post-post-enrichment-eligibility-check";
	public static final String POST_ENRICHMENT_BIZ_EXCEPTION_RULE_GRAPH = "m2post-post-enrichment-biz-exception-check";
	public static final String POST_ENRICHMENT_TECH_EXCEPTION_RULE_GRAPH = "m2post-post-enrichment-tech-exception-check";

	//COMMODITIES RULE GRAPHS
	public static final String COMMODITIES_PRE_ELIGIBILITY_RULE_GRAPH = "m2p0st_comderv_pre_eligibility_check";
	public static final String COMMODITIES_ENRICHMENT_RULE_GRAPH = "m2post_commodities_enrichment_rule_graph";
	public static final String COMMODITIES_NON_REPORTABLE_RULE_GRAPH = "m2p0st_comderv_p0st_enrichment_eligibility_check";
	public static final String COMMODITIES_BIZ_EXCEPTION_RULE_GRAPH = "m2p0st_comderv_p0st_enrichment_biz_exception_check";
	public static final String COMMODITIES_TECH_EXCEPTION_RULE_GRAPH = "m2p0st_comderv_tech_exception_check";
	
	//CSHEQ RULE GRAPHS
	public static final String CSHEQ_PRE_ELIGIBILITY_RULE_GRAPH = "m2post_all_eligibility_check";
	
}
