package com.citi.reghub.m2post.utils.fix;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ASSISTED_REPORT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CHECKSUM;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CLIENT_ORDER_TRADE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CONTRACT_MULTIPLIER;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.COUNTRY_OF_ISSUE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.DELAY_TO_TIME;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EMISSION_ALLOWANCE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXECMETHOD;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEMPT_TRANSACTION_CODE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_CAPACITY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_MKT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_PX;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.MSGSEGNUM;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Match_Type;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTATIONAL_AMOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTATION_OF_QTY_IN_MEASUREMENT_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTIONAL_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_PUBLICATION_REQUIRED;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_TRADE_REG_PUBLICATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_TRD_PRC_CONDITION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ON_EXCHANGE_INSTR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OTC_POST_TRADE_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PACKAGEID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PX_QTY_REVIEWED;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.QTY_IN_MESAUREMENT_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ID_SOURCE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SENDER_COMP_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SENDINGTIME;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SETTL_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SIDE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SRR_BEHAVIOUR_INSTR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TARGET_APA;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TARGET_COMP_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TEXT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TIME_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TOTAL_NUM_TRADE_REPORTS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADED_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADEID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADENUMBER;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_REG_PUBLICATION_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADINGSESSIONSUBID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRANSACTION_TO_CLEAR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRANSACT_TIME;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRD_PRC_CONDITION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Trade_Report_Trans_Type;

import java.time.ZoneOffset;
import java.util.Date;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.fix.QuickfixCommonEnums.QtyTyp;

import quickfix.DataDictionary;
import quickfix.custom.field.AlgorithmicTradeIndicator;
import quickfix.custom.field.AssistedReport;
import quickfix.custom.field.ClearingIntention;
import quickfix.custom.field.ClientOrderTrade;
import quickfix.custom.field.ContractMultiplier;
import quickfix.custom.field.DelayToTime;
import quickfix.custom.field.EmissionAllowanceType;
import quickfix.custom.field.ExecMethod;
import quickfix.custom.field.ExemptTransactionCode;
import quickfix.custom.field.LastQty;
import quickfix.custom.field.NoPublicationRequired;
import quickfix.custom.field.NoTradePriceConditions;
import quickfix.custom.field.NoTrdRegPublications;
import quickfix.custom.field.NotionalAmount;
import quickfix.custom.field.NotionalCurrency;
import quickfix.custom.field.OnExchangeInstr;
import quickfix.custom.field.PackageID;
import quickfix.custom.field.PxQtyReviewed;
import quickfix.custom.field.SRRBehaviourInstr;
import quickfix.custom.field.SideTradeReportingIndicator;
import quickfix.custom.field.TargetAPA;
import quickfix.custom.field.TotalNumTradeReports;
import quickfix.custom.field.TradeNumber;
import quickfix.custom.field.TradePriceCondition;
import quickfix.custom.field.TrdRegPublicationReason;
import quickfix.custom.field.TrdRegPublicationType;
import quickfix.field.Account;
import quickfix.field.AccountType;
import quickfix.field.CountryOfIssue;
import quickfix.field.Currency;
import quickfix.field.FirmTradeID;
import quickfix.field.LastCapacity;
import quickfix.field.LastMkt;
import quickfix.field.LastPx;
import quickfix.field.MatchType;
import quickfix.field.OrderCategory;
import quickfix.field.PartyID;
import quickfix.field.PartyIDSource;
import quickfix.field.PartyRole;
import quickfix.field.PriceType;
import quickfix.field.QtyType;
import quickfix.field.SecondaryTrdType;
import quickfix.field.SecurityID;
import quickfix.field.SecurityIDSource;
import quickfix.field.SettlDate;
import quickfix.field.Side;
import quickfix.field.Text;
import quickfix.field.TimeUnit;
import quickfix.field.TradeID;
import quickfix.field.TradePublishIndicator;
import quickfix.field.TradeReportTransType;
import quickfix.field.TradeType;
import quickfix.field.TradingSessionSubID;
import quickfix.field.TransactTime;
import quickfix.field.TrdSubType;
import quickfix.field.UnitOfMeasure;
import quickfix.field.VenueType;
import quickfix.custom.field.UnitOfMeasureQty;
import quickfix.fix50.TradeCaptureReport;
import quickfix.fix50.TradeCaptureReport.NoSides.NoPartyIDs;

public abstract class FixObject extends TradeCaptureReport {

       /**
       * 
        */
       private static final long serialVersionUID = -6862179389123632804L;
       private static  DataDictionary DICTIONARY;
      
       static {
   		try {
   			DICTIONARY = new DataDictionary("dictionary/DictNew.xml");
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
   	}
   	
   	protected static DataDictionary getDictionary() {
   		return DICTIONARY;
   	}

       public FixObject(Entity e) {

              /*********************************** Corefields **********************************/

              // TODO Ignoring certain fields as enrichment is yet to be done.
              if (e.sourceId != null)    this.setField(new FirmTradeID(e.sourceId));
              if (e.executionTs != null) this.setField(new TransactTime(Date.from(e.executionTs.atZone(ZoneOffset.UTC).toInstant())));

              // TODO Check the mapping TradeID. There are no ReadyMade objects
              // available for TradeID
              if (e.info.containsKey(TRADEID)) this.setField(new TradeID(e.getString(TRADEID)));
             // if (e.info.containsKey(TRADE_VENUE_TRANSACT_ID)) this.setField(new FirmTradeID(e.getString(TRADE_VENUE_TRANSACT_ID)));

              // custom fields
              if (e.info.containsKey(TARGET_APA)) this.setField(new TargetAPA(e.getString(TARGET_APA)));
              if (e.info.containsKey(ASSISTED_REPORT)) this.setField(new AssistedReport(e.getString(ASSISTED_REPORT).charAt(0)));
              
              // TODO typecheck will also have to be done
              if (e.info.containsKey(SECURITY_ID)) this.setField(new SecurityID(e.getString(SECURITY_ID)));
              if (e.info.containsKey(SECURITY_ID_SOURCE)) this.setField(new SecurityIDSource("4"));
              //  if (e.info.containsKey(SECURITY_ID_SOURCE)) this.setField(new SecurityIDSource(e.getString(SECURITY_ID_SOURCE)));
              
              // custom fields
              if (e.info.containsKey(COUNTRY_OF_ISSUE)) this.setField(new CountryOfIssue(e.getString(COUNTRY_OF_ISSUE)));
              if (e.info.containsKey(CURRENCY)) this.setField(new Currency(e.getString(CURRENCY)));
              if (e.info.containsKey(LAST_QTY)) this.setField(new LastQty(e.getBigDecimal(LAST_QTY)));
              
              
              if (e.info.containsKey(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT) && QtyTyp.contains(e.getString(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT))){
            	  
            	  this.setField(new QtyType(QtyTyp.valueOf(e.getString(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT)).getValue()));
              }
              if (e.info.containsKey(CONTRACT_MULTIPLIER)) this.setField(new ContractMultiplier(e.getBigDecimal(CONTRACT_MULTIPLIER)));
              if (e.info.containsKey(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT)) this.setField(new UnitOfMeasure(e.getString(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT)));
              if (e.info.containsKey(TIME_UNIT)) this.setField(new TimeUnit(e.getString(TIME_UNIT)));
              if (e.info.containsKey(QTY_IN_MESAUREMENT_UNIT)) this.setField(new UnitOfMeasureQty(e.getBigDecimal(QTY_IN_MESAUREMENT_UNIT)));
              if (e.info.containsKey(LAST_PX)) this.setField(new LastPx(e.getDouble(LAST_PX)));
              if (e.info.containsKey(PRICE_TYPE)) {
            	  if(com.citi.reghub.m2post.utils.fix.QuickfixCommonEnums.PriceType.contains(e.getString(PRICE_TYPE)))
            	  this.setField(
              
            		  new PriceType(com.citi.reghub.m2post.utils.fix.QuickfixCommonEnums.PriceType.getValue(e.getString(PRICE_TYPE))));
              } 
              if (e.info.containsKey(NOTATIONAL_AMOUNT)) this.setField(new NotionalAmount(e.getBigDecimal(NOTATIONAL_AMOUNT)));
              if (e.info.containsKey(NOTIONAL_CURRENCY)) this.setField(new NotionalCurrency(e.getString(NOTIONAL_CURRENCY)));
              if (e.info.containsKey(EMISSION_ALLOWANCE_TYPE)) this.setField(new EmissionAllowanceType(e.getString(EMISSION_ALLOWANCE_TYPE)));
              
              // transactTime this field is derived based on logic in csheq sender
              if (e.info.containsKey(TRANSACT_TIME))   this.setField(new TransactTime(Date.from(e.executionTs.atZone(ZoneOffset.UTC).toInstant())));
              if (e.info.containsKey(LAST_MKT)) this.setField(new LastMkt(e.getString(LAST_MKT)));
              if (e.info.containsKey(SETTL_DATE))      this.setField(new SettlDate(e.getLocalDate(SETTL_DATE).toString()));
              
              //custom field
              if (e.info.containsKey(SRR_BEHAVIOUR_INSTR)) this.setField(new SRRBehaviourInstr(e.getString(SRR_BEHAVIOUR_INSTR).charAt(0)));
              if (e.info.containsKey(ON_EXCHANGE_INSTR)) this.setField(new OnExchangeInstr(e.getString(ON_EXCHANGE_INSTR).charAt(0)));
              if (e.info.containsKey(NO_PUBLICATION_REQUIRED)) this.setField(new NoPublicationRequired(e.getString(NO_PUBLICATION_REQUIRED).charAt(0)));
              if (e.info.containsKey(EXEMPT_TRANSACTION_CODE)) this.setField(new ExemptTransactionCode(e.getString(EXEMPT_TRANSACTION_CODE)));
              if (e.info.containsKey(CLIENT_ORDER_TRADE))     this.setField(new ClientOrderTrade(e.getString(CLIENT_ORDER_TRADE).charAt(0)));
              if (e.info.containsKey(TRANSACTION_TO_CLEAR))  {
            	  if("false".equalsIgnoreCase(e.getString(TRANSACTION_TO_CLEAR)))
             	  this.setField(new ClearingIntention('0'));
            	  this.setField(new ClearingIntention('1'));
              }
              if (e.info.containsKey(TEXT)) this.setField(new Text(e.getString(TEXT)));
              if (e.info.containsKey(PX_QTY_REVIEWED)) this.setField(new PxQtyReviewed(e.getString(PX_QTY_REVIEWED).charAt(0)));
              if (e.info.containsKey(DELAY_TO_TIME)) this.setField(new DelayToTime(e.getString(DELAY_TO_TIME)));
              if (e.info.containsKey(PACKAGEID)) this.setField(new PackageID(e.getString(PACKAGEID)));
              if (e.info.containsKey(TRADENUMBER)) this.setField(new TradeNumber(e.getString(TRADENUMBER)));
              if (e.info.containsKey(TOTAL_NUM_TRADE_REPORTS)) this.setField(new TotalNumTradeReports(e.getString(TOTAL_NUM_TRADE_REPORTS)));
              

              /************************************* MMT *******************************/
              //custom field Hardcoded to O=off book as per TradeEcho spec
              //if (e.info.containsKey(Venue_Type))    this.setField(new VenueType('O'));
              this.setField(new VenueType('O'));
              if (e.info.containsKey(Match_Type))      this.setField(new MatchType(e.getString(Match_Type)));

              // TODO index safety needs to be handled
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR))      this.setField(new TradeType(e.getString(OTC_POST_TRADE_INDICATOR).charAt(0)));
              //
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR))      this.setField(new OrderCategory(e.getString(OTC_POST_TRADE_INDICATOR).charAt(0)));
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR))      this.setField(new TrdSubType(e.getString(OTC_POST_TRADE_INDICATOR).charAt(0)));
              if (e.info.containsKey(Trade_Report_Trans_Type)) this.setField(new TradeReportTransType(Integer.valueOf(e.getString(Trade_Report_Trans_Type))));
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new SecondaryTrdType(Integer.valueOf(e.getString(OTC_POST_TRADE_INDICATOR))));

              //custom field
              if (e.info.containsKey(EXECMETHOD))      this.setField(new ExecMethod(e.getInteger(EXECMETHOD)));
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new AlgorithmicTradeIndicator(Integer.valueOf(e.getString(OTC_POST_TRADE_INDICATOR))));
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new TradePublishIndicator(Integer.valueOf(e.getString(OTC_POST_TRADE_INDICATOR))));
              // descoped
              //if (e.info.containsKey(REGULATORY_REPORT_TYPE))      this.setField(new RegulatoryReportType(e.getString(REGULATORY_REPORT_TYPE)));

              /******************************************* MMT Helper **********************************************/
              //custom field
              if (e.info.containsKey(NO_TRD_PRC_CONDITION)) this.setField(new NoTradePriceConditions(e.getInteger(NO_TRD_PRC_CONDITION)));
              if (e.info.containsKey(TRD_PRC_CONDITION)) this.setField(new TradePriceCondition(e.getString(TRD_PRC_CONDITION)));
              if (e.info.containsKey(NO_TRADE_REG_PUBLICATION)) this.setField(new NoTrdRegPublications(e.getInteger(NO_TRADE_REG_PUBLICATION)));
              if (e.info.containsKey(TRADE_REG_PUBLICATION_TYPE)) this.setField(new TrdRegPublicationType(e.getInteger(TRADE_REG_PUBLICATION_TYPE)));
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new TrdRegPublicationReason(Integer.valueOf(e.getString(OTC_POST_TRADE_INDICATOR))));
              if (e.info.containsKey(PRICE)) this.setField(new LastPx(e.getDouble(PRICE)));
              if (e.info.containsKey(TRADED_QTY)) this.setField(new LastQty(e.getBigDecimal(TRADED_QTY)));
              

              /**************************************** Party and Side Groups ****************************************/
              
              
                    //Hardcoded as per Trade Echo specs as number of sides will always be 2 Executing Firm and Contra Firm
                   //  this.setField(new quickfix.field.NoSides(2));
                     NoSides noSides1 = new NoSides();

                     // Based on the side which is in Entity belongs to Citi and CounterParty side will be opposite of Citi  
                     
                    char side=1; 
                    
                     if (e.info.containsKey(SIDE)) {
                    	 side=e.getString(SIDE).equalsIgnoreCase("SELL")?'1':'2';
                     }
                     
                     noSides1.set(new Side(side));
                     if (e.info.containsKey(LAST_CAPACITY)) noSides1.setField(new LastCapacity(e.getString(LAST_CAPACITY).charAt(0)));
                     
                     /****************************** Block for citi (Executing firm)*************************/   
                    
                     NoPartyIDs noPartyIDs1=new NoPartyIDs();

                     //Hard coding the field to N i.e. Legal Entity Identifier.
                     noPartyIDs1.set(new PartyIDSource('N'));

                      //TODO need to discuss with BA regarding enrichment of LEI 
                     //if (e.info.containsKey("DummyLEI")) noPartyIDs1.setField(new PartyID(e.getString("DummyLEI")));
                      noPartyIDs1.setField(new PartyID("DummyLEI"));
                        
                     // Hardcoding the PartyRole as 1 for Executing firm as per TradeEcho Specs
                     noPartyIDs1.set(new PartyRole(1));
                     
                     //Added the NoPartyIDs group in nosides group
                     noSides1.addGroup(noPartyIDs1);
                     this.addGroup(noSides1);
                     /******************************Block for counter party (Contra firm)*************************/
                     NoSides noSides2 = new NoSides();
                     noSides2.set(new Side(side=='1'?'2':'1'));
                     NoPartyIDs noPartyIDs2=new NoPartyIDs();
                     // Hard coding the field to N i.e. Legal Entity Identifier.
                     noPartyIDs2.setField(new PartyIDSource('N'));
                     
                     //TODO need to discuss with BA regarding enrichment of LEI 
                     //if (e.info.containsKey("DummyLEI")) noPartyIDs2.setField(new PartyID(e.getString("DummyLEI")));
                     noPartyIDs2.setField(new PartyID("DummyLEI"));

                    //Hardcoding the PartyRole as 1 for Executing firm as per Trade Echo Trade Echo specs
                     noPartyIDs2.setField(new PartyRole(17));
                     noSides2.addGroup(noPartyIDs2);
                     this.addGroup(noSides2);
                    // if (e.info.containsKey("noSides.orderId")) noSides.set(new quickfix.field.OrderID("ASAGF245F"));
                   //  this.addGroup(noSides);
                     
              

              // TOD Index safety needs to handled.
              //if (e.info.containsKey(SIDE)) 
              //     this.setField(new Side(e.getString(SIDE).equalsIgnoreCase("SELL")?'1':'2'));
              // TOD Index safety needs to handled.
              //if (e.info.containsKey(LAST_CAPACITY)) this.setField(new LastCapacity(e.getString(LAST_CAPACITY).charAt(0)));

              // TODO custom field
              if (e.info.containsKey(OTC_POST_TRADE_INDICATOR))      this.setField(new SideTradeReportingIndicator(e.getInteger(OTC_POST_TRADE_INDICATOR)));
              if (e.info.containsKey(TRADINGSESSIONSUBID))this.setField(new TradingSessionSubID(e.getString(TRADINGSESSIONSUBID)));
              if (e.info.containsKey(ACCOUNT)) this.setField(new Account(e.getString(ACCOUNT)));
              
              
              
              
              // Hardcoded as per Trade Echo spec (Citi will always be Client)
                     this.setField(new AccountType(1));
              
          
            //  this.addGroup(noPartyIDs2);
              
              if (e.info.containsKey(TARGET_COMP_ID)) getHeader().setString(56, "SRRECHO");
              if (e.info.containsKey(SENDER_COMP_ID)) getHeader().setString(49, "REGHUB");
              if (e.info.containsKey(MSGSEGNUM)) getHeader().setInt(34, e.getInteger(MSGSEGNUM));
              if (e.info.containsKey(SENDINGTIME)) getHeader().setUtcTimeStamp(52, Date.from(e.getLocalDateTime(SENDINGTIME).atZone(ZoneOffset.UTC).toInstant()));
              
              if (e.info.containsKey(CHECKSUM)) getTrailer().setString(10, e.getString(CHECKSUM));
              
              
              
}
       
}
