package com.citi.reghub.m2post.utils.custombolts;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SEQUENCER_STORM_STREAM;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.caching.FetchEntityFromStorage;
import com.citi.reghub.m2post.utils.translators.TradeStatusTranslationEligibilityFinder;
import com.citi.reghub.m2post.utils.translators.TradeStatusTranslatorFactory;

/**
 * @author dk77005
 *
 */
public class StatusTranslationBolt extends RegHubBolt {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(StatusTranslationBolt.class);

	private FetchEntityFromStorage fetchEntityFromStorage = null;

	private OutputCollector _collector;
	private CacheClient cacheClient;
	private RestClient restClient;
	public Map<String, String> cacheCollectionConfig;

	private String serviceUrl = null;

	private TradeStatusTranslationEligibilityFinder tradeStatusTranslationEligibilityFinder;

	public StatusTranslationBolt(TradeStatusTranslationEligibilityFinder tradeStatusTranslationEligibilityFinder) {
		this.tradeStatusTranslationEligibilityFinder = tradeStatusTranslationEligibilityFinder;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {

		_collector = collector;

		fetchEntityFromStorage = new FetchEntityFromStorage();
		restClient = new RestClient(createDefault());

		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		setCacheClient(topologyConfig);
		cacheClient = SingletonCacheClient.getInstance();

		cacheCollectionConfig = new HashMap<>();
		cacheCollectionConfig.put(CacheClient.CACHE_COLLECTION_NAME, "m2post_entities_cache_collection");
		cacheCollectionConfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");

		serviceUrl = topologyConfig.get("entity-service-url");
	}

	@Override
	public void process(Tuple input) throws Exception {

		Entity inputEntityInstance = (Entity) input.getValueByField("message");
		List<Entity> translatedEntities = new ArrayList<>();

		LOG.info("Input Entity is : " + inputEntityInstance);
		if (serviceUrl != null) {
			String formattedUrl = String.format(serviceUrl, inputEntityInstance.flow, inputEntityInstance.sourceId);
			Entity cachedEntityInstance = fetchEntityFromStorage.fetchEntityFromCacheOrDb(restClient, cacheClient,
					inputEntityInstance.sourceId, cacheCollectionConfig, formattedUrl);
			if (tradeStatusTranslationEligibilityFinder.tradeEligibleForStatusTranslation(inputEntityInstance,
					cachedEntityInstance)) {
				translatedEntities = TradeStatusTranslatorFactory.getInstance().getTranslator(inputEntityInstance)
						.translateTradeStatus(inputEntityInstance, cachedEntityInstance);
			}
		}
		LOG.info("Finished status translation.");

		if (translatedEntities.size() == 0) {
			_collector.emit(INBOUND_M2POST_SEQUENCER_STORM_STREAM,
					new Values(inputEntityInstance.regHubId, inputEntityInstance));
		} else {
			for (Entity translatedEntity : translatedEntities) {
				_collector.emit(INBOUND_M2POST_SEQUENCER_STORM_STREAM,
						new Values(translatedEntity.regHubId, translatedEntity));
				_collector.emit(StormStreams.AUDIT, new Values(translatedEntity.regHubId, translatedEntity.toAudit()));
				pushMessageToAuditStream(translatedEntity, translatedEntity.status);
			}
		}

		_collector.ack(input);
	}

	public void pushMessageToAuditStream(Entity message, String auditResult) {
		LOG.info("Publsihing to Audit Stream " + message);
		Audit audit = message.toAudit();
		audit.event = "SEQUENCING";
		audit.result = auditResult;
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.NON_REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
		declarer.declareStream(INBOUND_M2POST_SEQUENCER_STORM_STREAM, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SEQUENCER_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SEQUENCER);
		return exceptionTags;
	}

	private static HttpClient createDefault() {
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		CloseableHttpClient client = builder.build();
		return client;
	}
}