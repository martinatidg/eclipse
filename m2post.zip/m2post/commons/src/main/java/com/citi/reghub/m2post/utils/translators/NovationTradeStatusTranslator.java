/**
 * 
 */
package com.citi.reghub.m2post.utils.translators;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;

/**
 * @author dk77005
 *
 */
public class NovationTradeStatusTranslator implements TradeStatusTranslator {
	
	private static final Logger LOG = LoggerFactory.getLogger(NovationTradeStatusTranslator.class);
	
	public List<Entity> translateTradeStatus(Entity currEntity, Entity prevEntity) {
		List<Entity> entities = new ArrayList<>();
		if(isStepInNovation(currEntity) && SourceStatus.NEW.equals(currEntity.sourceStatus) && !isUITIDEqual(currEntity, prevEntity)) {
			LOG.debug("Inside Stepin case.");
			currEntity.executionTs = prevEntity.executionTs;
			LOG.debug("Updated executionTs on currEntity from prevEntity");
			// TODO: check for MIFID trade id as new.
			entities.add(currEntity);
		} else if(isStepOut(currEntity) && (SourceStatus.AMEND.equals(currEntity.sourceStatus) || SourceStatus.CANCEL.equals(currEntity.sourceStatus))) {
			currEntity.sourceStatus = SourceStatus.NEW;
			entities.add(currEntity);
		}
		return entities;
		
	}

	private boolean isStepOut(Entity currEntity) {
		if(currEntity.info.get(InfoMapKeyStringConstants.ACTION_TYPE).equals("StepOut")) {
			return true;
		}
		return false;
	}

	private boolean isUITIDEqual(Entity currEntity, Entity prevEntity) {
		return currEntity.getString(InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID).equals(prevEntity.getString(InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID));
	}

	private boolean isStepInNovation(Entity currEntity) {
		if(currEntity.info.get(InfoMapKeyStringConstants.ACTION_TYPE).equals("StepIn")) {
			return true;
		}
		return false;
	}
}
