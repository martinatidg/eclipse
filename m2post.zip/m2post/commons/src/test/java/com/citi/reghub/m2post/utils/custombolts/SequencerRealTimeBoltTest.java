package com.citi.reghub.m2post.utils.custombolts;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityCacheSeqDetails;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.converter.ConvertRecordToString;

@RunWith(MockitoJUnitRunner.class)
public class SequencerRealTimeBoltTest {

	public static final String CACHE_PROVIDER = "cache.provider";
	public static final String HAZELCAST_CACHE = "hazelcast";
	public static final String AUDIT_RESULT = "auditResult";
	public static final String SEQUECNER_CACHE_COLLECTION_NAME = "cache.collection.name";
	public static final String TUPLE_KEY = "key";
	public static final String TUPLE_MESSAGE = "message";
	
	@Mock
	OutputFieldsDeclarer declarer;
	
	@Mock
	OutputCollector _collector;
	
	@SuppressWarnings("rawtypes")
	@Mock
	Map stormConf;
	
	@SuppressWarnings("rawtypes")
	@Mock
	Map topologyConfig;
	
	@Mock
	Entity message;
	
	@SuppressWarnings("rawtypes")
	HashMap SeqCacheconfig = new HashMap();
	
	@Mock
	TopologyContext context;
	
	@Mock
	ConvertRecordToString convertToFix;
	
	@Mock
	CacheClient cacheClient;
	
	@Mock
	Audit audit;
	
	@Mock
	Tuple tuple;
	
	@Mock
	EntityCacheSeqDetails seqObjWithSameKey;
	
	@SuppressWarnings("serial")
	@InjectMocks
	SequencerRealTimeBolt mockedSequencerRealTimeBolt = Mockito.spy(new SequencerRealTimeBolt(){
		
		@Override
		protected void setCacheClient(Map<String, String> topologyConfig) {
		}
		
		@Override
		protected CacheClient getCacheInstance() {
			return cacheClient;
		}
	});
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldPrepareBoltWhenInvoked() {
		
		Mockito.when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		Mockito.when(mockedSequencerRealTimeBolt.getMapInstance()).thenReturn(SeqCacheconfig);
		mockedSequencerRealTimeBolt.prepareBolt(stormConf, context, _collector);
		
		Assert.assertEquals("Map", SeqCacheconfig.get(CacheClient.CACHE_COLLECTION_TYPE));
	}
	
	@Test
	public void shouldDeclareOutputFieldsWhenInvoked() {
		mockedSequencerRealTimeBolt.declareOutputFields(declarer);
		verify(declarer, times(5)).declareStream(any(String.class), any(Fields.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldCreateExceptionTagListWhenInvoked() {
		List auditExceptionTags = mockedSequencerRealTimeBolt.getAuditExceptionsTags();
		Assert.assertEquals(StormConstants.SEQUENCER, auditExceptionTags.get(0));
	}
	
	@Test
	public void shuoldReturnAuditExceptionEventWhenInvoked() {
		Assert.assertEquals(StormConstants.SEQUENCER_APP_EXCEPTION, mockedSequencerRealTimeBolt.getAuditExceptionEvent());
	}
	
	@Test
	public void shouldReturnCollectorInstanceWhenInvoked() {
		Assert.assertEquals(_collector, mockedSequencerRealTimeBolt.getCollector());
	}
	
	@Test
	public void shouldPushMessageToAuditWhenInvoked() {
		
		Mockito.when(message.toAudit()).thenReturn(audit);
		mockedSequencerRealTimeBolt.pushMessageToAuditStream(message, AUDIT_RESULT);
		
		verify(_collector).emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		
	}
	
	@Test
	public void shouldStoreMessageInCacheAndPublishToOutboundStream(){
		
		mockedSequencerRealTimeBolt.storeMessageInCacheAndPushToSequencerOutbound(message);
		
		verify(_collector, times(1)).emit(any(String.class), any(Values.class));
		
	}
	
	@Test
	public void shouldEmitToPushBackAndAuditStreamWhenCacheCannotAcquireLock() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(false);
		Mockito.when(message.toAudit()).thenReturn(audit);
		
		message.sourceId = "sourceId";
		mockedSequencerRealTimeBolt.process(tuple);
		
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);;
	}
	
	@Test
	public void shouldEmitToCommonReportableAndAuditStreamWhenCacheCannotAcquireLock() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(true);
		Mockito.when(cacheClient.get("sourceId", null)).thenReturn(null);
		Mockito.when(message.toAudit()).thenReturn(audit);
		
		message.sourceId = "sourceId";
		message.sourceStatus = SourceStatus.NEW;
		mockedSequencerRealTimeBolt.process(tuple);
		
		Assert.assertEquals(EntityStatus.REPORTABLE, message.status);
		verify(_collector, times(3)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);
	}
	
	@Test
	public void shouldEmitToCommonReportableAndAuditStreamAndStatusAsPendingWhenCacheCannotAcquireLock() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(true);
		Mockito.when(cacheClient.get("sourceId", null)).thenReturn(seqObjWithSameKey);
		Mockito.when(message.toAudit()).thenReturn(audit);
		
		seqObjWithSameKey.publishedTs = LocalDateTime.parse("2017-06-08T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		message.publishedTs = LocalDateTime.parse("2017-06-09T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		message.sourceId = "sourceId";
		message.sourceStatus = SourceStatus.NEW;
		mockedSequencerRealTimeBolt.process(tuple);
		
		Assert.assertEquals(EntityStatus.PENDING, message.status);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);
	}
	
	@Test
	public void shouldEmitToCommonReportableAndAuditStreamAndStatusAsPendingIfDateAfterWhenCacheCannotAcquireLock() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(true);
		Mockito.when(cacheClient.get("sourceId", null)).thenReturn(seqObjWithSameKey);
		Mockito.when(message.toAudit()).thenReturn(audit);
		
		seqObjWithSameKey.publishedTs = LocalDateTime.parse("2017-06-10T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		message.publishedTs = LocalDateTime.parse("2017-06-09T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		message.sourceId = "sourceId";
		message.sourceStatus = SourceStatus.NEW;
		mockedSequencerRealTimeBolt.process(tuple);
		
		Assert.assertEquals(EntityStatus.PENDING, message.status);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);
	}
	
	@Test
	public void shouldEmitToCommonReportableAndAuditStreamAndStatusAsPendingIfDateAfterAndCancelStatusWhenCacheCannotAcquireLock() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(true);
		Mockito.when(cacheClient.get("sourceId", null)).thenReturn(seqObjWithSameKey);
		Mockito.when(message.toAudit()).thenReturn(audit);
		
		seqObjWithSameKey.publishedTs = LocalDateTime.parse("2017-06-07T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		message.publishedTs = LocalDateTime.parse("2017-06-09T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		message.sourceId = "sourceId";
		message.sourceStatus = SourceStatus.CANCEL;
		mockedSequencerRealTimeBolt.process(tuple);
		
		Assert.assertEquals(EntityStatus.REPORTABLE, message.status);
		verify(_collector, times(3)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);
	}
}
