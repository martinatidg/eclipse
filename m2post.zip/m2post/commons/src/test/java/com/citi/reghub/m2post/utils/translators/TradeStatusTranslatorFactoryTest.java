package com.citi.reghub.m2post.utils.translators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;
import com.citi.reghub.m2post.utils.translators.TradeStatusTransalationProcess;
import com.citi.reghub.m2post.utils.translators.TradeStatusTranslator;
import com.citi.reghub.m2post.utils.translators.TradeStatusTranslatorFactory;

public class TradeStatusTranslatorFactoryTest {

	@Test
	public void testGetInstance() {
		assertNotNull(TradeStatusTranslatorFactory.getInstance());
	}

	@Test
	public void testGetTranslator() {
		TradeStatusTranslatorFactory factory = TradeStatusTranslatorFactory.getInstance();
		Entity entity = new EntityBuilder().build();
		entity.info.put(InfoMapKeyStringConstants.EVENT_TYPE, "AMENDMENT");
		TradeStatusTranslator statusTranslator = factory.getTranslator(entity);
		assertEquals(statusTranslator.getClass().getName(), "com.citi.reghub.m2post.utils.translators.AmendmentTradeStatusTranslator");
	}

	@Test
	public void testAddTranslator() {
		TradeStatusTranslatorFactory factory = TradeStatusTranslatorFactory.getInstance();
		TradeStatusTranslator dummyTranslator = new TradeStatusTranslator() {
			
			@Override
			public List<Entity> translateTradeStatus(Entity currEntity, Entity prevEntity) {
				// TODO Auto-generated method stub
				return null;
			}
		};
		factory.addTranslator(TradeStatusTransalationProcess.AMENDMENT, dummyTranslator);
		Entity entity = new EntityBuilder().build();
		entity.info.put(InfoMapKeyStringConstants.EVENT_TYPE, "AMENDMENT");
		assertEquals(factory.getTranslator(entity), dummyTranslator);
	}

}
