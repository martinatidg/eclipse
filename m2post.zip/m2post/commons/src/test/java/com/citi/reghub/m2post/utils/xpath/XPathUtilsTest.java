package com.citi.reghub.m2post.utils.xpath;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.w3c.dom.Document;

import com.citi.reghub.m2post.utils.xpath.XPathUtils;

@RunWith(MockitoJUnitRunner.class)
public class XPathUtilsTest {

	@Mock
	XPath mockedXpath;
	
	@Mock
	XPathExpression mockedXPathExpression;
	
	@Mock
	Document mockedDocument;

	private String mockedExpression = "/dummy/xpath/xpression";
	private String ISIN = "ISIN";
	private String EMPTY_STRING = "";
	private String NULL_STRING = null;
	private XPath NULL_XPATH = null;
	@Test
	public void shouldReturnNodeValueWhenGivenXpathIsValid() throws XPathExpressionException {
		
		
		String outputNodeValue = evaluateXpathExpressionOnGivenUtilInstance(ISIN);
		
		Assert.assertEquals("ISIN", outputNodeValue);
		
	}
	
	@Test
	public void shouldReturnEmptyValueFromApiWhenDOMDoesNotConatianValueForGivenXpathAttribute() throws XPathExpressionException {
		
		String outputNodeValue = evaluateXpathExpressionOnGivenUtilInstance(EMPTY_STRING);
		
		Assert.assertNull(outputNodeValue);
		
	}
	
	@Test
	public void shouldReturnEmptyValueFromApiWhenInputXpathDoesNotEvaluateToAValidPath() throws XPathExpressionException {
		
		String outputNodeValue = evaluateXpathExpressionOnGivenUtilInstance(NULL_STRING);
		
		Assert.assertNull(outputNodeValue);
		
	}

	@Test
	public void shoudlReturnNullWhenInputXpathInstanceProvidedIsNull() throws XPathExpressionException {
		
		XPathUtils xPathUtils = new XPathUtils();
		String outputNodeValue = xPathUtils.getNodeValueFromXpathExpression(NULL_XPATH, mockedExpression, mockedDocument);
		
		Assert.assertNull(outputNodeValue);
	}
	
	@Test
	public void shoudlReturnNullWhenInputXpathExpressionProvidedIsNull() throws XPathExpressionException {
		
		XPathUtils xPathUtils = new XPathUtils();
		String outputNodeValue = xPathUtils.getNodeValueFromXpathExpression(mockedXpath, NULL_STRING, mockedDocument);
		
		Assert.assertNull(outputNodeValue);
	}
	
	@Test
	public void shoudlReturnNullWhenInputXpathExpressionProvidedIsEmpty() throws XPathExpressionException {
		
		XPathUtils xPathUtils = new XPathUtils();
		String outputNodeValue = xPathUtils.getNodeValueFromXpathExpression(mockedXpath, EMPTY_STRING, mockedDocument);
		
		Assert.assertNull(outputNodeValue);
	}
	
	private String evaluateXpathExpressionOnGivenUtilInstance(String valueToReturn) throws XPathExpressionException {
		
		XPathUtils xPathUtils = new XPathUtils();
		
		Mockito.when(mockedXpath.compile(mockedExpression)).thenReturn(mockedXPathExpression);
		Mockito.when(mockedXPathExpression.evaluate(mockedDocument, XPathConstants.STRING)).thenReturn(valueToReturn);
		
		String outputNodeValue = xPathUtils.getNodeValueFromXpathExpression(mockedXpath, mockedExpression, mockedDocument);
		return outputNodeValue;
	}
	
}
