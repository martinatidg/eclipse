package com.citi.reghub.m2post.utils.translators;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;

@RunWith(MockitoJUnitRunner.class)
public class NovationTradeStatusTranslatorTest {

	@Test
	public void shouldChangeFieldsForStepIn() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "500.00", "db-reghubid-123");
		dbEntity.executionTs=LocalDateTime.parse("2016-07-01 01:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		
		Entity inputEntity = createCustomEntity("1000.00", "200.00", "500.00", "input-reghubid-123");
		inputEntity.executionTs=LocalDateTime.parse("2016-07-02 01:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		inputEntity.info.put(InfoMapKeyStringConstants.ACTION_TYPE, "StepIn");
		inputEntity.info.put(InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID, "trade-uitid-value-new");
		
		List<Entity> translatedEntities = TradeStatusTranslatorFactory.getInstance().getTranslator(inputEntity).translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(1, translatedEntities.size());
		Assert.assertEquals(dbEntity.executionTs, inputEntity.executionTs);
		Assert.assertEquals(SourceStatus.NEW, inputEntity.sourceStatus);
		// TODO: Check for MIFID trade id, it should be new.
		Assert.assertNotNull(inputEntity.regHubId);
	}
	
	@Test
	public void shouldChangeFieldsForStepOutFullNovation() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "500.00", "db-reghubid-123");
		dbEntity.executionTs=LocalDateTime.parse("2016-07-01 01:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		
		Entity inputEntity = createCustomEntity("1000.00", "200.00", "500.00", "input-reghubid-123");
		inputEntity.executionTs=LocalDateTime.parse("2016-07-02 01:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		inputEntity.sourceStatus = SourceStatus.AMEND;
		inputEntity.info.put(InfoMapKeyStringConstants.ACTION_TYPE, "StepOut");
		inputEntity.info.put(InfoMapKeyStringConstants.REPORT_STATUS, "TERMINATED");
		inputEntity.info.put(InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID, "trade-uitid-value");
		
		List<Entity> translatedEntities = TradeStatusTranslatorFactory.getInstance().getTranslator(inputEntity).translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(1, translatedEntities.size());
		Assert.assertEquals(SourceStatus.NEW, inputEntity.sourceStatus);
		// TODO: Check for MIFID trade id, it should be new.
		Assert.assertNotNull(inputEntity.regHubId);
	}
	
	private Entity createCustomEntity(String notionalAmount, String price, String tradedQty, String reghubId) {

		Entity entity = new Entity();
		entity.sourceId = "m2post-1234";
		entity.regHubId = reghubId;
		entity.sourceStatus = SourceStatus.NEW;
		entity.info.put(InfoMapKeyStringConstants.REPORT_STATUS, "ACTIVE");
		entity.info.put(InfoMapKeyStringConstants.EVENT_TYPE, "NOVATION");
		entity.info.put(InfoMapKeyStringConstants.NOTIONAL_AMOUNT, new BigDecimal(notionalAmount));
		entity.info.put(InfoMapKeyStringConstants.PRICE, new BigDecimal(price));
		entity.info.put(InfoMapKeyStringConstants.TRADED_QTY, new BigDecimal(tradedQty));
		entity.info.put(InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID, "trade-uitid-value");
		
		return entity;
	}

}