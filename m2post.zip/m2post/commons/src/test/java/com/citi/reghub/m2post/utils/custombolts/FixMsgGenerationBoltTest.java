package com.citi.reghub.m2post.utils.custombolts;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.converter.ConvertRecordToString;

@RunWith(MockitoJUnitRunner.class)
public class FixMsgGenerationBoltTest {

	public static final String CACHE_PROVIDER = "cache.provider";
	public static final String HAZELCAST_CACHE = "hazelcast";
	public static final String AUDIT_RESULT = "auditResult";
	public static final String SEQUECNER_CACHE_COLLECTION_NAME = "cache.collection.name";
	public static final String TUPLE_KEY = "key";
	public static final String TUPLE_MESSAGE = "message";
	
	HashMap<String, Object> infoMocked = new HashMap<String, Object>();
	
	@Mock
	OutputFieldsDeclarer declarer;
	
	@Mock
	OutputCollector _collector;
	
	@SuppressWarnings("rawtypes")
	@Mock
	Map stormConf;
	
	@SuppressWarnings("rawtypes")
	@Mock
	Map topologyConfig;
	
	@Mock
	Entity message;
	
	@SuppressWarnings("rawtypes")
	HashMap SeqCacheconfig = new HashMap();
	
	@Mock
	TopologyContext context;
	
	@Mock
	ConvertRecordToString convertToFix;
	
	@Mock
	CacheClient cacheClient;
	
	@Mock
	Audit audit;
	
	@Mock
	Tuple tuple;
	
	@SuppressWarnings("serial")
	@InjectMocks
	FixMsgGenerationBolt mockedFixMsgGenerationBolt = Mockito.spy(new FixMsgGenerationBolt(null, null, convertToFix));
	
	
	@Test
	public void shouldDeclareOutputFieldsWhenInvoked() {
		mockedFixMsgGenerationBolt.declareOutputFields(declarer);
		verify(declarer, times(5)).declareStream(any(String.class), any(Fields.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldCreateExceptionTagListWhenInvoked() {
		List auditExceptionTags = mockedFixMsgGenerationBolt.getAuditExceptionsTags();
		
		Assert.assertEquals(StormConstants.SENDER, auditExceptionTags.get(0));
		Assert.assertEquals(StormConstants.FIX_MSG_GENERATION_EXCEPTION, auditExceptionTags.get(1));
	}
	
	@Test
	public void shuoldReturnAuditExceptionEventWhenInvoked() {
		Assert.assertEquals(StormConstants.SENDER_APP_EXCEPTION, mockedFixMsgGenerationBolt.getAuditExceptionEvent());
	}
	
	@Test
	public void shouldReturnCollectorInstanceWhenInvoked() {
		Assert.assertEquals(_collector, mockedFixMsgGenerationBolt.getCollector());
	}
	
	@Test
	public void shouldReturnConvertToFixInstanceWhenInvoked() {
		Assert.assertEquals(convertToFix, mockedFixMsgGenerationBolt.getConvertRecordToString());
	}
	
	@Test
	public void shoouldPushMessageToAuditWhenInvoked() {
		
		Mockito.when(message.toAudit()).thenReturn(audit);
		mockedFixMsgGenerationBolt.pushMessageToAuditStream(message, AUDIT_RESULT);
		
		verify(_collector).emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldEmitToPushBackAndAuitStreamWhenFixMessageGeneratedEmpty() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(true);
		Mockito.when(convertToFix.convert(any(List.class))).thenReturn("");
		Mockito.when(message.toAudit()).thenReturn(audit);
		message.info = infoMocked;
		
		message.sourceId = "sourceId";
		mockedFixMsgGenerationBolt.process(tuple);
		
		verify(_collector, times(1)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);
		message.info.clear();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldEmitTorwOutboundFixPushBackAndAuitStreamWhenFixMessageGeneratedEmpty() throws Exception {
		
		Mockito.when(tuple.getValueByField(TUPLE_MESSAGE)).thenReturn(message);
		Mockito.when(cacheClient.tryLock("sourceId", null)).thenReturn(true);
		Mockito.when(convertToFix.convert(any(List.class))).thenReturn("ABC");
		Mockito.when(message.toAudit()).thenReturn(audit);
		message.info = infoMocked;
		message.sourceId = "sourceId";
		mockedFixMsgGenerationBolt.process(tuple);
		
		verify(_collector, times(3)).emit(any(String.class), any(Values.class));
		verify(_collector).ack(tuple);
		message.info.clear();
	}
	
}
