package com.citi.reghub.m2post.utils.translators;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;
import com.citi.reghub.m2post.utils.translators.AmendmentTradeStatusTranslator;

@RunWith(MockitoJUnitRunner.class)
public class AmendmentTradeStatusTranslatorTest {

	private AmendmentTradeStatusTranslator classUndertest = new AmendmentTradeStatusTranslator();
	
	/*@Test
	public void shouldNotOverrideEntityWhenThereIsNoChangeInNotional() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "500.00", "db-reghubid-123");
		Entity inputEntity = createCustomEntity("1000.00", "200.00", "500.00", "input-reghubid-123");
		
		List<Entity> translatedEntities = classUndertest.translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(1, translatedEntities.size());
		Assert.assertEquals(SourceStatus.NEW, translatedEntities.get(0).sourceStatus);
		Assert.assertEquals("input-reghubid-123", translatedEntities.get(0).regHubId);
		Assert.assertEquals(new BigDecimal("1000.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.NOTIONAL_AMOUNT));
		Assert.assertNotNull(translatedEntities.get(0).info.get(InfoMapKeyStringConstants.REF_REG_HUBID));
		
	}*/
	
	@Test
	public void shouldChangeNotionalAmountInInputEntityWhenItDiffersFormCachedEntity() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "500.00", "db-reghubid-123");
		Entity inputEntity = createCustomEntity("3000.00", "200.00", "500.00", "input-reghubid-123");
		
		List<Entity> translatedEntities = classUndertest.translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(1, translatedEntities.size());
		Assert.assertEquals(SourceStatus.NEW, translatedEntities.get(0).sourceStatus);
		Assert.assertEquals("input-reghubid-123", translatedEntities.get(0).regHubId);
		Assert.assertEquals(new BigDecimal("2000.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.NOTIONAL_AMOUNT));
		Assert.assertEquals(new BigDecimal("200.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.PRICE));
		Assert.assertEquals(new BigDecimal("500.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.TRADED_QTY));
		Assert.assertEquals("db-reghubid-123", translatedEntities.get(0).info.get(InfoMapKeyStringConstants.REF_REG_HUBID));
		
	}
	
	@Test
	public void shouldChangeOnlyNotionalWhenPriceChangesDiffersFromCachedEntity() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "500.00", "db-reghubid-123");
		Entity inputEntity = createCustomEntity("1000.00", "400.00", "500.00", "input-reghubid-123");
		
		List<Entity> translatedEntities = classUndertest.translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(1, translatedEntities.size());
		Assert.assertEquals(SourceStatus.NEW, translatedEntities.get(0).sourceStatus);
		Assert.assertEquals("input-reghubid-123", translatedEntities.get(0).regHubId);
		Assert.assertEquals(new BigDecimal("0.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.NOTIONAL_AMOUNT));
		Assert.assertEquals(new BigDecimal("400.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.PRICE));
		Assert.assertEquals("db-reghubid-123", translatedEntities.get(0).info.get(InfoMapKeyStringConstants.REF_REG_HUBID));
		
		
	}
	
	@Test
	public void shouldChangeOnlyNotionalWhenQtyChangesDiffersFromCachedEntity() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "500.00", "db-reghubid-123");
		Entity inputEntity = createCustomEntity("1000.00", "200.00", "800.00", "input-reghubid-123");
		
		List<Entity> translatedEntities = classUndertest.translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(1, translatedEntities.size());
		Assert.assertEquals(SourceStatus.NEW, translatedEntities.get(0).sourceStatus);
		Assert.assertEquals("input-reghubid-123", translatedEntities.get(0).regHubId);
		Assert.assertEquals(new BigDecimal("0.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.NOTIONAL_AMOUNT));
		Assert.assertEquals(new BigDecimal("200.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.PRICE));
		Assert.assertEquals(new BigDecimal("800.00"), translatedEntities.get(0).info.get(InfoMapKeyStringConstants.TRADED_QTY));
		Assert.assertEquals("db-reghubid-123", translatedEntities.get(0).info.get(InfoMapKeyStringConstants.REF_REG_HUBID));
	}
	
	@Test
	public void shouldCancelExistingTradeAndBookCurrentTradeAsNew() {
		
		Entity dbEntity = createCustomEntity("1000.00", "200.00", "800.00", "db-reghubid-123");
		Entity inputEntity = createCustomEntity("1000.00", "200.00", "800.00", "input-reghubid-123");
		
		List<Entity> translatedEntities = classUndertest.translateTradeStatus(inputEntity, dbEntity);
		
		Assert.assertEquals(2, translatedEntities.size());
		Assert.assertEquals(SourceStatus.CANCEL, translatedEntities.get(0).sourceStatus);
		Assert.assertEquals(SourceStatus.NEW, translatedEntities.get(1).sourceStatus);
		Assert.assertEquals("input-reghubid-123", translatedEntities.get(1).regHubId);
		Assert.assertEquals(new BigDecimal("1000.00"), translatedEntities.get(1).info.get(InfoMapKeyStringConstants.NOTIONAL_AMOUNT));
		Assert.assertEquals(new BigDecimal("200.00"), translatedEntities.get(1).info.get(InfoMapKeyStringConstants.PRICE));
		Assert.assertEquals(new BigDecimal("800.00"), translatedEntities.get(1).info.get(InfoMapKeyStringConstants.TRADED_QTY));
	}
	
	private Entity createCustomEntity(String notionalAmount, String price, String tradedQty, String reghubId) {

		Entity entity = new Entity();
		entity.sourceId = "m2post-1234";
		entity.regHubId = reghubId;
		entity.info.put(InfoMapKeyStringConstants.EVENT_TYPE, "AMENDMENT");
		entity.info.put(InfoMapKeyStringConstants.NOTIONAL_AMOUNT, new BigDecimal(notionalAmount));
		entity.info.put(InfoMapKeyStringConstants.PRICE, new BigDecimal(price));
		entity.info.put(InfoMapKeyStringConstants.TRADED_QTY, new BigDecimal(tradedQty));
		
		return entity;
	}

}