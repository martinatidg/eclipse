package com.citi.reghub.m2post.utils.dataaccess;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;

@RunWith(MockitoJUnitRunner.class)
public class FetchEntityFromStorageTest {

	private FetchEntityFromStorage classUndertest = new FetchEntityFromStorage();
	private String cacheKey = "sourceId-123";
	private String serviceUrl = "http://dummy.url.com";
	Entity expectedEntity = createEntity();
	Entity cachedEntity = createEntity();
	List<Entity> entityList = new ArrayList<Entity>();
	
	@Mock
	RestClient mockedRestClient;
	
	@Mock
	CacheClient mockedCacheClient;
	
	@SuppressWarnings("rawtypes")
	@Mock
	Map mockedConfig;
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldReturnEntityFromCacheWhenAlreadyCached() {
		
		Mockito.when(mockedCacheClient.get(cacheKey, mockedConfig)).thenReturn(cachedEntity);
		Entity actualEntity = classUndertest.fetchEntityFromCacheOrDb(mockedRestClient, mockedCacheClient, cacheKey, mockedConfig, serviceUrl);
		
		Assert.assertEquals(expectedEntity.sourceId, actualEntity.sourceId);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldreturnEntityWhenEntityNotPresentInCacheButPresentInDatabase() {
		
		entityList.add(cachedEntity);
		Mockito.when(mockedCacheClient.get(cacheKey, mockedConfig)).thenReturn(null);
		Mockito.when(mockedRestClient.getValues(serviceUrl, Entity.class)).thenReturn(entityList);
		
		Entity actualEntity = classUndertest.fetchEntityFromCacheOrDb(mockedRestClient, mockedCacheClient, cacheKey, mockedConfig, serviceUrl);
		
		Assert.assertEquals(expectedEntity.sourceId, actualEntity.sourceId);
		
		entityList.clear();
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldreturnNullWhenEntityNotFoundInCacheAndDb() {
		
		Mockito.when(mockedCacheClient.get(cacheKey, mockedConfig)).thenReturn(null);
		Mockito.when(mockedRestClient.getValues(serviceUrl, Entity.class)).thenReturn(null);
		
		Entity actualEntity = classUndertest.fetchEntityFromCacheOrDb(mockedRestClient, mockedCacheClient, cacheKey, mockedConfig, serviceUrl);
		
		Assert.assertNull(actualEntity);
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldreturnNullWhenEntityNotFoundInCacheAndDbAndresultisEnptyList() {
		
		Mockito.when(mockedCacheClient.get(cacheKey, mockedConfig)).thenReturn(null);
		Mockito.when(mockedRestClient.getValues(serviceUrl, Entity.class)).thenReturn(entityList);
		
		Entity actualEntity = classUndertest.fetchEntityFromCacheOrDb(mockedRestClient, mockedCacheClient, cacheKey, mockedConfig, serviceUrl);
		
		Assert.assertNull(actualEntity);
		
	}
	
	private Entity createEntity() {

		Entity entity = new Entity();
		entity.sourceId = "sourceId-123";
		return entity;
	}
	
}
