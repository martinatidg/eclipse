package com.citi.reghub.m2post.utils.sourcetoentitymappers;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.COMMODITIES_DERIVATIVE_INDICATOR_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.CONTRACT_MULTIPLIER_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.DELIVERY_TYPE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.EMISSION_ALLOWANCE_TYPE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.EXECUTION_VENUE_TYPE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.INSTRUMENT_CLASSIFICATION_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.INSTRUMENT_IDENTIFICATION_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.NOTATIONAL_AMOUNT_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.NOTATION_OF_QTY_IN_MEASUREMENT_UNIT_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.NOTIONAL_CURRENCY_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.NOTIONAL_CURRENCY_XPATH_1;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.OPTION_EXERCISE_STYLE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.OPTION_TYPE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.OTC_POST_TRADE_INDICATOR_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PARTY_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PERIOD_MULTIPLIER_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PERIOD_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PORTFOLIO_COMPRESSION_TRADES_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PRICE_CURRENCY_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PRICE_NOTATION_AMT_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PRICE_NOTATION_PRC_RATE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PRODUCT_DELIVERY_TYPE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.PUBLISH_TS_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.QTY_IN_MESAUREMENT_UNIT_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.REPORT_STATUS_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.SOURCE_SYSTEM_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.SOURCE_UNIQUE_ID_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.STRIKE_PRICE_CURRENCY_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.STRIKE_PRICE_PER_UNIT_AMOUNT_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.STRIKE_PRICE_PER_UNIT_CURRENCY_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.STRIKE_PRICE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.TRADE_CAPACITY_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.TRADE_VENUE_TRANSACT_ID_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.TRADING_DATE_TIME_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.TRANSACTION_TO_CLEAR_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.UITID_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.UNDERLYING_INDEX_NAME_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.VENUE_TRADE_XPATH;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.WAIVER_INDICATOR_XPATH;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.w3c.dom.Document;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.m2post.utils.xpath.XPathUtils;

@RunWith(MockitoJUnitRunner.class)
public class AbstractCitiMLToEntityMapperTest {
	
	@Mock
	Document xmlDocument;
	
	@Mock
	XPath xPath;
	
	@Mock
	Entity entity = new Entity();
	
	HashMap<String, Object> infoMocked = new HashMap<String, Object>();
	
	@Mock
	XPathUtils xPathUtilInstance;
	
	String flow = "com";
	String stream = "m2post";
	
	@SuppressWarnings("serial")
	@InjectMocks
	AbstractCitiMLToEntityMapper mockedAbstractCitiMLToEntityMapper = Mockito.spy(new AbstractCitiMLToEntityMapper(flow, stream){
		
		@Override
		protected void setPrice() throws XPathExpressionException {
			
		}

		@Override
		protected void setVenueOfExecution() throws XPathExpressionException {
			
		}
		
	});
	
	@Test
	public void shouldSetReportStatusWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, REPORT_STATUS_XPATH, xmlDocument)).thenReturn("ACTIVE");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setReportStatus();
		Assert.assertEquals("ACTIVE", entity.info.get(REPORT_STATUS));
		entity.info.clear();
	}
	
	@Test
	public void shouldSetExecutionVenueWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, EXECUTION_VENUE_TYPE_XPATH, xmlDocument)).thenReturn("OFFFACILITY");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setExecutionVenueType();
		Assert.assertEquals("OFFFACILITY", entity.info.get(EXECUTION_VENUE_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldSetTransactionToClearWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRANSACTION_TO_CLEAR_XPATH, xmlDocument)).thenReturn("true");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTransactionToClear();
		Assert.assertEquals("true", entity.info.get(TRANSACTION_TO_CLEAR));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldSetExecutingEntityIdentityficationCodeWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, EXECUTING_ENTITY, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACCT_MNEMONIC");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, EXECUTING_ENTITY, GFCID), xmlDocument)).thenReturn("GFCID");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setExecutingEntityIdentityficationCode();
		Assert.assertEquals("ACCT_MNEMONIC", entity.info.get(EXECENTITY_ACCTMNEMONIC));
		Assert.assertEquals("GFCID", entity.info.get(EXECENTITY_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotSetExecutingEntityIdentityficationCodeAcctMnemonicWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, EXECUTING_ENTITY, ACCT_MNEMONIC), xmlDocument)).thenReturn(null);
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, EXECUTING_ENTITY, GFCID), xmlDocument)).thenReturn("GFCID");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setExecutingEntityIdentityficationCode();
		Assert.assertNull(entity.info.get(EXECENTITY_ACCTMNEMONIC));
		Assert.assertEquals("GFCID", entity.info.get(EXECENTITY_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotSetExecutingEntityIdentityficationCodeGfcidWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, EXECUTING_ENTITY, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACCT_MNEMONIC");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, EXECUTING_ENTITY, GFCID), xmlDocument)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setExecutingEntityIdentityficationCode();
		Assert.assertEquals("ACCT_MNEMONIC", entity.info.get(EXECENTITY_ACCTMNEMONIC));
		Assert.assertNull(entity.info.get(EXECENTITY_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetInstrumentClassificationWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, INSTRUMENT_CLASSIFICATION_XPATH, xmlDocument)).thenReturn("Commodities:Metals");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setInstrumentClassification();
		Assert.assertEquals("Commodities:Metals", entity.info.get(INSTRUMENT_CLASSIFICATION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetInstrumentIdentificationWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, INSTRUMENT_IDENTIFICATION_XPATH, xmlDocument)).thenReturn("ISIN");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setInstrumentIdentification();
		Assert.assertEquals("ISIN", entity.info.get(INSTRUMENT_IDENTIFICATION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeExecutionTsAndexecutionTradeDateWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADING_DATE_TIME_XPATH, xmlDocument)).thenReturn("2017-06-09T22:02:41Z");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradeExecutionTs();
		Assert.assertEquals(LocalDate.parse("2017-06-09"), entity.info.get(TRADE_DATE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeExecutionTsAndexecutionTradeDateWhenInvokedAndTradeDateisNull() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADING_DATE_TIME_XPATH, xmlDocument)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradeExecutionTs();
		Assert.assertNull(entity.executionTs);
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetWaiverIndicatorWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, WAIVER_INDICATOR_XPATH, xmlDocument)).thenReturn("Y");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setWaiverIndicator();
		Assert.assertEquals("Y", entity.info.get(WAIVER_INDICATOR));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOtcPostTradeIndicatorWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, OTC_POST_TRADE_INDICATOR_XPATH, xmlDocument)).thenReturn("Y");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setOtcPostTradeIndicator();
		Assert.assertEquals("Y", entity.info.get(OTC_POST_TRADE_INDICATOR));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetCommoditiesDerivativeIndicatorWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, COMMODITIES_DERIVATIVE_INDICATOR_XPATH, xmlDocument)).thenReturn("Y");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setCommoditiesDerivativeIndicator();
		Assert.assertEquals("Y", entity.info.get(COMMODITIES_DERIVATIVE_INDICATOR));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetQtyInMeasurementUnitWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, QTY_IN_MESAUREMENT_UNIT_XPATH, xmlDocument)).thenReturn("2.00");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setQtyInMeasurementUnit();
		Assert.assertEquals(new BigDecimal("2.00"), entity.info.get(QTY_IN_MESAUREMENT_UNIT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastCapacityAsAOTCWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADE_CAPACITY_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setLastCapacity();
		Assert.assertEquals(AOTC, entity.info.get(LAST_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastCapacityAsMTCHWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADE_CAPACITY_XPATH, xmlDocument)).thenReturn("MatchedPrincipal");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setLastCapacity();
		Assert.assertEquals(MTCH, entity.info.get(LAST_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastCapacityAsDEALWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADE_CAPACITY_XPATH, xmlDocument)).thenReturn("Principal");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setLastCapacity();
		Assert.assertEquals(DEAL, entity.info.get(LAST_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetLastCapacityAsDEALWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADE_CAPACITY_XPATH, xmlDocument)).thenReturn("ABC");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setLastCapacity();
		Assert.assertNull(entity.info.get(LAST_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNotationOfQtyInMeasurementUnitWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTATION_OF_QTY_IN_MEASUREMENT_UNIT_XPATH, xmlDocument)).thenReturn("TOCD");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setNotationOfQtyInMeasurementUnit();
		Assert.assertEquals("TOCD", entity.info.get(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNotationalAmountWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTATIONAL_AMOUNT_XPATH, xmlDocument)).thenReturn("2100.22");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setNotationalAmount();
		Assert.assertEquals(new BigDecimal("2100.22"), entity.info.get(NOTATIONAL_AMOUNT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetEmissionAllowanceTypeWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, EMISSION_ALLOWANCE_TYPE_XPATH, xmlDocument)).thenReturn("AER");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setEmissionAllowanceType();
		Assert.assertEquals("AER", entity.info.get(EMISSION_ALLOWANCE_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetInstrIdentTypeCodeWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, INSTRUMENT_CLASSIFICATION_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setInstrIdentTypeCode();
		Assert.assertNull(entity.info.get(INSTR_IDENT_CODE_TYPE));
		Assert.assertNull(entity.info.get(INSTR_IDENT_CODE));
		Assert.assertNull(entity.info.get(SECURITY_ISIN));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetInstrIdentTypeCodeWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, INSTRUMENT_CLASSIFICATION_XPATH, xmlDocument)).thenReturn("US12345678910");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setInstrIdentTypeCode();
		Assert.assertEquals("ISIN", entity.info.get(INSTR_IDENT_CODE_TYPE));
		Assert.assertEquals("US12345678910", entity.info.get(INSTR_IDENT_CODE));
		Assert.assertEquals("US12345678910", entity.info.get(SECURITY_ISIN));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceCurrencyWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_CURRENCY_XPATH, xmlDocument)).thenReturn("USD");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPriceCurrency();
		Assert.assertEquals("USD", entity.info.get(PRICE_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNotionalCurrencyWhenCurrency1IsNullInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTIONAL_CURRENCY_XPATH_1, xmlDocument)).thenReturn(null);
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTIONAL_CURRENCY_XPATH, xmlDocument)).thenReturn("INR");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setNotionalCurrency();
		Assert.assertEquals("INR", entity.info.get(NOTIONAL_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNotionalCurrencyWhenCurrency1IsNotNullInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTIONAL_CURRENCY_XPATH_1, xmlDocument)).thenReturn("USD");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setNotionalCurrency();
		Assert.assertEquals("USD", entity.info.get(NOTIONAL_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetUnderlyingIndexNameWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, UNDERLYING_INDEX_NAME_XPATH, xmlDocument)).thenReturn("200.2");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setUnderlyingIndexName();
		Assert.assertEquals(new BigDecimal("200.2"), entity.info.get(UNDERLYING_INDEX_NAME));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOptionTypeWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, OPTION_TYPE_XPATH, xmlDocument)).thenReturn("OPT");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setOptionType();
		Assert.assertEquals("OPT", entity.info.get(OPTION_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetStrikePriceWhenStrikePricePerUnitAndisNullInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_XPATH, xmlDocument)).thenReturn("200.2");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_PER_UNIT_AMOUNT_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setStrikePrice();
		Assert.assertEquals(new BigDecimal("200.2"), entity.info.get(STRIKE_PRICE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetStrikePriceWhenStrikePriceisNullAndIsInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_PER_UNIT_AMOUNT_XPATH, xmlDocument)).thenReturn("563.21");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setStrikePrice();
		Assert.assertEquals(new BigDecimal("563.21"), entity.info.get(STRIKE_PRICE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetStrikePriceWhenBothAreNullAndIsInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_PER_UNIT_AMOUNT_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setStrikePrice();
		Assert.assertNull(entity.info.get(STRIKE_PRICE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOptionExerciseStyleWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, OPTION_EXERCISE_STYLE_XPATH, xmlDocument)).thenReturn("ABC");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setOptionExerciseStyle();
		Assert.assertEquals("ABC", entity.info.get(OPTION_EXERCISE_STYLE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetDeliveryTypeWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, DELIVERY_TYPE_XPATH, xmlDocument)).thenReturn("XYZ");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setDeliveryType();
		Assert.assertEquals("XYZ", entity.info.get(DELIVERY_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetStrikePriceCurrencyWhenStrikePricePerUnitCurrencyAndisNullInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_CURRENCY_XPATH, xmlDocument)).thenReturn("INR");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_PER_UNIT_CURRENCY_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setStrikePriceCurrency();
		Assert.assertEquals("INR", entity.info.get(STRIKE_PRICE_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldssetStrikePriceCurrencyWhenStrikePriceCurrencyisNullAndIsInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_CURRENCY_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_PER_UNIT_CURRENCY_XPATH, xmlDocument)).thenReturn("USD");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setStrikePriceCurrency();
		Assert.assertEquals("USD", entity.info.get(STRIKE_PRICE_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetStrikePriceCurrencyWhenBothAreNullAndIsInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_CURRENCY_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, STRIKE_PRICE_PER_UNIT_CURRENCY_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setStrikePriceCurrency();
		Assert.assertNull(entity.info.get(STRIKE_PRICE_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTermOfUnderlyingIndexWhenPeriodMultiplierIsNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PERIOD_MULTIPLIER_XPATH, xmlDocument)).thenReturn("1");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PERIOD_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTermOfUnderlyingIndex();
		Assert.assertEquals("1", entity.info.get(TERM_OF_UNDERLYING_INDEX));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTermOfUnderlyingIndexWhenPeriodIsNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PERIOD_MULTIPLIER_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PERIOD_XPATH, xmlDocument)).thenReturn("2");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTermOfUnderlyingIndex();
		Assert.assertEquals("2", entity.info.get(TERM_OF_UNDERLYING_INDEX));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTermOfUnderlyingIndexWhenBothAreNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PERIOD_MULTIPLIER_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PERIOD_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTermOfUnderlyingIndex();
		Assert.assertNull(entity.info.get(TERM_OF_UNDERLYING_INDEX));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNotionalCurrency2WhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTIONAL_CURRENCY_XPATH, xmlDocument)).thenReturn("INR");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setNotionalCurrency2();
		Assert.assertEquals("INR", entity.info.get(NOTIONAL_CURRENCY2));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceNotationWhenPriceNotationPercrateIsNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_NOTATION_AMT_XPATH, xmlDocument)).thenReturn("100");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_NOTATION_PRC_RATE_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPriceNotation();
		Assert.assertEquals("MONE", entity.info.get(PRICE_NOTATION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceNotationWhenPriceNotationsAmntIsNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_NOTATION_AMT_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_NOTATION_PRC_RATE_XPATH, xmlDocument)).thenReturn("200");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPriceNotation();
		Assert.assertEquals("PERC", entity.info.get(PRICE_NOTATION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceNotationWhenBothAreNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_NOTATION_AMT_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRICE_NOTATION_PRC_RATE_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPriceNotation();
		Assert.assertNull(entity.info.get(PRICE_NOTATION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetTradeVenueTransactionIdIsNullWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, TRADE_VENUE_TRANSACT_ID_XPATH, xmlDocument)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradeVenueTransactionId();
		Assert.assertNull(entity.info.get(TRADE_VENUE_TRANSACT_ID));
		Assert.assertNull(entity.sourceId);
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeVenueTransactionIdWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(UITID_XPATH, UITID1), xmlDocument)).thenReturn("XOFF");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradeVenueTransactionId();
		Assert.assertEquals("XOFF", entity.info.get(TRADE_VENUE_TRANSACT_ID));
		Assert.assertEquals("XOFF", entity.sourceId);
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradedQuantityWhenNotationalAmntIsNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, QTY_IN_MESAUREMENT_UNIT_XPATH, xmlDocument)).thenReturn("100");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTATIONAL_AMOUNT_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradedQuantity();
		Assert.assertEquals(new BigDecimal("100"), entity.info.get(TRADED_QTY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradedQuantityWhenQtyInSmrmntUnitIsNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, QTY_IN_MESAUREMENT_UNIT_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTATIONAL_AMOUNT_XPATH, xmlDocument)).thenReturn("200");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradedQuantity();
		Assert.assertEquals(new BigDecimal("200"), entity.info.get(TRADED_QTY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradedQuantityWhenBothAreNullAndInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, QTY_IN_MESAUREMENT_UNIT_XPATH, xmlDocument)).thenReturn("");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, NOTATIONAL_AMOUNT_XPATH, xmlDocument)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setTradedQuantity();
		Assert.assertNull(entity.info.get(TRADED_QTY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNoPartyIdsWhenInvoked() throws XPathExpressionException {
		
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setNoPartyIds();
		Assert.assertEquals(2, entity.info.get(NO_PARTY_IDS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPartyIdsWhennvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_A");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, GFCID), xmlDocument)).thenReturn("GFCID_A");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, GFCID), xmlDocument)).thenReturn("GFCID_B");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPartyIds();
		Assert.assertEquals("ACTMNE_A", entity.info.get(EXEC_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_A", entity.info.get(EXEC_FIRM_GFCID));
		Assert.assertEquals("ACTMNE_B", entity.info.get(CPTY_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_B", entity.info.get(CPTY_FIRM_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetPartyIdsPartyAAcctMnemonicWhennvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC), xmlDocument)).thenReturn(null);
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, GFCID), xmlDocument)).thenReturn("GFCID_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_A");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, GFCID), xmlDocument)).thenReturn("GFCID_A");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPartyIds();
		Assert.assertNull(entity.info.get(CPTY_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_B", entity.info.get(CPTY_FIRM_GFCID));
		Assert.assertEquals("ACTMNE_A", entity.info.get(EXEC_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_A", entity.info.get(EXEC_FIRM_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetPartyIdsPartyAGfcidWhennvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, GFCID), xmlDocument)).thenReturn(null);
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_A");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, GFCID), xmlDocument)).thenReturn("GFCID_A");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPartyIds();
		Assert.assertEquals("ACTMNE_B",entity.info.get(CPTY_FIRM_ACCT_MNEMONIC));
		Assert.assertNull(entity.info.get(CPTY_FIRM_GFCID));
		Assert.assertEquals("ACTMNE_A", entity.info.get(EXEC_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_A", entity.info.get(EXEC_FIRM_GFCID));
		entity.info.clear();
		
	}
	
	
	@Test
	public void shouldNotsetPartyIdsPartyBAcctMnemonicWhennvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, GFCID), xmlDocument)).thenReturn("GFCID_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC), xmlDocument)).thenReturn(null);
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, GFCID), xmlDocument)).thenReturn("GFCID_A");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPartyIds();
		Assert.assertEquals("ACTMNE_B",entity.info.get(CPTY_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_B", entity.info.get(CPTY_FIRM_GFCID));
		Assert.assertNull(entity.info.get(EXEC_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_A", entity.info.get(EXEC_FIRM_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetPartyIdsPartyBGfcidWhennvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_B, GFCID), xmlDocument)).thenReturn("GFCID_B");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, ACCT_MNEMONIC), xmlDocument)).thenReturn("ACTMNE_A");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, String.format(PARTY_XPATH, PARTY_A, GFCID), xmlDocument)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPartyIds();
		Assert.assertEquals("ACTMNE_B",entity.info.get(CPTY_FIRM_ACCT_MNEMONIC));
		Assert.assertEquals("GFCID_B", entity.info.get(CPTY_FIRM_GFCID));
		Assert.assertEquals("ACTMNE_A", entity.info.get(EXEC_FIRM_ACCT_MNEMONIC));
		Assert.assertNull(entity.info.get(EXEC_FIRM_GFCID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetVenueTradeWhennvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, VENUE_TRADE_XPATH, xmlDocument)).thenReturn("XOFF");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setVenueTrade();
		Assert.assertEquals("XOFF", entity.info.get(VENUE_TRADE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPartyIDSourceWhenInvoked() throws XPathExpressionException {
		
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPartyIDSource();
		Assert.assertEquals("N", entity.info.get(PARTY_ID_SOURCE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPortfolioCompressionTradesWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PORTFOLIO_COMPRESSION_TRADES_XPATH, xmlDocument)).thenReturn("YES");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setPortfolioCompressionTrades();
		Assert.assertEquals("YES", entity.info.get(PORTFOLIO_COMPRESSION_TRADES));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetProductDeliveryTypeTradeReportAndContractMultiplierWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PRODUCT_DELIVERY_TYPE_XPATH, xmlDocument)).thenReturn("COURIER");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, REPORT_STATUS_XPATH, xmlDocument)).thenReturn("ACTIVE");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, CONTRACT_MULTIPLIER_XPATH, xmlDocument)).thenReturn("200.21");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.setProductDeliveryType();
		mockedAbstractCitiMLToEntityMapper.setTradeReportTransType();
		mockedAbstractCitiMLToEntityMapper.setContractMultiplier();
		Assert.assertEquals("COURIER", entity.info.get(PRODUCT_DELIVERY_TYPE));
		Assert.assertEquals("ACTIVE", entity.info.get(TRADE_REPORT_TRANS_TYPE));
		Assert.assertEquals(new BigDecimal("200.21"), entity.info.get(CONTRACT_MULTIPLIER));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldgetPublishedTimeStamphenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PUBLISH_TS_XPATH, xmlDocument)).thenReturn("2017-06-09T22:02:41Z");
		Assert.assertEquals(LocalDateTime.parse("2017-06-09T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME), mockedAbstractCitiMLToEntityMapper.getPublishedTimeStamp());
		
	}
	
	@Test
	public void shouldNotgetPublishedTimeStamphenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PUBLISH_TS_XPATH, xmlDocument)).thenReturn(null);
		Assert.assertNull(mockedAbstractCitiMLToEntityMapper.getPublishedTimeStamp());
		
	}
	
	@Test
	public void shouldpopulateEntityFlagListWhenInvoked() throws XPathExpressionException {
		
		entity.flags = new ArrayList<String>();
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PUBLISH_TS_XPATH, xmlDocument)).thenReturn("2017-06-09T22:02:41Z");
		mockedAbstractCitiMLToEntityMapper.populateEntityFlagList("PNDG");
		Assert.assertEquals("PNDG", entity.flags.get(0));
		entity.flags.clear();
		
	}
	
	@Test
	public void shouldpopulateMandatoryFeildsInEntityObjectWhenInvoked() throws XPathExpressionException {
		
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, PUBLISH_TS_XPATH, xmlDocument)).thenReturn("2017-06-09T22:02:41Z");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, SOURCE_SYSTEM_XPATH, xmlDocument)).thenReturn("OPENLINK_NAM");
		Mockito.when(xPathUtilInstance.getNodeValueFromXpathExpression(xPath, SOURCE_UNIQUE_ID_XPATH, xmlDocument)).thenReturn("OP12345");
		entity.info = infoMocked;
		mockedAbstractCitiMLToEntityMapper.populateMandatoryFeildsInEntityObject();
		Assert.assertEquals(LocalDateTime.parse("2017-06-09T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME), entity.publishedTs);
		Assert.assertEquals(EntityStatus.REPORTABLE, entity.status);
		Assert.assertEquals("m2post", entity.stream);
		Assert.assertEquals("com", entity.flow);
		Assert.assertEquals("OPENLINK_NAM", entity.sourceSystem);
		
	}
}
