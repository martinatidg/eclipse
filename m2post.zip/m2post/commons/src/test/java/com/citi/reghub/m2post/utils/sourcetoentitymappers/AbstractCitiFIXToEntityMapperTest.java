package com.citi.reghub.m2post.utils.sourcetoentitymappers;


import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;
import static com.citi.reghub.m2post.utils.constants.M2PostConstants.TIMEZONE_UTC_1;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.citi.qfix.SrcSystemID;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;
import com.citigroup.get.zcc.intf.AccountGrp;
import com.citigroup.get.zcc.intf.LastCapacity;
import com.citigroup.get.zcc.intf.MOTradeMessage;
import com.citigroup.get.zcc.intf.PriceType;
import com.citigroup.get.zcc.intf.ReportToExch;
import com.citigroup.get.zcc.intf.SecurityIDSource;
import com.citigroup.get.zcc.intf.Side;
import com.citigroup.get.zcc.intf.TradeExecType;
import com.citigroup.get.zcc.intf.TradeStatus;
import com.citigroup.get.zcc.intf.TradeSubType;

@RunWith(MockitoJUnitRunner.class)
public class AbstractCitiFIXToEntityMapperTest {
	
	@Mock
	Entity entity = new Entity();
	@Mock
	AccountGrp grp;
	
	
	@Mock
	MOTradeMessage citifixTrade;
	
	HashMap<String, Object> infoMocked = new HashMap<String, Object>();
	
	String flow = "cshfi";
	String stream = "m2post";
	
	@SuppressWarnings("serial")
	@InjectMocks
	AbstractCitiFIXToEntityMapper mockedAbstractCitiFIXToEntityMapper = Mockito.spy(new AbstractCitiFIXToEntityMapper(stream, flow){
		
	});
	
	@Test
	public void shouldPopulateMandatoryFieldsWhenInvoked() {
		
		Mockito.when(citifixTrade.getTradeID()).thenReturn("TRD123");
		Mockito.when(citifixTrade.getZTradeVersion()).thenReturn(1);
		Mockito.when(citifixTrade.getRIOTransactTime()).thenReturn(ZonedDateTime.of(2017, 3, 21, 23, 45, 59, 1234, ZoneId.of(TIMEZONE_UTC_1)));
		Mockito.when(citifixTrade.getTransactTime()).thenReturn(ZonedDateTime.of(2017, 3, 21, 23, 45, 59, 1234, ZoneId.of(TIMEZONE_UTC_1)));
		Mockito.when(citifixTrade.getSrcSystemID()).thenReturn(SrcSystemID.AGAES_SRCSYS_ID);
		mockedAbstractCitiFIXToEntityMapper.populateMandatoryEntityAttributesFromInputFixMessage(entity, citifixTrade);
		
		Assert.assertEquals(EntityStatus.REPORTABLE, entity.status);
		Assert.assertEquals(flow, entity.flow);
		Assert.assertEquals(stream, entity.stream);
		Assert.assertEquals("TRD123", entity.sourceId);
	}
	
	@Test
	public void shouldPopulateSymbolsFxWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(65)).thenReturn("SYMBOLSFX");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSymbolsFx(entity, citifixTrade);
		Assert.assertEquals("SYMBOLSFX", entity.info.get(SYMBOLS_FX));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSecurityExchangeWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(207)).thenReturn("NSE");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSecurityExchange(entity, citifixTrade);
		Assert.assertEquals("NSE", entity.info.get(SECURITY_EXCHANGE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetCrossIdWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(548)).thenReturn("ID123");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setCrossId(entity, citifixTrade);
		Assert.assertEquals("ID123", entity.info.get(CROSS_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetRelatedmarketCenterWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(9277)).thenReturn("R_MKT");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setRelatedmarketCenter(entity, citifixTrade);
		Assert.assertEquals("R_MKT", entity.info.get(RELATED_MARKET_CENTER));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOverrrideFlagWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(9854)).thenReturn("Y");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOverrrideFlag(entity, citifixTrade);
		Assert.assertEquals("Y", entity.info.get(OVERRIDE_FLAG));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExecutedByWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(10021)).thenReturn("REGHUB");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExecutedBy(entity, citifixTrade);
		Assert.assertEquals("REGHUB", entity.info.get(EXECUTED_BY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSalesPersonIdWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(10036)).thenReturn("SP123");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSalesPersonId(entity, citifixTrade);
		Assert.assertEquals("SP123", entity.info.get(SALES_PERSON_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetAvgPriceAcctWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(10051)).thenReturn("SP123");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setAvgPriceAcct(entity, citifixTrade);
		Assert.assertEquals("SP123", entity.info.get(AVG_PRICE_ACCT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExecCommentsWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(10076)).thenReturn("COMMENTS");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExecComments(entity, citifixTrade);
		Assert.assertEquals("COMMENTS", entity.info.get(EXEC_COMMENTS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNoTempContraBrokersWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(10533)).thenReturn("123");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setNoTempContraBrokers(entity, citifixTrade);
		Assert.assertEquals("123", entity.info.get(NOTEMPCONTRABROKERS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetContraBrokersWhenInvoked() {
		
		Mockito.when(citifixTrade.getTag(375)).thenReturn("C_BROKER");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setContraBrokers(entity, citifixTrade);
		Assert.assertEquals("C_BROKER", entity.info.get(CONTRA_BROKER));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetNoOfContarBrokersWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTag(382)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setNoOfContarBrokers(entity, citifixTrade);
		Assert.assertNull(entity.info.get(NO_CONTRA_BROKERS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNoOfContarBrokersWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(382)).thenReturn("1");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setNoOfContarBrokers(entity, citifixTrade);
		Assert.assertEquals(1, entity.info.get(NO_CONTRA_BROKERS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOrdStatusWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(39)).thenReturn("ACTIVE");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOrdStatus(entity, citifixTrade);
		Assert.assertEquals("ACTIVE", entity.info.get(ORD_STATUS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetContraAccountWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(10514)).thenReturn("ACC123");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setContraAccount(entity, citifixTrade);
		Assert.assertEquals("ACC123", entity.info.get(CONTRA_ACCOUNT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetBargainConditionsWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(11303)).thenReturn("BARGAIN_CONDITION");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setBargainConditions(entity, citifixTrade);
		Assert.assertEquals("BARGAIN_CONDITION", entity.info.get(BARGAIN_CONDITIONS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradingAcctWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(10050)).thenReturn("TRD1234");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradingAcct(entity, citifixTrade);
		Assert.assertEquals("TRD1234", entity.info.get(TRADING_ACCT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOrderIdButNnotSourceIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(37)).thenReturn("ORD1234");
		entity.info = infoMocked;
		entity.sourceId = "SRC1234";
		mockedAbstractCitiFIXToEntityMapper.setOrderId(entity, citifixTrade);
		Assert.assertEquals("ORD1234", entity.info.get(ORDER_ID));
		Assert.assertEquals("SRC1234", entity.sourceId);
		entity.info.clear();
		entity.sourceId = null;
		
	}
	
	@Test
	public void shouldsetOrderIdAndSourceIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(37)).thenReturn("ORD1234");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOrderId(entity, citifixTrade);
		Assert.assertEquals("ORD1234", entity.info.get(ORDER_ID));
		Assert.assertEquals("ORD1234", entity.sourceId);
		entity.info.clear();
		entity.sourceId = null;
		
	}
	
	@Test
	public void shouldNotsetOrderIdAndSourceIdWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTag(37)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOrderId(entity, citifixTrade);
		Assert.assertNull(entity.info.get(ORDER_ID));
		Assert.assertNull(entity.sourceId);
		entity.info.clear();
		entity.sourceId = null;
		
	}
	
	@Test
	public void shouldNotsetOrderIdAndSourceIdWhenLowerServiceReturnsEmpty() {
		
		Mockito.when(citifixTrade.getTag(37)).thenReturn("");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOrderId(entity, citifixTrade);
		Assert.assertNull(entity.info.get(ORDER_ID));
		Assert.assertNull(entity.sourceId);
		entity.info.clear();
		entity.sourceId = null;
		
	}
	
	@Test
	public void shouldsetOrderCapacityWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(528)).thenReturn("100");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOrderCapacity(entity, citifixTrade);
		Assert.assertEquals("100", entity.info.get(ORDER_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExecIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(17)).thenReturn("1001");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExecId(entity, citifixTrade);
		Assert.assertEquals("1001", entity.info.get(EXEC_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExecLinkIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(11049)).thenReturn("LINKID");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExecLinkId(entity, citifixTrade);
		Assert.assertEquals("LINKID", entity.info.get(EXEC_LINK_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExDestinationWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(100)).thenReturn("EX_dEST");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExDestination(entity, citifixTrade);
		Assert.assertEquals("EX_dEST", entity.info.get(EX_DESTINATION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExecTypeWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(150)).thenReturn("TYPE");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExecType(entity, citifixTrade);
		Assert.assertEquals("TYPE", entity.info.get(EXEC_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetCloRdIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(11)).thenReturn("CLORDID");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setCloRdId(entity, citifixTrade);
		Assert.assertEquals("CLORDID", entity.info.get(CLO_RD_ID));
		entity.info.clear();
		
	}

	@Test
	public void shouldNotsetAcceptedTimeStampWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTag(11015)).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setAcceptedTimeStamp(entity, citifixTrade);
		Assert.assertNull(entity.info.get(ACCEPTED_TIMESTAMP));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetAcceptedTimeStampWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTag(11015)).thenReturn("20170609-22:02:41");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setAcceptedTimeStamp(entity, citifixTrade);
		Assert.assertEquals(LocalDate.parse("2017-06-09"), entity.info.get(ACCEPTED_TIMESTAMP));
		entity.info.clear();
		
	}
	
	@Test(expected = RuntimeException.class)
	public void shouldNotsetAcceptedTimeStampAndThrowParExceptionWhenLowerServiceReturnsIncorrectDate() {
		
		Mockito.when(citifixTrade.getTag(11015)).thenReturn("201706-09-27T:02:41Z");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setAcceptedTimeStamp(entity, citifixTrade);
		
	}
	
	@Test
	public void shouldsetQtyWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getQuantity()).thenReturn(200.21);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setQty(entity, citifixTrade);
		Assert.assertEquals(200.21, entity.info.get(QTY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetYieldWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getYield()).thenReturn(200.21);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setYield(entity, citifixTrade);
		Assert.assertEquals(200.21, entity.info.get(YIELD));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPreviousSrcSystemIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getPreviousSrcSystemID()).thenReturn(21);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setPreviousSrcSystemId(entity, citifixTrade);
		Assert.assertEquals(21, entity.info.get(PREV_SRC_SYS_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetNoOfAccntsWhenLowerServiceReturnsValue() {
		
		AccountGrp[] grpArray =new AccountGrp[1];
		grpArray[0] = grp;
		
		Mockito.when(citifixTrade.getAccountGrp()).thenReturn(grpArray);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setNoOfAccnts(entity, citifixTrade);
		Assert.assertEquals(1, entity.info.get(NO_ACCOUNTS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetNoOfAccntsWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getAccountGrp()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setNoOfAccnts(entity, citifixTrade);
		Assert.assertNull(entity.info.get(NO_ACCOUNTS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSenderSubIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSenderSubID()).thenReturn("SENDERID");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSenderSubId(entity, citifixTrade);
		Assert.assertEquals("SENDERID", entity.info.get(SENDER_SUB_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetReportToExchWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getReportToExch()).thenReturn(ReportToExch.BOOKING);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setReportToExch(entity, citifixTrade);
		Assert.assertEquals("BOOKING", entity.info.get(REPORT_TO_EXCH));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetReportToExchWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getReportToExch()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setReportToExch(entity, citifixTrade);
		Assert.assertNull(entity.info.get(REPORT_TO_EXCH));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldgetSettlCurrencyWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSettlCurrency()).thenReturn("INR");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSetlCurrency(entity, citifixTrade);
		Assert.assertEquals("INR", entity.info.get(SETTL_CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetClearingAccountWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getClearingAccount()).thenReturn("CLRACT123");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setClearingAccount(entity, citifixTrade);
		Assert.assertEquals("CLRACT123", entity.info.get(CLEARING_ACCOUNT));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetCurrencyWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getCurrency()).thenReturn("USD");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setCurrency(entity, citifixTrade);
		Assert.assertEquals("USD", entity.info.get(CURRENCY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetOrderQtyWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getOrderQty()).thenReturn(200.00);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setOrderQty(entity, citifixTrade);
		Assert.assertEquals(200.00, entity.info.get(ORDER_QTY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeStatusWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTradeStatus()).thenReturn(TradeStatus.New);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeStatus(entity, citifixTrade);
		Assert.assertEquals("New", entity.info.get(TRADE_STATUS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeStatusWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTradeStatus()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeStatus(entity, citifixTrade);
		Assert.assertNull(entity.info.get(TRADE_STATUS));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeExecTypeWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTradeExecType()).thenReturn(TradeExecType.New);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeExecType(entity, citifixTrade);
		Assert.assertEquals("New", entity.info.get(TRADE_EXEC_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeExecTypeWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTradeExecType()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeExecType(entity, citifixTrade);
		Assert.assertNull(entity.info.get(TRADE_EXEC_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeSubTypeWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTradeSubType()).thenReturn(TradeSubType.ALLOC);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeSubType(entity, citifixTrade);
		Assert.assertEquals("ALLOC", entity.info.get(TRADE_SUB_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeSubTypeWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTradeSubType()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeSubType(entity, citifixTrade);
		Assert.assertNull(entity.info.get(TRADE_SUB_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeDateWhenLowerServiceReturnsValue() {
		Mockito.when(citifixTrade.getTradeDate()).thenReturn(ZonedDateTime.of(2017, 3, 21, 0, 0, 0, 0, ZoneId.of(TIMEZONE_UTC_1)));
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeDate(entity, citifixTrade);
		Assert.assertEquals(LocalDateTime.ofInstant(citifixTrade.getTradeDate().toInstant(), ZoneId.systemDefault()).toLocalDate(),entity.info.get(TRADE_DATE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTradeDateWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getTradeDate()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTradeDate(entity, citifixTrade);
		Assert.assertNull(entity.info.get(TRADE_DATE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceTypeWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getPriceType()).thenReturn(PriceType.PREMIUM);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setPriceType(entity, citifixTrade);
		Assert.assertEquals("PREMIUM", entity.info.get(PRICE_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceTypeWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getPriceType()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setPriceType(entity, citifixTrade);
		Assert.assertNull(entity.info.get(PRICE_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetPriceWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getPrice()).thenReturn(200.21);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setPrice(entity, citifixTrade);
		Assert.assertEquals(200.21, entity.info.get(PRICE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastMktWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getLastMkt()).thenReturn("NYSE");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setLastMkt(entity, citifixTrade);
		Assert.assertEquals("NYSE", entity.info.get(VENUE_OF_EXECUTION));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSideWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSide()).thenReturn(Side.BUY);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSide(entity, citifixTrade);
		Assert.assertEquals("BUY", entity.info.get(BUY_SELL_IND));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSideWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getSide()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSide(entity, citifixTrade);
		Assert.assertNull(entity.info.get(SIDE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetInstrIdentCodeTypeWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSecurityIDSource()).thenReturn(SecurityIDSource.ISIN);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setInstrIdentCodeType(entity, citifixTrade);
		Assert.assertEquals("ISIN", entity.info.get(INSTR_IDENT_CODE_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetInstrIdentCodeTypeWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getSecurityIDSource()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSide(entity, citifixTrade);
		Assert.assertNull(entity.info.get(INSTR_IDENT_CODE_TYPE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetInstrIdentCodeWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSecurityID()).thenReturn("US2345654321");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setInstrIdentCode(entity, citifixTrade);
		Assert.assertEquals("US2345654321", entity.info.get(INSTR_IDENT_CODE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSrcSystemIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSrcSystemID()).thenReturn(SrcSystemID.AES_SRC_ID);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSrcSystemId(entity, citifixTrade);
		Assert.assertEquals("AES_SRC_ID", entity.info.get(SRC_SYSTEM_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSrcSystemIdWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getSrcSystemID()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSrcSystemId(entity, citifixTrade);
		Assert.assertNull(entity.info.get(SRC_SYSTEM_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSymbolWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSymbol()).thenReturn("Symbol");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSymbol(entity, citifixTrade);
		Assert.assertEquals("Symbol", entity.info.get(SYMBOL));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastCapacityWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getLastCapacity()).thenReturn(LastCapacity.C);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setLastCapacity(entity, citifixTrade);
		Assert.assertEquals("6", entity.info.get(TRADE_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastCapacityWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getLastCapacity()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setLastCapacity(entity, citifixTrade);
		Assert.assertNull(entity.info.get(LAST_CAPACITY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetTargetSubIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getTargetSubID()).thenReturn("TaregtSubId");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setTargetSubId(entity, citifixTrade);
		Assert.assertEquals("TaregtSubId", entity.info.get(TARGET_SUB_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetSetlDateWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getSettlDate()).thenReturn(ZonedDateTime.of(2017, 3, 21, 0, 0, 0, 0, ZoneId.of(TIMEZONE_UTC_1)));
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setSetlDate(entity, citifixTrade);
		Assert.assertEquals(LocalDateTime.ofInstant(citifixTrade.getSettlDate().toInstant(), ZoneId.systemDefault()).toLocalDate(),entity.info.get(SETTL_DATE));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastQtyWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getLastQty()).thenReturn(123.21);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setLastQty(entity, citifixTrade);
		Assert.assertEquals(123.21, entity.info.get(LAST_QTY));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetLastPxWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getLastPx()).thenReturn(123.21);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setLastPx(entity, citifixTrade);
		Assert.assertEquals(123.21, entity.info.get(LAST_PX));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetExecRefIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getExecRefID()).thenReturn("ExecRefId");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setExecRefId(entity, citifixTrade);
		Assert.assertEquals("ExecRefId", entity.info.get(EXEC_REF_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldsetZExecIdWhenLowerServiceReturnsValue() {
		
		Mockito.when(citifixTrade.getZExecID()).thenReturn("ZExecRefId");
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setZExecId(entity, citifixTrade);
		Assert.assertEquals("ZExecRefId", entity.info.get(Z_EXEC_ID));
		entity.info.clear();
		
	}
	
	@Test
	public void shouldNotsetZExecIdWhenLowerServiceReturnsNull() {
		
		Mockito.when(citifixTrade.getZExecID()).thenReturn(null);
		entity.info = infoMocked;
		mockedAbstractCitiFIXToEntityMapper.setZExecId(entity, citifixTrade);
		Assert.assertNull(entity.info.get(Z_EXEC_ID));
		entity.info.clear();
		
	}
	
}
