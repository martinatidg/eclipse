package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class NoTrdRegPublicationsTest {

	private final NoTrdRegPublications classUndertest = new NoTrdRegPublications();
	private final NoTrdRegPublications classUndertest2 = new NoTrdRegPublications(100);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2668, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(100), (Integer)classUndertest2.getObject());
	}
}
