package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class NoPublicationRequiredTest {

	private final NoPublicationRequired classUndertest = new NoPublicationRequired();
	private final NoPublicationRequired classUndertest2 = new NoPublicationRequired('Y');
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25003, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Character('Y'), (Character)classUndertest2.getObject());
	}
}
