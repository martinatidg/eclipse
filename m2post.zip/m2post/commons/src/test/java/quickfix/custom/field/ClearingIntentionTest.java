package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ClearingIntentionTest {

	private final ClearingIntention classUndertest = new ClearingIntention();
	private final ClearingIntention classUndertest2 = new ClearingIntention('Y');
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(1924, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Character('Y'), (Character)classUndertest2.getObject());
	}
}
