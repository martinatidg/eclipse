package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PackageIDTest {

	private final PackageID classUndertest = new PackageID();
	private final PackageID classUndertest2 = new PackageID("USD");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2489, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("USD", classUndertest2.getObject());
	}
}
