package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TrdRegPublicationReasonsTest {

	private final TrdRegPublicationReasons classUndertest = new TrdRegPublicationReasons();
	private final TrdRegPublicationReasons classUndertest2 = new TrdRegPublicationReasons(200);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(8013, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(200), (Integer)classUndertest2.getObject());
	}
}
