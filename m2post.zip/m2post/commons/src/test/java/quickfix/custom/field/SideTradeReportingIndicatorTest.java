package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SideTradeReportingIndicatorTest {

	private final SideTradeReportingIndicator classUndertest = new SideTradeReportingIndicator();
	private final SideTradeReportingIndicator classUndertest2 = new SideTradeReportingIndicator(200);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2671, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(200), (Integer)classUndertest2.getObject());
	}
}
