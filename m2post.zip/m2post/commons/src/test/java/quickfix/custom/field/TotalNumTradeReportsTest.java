package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TotalNumTradeReportsTest {

	private final TotalNumTradeReports classUndertest = new TotalNumTradeReports();
	private final TotalNumTradeReports classUndertest2 = new TotalNumTradeReports("APA");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(748, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("APA", classUndertest2.getObject());
	}
}
