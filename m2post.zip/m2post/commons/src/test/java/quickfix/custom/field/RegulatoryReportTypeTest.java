package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RegulatoryReportTypeTest {

	private final RegulatoryReportType classUndertest = new RegulatoryReportType();
	private final RegulatoryReportType classUndertest2 = new RegulatoryReportType("USD");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(1934, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("USD", classUndertest2.getObject());
	}
}
