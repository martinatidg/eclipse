package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TrdRegPublicationReasonTest {

	private final TrdRegPublicationReason classUndertest = new TrdRegPublicationReason();
	private final TrdRegPublicationReason classUndertest2 = new TrdRegPublicationReason(200);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2670, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(200), (Integer)classUndertest2.getObject());
	}
}
