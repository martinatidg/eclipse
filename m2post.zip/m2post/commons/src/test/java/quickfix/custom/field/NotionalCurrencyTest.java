package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class NotionalCurrencyTest {

	private final NotionalCurrency classUndertest = new NotionalCurrency();
	private final NotionalCurrency classUndertest2 = new NotionalCurrency("USD");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25015, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("USD", classUndertest2.getObject());
	}
}
