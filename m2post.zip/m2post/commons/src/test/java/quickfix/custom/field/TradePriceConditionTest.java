package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TradePriceConditionTest {

	private final TradePriceCondition classUndertest = new TradePriceCondition();
	private final TradePriceCondition classUndertest2 = new TradePriceCondition("APA");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(1839, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("APA", classUndertest2.getObject());
	}
}
