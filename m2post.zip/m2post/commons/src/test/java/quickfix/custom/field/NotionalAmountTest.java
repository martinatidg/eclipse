package quickfix.custom.field;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class NotionalAmountTest {

	private final NotionalAmount classUndertest = new NotionalAmount();
	private final NotionalAmount classUndertest2 = new NotionalAmount(new BigDecimal(200.2));
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25014, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new BigDecimal(200.2), (BigDecimal)classUndertest2.getObject());
	}
}
