package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class EmissionAllowanceTypeTest {

	private final EmissionAllowanceType classUndertest = new EmissionAllowanceType();
	private final EmissionAllowanceType classUndertest2 = new EmissionAllowanceType("Yes");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25015, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("Yes", classUndertest2.getObject());
	}
}
