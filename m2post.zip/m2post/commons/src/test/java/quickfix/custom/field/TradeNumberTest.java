package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TradeNumberTest {

	private final TradeNumber classUndertest = new TradeNumber();
	private final TradeNumber classUndertest2 = new TradeNumber("APA");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2890, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("APA", classUndertest2.getObject());
	}
}
