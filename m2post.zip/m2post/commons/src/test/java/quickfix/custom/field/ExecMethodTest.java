package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ExecMethodTest {

	private final ExecMethod classUndertest = new ExecMethod();
	private final ExecMethod classUndertest2 = new ExecMethod(200);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2405, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(200), (Integer)classUndertest2.getObject());
	}
}
