package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TargetAPATest {

	private final TargetAPA classUndertest = new TargetAPA();
	private final TargetAPA classUndertest2 = new TargetAPA("APA");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25011, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("APA", classUndertest2.getObject());
	}
}
