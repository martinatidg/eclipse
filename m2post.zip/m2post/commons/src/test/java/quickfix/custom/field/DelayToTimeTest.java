package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class DelayToTimeTest {

	private final DelayToTime classUndertest = new DelayToTime();
	private final DelayToTime classUndertest2 = new DelayToTime("Yes");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(7552, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("Yes", classUndertest2.getObject());
	}
}
