package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ExemptTransactionCodeTest {

	private final ExemptTransactionCode classUndertest = new ExemptTransactionCode();
	private final ExemptTransactionCode classUndertest2 = new ExemptTransactionCode("Yes");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25013, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("Yes", classUndertest2.getObject());
	}
}
