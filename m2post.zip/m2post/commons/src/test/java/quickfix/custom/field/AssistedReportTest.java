package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AssistedReportTest {

	private final AssistedReport classUndertest = new AssistedReport();
	private final AssistedReport classUndertest2 = new AssistedReport('A');
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25018, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Character('A'), (Character)classUndertest2.getObject());
	}
}
