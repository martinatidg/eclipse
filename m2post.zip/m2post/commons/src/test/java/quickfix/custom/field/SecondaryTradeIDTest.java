package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SecondaryTradeIDTest {

	private final SecondaryTradeID classUndertest = new SecondaryTradeID();
	private final SecondaryTradeID classUndertest2 = new SecondaryTradeID("USD");
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(7562, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals("USD", classUndertest2.getObject());
	}
}
