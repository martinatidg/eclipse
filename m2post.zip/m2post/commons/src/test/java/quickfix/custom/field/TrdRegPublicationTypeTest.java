package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TrdRegPublicationTypeTest {

	private final TrdRegPublicationType classUndertest = new TrdRegPublicationType();
	private final TrdRegPublicationType classUndertest2 = new TrdRegPublicationType(200);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2669, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(200), (Integer)classUndertest2.getObject());
	}
}
