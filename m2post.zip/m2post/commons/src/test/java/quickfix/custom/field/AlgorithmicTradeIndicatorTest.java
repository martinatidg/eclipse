package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AlgorithmicTradeIndicatorTest {

	private final AlgorithmicTradeIndicator classUndertest = new AlgorithmicTradeIndicator();
	private final AlgorithmicTradeIndicator classUndertest2 = new AlgorithmicTradeIndicator(200);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(2667, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(200), (Integer)classUndertest2.getObject());
	}
}
