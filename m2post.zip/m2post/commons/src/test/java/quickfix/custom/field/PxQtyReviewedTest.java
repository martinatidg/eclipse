package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PxQtyReviewedTest {

	private final PxQtyReviewed classUndertest = new PxQtyReviewed();
	private final PxQtyReviewed classUndertest2 = new PxQtyReviewed('A');
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(7596, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Character('A'), (Character)classUndertest2.getObject());
	}
}
