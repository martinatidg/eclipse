package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class NoTradePriceConditionsTest {

	private final NoTradePriceConditions classUndertest = new NoTradePriceConditions();
	private final NoTradePriceConditions classUndertest2 = new NoTradePriceConditions(100);
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(1838, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Integer(100), (Integer)classUndertest2.getObject());
	}
}
