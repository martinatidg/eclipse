package quickfix.custom.field;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ClientOrderTradeTest {

	private final ClientOrderTrade classUndertest = new ClientOrderTrade();
	private final ClientOrderTrade classUndertest2 = new ClientOrderTrade('Y');
	
	@Test
	public void shouldReturnFeildWhenInvoked(){
		Assert.assertEquals(25016, classUndertest.getField());
	}
	
	@Test
	public void shouldReturnDaatObjectWhenInvoked(){
		Assert.assertEquals(new Character('Y'), (Character)classUndertest2.getObject());
	}
}
