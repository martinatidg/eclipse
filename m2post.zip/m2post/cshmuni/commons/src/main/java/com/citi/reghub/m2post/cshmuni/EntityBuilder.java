package com.citi.reghub.m2post.cshmuni;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.citi.reghub.core.Entity;

public class EntityBuilder {
	
	private Entity entity;
	
	public EntityBuilder(){
		this.entity = new Entity();
		//entity.sourceStatus="Replaced";
		entity.sourceId="82125996";
		entity.status="REPORTABLE";
		entity.stream="M2PO";
		entity.flow="MUNIDERV";
		entity.sourceVersion="3";
		entity.sourceSystem="TPS";
		entity.info.put("tradeSubType","TRADE");
		entity.info.put("quantity",Double.valueOf(5000000.0));
		entity.info.put("cptyAccountmnemonicAccountType","ACCOUNTCUSTOMER");
		entity.info.put("priceType", "PCT");
		entity.info.put("cptyAccountmnemonicAlternateGfc", "1013098812");
		entity.info.put("securityId", "74830A9G5");
		entity.info.put("cptyAccountmnemonicNoAltAccounts", 1);
		entity.info.put("bookAccountmnemonicAccountType", "FIRM");
		entity.info.put("tradeDate", LocalDate.of(2016, 1, 7));
		entity.info.put("settlementDate", LocalDate.of(2016, 1, 13));
		entity.info.put("bookAccountmnemonicAlternateGfc", "1000464046");
		entity.info.put("securitySmcp", "35897404");
		entity.info.put("tradeExecType", "PendingReplace");
		entity.info.put("bookAccountmnemonicNoAltAccounts", 1);
		entity.info.put("lastMkt", "LUX");
		entity.info.put("noAccounts", 2);
		entity.info.put("price", Double.valueOf(119.759));
		entity.info.put("securityIdSource", "CUSIP");
		entity.info.put("yield", Double.valueOf(3.09500574));
		entity.info.put("previousSrcSystemId", 150699);
		entity.info.put("orderQty", Double.valueOf(5000000.0));
		entity.info.put("cptyAccountmnemonic", "TMDRES");
		entity.info.put("bookAccountmnemonic", "SIGJNB");
		entity.info.put("side", "SELL");
		entity.info.put("tradeStatus", "Replaced");
		entity.regHubId=entity.stream+entity.flow+"123456";
		entity.executionTs=LocalDateTime.parse("2016-01-07 06:38:07", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		entity.publishedTs=LocalDateTime.parse("2016-01-07 06:41:38.205", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
		entity.receivedTs=LocalDateTime.now();
		entity.generateRegReportingRef();
	}
	
	public EntityBuilder regHubId(String reghubId){
		entity.regHubId = reghubId;
		return this;
	}
	
	public EntityBuilder sourceStatus(String sourceStatus){
		entity.sourceStatus = sourceStatus;
		return this;
	}
	
	public EntityBuilder sourceId(String sourceId){
		entity.sourceId = sourceId;
		return this;
	}
	
	public EntityBuilder sourceUid(String sourceUid){
		entity.sourceUId = sourceUid;
		return this;
	}
	
	public EntityBuilder executionTs(LocalDateTime executionTs){
		entity.executionTs = executionTs;
		return this;
	}
	
	public EntityBuilder publishedTs(LocalDateTime publishedTs){
		entity.publishedTs = publishedTs;
		return this;
	}
	
	public EntityBuilder receivedTs(LocalDateTime receivedTs){
		entity.receivedTs = receivedTs;
		return this;
	}
	
	public EntityBuilder sourceVersion(String sourceVersion){
		entity.sourceVersion = sourceVersion;
		return this;
	}
	
	public EntityBuilder info(String key,Object value){
		entity.info.put(key, value);
		return this;
	}
	
	public Entity build(){
		return entity;
	}

}
