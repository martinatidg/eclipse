package com.citi.reghub.m2post.cshmuni;

public class CshMuniRespConsConstants {

	
	public static final String TOPOLGY_NAME = "topology.name";
	public static final String TOPOLOGY_STREAM_NAME = "topolgy.stream.name";
	public static final String KAFKA_TOPIC_NAMES = "kafka.input.topic.names";
	
	public static final String PARTIAL_ENTITY_TOPIC_NAME = "partialUpdateBolt.kafka.topic.names";
	
	public static final String PARTIAL_RAW_OUTBOUND_TOPIC_NAME = "partialRawOutgoingBolt.kafka.topic.names";

	public static final String AUDIT_LOG_TOPIC="auditBolt.kafka.topic.names";

	

}