package com.citi.reghub.m2post.cshmuni;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.citi.reghub.core.Entity;
import com.esotericsoftware.minlog.Log;

public class SimpleConsumer {

	public static void main(String[] args) {
		String topicName = "m2post_muniderv_exception";
		Properties props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("group.id", "testFileMongo");
		props.put("enable.auto.commit", "true");
		props.put("auto.commit.interval.ms", "1000");
		props.put("session.timeout.ms", "30000");
		props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		props.put("value.deserializer",
				"com.citi.reghub.core.EntityKafkaSerializerDeserializer");

		KafkaConsumer<String, Entity> consumer = new KafkaConsumer<>(props);
		consumer.subscribe(Arrays.asList(topicName));
		while (true) {
			ConsumerRecords<String, Entity> records = consumer.poll(100);
			for (ConsumerRecord<String, Entity> record : records) {
				Log.info("----"+record.value().toString());

			}
		}

	}

}
