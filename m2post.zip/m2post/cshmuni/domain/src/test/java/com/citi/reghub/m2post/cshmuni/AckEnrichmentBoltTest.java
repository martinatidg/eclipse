package com.citi.reghub.m2post.cshmuni;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.cshmuni.AckEnrichmentBolt;

@RunWith(JUnit4.class)
public class AckEnrichmentBoltTest {
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	private AckEnrichmentBolt bolt;

	@Before
	public void setUp() throws Exception {
		bolt = new AckEnrichmentBolt();
		
	}

	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}

	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		AckEnrichmentBolt bolt = new AckEnrichmentBolt();
		bolt.declareOutputFields(declarer);
		verify(declarer, times(3)).declareStream(any(String.class), any(Fields.class));
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitInputTuple() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));

	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitReportableAndAuditStreamTest() {
		Entity trade = new EntityBuilder().regHubId("1").sourceStatus("NEW").info("tradeDate", LocalDate.now()).build();

		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitReportableStreamTest() {
		Entity trade = new EntityBuilder().sourceId("source1").flow("csheq").stream("m2tr").sourceStatus("AMEND").build();
		Tuple tuple = mockNormalTuple(trade);
		RawOutboundRecord record=new RawOutboundRecord();
		record.ackId="1234";
		Map stormConf = mock(Map.class);
		Map topologyConfig=mock(Map.class);
		when(topologyConfig.get("raw.outbound.service.url")).thenReturn("localhost:8135/{0}?stream={1}&flow={2}");
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.restClient=mock(RestClient.class);
 		when((bolt.restClient).get("localhost:8135/source1?stream=m2tr&flow=csheq", RawOutboundRecord.class)).thenReturn(record);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));

	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitExceptionStreamTest1() {
		Entity trade = new EntityBuilder().sourceId("source1").flow("csheq").stream("m2tr").sourceStatus("AMEND").build();
		Tuple tuple = mockNormalTuple(trade);
		RawOutboundRecord record=new RawOutboundRecord();
		record.ackId=null;
		Map stormConf = mock(Map.class);
		Map topologyConfig=mock(Map.class);
		when(topologyConfig.get("raw.outbound.service.url")).thenReturn("localhost:8135/{0}?stream={1}&flow={2}");
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.restClient=mock(RestClient.class);
 		when((bolt.restClient).get("localhost:8135/source1?stream=m2tr&flow=csheq", RawOutboundRecord.class)).thenReturn(record);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.EXCEPTION, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));

	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitExceptionStreamTest2() {
		Entity trade = new EntityBuilder().sourceId("source1").flow("csheq").stream("m2tr").sourceStatus("AMEND").build();
		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		Map topologyConfig=mock(Map.class);
		when(topologyConfig.get("raw.outbound.service.url")).thenReturn("localhost:8135/{0}?stream={1}&flow={2}");
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(topologyConfig);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.restClient=mock(RestClient.class);
 		when((bolt.restClient).get("localhost:8135/source1?stream=m2tr&flow=csheq", RawOutboundRecord.class)).thenReturn(null);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(_collector).emit(StormStreams.EXCEPTION, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));

	}
}
