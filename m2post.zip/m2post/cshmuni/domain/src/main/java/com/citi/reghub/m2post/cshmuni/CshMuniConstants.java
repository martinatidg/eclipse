package com.citi.reghub.m2post.cshmuni;

public class CshMuniConstants {
	
	public static final String KAFKA_TOPIC_NAMES = "kafka.input.topic.names";
	public static final String TOPOLOGY_STREAM_NAME = "topolgy.stream.name";
	
	public static final String KAFKA_REPORTABLE_BOLT_NAMES = "reportable-bolt";
	public static final String KAFKA_NON_REPORTABLE_BOLT_NAMES = "non-reportable-bolt";
	public static final String KAFKA_EXCEPTION_BOLT_NAMES = "exception-bolt";
	public static final String KAFKA_AUDIT_BOLT_NAMES = "audit-bolt";
	
	public static final String KAFKA_REPORTABLE_TOPIC_NAMES = KAFKA_REPORTABLE_BOLT_NAMES+".kafka.topic.names";
	public static final String KAFKA_NON_REPORTABLE_TOPIC_NAMES = KAFKA_NON_REPORTABLE_BOLT_NAMES+".kafka.topic.names";
	public static final String KAFKA_EXCEPTION_TOPIC_NAMES = KAFKA_EXCEPTION_BOLT_NAMES+".kafka.topic.names";
	public static final String KAFKA_AUDIT_TOPIC_NAMES = KAFKA_AUDIT_BOLT_NAMES+".kafka.topic.names";
	
	public static final String PRE_ELIGIBILITY_RULE_GRAPH = "m2post_cshfi_eligibility_check";
	public static final String ENRICHMENT_PLAN_NAME = "m2tr-enrichment-plan";
	public static final String POST_ENRICHMENT_ELIGIBILITY_RULE_GRAPH = "m2post-post-enrichment-eligibility-check";
	public static final String POST_ENRICHMENT_BIZ_EXCEPTION_RULE_GRAPH = "m2post-post-enrichment-biz-exception-check";
	public static final String POST_ENRICHMENT_TECH_EXCEPTION_RULE_GRAPH = "m2post-post-enrichment-tech-exception-check";
	
	public static final String RAW_OUTBOUND_SERVICE_URL="raw.outbound.service.url";
}
