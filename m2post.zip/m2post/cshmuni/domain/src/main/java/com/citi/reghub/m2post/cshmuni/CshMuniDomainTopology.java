package com.citi.reghub.m2post.cshmuni;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.storm.commons.BaseTopology;
import com.citi.reghub.core.storm.commons.EligibilityBolt;
import com.citi.reghub.core.storm.commons.EnrichmentBolt;
import com.citi.reghub.core.storm.kafka.KafkaBoltFactory;
import com.citi.reghub.core.storm.kafka.KafkaSpoutFactory;

public class CshMuniDomainTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
		new CshMuniDomainTopology().runTopology(args);

	}

	@Override
	protected StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		final TopologyBuilder tp = new TopologyBuilder();
		String sourceStreamName = topologyConfig.get(CshMuniConstants.TOPOLOGY_STREAM_NAME);
		String sourceKafkaTopics = topologyConfig.get(CshMuniConstants.KAFKA_TOPIC_NAMES);

		tp.setSpout("cshmuni_spout", KafkaSpoutFactory.getKafkaSpout(topologyConfig, sourceKafkaTopics, sourceStreamName),
				3);

		
		
		tp.setBolt("pre_eligibility", new EligibilityBolt(CshMuniConstants.PRE_ELIGIBILITY_RULE_GRAPH), 3)
		.shuffleGrouping("cshmuni_spout", sourceStreamName);
		tp.setBolt("ackEnrichment", new AckEnrichmentBolt(),1).shuffleGrouping("cshmuni_spout",sourceStreamName);
		
		tp.setBolt(CshMuniConstants.KAFKA_REPORTABLE_BOLT_NAMES, KafkaBoltFactory.getKafkaBolt(topologyConfig, CshMuniConstants.KAFKA_REPORTABLE_BOLT_NAMES), 3)
		.shuffleGrouping("ackEnrichment", StormStreams.REPORTABLE);
		
		tp.setBolt(CshMuniConstants.KAFKA_EXCEPTION_BOLT_NAMES, KafkaBoltFactory.getKafkaBolt(topologyConfig, CshMuniConstants.KAFKA_EXCEPTION_BOLT_NAMES), 3)
		.shuffleGrouping("ackEnrichment", StormStreams.EXCEPTION);

		return tp.createTopology();
	}
}
