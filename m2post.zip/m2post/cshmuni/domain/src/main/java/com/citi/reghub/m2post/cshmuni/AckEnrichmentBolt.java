package com.citi.reghub.m2post.cshmuni;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.client.utils.URIBuilder;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.client.SingletonRestClient;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.storm.commons.RegHubBolt;

public class AckEnrichmentBolt extends RegHubBolt {

	protected static final Logger LOG = LoggerFactory.getLogger(AckEnrichmentBolt.class);
	private static final long serialVersionUID = 1L;

	private OutputCollector _collector;
	public RestClient restClient;
	private String url;

	@Override
	public void process(Tuple input) throws Exception {
		Entity message = (Entity) input.getValueByField("message");

		if ("NEW".equals(message.sourceStatus)) {
			_collector.emit(StormStreams.REPORTABLE, new Values(message.regHubId, message));
		} else {
			if (url != null) {
				String url1 = MessageFormat.format(url, message.sourceId, message.stream, message.flow);
				RawOutboundRecord record = null;

				record = restClient.get(url1, RawOutboundRecord.class);

				if ((record == null) || (record.ackId == null)) {
					_collector.emit(StormStreams.EXCEPTION, new Values(message.regHubId, message));
					LOG.error("No such record in rawOutbound Database, reghubId:" + message.regHubId+ " sourceId:"+message.sourceId);
				} else {
					message.info.put("ackId", record.ackId);
					_collector.emit(StormStreams.REPORTABLE, new Values(message.regHubId, message));
				}
			} else {
				LOG.error("RawOutboundService Url missing : " + message.regHubId);
				throw new Exception("RawOutboundService Url missing");
			}
		}
		Audit audit = message.toAudit();
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		_collector.ack(input);

	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));

	}

	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		restClient = SingletonRestClient.getInstance();
		Map topologyConfig = (Map) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		if (topologyConfig != null)
			url = (String) topologyConfig.get(CshMuniConstants.RAW_OUTBOUND_SERVICE_URL);

	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.DOMAIN_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.DOMAIN);
		return exceptionTags;
	}

}
