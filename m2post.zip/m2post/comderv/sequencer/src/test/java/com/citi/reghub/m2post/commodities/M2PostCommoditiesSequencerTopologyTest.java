package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUECNER_CACHE_COLLECTION_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_TOPIC_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.IntStream;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;

public class M2PostCommoditiesSequencerTopologyTest {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCommoditiesSequencerTopologyTest.class);
	private static Map<String, String> appProps;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(29092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(),
			EntityKafkaSerializerDeserializer.class.getCanonicalName());

	private static LocalCluster cluster;
	private static List<LocalDate> tradeDateList = Arrays.asList(LocalDate.now(), LocalDate.of(2017, 01, 20),
			LocalDate.of(2012, 12, 21), LocalDate.of(2007, 11, 4), LocalDate.of(2007, 11, 5), LocalDate.of(2007, 11, 6),
			LocalDate.of(1990, 01, 01));


	@SuppressWarnings("unchecked")
	void populateTopicData(String topicName, int msgCount) {
		List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new EntityBuilder().info("tradeDate", (LocalDate) getRandomItemFromInput(tradeDateList)).build();
			t.regHubId = "" + value;
			messages.add(t);
		});

		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (Exception e) {
			LOG.error("Error sending messages to kafka", e);
			;
		}
	}

	@SuppressWarnings("unchecked")
	void populateCustomTopicData(String topicName) {
		List<Entity> messages = new ArrayList<>();

		Entity t1 = new EntityBuilder().build();
		t1.regHubId = "1";
		t1.sourceId = "123";
		t1.sourceStatus = SourceStatus.NEW;
		messages.add(t1);

		Entity t2 = new EntityBuilder().build();
		t2.regHubId = "2";
		t2.sourceId = "123";
		t2.publishedTs = LocalDateTime.parse("2017-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t2.sourceStatus = SourceStatus.CANCEL;
		messages.add(t2);

		Entity t3 = new EntityBuilder().build();
		t3.regHubId = "3";
		t3.sourceId = "123";
		t3.sourceStatus = SourceStatus.AMEND;
		t3.publishedTs = LocalDateTime.parse("2018-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		messages.add(t3);

		Entity t4 = new EntityBuilder().build();
		t4.regHubId = "4";
		t4.sourceId = "456";
		t4.sourceStatus = SourceStatus.CANCEL;
		messages.add(t4);

		Entity t5 = new EntityBuilder().build();
		t5.regHubId = "5";
		t5.sourceId = "456";
		t5.sourceStatus = SourceStatus.NEW;
		t5.publishedTs = LocalDateTime.parse("2017-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		messages.add(t5);

		Entity t6 = new EntityBuilder().build();
		t6.regHubId = "6";
		t6.sourceId = "456";
		t6.sourceStatus = SourceStatus.AMEND;
		t6.publishedTs = LocalDateTime.parse("2018-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		messages.add(t6);

		Entity t7 = new EntityBuilder().build();
		t7.regHubId = "7";
		t7.sourceId = "789";
		t7.sourceStatus = SourceStatus.AMEND;
		messages.add(t7);

		Entity t8 = new EntityBuilder().build();
		t8.regHubId = "8";
		t8.sourceId = "789";
		t8.publishedTs = LocalDateTime.parse("2017-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t8.sourceStatus = SourceStatus.NEW;
		messages.add(t8);

		Entity t9 = new EntityBuilder().build();
		t9.regHubId = "9";
		t9.sourceId = "789";
		t9.publishedTs = LocalDateTime.parse("2018-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t9.sourceStatus = SourceStatus.CANCEL;
		messages.add(t9);

		Entity t10 = new EntityBuilder().build();
		t10.regHubId = "10";
		t10.sourceId = "321";
		t10.publishedTs = LocalDateTime.parse("2016-07-04 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t10.sourceStatus = SourceStatus.NEW;
		messages.add(t10);

		Entity t11 = new EntityBuilder().build();
		t11.regHubId = "11";
		t11.sourceId = "321";
		t11.publishedTs = LocalDateTime.parse("2016-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t11.sourceStatus = SourceStatus.AMEND;
		messages.add(t11);

		Entity t12 = new EntityBuilder().build();
		t12.regHubId = "12";
		t12.sourceId = "321";
		t12.publishedTs = LocalDateTime.parse("2016-08-04 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t12.sourceStatus = SourceStatus.AMEND;
		messages.add(t12);

		Entity t13 = new EntityBuilder().build();
		t13.regHubId = "13";
		t13.sourceId = "654";
		t13.publishedTs = LocalDateTime.parse("2016-07-04 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t13.sourceStatus = SourceStatus.NEW;
		messages.add(t13);

		Entity t14 = new EntityBuilder().build();
		t14.regHubId = "14";
		t14.sourceId = "654";
		t14.publishedTs = LocalDateTime.parse("2016-08-04 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t14.sourceStatus = SourceStatus.AMEND;
		messages.add(t14);

		Entity t15 = new EntityBuilder().build();
		t15.regHubId = "15";
		t15.sourceId = "654";
		t15.publishedTs = LocalDateTime.parse("2016-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		t15.sourceStatus = SourceStatus.AMEND;
		messages.add(t15);

		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (Exception e) {
			LOG.error("Error sending messages to kafka", e);
			
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldBeAbleToSendAndReceiveTrades() throws Exception {
		final String topic = "m2post_commodities_reportable_demo";
		populateTopicData(topic, 10);
		Thread.sleep(3000);
		List<Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(topic);
		assertThat(result.isEmpty(), is(false));
		assertThat(result.size(), is(10));
		System.out.println("successful");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldRunTopologyAndPostToKafkaTopics() throws Exception {
		String inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		String outputTopic = appProps.get(SEQUENCED_OUTBOUND_TOPIC_NAME);
	    String commonReportableTopic = appProps.get(REPORTABLE_TOPIC_NAME);
	    String auditLogTopic = appProps.get(AUDIT_TOPIC_NAME);
		populateCustomTopicData(inputTopic);

		Thread.sleep(6000);

		Properties entityConsumerProps = new Properties();
        entityConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
        entityConsumerProps.put("auto.offset.reset", "earliest");
        entityConsumerProps.put("group.id", "entity_group");
        entityConsumerProps.put("value.deserializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
        List<Entity> sequencedOutboundResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(outputTopic,entityConsumerProps);
        List<Entity> commonReportableResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(commonReportableTopic, entityConsumerProps);

        Properties auditConsumerProps = new Properties();
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");

		List<Audit> auditResult= kafkaUnitRule.getKafkaUnit().consumeFromTopic(auditLogTopic, auditConsumerProps);

		/*assertThat(sequencedOutboundResult.isEmpty(), is(false));
		assertThat((sequencedOutboundResult.size()), is(11));
		assertThat(commonReportableResult.isEmpty(), is(false));
		assertThat((commonReportableResult.size()), is(15));*/
		assertThat(auditResult.isEmpty(), is(false));
		assertThat((auditResult.size()), is(15));
	}

	@Before
	public void setUp() throws Exception {

		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(true);
		conf.put("topologyConfig", appProps);
		cluster.submitTopology(M2PostCommoditiesSequencerTopologyTest.class.getSimpleName(), conf,
				new M2PostCommoditiesSequencerTopology().buildTopology(appProps));
		// Wait till topology to get started
		Thread.sleep(15000);
	}

	@After
	public void teardown() throws Exception {
		cluster.killTopology(M2PostCommoditiesSequencerTopologyTest.class.getSimpleName());
		CacheClient cacheClient = SingletonCacheClient.getInstance();
		Map<String, String> Cacheconfig = new HashMap<>();
		Cacheconfig.put(CacheClient.CACHE_COLLECTION_NAME,
				appProps.get(SEQUECNER_CACHE_COLLECTION_NAME));
		Cacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.evictCollection(Cacheconfig);
	}

	public static Object getRandomItemFromInput(List<?> list) {
		return list.get((new Random()).nextInt(list.size()));
	}
}
