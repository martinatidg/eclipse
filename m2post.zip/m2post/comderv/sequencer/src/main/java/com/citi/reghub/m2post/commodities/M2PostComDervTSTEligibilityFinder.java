/**
 * 
 */
package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ALLOC_TRADE_STATUS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.COMMODITIES_DERIVATIVE_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CPTY_FIRM_ACCT_MNEMONIC;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CPTY_FIRM_GFCID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EMISSION_ALLOWANCE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXECUTION_VENUE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_FIRM_ACCT_MNEMONIC;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_FIRM_GFCID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTRUMENT_CLASSIFICATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NON_TOTV_INSTRUMENT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTATIONAL_AMOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTATION_OF_QTY_IN_MEASUREMENT_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTIONAL_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_PARTY_IDS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OTC_POST_TRADE_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PARTY_ID_SOURCE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PORTFOLIO_COMPRESSION_TRADES;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE_DISC_N_NEGO_TXN;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE_NOTATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRODUCT_DELIVERY_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.QTY_IN_MESAUREMENT_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADED_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRANSACTION_TO_CLEAR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.VENUE_TRADE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.WAIVER_INDICATOR;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;
import com.citi.reghub.m2post.utils.translators.TradeStatusTranslationEligibilityFinder;

/**
 * @author dk77005
 *
 */
public class M2PostComDervTSTEligibilityFinder implements TradeStatusTranslationEligibilityFinder, Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private static final List<String> TST_ELIGIBILE_FIELDS = Arrays.asList(INSTRUMENT_CLASSIFICATION,
			TRANSACTION_TO_CLEAR, EXECUTION_VENUE_TYPE, WAIVER_INDICATOR, OTC_POST_TRADE_INDICATOR,
			COMMODITIES_DERIVATIVE_INDICATOR, QTY_IN_MESAUREMENT_UNIT, NOTATION_OF_QTY_IN_MEASUREMENT_UNIT,
			NOTATIONAL_AMOUNT, EMISSION_ALLOWANCE_TYPE, INSTR_IDENT_CODE, PRICE_CURRENCY, NOTIONAL_CURRENCY,
			PRICE_NOTATION, TRADED_QTY, NO_PARTY_IDS, EXEC_FIRM_ACCT_MNEMONIC, EXEC_FIRM_GFCID, CPTY_FIRM_ACCT_MNEMONIC,
			CPTY_FIRM_GFCID, PARTY_ID_SOURCE, ALLOC_TRADE_STATUS, NON_TOTV_INSTRUMENT, PORTFOLIO_COMPRESSION_TRADES,
			VENUE_TRADE, PRICE_DISC_N_NEGO_TXN, PRODUCT_DELIVERY_TYPE);

	public boolean tradeEligibleForStatusTranslation(Entity currEntity, Entity prevEntity) {

		// If no previous entity then no need for translation
		if (null == prevEntity) {
			return false;
		}

		// If not active then no going to report and no need of translation 
		if (!StringUtils.equalsIgnoreCase("ACTIVE", currEntity.getString(InfoMapKeyStringConstants.REPORT_STATUS))) {
			return false;
		}

		// If any reportable field changed then call translator to decide the change
		for (String key : TST_ELIGIBILE_FIELDS) {
			Object inputEntityValue = currEntity.info.get(key);
			Object dbEntityValue = prevEntity.info.get(key);

			if (null == inputEntityValue && null != dbEntityValue) {
				return true;
			} else if (null != inputEntityValue && null == dbEntityValue) {
				return true;
			} else if (null != inputEntityValue && null != dbEntityValue && !inputEntityValue.equals(dbEntityValue)) {
				return true;
			}
		}
		return false;
	}
}
