package com.citi.reghub.m2post.commodities;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.Ignore;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;

@Ignore
public class PublichToDomTopicLocal {
	
	/*@SuppressWarnings({ "unchecked", "rawtypes" })
	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(29092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(),
			EntityKafkaSerializerDeserializer.class.getCanonicalName());*/
	
	@Test
	public void main() {
		
		List<Entity> listEntity = new ArrayList<Entity>();
		listEntity.add(createEntity());
		try {
			
			Properties props = new Properties();
			props.put("bootstrap.servers", "localhost:9092");
			props.put("acks", "all");
			props.put("key.serializer", 
			         "org.apache.kafka.common.serialization.StringSerializer");
	      props.put("value.serializer", 
			         "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
	      Producer<String, Entity> producer = new KafkaProducer
	    	         <String, Entity>(props);
	      
	      producer.send(new ProducerRecord<String, Entity>("m2post_comderv_domain_input", 
	              Integer.toString(1), createEntity()));
	                 System.out.println("Message sent successfully");
	                 producer.close();
	      
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private static Entity createEntity() {
		Entity entity = new Entity();
		
		entity.receivedTs = LocalDateTime.now();
		entity.publishedTs = LocalDateTime.now();
		entity.executionTs = LocalDateTime.now();
		entity.lastUpdatedTs = LocalDateTime.now();

		entity.sourceId = "CE:CE:9000:1";
		entity.regHubId = "reghub-CE:CE:1777780061";
		entity.stream = "m2post";
		entity.flow = "comderv";
		
		entity.info.put(InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID, "CE:CE:9000:1");
		entity.info.put(InfoMapKeyStringConstants.REPORT_STATUS, "ACTIVE");
		entity.info.put(InfoMapKeyStringConstants.TRADED_QTY, new BigDecimal("200.00"));
		entity.info.put(InfoMapKeyStringConstants.PRICE, new BigDecimal("200.00"));
		entity.info.put(InfoMapKeyStringConstants.NOTIONAL_AMOUNT, new BigDecimal("1000.0"));
		
		return entity;
	}
	
}
