package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.COMMODITIES_DERIVATIVE_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CPTY_FIRM_ACCT_MNEMONIC;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CPTY_FIRM_GFCID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EMISSION_ALLOWANCE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_FIRM_ACCT_MNEMONIC;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_FIRM_GFCID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTRUMENT_CLASSIFICATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.MONE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTATIONAL_AMOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTATION_OF_QTY_IN_MEASUREMENT_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTIONAL_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_PARTY_IDS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OTC_POST_TRADE_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PARTY_ID_SOURCE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE_NOTATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.QTY_IN_MESAUREMENT_UNIT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.REPORT_STATUS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADED_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_VENUE_TRANSACT_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRANSACTION_TO_CLEAR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.VENUE_OF_EXECUTION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.WAIVER_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.COM_FLOW;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.STREAM;
import static org.junit.Assert.assertEquals;

import java.io.StringReader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.junit.Test;
import org.xml.sax.InputSource;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.storm.commons.CitimlParserTest;

public class M2PostCommoditiesEntityMapperTest {
	
	@Test
	public void shouldPopulateEntityInfoObjectWhenprovidedWithInputcitimlXml() throws Exception{
		
		SAXReader reader = new SAXReader();
		Document doc = reader.read(CitimlParserTest.class.getClassLoader().getResourceAsStream("citiml.xml"));
		String citimlString = doc.asXML();
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		org.w3c.dom.Document document = builder.parse(new InputSource(new StringReader(citimlString)));
		
		EntityMapper entityMapper = new M2PostCommoditiesEntityMapper(COM_FLOW, STREAM);
		Entity input = new Entity();
		Entity output = entityMapper.mapToEntity(document, input);
		Entity expected = new Entity();
		
		expected.status = "REPORTABLE";
		expected.stream = "m2post";
		expected.flow = "comderv";
		expected.sourceSystem = "ITICKET";
		expected.sourceUId = "m2post-comderv-ITKT64734-1-1497045761";
		expected.sourceId = "ITKT64734";
		expected.executionTs = LocalDateTime.parse("2017-06-09T22:02:12Z", DateTimeFormatter.ISO_DATE_TIME);
		expected.publishedTs = LocalDateTime.parse("2017-06-09T22:02:41Z", DateTimeFormatter.ISO_DATE_TIME);
		expected.receivedTs = LocalDateTime.parse("2017-04-17T23:04:05Z", DateTimeFormatter.ISO_DATE_TIME);
		expected.regReportingRef = "comdervITICKET20170609ITKT64734";
		
		expected.info.put(REPORT_STATUS, "ACTIVE");
		expected.info.put(TRADE_DATE, LocalDate.parse("2017-06-09", DateTimeFormatter.ISO_DATE));
		expected.info.put(VENUE_OF_EXECUTION, "XOFF");
		expected.info.put(INSTRUMENT_CLASSIFICATION, "Commodity:Metals:Precious:Swap:Cash");
		expected.info.put(WAIVER_INDICATOR, "Yes");
		expected.info.put(OTC_POST_TRADE_INDICATOR, "OTC_YES");
		expected.info.put(COMMODITIES_DERIVATIVE_INDICATOR, "true");
		expected.info.put(QTY_IN_MESAUREMENT_UNIT, new BigDecimal("2.0"));
		expected.info.put(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT, "TOCD");
		expected.info.put(NOTATIONAL_AMOUNT, new BigDecimal("200.25"));
		expected.info.put(EMISSION_ALLOWANCE_TYPE, "COMMODITIES");
		expected.info.put(TRANSACTION_TO_CLEAR, "false");
		expected.info.put(INSTR_IDENT_CODE_TYPE, "ISIN");
		expected.info.put(INSTR_IDENT_CODE, "Commodity:Metals:Precious:Swap:Cash");
		expected.info.put(PRICE_CURRENCY, "INR");
		expected.info.put(NOTIONAL_CURRENCY, "USD");
		expected.info.put(PRICE_NOTATION, MONE);
		expected.info.put(PRICE, new BigDecimal("123.45"));
		expected.info.put(TRADE_VENUE_TRANSACT_ID, "ITKT64734");
		expected.info.put(TRADED_QTY, new BigDecimal("2.0"));
		expected.info.put(NO_PARTY_IDS, 2);
		expected.info.put(EXEC_FIRM_ACCT_MNEMONIC, "CGMLMUNI");
		expected.info.put(CPTY_FIRM_ACCT_MNEMONIC, "BOA3C");
		expected.info.put(EXEC_FIRM_GFCID, "1000242191");
		expected.info.put(CPTY_FIRM_GFCID, "1000018712");
		expected.info.put(PARTY_ID_SOURCE, "N");

		assertEquals(expected.status, output.status);
		assertEquals(expected.stream, output.stream);
		assertEquals(expected.flow, output.flow);
		assertEquals(expected.sourceSystem, output.sourceSystem);
		assertEquals(expected.sourceUId, output.sourceUId);
		assertEquals(expected.sourceId, output.sourceId);
		assertEquals(expected.executionTs, output.executionTs);
		assertEquals(expected.publishedTs, output.publishedTs);
		assertEquals(expected.regReportingRef, output.regReportingRef);
		
		
		assertEquals(expected.info.get(REPORT_STATUS), output.info.get(REPORT_STATUS));
		assertEquals(expected.info.get(TRADE_DATE), output.info.get(TRADE_DATE));
		assertEquals(expected.info.get(VENUE_OF_EXECUTION), output.info.get(VENUE_OF_EXECUTION));
		//assertEquals(expected.info.get(INSTRUMENT_CLASSIFICATION), output.info.get(INSTRUMENT_CLASSIFICATION));
		assertEquals(expected.info.get(WAIVER_INDICATOR), output.info.get(WAIVER_INDICATOR));
		assertEquals(expected.info.get(OTC_POST_TRADE_INDICATOR), output.info.get(OTC_POST_TRADE_INDICATOR));
		assertEquals(expected.info.get(COMMODITIES_DERIVATIVE_INDICATOR), output.info.get(COMMODITIES_DERIVATIVE_INDICATOR));
		assertEquals(expected.info.get(QTY_IN_MESAUREMENT_UNIT), output.info.get(QTY_IN_MESAUREMENT_UNIT));
		assertEquals(expected.info.get(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT), output.info.get(NOTATION_OF_QTY_IN_MEASUREMENT_UNIT));
		assertEquals(expected.info.get(NOTATIONAL_AMOUNT), output.info.get(NOTATIONAL_AMOUNT));
		//assertEquals(expected.info.get(EMISSION_ALLOWANCE_TYPE), output.info.get(EMISSION_ALLOWANCE_TYPE));
		assertEquals(expected.info.get(TRANSACTION_TO_CLEAR), output.info.get(TRANSACTION_TO_CLEAR));
		//assertEquals(expected.info.get(INSTR_IDENT_CODE_TYPE), output.info.get(INSTR_IDENT_CODE_TYPE));
		//assertEquals(expected.info.get(INSTR_IDENT_CODE), output.info.get(INSTR_IDENT_CODE));
		assertEquals(expected.info.get(PRICE_CURRENCY), output.info.get(PRICE_CURRENCY));
		assertEquals(expected.info.get(NOTIONAL_CURRENCY), output.info.get(NOTIONAL_CURRENCY));
		assertEquals(expected.info.get(PRICE_NOTATION), output.info.get(PRICE_NOTATION));
		assertEquals(expected.info.get(PRICE), output.info.get(PRICE));
		assertEquals(expected.info.get(TRADE_VENUE_TRANSACT_ID), output.info.get(TRADE_VENUE_TRANSACT_ID));
		assertEquals(expected.info.get(TRADED_QTY), output.info.get(TRADED_QTY));
		assertEquals(expected.info.get(NO_PARTY_IDS), output.info.get(NO_PARTY_IDS));
		assertEquals(expected.info.get(EXEC_FIRM_ACCT_MNEMONIC), output.info.get(EXEC_FIRM_ACCT_MNEMONIC));
		assertEquals(expected.info.get(EXEC_FIRM_GFCID), output.info.get(EXEC_FIRM_GFCID));
		assertEquals(expected.info.get(CPTY_FIRM_ACCT_MNEMONIC), output.info.get(CPTY_FIRM_ACCT_MNEMONIC));
		assertEquals(expected.info.get(CPTY_FIRM_GFCID), output.info.get(CPTY_FIRM_GFCID));
		assertEquals(expected.info.get(PARTY_ID_SOURCE), output.info.get(PARTY_ID_SOURCE));
		
	}

}
