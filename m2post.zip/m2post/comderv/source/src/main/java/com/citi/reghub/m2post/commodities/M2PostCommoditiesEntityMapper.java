package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.sourcetoentitymappers.AbstractCitiMLToEntityMapper;

/**
 * This class transforms the incoming Commodities CITIML XML DOM to the
 * corresponding RegHub Entity Domain Object using XPATHs
 * 
 * @author pg60809
 *
 */
public class M2PostCommoditiesEntityMapper extends AbstractCitiMLToEntityMapper {

	private static final long serialVersionUID = 656563698720817301L;

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCommoditiesEntityMapper.class);

	/**
	 * 
	 * @param flow
	 * @param stream
	 */
	public M2PostCommoditiesEntityMapper(String flow, String stream) {
		super(flow, stream);
	}
	
	/**
	 * This methods works on the CITIML DOM using XPATHs. For the corresponding
	 * XPATH provided, it extracts the value from DOM. Converts in into the
	 * expected Data Type and populates the Entity Domain Object.
	 * 
	 * @param message
	 * @param entity
	 * @return Entity
	 * 
	 */
	@Override
	public Entity mapToEntity(Object message, Entity entity) {

		LOG.info("Mapping for Entity Object Started for Commodities Asset Class");

		try {
			
			entity = super.mapToEntity(message, entity);
			
		} catch (Exception e) {
			LOG.error(String.format("Exception Occurred while Mapping Entity Object for Commodities Asset Class : %s",
					e.getMessage()));
			throw new RuntimeException(e);
		}
		LOG.info(String.format(
				"Mapping for Entity Object Completed for Commodities Asset Class, created Entity Object : %s", entity));
		return entity;
	}

	/**
	 * This method populates the Price in Entity Domain Object
	 * PNDG Flag is populated if priceType is missing which in turn says Price is Missing
	 * If PriceType is present, Price has to be present.
	 * @throws XPathExpressionException
	 */
	@Override
	protected void setPrice() throws XPathExpressionException {
		
		LOG.debug("Setting Price for Commodities started");
		
		String priceType = getNodeValue(PRICE_TYPE_XPATH);

		if (!StringUtils.isBlank(priceType) && (FIXED_PRICE.equals(priceType) || PREMIUM.equals(priceType))) {
			
			String amount = getNodeValue(PRICE_NOTATION_AMT_XPATH);
			
			if (null != amount) {
				LOG.debug("Setting Price as "+amount+" for Commodities");
				getDoubleValue(PRICE, amount);
			}
			
		} else {
			
			LOG.debug("Price not avaiable for Commodities, setting PNDG flag");
			populateEntityFlagList(PNDG);
			
		}
		LOG.debug("Setting Price for Commodities completed");

	}
	
	@Override
	protected void setVenueOfExecution() throws XPathExpressionException {
		
		LOG.debug("Setting Venue Of Execution for Commodities started");
		populateEntityInfoForStringValues(VENUE_OF_EXECUTION, String.format(PARTY_XPATH, EXEC_FACILITY, EXEC_FAC_ID_SCHEME));
		LOG.debug("Setting Venue Of Execution for Commodities started");
		
	}
	
	
	protected void setEmissionAllowanceType() throws XPathExpressionException {
		
		
		String emmisionAlTp = getNodeValue(EMISSION_ALLOWANCE_TRADE_TYPE_XPATH);
		
		if(!StringUtils.isBlank(emmisionAlTp)){
		
		if(emmisionAlTp.equalsIgnoreCase("pipeline") || emmisionAlTp.equalsIgnoreCase("crudeType")){
			
			LocalDateTime tradingDateTime = LocalDateTime.parse(getNodeValue(TRADING_DATE_TIME_XPATH), DateTimeFormatter.ISO_DATE_TIME);
			LocalDateTime excerciseDateTime = LocalDateTime.parse(getNodeValue(EXCERCISE_DATE_XPATH), DateTimeFormatter.ISO_DATE_TIME);


			
			Long dateDuration = Duration.between(excerciseDateTime,tradingDateTime).toDays(); 	
			if(dateDuration>=2){
				populateEntityInfoMap(EMISSION_ALLOWANCE_TYPE, "OTHR");
			}else{
				Map<String, String> emMap = new HashMap<>();		
				emMap.put("EUA", "EUA");
				emMap.put("EUA USD", "EUA");
				emMap.put("CER", "CER");
				emMap.put("ERU", "ERU");
				emMap.put("EUAAVIATION", "EUAA");
				emMap.put("EUAGREENX", "EUAA");
				emMap.put("CER", "CER");
				emMap.put("CER PRIMARY EUR", "CER");
				emMap.put("CER PRIMARY USD", "CER");
				emMap.put("CERCLEAN", "CER");
				emMap.put("CERGREENX", "CER");
				emMap.put("CERGREY", "CER");
				emMap.put("ERU", "ERU");
				emMap.put("ERU.CER", "ERU");
				emMap.put("ERUCLEAN", "ERU");
				
				
				String nodeValue = getNodeValue(EMISSION_ALLOWANCE_TYPE_XPATH);

				if(emMap.containsValue(nodeValue)){
					populateEntityInfoMap(EMISSION_ALLOWANCE_TYPE, emMap.get(nodeValue));
				}
				
			}
		}
		
	}}

}
