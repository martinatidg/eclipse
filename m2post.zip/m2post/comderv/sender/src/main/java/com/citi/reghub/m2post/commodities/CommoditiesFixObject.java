package com.citi.reghub.m2post.commodities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.fix.FixObject;

import quickfix.ConfigError;
import quickfix.DataDictionary;
import quickfix.FieldNotFound;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;

/**
 * This class converts the Commodities Entity Object to output FIX object.
 * @author pg60809
 *
 */
@SuppressWarnings("serial")
public class CommoditiesFixObject extends FixObject {
	
	private static final Logger LOG = LoggerFactory.getLogger(CommoditiesFixObject.class);
	
	public CommoditiesFixObject(Entity e) throws ConfigError {
		
		super(e);
		try {
			LOG.debug("validating Commodities fix object with dictionary.");
			getDictionary().validate(this, true);
			LOG.debug("validated Commodities fix object with dictionary.");
		} catch (IncorrectTagValue | FieldNotFound | IncorrectDataFormat exception) {
			LOG.error("Error while validating Commodities FIX object with dictionary.", exception);
			throw new ConfigError(exception);
		}
	}
}
