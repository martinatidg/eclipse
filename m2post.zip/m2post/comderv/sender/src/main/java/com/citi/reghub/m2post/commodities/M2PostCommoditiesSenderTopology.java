package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.APA_SENDER_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.APA_TRADE_ID_ENRICHMENT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_MSG_GEN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SENDER_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SENDER_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_TOPIC_NAME;

import java.util.Map;

import org.apache.storm.Config;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.APASenderBolt;
import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.constants.RegulatoryReportingBody;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.custombolts.APATradeIdEnrichmentBolt;
import com.citi.reghub.m2post.utils.custombolts.FixMsgGenerationBolt;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

/**
 * This class creates the Topology for the Processing the Entity object dispatched by Seqeuncer. 
 * @author pg60809
 *
 */
public class M2PostCommoditiesSenderTopology extends BaseTopology {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCommoditiesSenderTopology.class);
	
	public static void main(String[] args) throws Exception {
		new M2PostCommoditiesSenderTopology().runTopology(args);
	}

	public Config getTopologyConfig(){
		Config config = new Config();
		config.setDebug(true);
		return config;
	}

	/**
	 * The below method configures the Spouts and Bolts for the Commodities Sender Topology.
	 * 1. Creates a spout which will read/stream the data from kafka Topic on which Sequencer Sequenced Stream will input the data.
	 * 2. Various bolts are associated with the Stream Spout for Rules Processing.
	 * 	2.1. Fix Msg Generation Bolt : This Bolts converts the Entity object to Output FIX message and validates it with the Dictionary.
	 * 3. Once processed this data is forwarded to Outbound topic.
	 * 4. If any exceptions, the messages are sent to exception Queue.
	 * 
	 * @param  topologyConfig
	 * @return StormTopology
	 * @throws Exception
	 * 
	 */
	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		LOG.info("Sender Topology creation Started for Commodities");
		
		final TopologyBuilder tp = new TopologyBuilder();
		
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String rawOutboundTopicName = topologyConfig.get(RAW_OUTBOUND_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);

		tp.setSpout(SENDER_SPOUT_ID,  StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SENDER_STORM_STREAM, topologyConfig)); 
		
		tp.setBolt(APA_TRADE_ID_ENRICHMENT_BOLT_ID, new APATradeIdEnrichmentBolt(),3).
			fieldsGrouping(SENDER_SPOUT_ID, INBOUND_M2POST_SENDER_STORM_STREAM,new Fields("key"));

		tp.setBolt(APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(sourceKafkaTopics,
				APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_NAME, topologyConfig), 3)
				.fieldsGrouping(APA_TRADE_ID_ENRICHMENT_BOLT_ID, StormStreams.SOURCE,new Fields("key"));
		
		tp.setBolt(FIX_MSG_GEN_BOLT_ID, new FixMsgGenerationBolt(RawOutboundRecord.OutboundMessageType.FIX, RegulatoryReportingBody.APA, new CommoditiesEntityToFixConverter()), 3)
			.fieldsGrouping(APA_TRADE_ID_ENRICHMENT_BOLT_ID, StormStreams.REPORTABLE, new Fields("key"));
		
		tp.setBolt(APA_SENDER_BOLT_ID, new APASenderBolt(), 3).fieldsGrouping(FIX_MSG_GEN_BOLT_ID,  StormStreams.FIX_MSG, new Fields("sourceId"));

		tp.setBolt(RAW_MSG_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(rawOutboundTopicName, RAW_MSG_OUTBOUND_BOLT_NAME, topologyConfig), 3)
			.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.RAW_OUTBOUND_OBJECT);

		tp.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
			.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.AUDIT);
		
		tp.setBolt(EXCEPTION_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME, topologyConfig), 3)
			.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.EXCEPTION);
		
		LOG.info("Sender Topology creation Completed for Commodities");
		
		return tp.createTopology();
	}
}