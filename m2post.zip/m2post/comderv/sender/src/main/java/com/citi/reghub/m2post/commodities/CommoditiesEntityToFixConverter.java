package com.citi.reghub.m2post.commodities;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.converter.ConvertRecordToString;

/**
 * This class converts the Entity to FIX message through FIXObject converter and generates a outBound
 * FIX Message String.
 * @author pg60809
 *
 */
public class CommoditiesEntityToFixConverter implements ConvertRecordToString, Serializable {

	private static final Logger LOG = LoggerFactory.getLogger(CommoditiesEntityToFixConverter.class);

	//private static final String DELIMITER= "^B";
	private static final long serialVersionUID = 6842509178329170127L;

	@Override
	public String convert(List<Entity> entityList) throws Exception {
		
		LOG.debug("Convert Commodities entities to FIX started.");
		
		StringBuilder sb = new StringBuilder();
		for (Entity entity : entityList) {
			CommoditiesFixObject ffo = new CommoditiesFixObject(entity);
			//sb.append(DELIMITER);
			sb.append(ffo.toString());
		}
		
		LOG.debug("Convert Commodities entities to FIX finished.");
		return sb.toString();
	}
	
	public String convert(List<Entity> arg0, Boolean arg1) throws Exception {
		return null;
	}
}
