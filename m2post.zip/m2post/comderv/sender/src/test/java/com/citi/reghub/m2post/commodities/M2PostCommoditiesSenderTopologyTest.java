package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUECNER_CACHE_COLLECTION_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.IntStream;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;

@RunWith(JUnit4.class)
public class M2PostCommoditiesSenderTopologyTest{

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCommoditiesSenderTopologyTest.class);
	private static Map<String, String> appProps;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(19092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(),
			EntityKafkaSerializerDeserializer.class.getCanonicalName());

	private static LocalCluster cluster;
	private static List<LocalDate> tradeDateList = Arrays.asList(LocalDate.now(), LocalDate.of(2017, 01, 20),
			LocalDate.of(2012, 12, 21), LocalDate.of(2007, 11, 4), LocalDate.of(2007, 11, 5), LocalDate.of(2007, 11, 6),
			LocalDate.of(1990, 01, 01));
	
	@SuppressWarnings("unchecked")
	void populateTopicEntityData(String topicName, int msgCount) {
        List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new EntityBuilder()
					.info("tradeDate", (LocalDate) getRandomItemFromInput(tradeDateList))
					.build();
		    t.regHubId = "" + value;
		    t.sourceStatus="NEW";
			messages.add(t);
		});
		
		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (Exception e) {
			LOG.error("Error sending messages to kafka", e);
		}
    }

	@SuppressWarnings("unchecked")
	@Test
	public void shouldBeAbleToSendAndReceiveTrades() throws Exception {
		final String topic = "m2post_commodities_reportable_demo";
		populateTopicEntityData(topic, 10);
		Thread.sleep(3000);
		List<Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(topic);
		assertThat(result.isEmpty(), is(false));
		assertThat(result.size(), is(10));
		System.out.println("successful");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldRunTopologyAndPostToKafkaTopics() throws Exception {
		String inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
	    String rawOutboundTopic = appProps.get(RAW_OUTBOUND_TOPIC_NAME);
	    String auditLogTopic = appProps.get(AUDIT_TOPIC_NAME);
	    populateTopicEntityData(inputTopic, 10);

		Thread.sleep(6000);

		Properties fixMsgConsumerProps = new Properties();
		fixMsgConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		fixMsgConsumerProps.put("auto.offset.reset", "earliest");
		fixMsgConsumerProps.put("group.id", "fixMsg_group_1");
		fixMsgConsumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		Properties auditConsumerProps = new Properties();
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		
		Properties rawOutboundRecordConsumerProps = new Properties();
		rawOutboundRecordConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		rawOutboundRecordConsumerProps.put("auto.offset.reset", "earliest");
		rawOutboundRecordConsumerProps.put("group.id", "raw_msg_group_1");
		rawOutboundRecordConsumerProps.put("value.deserializer", "com.citi.reghub.core.RawOutboundRecordSerializerDeserializer");

		List<Audit> auditResult= kafkaUnitRule.getKafkaUnit().consumeFromTopic(auditLogTopic, auditConsumerProps);
		List<String> rawOutboundResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(rawOutboundTopic, rawOutboundRecordConsumerProps);
		
		
		assertThat(auditResult.isEmpty(), is(false));
		assertThat((auditResult.size()), is(10));
	}

	@BeforeClass
	public static void setUp() throws Exception {

		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(true);
		conf.put("topologyConfig", appProps);
		cluster.submitTopology(M2PostCommoditiesSenderTopologyTest.class.getSimpleName(), conf,
				new M2PostCommoditiesSenderTopology().buildTopology(appProps));
		// Wait till topology to get started
		Thread.sleep(15000);
	}

	@AfterClass
	public static void teardown() throws Exception {
		cluster.killTopology(M2PostCommoditiesSenderTopologyTest.class.getSimpleName());
		CacheClient cacheClient = SingletonCacheClient.getInstance();
		Map<String, String> Cacheconfig = new HashMap<>();
		Cacheconfig.put(CacheClient.CACHE_COLLECTION_NAME,
				appProps.get(SEQUECNER_CACHE_COLLECTION_NAME));
		Cacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.evictCollection(Cacheconfig);
	}

	public static Object getRandomItemFromInput(List<?> list) {
		return list.get((new Random()).nextInt(list.size()));
	}
}

