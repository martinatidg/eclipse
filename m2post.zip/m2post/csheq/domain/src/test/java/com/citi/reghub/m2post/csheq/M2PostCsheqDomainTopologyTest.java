package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.NON_REPORTABLE_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_TOPIC_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.IntStream;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;


@RunWith(JUnit4.class)
public class M2PostCsheqDomainTopologyTest {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCsheqDomainTopologyTest.class);
	private static Map<String, String> appProps;
	private static List<LocalDate> tradeDateList = Arrays.asList(LocalDate.now(), LocalDate.of(2017, 01, 20),
			LocalDate.of(2012, 12, 21), LocalDate.of(2007, 11, 4), LocalDate.of(2007, 11, 5), LocalDate.of(2007, 11, 6),
			LocalDate.of(1990, 01, 01));

	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(19092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(),
			EntityKafkaSerializerDeserializer.class.getCanonicalName());

	private static LocalCluster cluster;
	
	private static Properties reportableConsumerProps = null;
	private static Properties nonReportableConsumerProps = null;
	private static Properties auditConsumerProps = null;
	
	private static String inputTopic = null;
	private static String reportableInputTopic = null;
	private static String nonReportableInboundMessageTopic = null;
	private static String auditLogTopic = null;
	
	
	@BeforeClass
	public static void setUp() throws Exception {

		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());

		inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		reportableInputTopic = appProps.get(REPORTABLE_TOPIC_NAME);
		nonReportableInboundMessageTopic = appProps.get(NON_REPORTABLE_TOPIC_NAME);
		auditLogTopic = appProps.get(AUDIT_TOPIC_NAME);
		
//		Thread.sleep(6000);

		auditConsumerProps = new Properties();
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		
		reportableConsumerProps = new Properties();
		reportableConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		reportableConsumerProps.put("auto.offset.reset", "earliest");
		reportableConsumerProps.put("group.id", "reportable_group_1");
		reportableConsumerProps.put("value.serializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		
		nonReportableConsumerProps = new Properties();
		nonReportableConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		nonReportableConsumerProps.put("auto.offset.reset", "earliest");
		nonReportableConsumerProps.put("group.id", "nonreportable_group_1");
		nonReportableConsumerProps.put("value.serializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");

		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(false);
		conf.put("topologyConfig", appProps);
		cluster.submitTopology(M2PostCsheqDomainTopology.class.getSimpleName(), conf,
				new M2PostCsheqDomainTopology().buildTopology(appProps));
		// Wait till topology to get started
		Thread.sleep(15000);
	}

	@Test
	public void shouldConsumeMessagesFromSourceAndEmitToReportableKafkaTopics() throws Exception {
		populateTopicEntityData(reportableInputTopic, 10, EntityStatus.REPORTABLE);
		Thread.sleep(3000);
		List<Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(reportableInputTopic);
		assertThat(result.isEmpty(), is(false));
		assertThat(result.size(), is(10));
	}
	
	@Test
	public void shouldConsumeMessagesFromSourceAndEmitToNonReportableKafkaTopics() throws Exception {
		populateTopicEntityData(nonReportableInboundMessageTopic, 10, EntityStatus.NON_REPORTABLE);
		Thread.sleep(3000);
		List<Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(nonReportableInboundMessageTopic);
		assertThat(result.isEmpty(), is(false));
		assertThat(result.size(), is(10));
	}
	
	@Test
	public void shouldConsumeMessagesFromSourceAndEmitToAuditKafkaTopics() throws Exception {
		populateTopicEntityData(auditLogTopic, 10, EntityStatus.REPORTABLE);
		Thread.sleep(3000);
		List<Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(auditLogTopic);
		assertThat(result.isEmpty(), is(false));
		assertTrue(result.size() > 1);
	}
	
	@AfterClass
	public static void teardown() throws Exception {
		//cluster.killTopology(M2PostCshEqTopologyTest.class.getSimpleName());
	}
	
	void populateTopicEntityData(String topicName, int msgCount, String entityStatus) {
        List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new EntityBuilder()
					.info("tradeDate", (LocalDate) getRandomItemFromInput(tradeDateList))
					.build();
		    t.regHubId = "" + value;
		    t.status= entityStatus;
			messages.add(t);
		});
		
		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (Exception e) {
			LOG.error("Error sending messages to kafka", e);
		}
    }
	
	public static Object getRandomItemFromInput(List<?> list) {
		return list.get((new Random()).nextInt(list.size()));
	}
}
