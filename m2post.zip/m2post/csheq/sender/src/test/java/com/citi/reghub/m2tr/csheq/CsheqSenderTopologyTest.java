package com.citi.reghub.m2tr.csheq;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_MSG_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_OUTBOUND_TOPIC_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.IntStream;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;
import com.citi.reghub.m2post.csheq.CsheqSenderTopology;

@RunWith(JUnit4.class)
public class CsheqSenderTopologyTest{

	private static final Logger LOG = LoggerFactory.getLogger(CsheqSenderTopologyTest.class);
	private static Map<String, String> appProps;

	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(19092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(),
			EntityKafkaSerializerDeserializer.class.getCanonicalName());

	private static LocalCluster cluster;
	private static String inputTopic =null;
	private static String fixMsgTopic = null;
	private static String rawOutboundTopic = null;
	private static String auditLogTopic = null;
	
	private static Properties fixMsgConsumerProps =null;
	private static Properties auditConsumerProps= null;
	private static Properties rawOutboundRecordConsumerProps =null;
	
	private static List<LocalDate> tradeDateList = Arrays.asList(LocalDate.now(), LocalDate.of(2017, 01, 20),
			LocalDate.of(2012, 12, 21), LocalDate.of(2007, 11, 4), LocalDate.of(2007, 11, 5), LocalDate.of(2007, 11, 6),
			LocalDate.of(1990, 01, 01));
	
	void populateTopicEntityData(String topicName, int msgCount) {
        List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new EntityBuilder()
					.info("tradeDate", (LocalDate) getRandomItemFromInput(tradeDateList))
					.build();
		    t.regHubId = "" + value;
			messages.add(t);
		});
		
		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (Exception e) {
			LOG.error("Error sending messages to kafka", e);
		}
    }
	
	@Test
	public void shouldBeAbleToSendAndReceiveTrades() throws Exception {
		final String topic = "m2post_csheq_reportable_demo";
		populateTopicEntityData(topic, 10);
		Thread.sleep(3000);
		List<Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(topic);
		assertThat(result.isEmpty(), is(false));
		assertThat(result.size(), is(10));
		System.out.println("successful");
	}
	
	@Test
	public void shouldRunTopologyAndPostToKafkaTopics() throws Exception {

		populateTopicEntityData(inputTopic, 10);
		List<Audit> auditResult= kafkaUnitRule.getKafkaUnit().consumeFromTopic(auditLogTopic, auditConsumerProps);
		List<String> fixMsgResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(fixMsgTopic, fixMsgConsumerProps);
		List<String> rawOutboundResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(rawOutboundTopic, rawOutboundRecordConsumerProps);
		
		assertThat(fixMsgResult.isEmpty(), is(false));
		assertThat((fixMsgResult.size()), is(10));
		assertThat(rawOutboundResult.isEmpty(), is(false));
		assertThat((rawOutboundResult.size()), is(10));
		assertThat(auditResult.isEmpty(), is(false));
		assertThat((auditResult.size()), is(10));
	}
	
	@BeforeClass
	public static void setUp() throws Exception {

		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());
		
		inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		fixMsgTopic = appProps.get(FIX_MSG_TOPIC_NAME);
	    rawOutboundTopic = appProps.get(RAW_OUTBOUND_TOPIC_NAME);
	    auditLogTopic = appProps.get(AUDIT_TOPIC_NAME);

		Thread.sleep(6000);

		fixMsgConsumerProps = new Properties();
		fixMsgConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		fixMsgConsumerProps.put("auto.offset.reset", "earliest");
		fixMsgConsumerProps.put("group.id", "fixMsg_group_1");
		fixMsgConsumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		auditConsumerProps = new Properties();
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		
		rawOutboundRecordConsumerProps = new Properties();
		rawOutboundRecordConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		rawOutboundRecordConsumerProps.put("auto.offset.reset", "earliest");
		rawOutboundRecordConsumerProps.put("group.id", "audit_group_1");
		rawOutboundRecordConsumerProps.put("value.deserializer", "com.citi.reghub.core.RawOutboundRecordSerializerDeserializer");
		
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(true);
		conf.put("topologyConfig", appProps);
		cluster.submitTopology(CsheqSenderTopologyTest.class.getSimpleName(), conf,
				new CsheqSenderTopology().buildTopology(appProps));
		// Wait till topology to get started
		Thread.sleep(15000);
	}
	
	@AfterClass
	public static void teardown() throws Exception {
		cluster.killTopology(CsheqSenderTopologyTest.class.getSimpleName());
	/*	CacheClient cacheClient = SingletonCacheClient.getInstance();
		Map<String, String> Cacheconfig = new HashMap<>();
		Cacheconfig.put(CacheClient.CACHE_COLLECTION_NAME,
				appProps.get(SEQUECNER_CACHE_COLLECTION_NAME));
		Cacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient.evictCollection(Cacheconfig);*/
	}

	public static Object getRandomItemFromInput(List<?> list) {
		return list.get((new Random()).nextInt(list.size()));
	}
}
	
