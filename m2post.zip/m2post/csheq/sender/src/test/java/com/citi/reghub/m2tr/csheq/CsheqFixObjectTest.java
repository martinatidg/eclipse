package com.citi.reghub.m2tr.csheq;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;

import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Date;

import com.citi.reghub.core.Entity;

import quickfix.ConfigError;
import quickfix.DataDictionary;
import quickfix.custom.field.AlgorithmicTradeIndicator;
import quickfix.custom.field.ExecMethod;
import quickfix.custom.field.NoTradePriceConditions;
import quickfix.custom.field.SecondaryTradeID;
import quickfix.custom.field.TradePriceCondition;
import quickfix.custom.field.TrdRegPublicationReasons;
import quickfix.field.BeginString;
import quickfix.field.BodyLength;
import quickfix.field.CheckSum;
import quickfix.field.Currency;
import quickfix.field.ExecInst;
import quickfix.field.ExecType;
import quickfix.field.FirmTradeID;
import quickfix.field.GrossTradeAmt;
import quickfix.field.LastPx;
import quickfix.field.LastQty;
import quickfix.field.MatchType;
import quickfix.field.MsgSeqNum;
import quickfix.field.MsgType;
import quickfix.field.OrderCapacity;
import quickfix.field.SecondaryTrdType;
import quickfix.field.SecurityExchange;
import quickfix.field.SecurityID;
import quickfix.field.SecurityIDSource;
import quickfix.field.SenderCompID;
import quickfix.field.SendingTime;
import quickfix.field.SettlDate;
import quickfix.field.SettlType;
import quickfix.field.Symbol;
import quickfix.field.TargetCompID;
import quickfix.field.TargetSubID;
import quickfix.field.TradeDate;
import quickfix.field.TradeHandlingInstr;
import quickfix.field.TradeID;
import quickfix.field.TradePublishIndicator;
import quickfix.field.TradeReportID;
import quickfix.field.TradeReportTransType;
import quickfix.field.TradeReportType;
import quickfix.field.TradingSessionSubID;
import quickfix.field.TransactTime;
import quickfix.field.TrdSubType;
import quickfix.field.TrdType;
import quickfix.field.VenueType;
import quickfix.fix44.TradeCaptureReport;

@SuppressWarnings("serial")
public class CsheqFixObjectTest extends TradeCaptureReport {

	public String message = "";
	DataDictionary dictionary;

	public CsheqFixObjectTest() throws ConfigError {
		dictionary = new DataDictionary("src/main/resources/dictionary/dict.xml");
	}

	public static CsheqFixObjectTest from(Entity e) throws Exception {

		CsheqFixObjectTest eFix = new CsheqFixObjectTest();

		// Ignoring certain fields as enrichment is yet to be done.
		if (e.sourceId != null)
			eFix.setField(new FirmTradeID(e.sourceId));
		if (e.executionTs != null)
			eFix.setField(new TransactTime(Date.from(e.executionTs.atZone(ZoneOffset.UTC).toInstant())));

		// typecheck will also have to be done
		if (e.info.containsKey(SECURITY_ID))
			eFix.setField(new SecurityID(e.getString(SECURITY_ID)));
		if (e.info.containsKey(SECURITY_ID_SOURCE))
			eFix.setField(new SecurityIDSource(e.getString(SECURITY_ID_SOURCE)));
		if (e.info.containsKey(TARGET_COMP_ID))
			eFix.setField(new TargetCompID(e.getString(TARGET_COMP_ID)));
		if (e.info.containsKey(CURRENCY))
			eFix.setField(new Currency(e.getDouble(CURRENCY).toString()));
		if (e.info.containsKey(EXEC_TYPE))
			eFix.setField(new ExecType(e.getString(EXEC_TYPE).charAt(0)));
		if (e.info.containsKey(SECURITY_EXCHANGE))
			eFix.setField(new SecurityExchange(e.getString(SECURITY_EXCHANGE)));
		if (e.info.containsKey(SENDER_COMP_ID))
			eFix.setField(new SenderCompID(e.getString(SENDER_COMP_ID)));
		if (e.info.containsKey(TARGET_SUB_ID))
			eFix.setField(new TargetSubID(e.getString(TARGET_SUB_ID)));
		if (e.info.containsKey(LAST_QTY))
			eFix.setField(new LastQty(e.getDouble(LAST_QTY)));
		if (e.info.containsKey(LAST_PX))
			eFix.setField(new LastPx(e.getDouble(LAST_PX)));
		if (e.info.containsKey(TRADE_DATE))
			eFix.setField(new TradeDate(e.getLocalDate(TRADE_DATE).toString()));
		if (e.info.containsKey(Trade_Report_Trans_Type))
			eFix.setField(new TradeReportTransType(e.getInteger(Trade_Report_Trans_Type)));
		if (e.info.containsKey(Z_EXEC_ID))
			eFix.setField(new TradeReportID(e.getString(Z_EXEC_ID)));
		if (e.info.containsKey(EXEC_ID))
			eFix.setField(new SecondaryTradeID(e.getString(EXEC_ID)));
		if (e.info.containsKey(Trade_Report_Type))
			eFix.setField(new TradeReportType(e.getInteger(Trade_Report_Type)));
		if (e.info.containsKey(Venue_Type))
			eFix.setField(new VenueType(e.getString(Venue_Type).charAt(0)));
		if (e.info.containsKey(Trade_Type))
			eFix.setField(new TrdType(e.getInteger(Trade_Type)));
		if (e.info.containsKey(Trade_Publish_indicator))
			eFix.setField(new TradePublishIndicator(e.getInteger(Trade_Publish_indicator)));
		if (e.info.containsKey(Trade_Handling_Instr))
			eFix.setField(new TradeHandlingInstr(e.getString(Trade_Handling_Instr).charAt(0)));
		if (e.info.containsKey(Match_Type))
			eFix.setField(new MatchType(e.getString(Match_Type)));
		if (e.info.containsKey(Trade_SubType))
			eFix.setField(new TrdSubType(e.getInteger(Trade_SubType)));
		if (e.info.containsKey(Secondary_Trade_Type))
			eFix.setField(new SecondaryTrdType(e.getInteger(Secondary_Trade_Type)));
		if (e.info.containsKey(ORDER_CAPACITY))
			eFix.setField(new OrderCapacity(e.getString(ORDER_CAPACITY).charAt(0)));
		if (e.info.containsKey(SETTL_DATE))
			eFix.setField(new SettlDate(e.getString(SETTL_DATE)));
		if (e.info.containsKey(NO_PARTY_IDS)) {
			eFix.setField(new quickfix.field.NoPartyIDs(e.getInteger(NO_PARTY_IDS).intValue()));
			quickfix.fix43.TradeCaptureReportRequest.NoPartyIDs noPartyIDs = new quickfix.fix43.TradeCaptureReportRequest.NoPartyIDs();
			if (e.info.containsKey(PARTY_ID))
				noPartyIDs.set(new quickfix.field.PartyID((String) e.info.get(PARTY_ID)));
			if (e.info.containsKey(PARTY_ID_SOURCE))
				noPartyIDs.set(new quickfix.field.PartyIDSource((char) e.info.get(PARTY_ID_SOURCE)));
			if (e.info.containsKey(PARTY_ROLE))
				noPartyIDs.set(new quickfix.field.PartyRole((Integer) e.info.get(PARTY_ROLE)));
			eFix.addGroup(noPartyIDs);

		}

		if (e.info.containsKey(NO_SIDES)) {
			eFix.setField(new quickfix.field.NoSides(e.getInteger(NO_SIDES).intValue()));
			NoSides noSides = new NoSides();
			if (e.info.containsKey(SIDE))
				noSides.set(new quickfix.field.Side((char) e.info.get(SIDE)));
			eFix.addGroup(noSides);
		}

		// Headers
		if (e.info.containsKey(SENDER_COMP_ID))
			eFix.setField(new SenderCompID(e.getString(SENDER_COMP_ID)));
		if (e.info.containsKey(MSGSEGNUM))
			eFix.setField(new MsgSeqNum(e.getInteger(MSGSEGNUM)));
		if (e.info.containsKey(MSG_TYPE))
			eFix.setField(new MsgType(e.getString(MSG_TYPE)));
		if (e.info.containsKey(BEGIN_STRING))
			eFix.setField(new BeginString(e.getString(BEGIN_STRING)));

		if (e.info.containsKey(BODY_LENGTH))
			eFix.setField(new BodyLength(e.getInteger(BODY_LENGTH)));
		if (e.info.containsKey(CHECKSUM))
			eFix.setField(new CheckSum(e.getString(CHECKSUM)));
		if (e.info.containsKey(SENDINGTIME))
			eFix.setField(new SendingTime(
					Date.from(e.getLocalDate(SENDINGTIME).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant())));

		if (e.info.containsKey(GROSS_TRADE_AMT))
			eFix.setField(new GrossTradeAmt(e.getDouble(GROSS_TRADE_AMT)));
		if (e.info.containsKey(TRADEID))
			eFix.setField(new TradeID(e.getString(TRADEID)));

		// Custom QuickFix Objects

		if (e.info.containsKey(NO_TRD_PRC_CONDITION))
			eFix.setField(new NoTradePriceConditions(e.getInteger(NO_TRD_PRC_CONDITION)));
		if (e.info.containsKey(ALGORITHMIC_TRD_INDICATOR))
			eFix.setField(new AlgorithmicTradeIndicator(e.getInteger(ALGORITHMIC_TRD_INDICATOR)));
		if (e.info.containsKey(EXECMETHOD))
			eFix.setField(new ExecMethod(e.getInteger(EXECMETHOD)));
		if (e.info.containsKey(TRD_PRC_CONDITION))
			eFix.setField(new TradePriceCondition(e.getString(TRD_PRC_CONDITION)));
		if (e.info.containsKey(TRD_REG_PUBLICATION_REASONS))
			eFix.setField(new TrdRegPublicationReasons(e.getInteger(TRD_REG_PUBLICATION_REASONS)));
		if (e.info.containsKey(TRADINGSESSIONSUBID))
			eFix.setField(new TradingSessionSubID(e.getString(TRADINGSESSIONSUBID)));
		if (e.info.containsKey(TRADINGSESSIONSUBID))
			eFix.setField(new TradingSessionSubID(e.getString(TRADINGSESSIONSUBID)));
		if (e.info.containsKey(EXECINST))
			eFix.setField(new ExecInst(e.getString(EXECINST)));
		if (e.info.containsKey(EXECINST))
			eFix.setField(new ExecInst(e.getString(EXECINST)));
		if (e.info.containsKey(SYMBOL))
			eFix.setField(new Symbol(e.getString(SYMBOL)));
		if (e.info.containsKey(SETTLTYPE))
			eFix.setField(new SettlType(e.getString(SETTLTYPE)));
		eFix.dictionary.validate(eFix, true);
		eFix.message = eFix.toString();

		return eFix;
	}
}
