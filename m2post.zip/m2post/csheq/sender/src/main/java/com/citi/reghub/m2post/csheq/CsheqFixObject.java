package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CONTRA_PARTYID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXECMETHOD;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_INST;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.GROSS_TRADE_AMT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_PX;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Match_Type;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_TRD_PRC_CONDITION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OTC_POST_TRADE_INDICATOR;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_EXCHANGE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ID_SOURCE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SIDE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SYMBOL;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADED_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADEID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_REPORT_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADINGSESSIONSUBID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRANSACT_TIME;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRD_PRC_CONDITION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRD_REG_PUBLICATION_REASONS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Trade_Handling_Instr;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Trade_Report_Trans_Type;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Trade_Report_Type;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Trade_Type;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_CAPACITY;



import java.time.ZoneOffset;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;

import quickfix.ConfigError;
import quickfix.DataDictionary;
import quickfix.custom.field.AlgorithmicTradeIndicator;
import quickfix.custom.field.ExecMethod;
import quickfix.custom.field.NoTradePriceConditions;
import quickfix.custom.field.TradePriceCondition;
import quickfix.custom.field.TrdRegPublicationReasons;
import quickfix.field.Account;
import quickfix.field.Currency;
import quickfix.field.ExecInst;
import quickfix.field.ExecType;
import quickfix.field.GrossTradeAmt;
import quickfix.field.LastPx;
import quickfix.field.LastQty;
import quickfix.field.MatchType;
import quickfix.field.OrderCapacity;
import quickfix.field.PartyID;
import quickfix.field.PartyIDSource;
import quickfix.field.PartyRole;
import quickfix.field.SecondaryTrdType;
import quickfix.field.SecurityExchange;
import quickfix.field.SecurityID;
import quickfix.field.SecurityIDSource;
import quickfix.field.Side;
import quickfix.field.Symbol;
import quickfix.field.TradeDate;
import quickfix.field.TradeHandlingInstr;
import quickfix.field.TradeID;
import quickfix.field.TradePublishIndicator;
import quickfix.field.TradeReportID;
import quickfix.field.TradeReportTransType;
import quickfix.field.TradeReportType;
import quickfix.field.TradingSessionSubID;
import quickfix.field.TransactTime;
import quickfix.field.TrdSubType;
import quickfix.field.TrdType;
import quickfix.field.VenueType;
import quickfix.fix50.RequestForPositions.NoPartyIDs;
import quickfix.fix50.TradeCaptureReport;

@SuppressWarnings("serial")
public class CsheqFixObject extends TradeCaptureReport {

	public String message = "";
	private static DataDictionary dictionary;
	private static final Logger LOG = LoggerFactory.getLogger(CsheqFixObject.class);
	
	static {
   		try {
   			dictionary = new DataDictionary("src/main/resources/dictionary/DictNew.xml");
   		} catch(Exception e) {
   			LOG.error(e.getMessage());
   			
   		}
   	}

	private CsheqFixObject(Entity e) throws ConfigError {
		super();
		
		
		if (e.info.containsKey(SECURITY_ID_SOURCE)) this.setField(new SecurityIDSource(Integer.toString(e.getInteger(SECURITY_ID_SOURCE))));
		
		
		if (e.info.containsKey(CURRENCY)) this.setField(new Currency(e.getString(CURRENCY)));
		if (e.info.containsKey(SECURITY_ID)) this.setField(new SecurityID(e.getString(SECURITY_ID)));
        
        if (e.info.containsKey(LAST_PX)) this.setField(new LastPx(e.getDouble(LAST_PX)));
        if (e.info.containsKey(TRADED_QTY)) this.setField(new LastQty(e.getDouble(TRADED_QTY)));
        if (e.info.containsKey(TRANSACT_TIME))   this.setField(new TransactTime(Date.from(e.executionTs.atZone(ZoneOffset.UTC).toInstant())));
        if (e.info.containsKey(Trade_Report_Trans_Type)) this.setField(new TradeReportTransType(e.getInteger(Trade_Report_Trans_Type)));
        //TODO need to check they key for TRADE_REPORT_ID
        if (e.info.containsKey(TRADE_REPORT_ID)) this.setField(new TradeReportID(e.getString(TRADE_REPORT_ID)));
        if (e.info.containsKey(Match_Type))      this.setField(new MatchType(e.getString(Match_Type)));
        if (e.info.containsKey(OTC_POST_TRADE_INDICATOR))      this.setField(new TrdSubType(e.getString(OTC_POST_TRADE_INDICATOR).charAt(0)));
        //TODO check duplicacy of key, same as FIXOBJECT
        if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new SecondaryTrdType(e.getInteger(OTC_POST_TRADE_INDICATOR)));
        if (e.info.containsKey(TRADEID)) this.setField(new TradeID(e.getString(TRADEID)));
        if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new TradePublishIndicator(e.getInteger(OTC_POST_TRADE_INDICATOR)));
      //custom field Hardcoded to O=off book as per TradeEcho spec
        
        this.setField(new VenueType('O'));
        if (e.info.containsKey(NO_TRD_PRC_CONDITION)) this.setField(new NoTradePriceConditions(e.getInteger(NO_TRD_PRC_CONDITION)));
        if (e.info.containsKey(TRD_PRC_CONDITION)) this.setField(new TradePriceCondition(e.getString(TRD_PRC_CONDITION)));
        if (e.info.containsKey(EXECMETHOD))      this.setField(new ExecMethod(e.getInteger(EXECMETHOD)));
        if (e.info.containsKey(OTC_POST_TRADE_INDICATOR)) this.setField(new AlgorithmicTradeIndicator(e.getInteger(OTC_POST_TRADE_INDICATOR)));
        /**************************************** Party and Side Groups ****************************************/
        
        
        //Hardcoded as per Trade Echo specs as number of sides will always be 2 Executing Firm and Contra Firm
        this.setField(new quickfix.field.NoSides(1));
        NoSides noSides = new NoSides();
        // TODO below two if loops needs clarification 
        if (e.info.containsKey("side"))   noSides.set(new Side(e.getString(SIDE).equalsIgnoreCase("SELL")?'1':'2'));
        if (e.info.containsKey("noSides.orderId")) noSides.set(new quickfix.field.OrderID("ASAGF245F"));
        this.addGroup(noSides);
        
        if (e.info.containsKey(ACCOUNT)) this.setField(new Account(e.getString(ACCOUNT)));
        
        NoPartyIDs noPartyIDs1=new NoPartyIDs();
        
        //     Hard coding the field to N i.e. Legal Entity Identifier.
           noPartyIDs1.set(new PartyIDSource('N'));
           noPartyIDs1.set(new PartyRole(1));
           this.addGroup(noPartyIDs1);
           
           NoPartyIDs noPartyIDs2=new NoPartyIDs();
           // Hard coding the field to N i.e. Legal Entity Identifier.
           noPartyIDs2.setField(new PartyIDSource('N'));

      // Hardcoding the partyIds to 1 as per TradeEcho specs.
           
           
           if (e.info.containsKey(CONTRA_PARTYID)) noPartyIDs2.setField(new PartyID(e.getString(CONTRA_PARTYID)));
           
           if (e.info.containsKey(TRADINGSESSIONSUBID))this.setField(new TradingSessionSubID(e.getString(TRADINGSESSIONSUBID)));
        
        
       //TODO Add the new attributes
           
           if (e.info.containsKey(EXEC_INST))this.setField(new ExecInst(e.getString(EXEC_INST)));
           if (e.info.containsKey(SYMBOL))this.setField(new Symbol(e.getString(SYMBOL)));
           if (e.info.containsKey(TRADE_DATE))this.setField(new TradeDate(e.getString(TRADE_DATE)));
           
           
           if (e.info.containsKey(EXEC_TYPE))this.setField(new ExecType(e.getString(EXEC_TYPE).charAt(0)));
           
           if (e.info.containsKey(SECURITY_EXCHANGE))this.setField(new SecurityExchange(e.getString(SECURITY_EXCHANGE)));
           
           if (e.info.containsKey(GROSS_TRADE_AMT))this.setField(new GrossTradeAmt(e.getDouble(GROSS_TRADE_AMT)));
           
           if (e.info.containsKey(Trade_Type))this.setField(new TrdType(e.getInteger(Trade_Type)));
           
           if (e.info.containsKey(Trade_Report_Type))this.setField(new TradeReportType(e.getInteger(Trade_Report_Type)));
           
         //TODO key is char type need to updated parnet obejct or else
           if (e.info.containsKey(Trade_Handling_Instr))this.setField(new TradeHandlingInstr(e.getString(Trade_Handling_Instr).charAt(0)));
           
           if (e.info.containsKey(TRD_REG_PUBLICATION_REASONS))this.setField(new TrdRegPublicationReasons(e.getInteger(TRD_REG_PUBLICATION_REASONS)));
           
           if (e.info.containsKey(ORDER_CAPACITY))this.setField(new OrderCapacity(e.getString(ORDER_CAPACITY).charAt(0)));
           
          
	
           // TODO OrderCapcity quickfix.field.OrderCapacity

	}

	public static CsheqFixObject from(Entity e) throws Exception {
		CsheqFixObject eFix = new CsheqFixObject(e);
		dictionary.validate(eFix, true);
		eFix.message = eFix.toString();

		return eFix;
	}

	
	
	
}
