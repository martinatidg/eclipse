package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_MSG_GEN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_MSG_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_PUBLISH_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_PUBLLISH_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SENDER_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SENDER_SPOUT_ID;

import java.util.Map;

import org.apache.storm.Config;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.FixMsgGenerationBolt;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.constants.RegulatoryReportingBody;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

public class CsheqSenderTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
		String env = "local";
		if (args.length != 0) {
			env = args[1];
		}
		new CsheqSenderTopology().runTopology(args);
	}

	public Config getTopologyConfig() {
		Config config = new Config();
		config.setDebug(true);
		return config;
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		final TopologyBuilder tp = new TopologyBuilder();
		String inputTopicNames = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String fixMessagePublishTopicName= topologyConfig.get(FIX_MSG_TOPIC_NAME);
		String rawOutboundMessageTopicName = topologyConfig.get(RAW_OUTBOUND_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		
		tp.setSpout(SENDER_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(inputTopicNames, INBOUND_M2POST_SENDER_STORM_STREAM, topologyConfig), 1);
		tp.setBolt(FIX_MSG_GEN_BOLT_ID, new FixMsgGenerationBolt(RawOutboundRecord.OutboundMessageType.FIX,
				RegulatoryReportingBody.APA, new CsheqEntityToFixConverter()))
				.shuffleGrouping(SENDER_SPOUT_ID, INBOUND_M2POST_SENDER_STORM_STREAM);
		
		tp.setBolt(FIX_PUBLISH_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(fixMessagePublishTopicName, FIX_PUBLLISH_BOLT_NAME, topologyConfig), 2)
		.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.FIX_MSG);
		tp.setBolt(RAW_MSG_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(rawOutboundMessageTopicName,RAW_MSG_OUTBOUND_BOLT_NAME,topologyConfig ), 2)
		.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.RAW_OUTBOUND_OBJECT);
		tp.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME,topologyConfig), 2)
		.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.AUDIT);
		
		return tp.createTopology();
	}
}