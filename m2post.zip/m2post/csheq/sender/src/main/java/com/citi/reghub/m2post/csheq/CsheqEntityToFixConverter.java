package com.citi.reghub.m2post.csheq;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.converter.ConvertRecordToString;

public class CsheqEntityToFixConverter implements ConvertRecordToString, Serializable {

	final String delimiter= "^B";
	private static final long serialVersionUID = 6842509178329170127L;
	protected static final Logger LOG = LoggerFactory.getLogger(CsheqEntityToFixConverter.class);

	@Override
	public String convert(List<Entity> entityList) throws Exception {

		List<CsheqFixObject> entityFixList = new ArrayList<CsheqFixObject>();
		List<String> fixMsgs = new ArrayList<String>();

		for (Entity entity : entityList) {
			entityFixList.add(CsheqFixObject.from(entity));
		}

		fixMsgs = entityFixList.stream().map(e -> e.toString()).collect(Collectors.toList());

		String message = "";
		for (String m : fixMsgs) {
			message = message + delimiter + m;
		}
		return message;
	}

	@Override
	public String convert(List<Entity> entity, Boolean headerRequired) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
