# M2POST Cash FI Topology

Processing Pipeline build in Apache Storm for real-time processing 


# Getting started

## Prerequisites

To run topology you need `java-1.8`, `python-2.7` and `git` installed and in your user's `PATH`.  Also, you need `kafka`, `mongo-db` running.


## Running unit test
		
		$ mvn test
		

## Running topology on local

		$ storm jar target\m2post-cshfi-domain-1.0.0-SNAPSHOT-jar-with-dependencies.jar com.citi.reghub.m2post.cshfi.M2POCshFiTopology


## Running topology on remote

		$ storm jar target\m2post-cshfi-domain-1.0.0-SNAPSHOT-jar-with-dependencies.jar com.citi.reghub.m2post.cshfi.M2POCshFiTopology arg1 arg2