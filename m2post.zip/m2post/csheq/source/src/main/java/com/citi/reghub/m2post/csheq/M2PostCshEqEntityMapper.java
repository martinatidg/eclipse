package com.citi.reghub.m2post.csheq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;

/**
 * This class transforms the incoming FIX Message Java representation to the corresponding
 * RegHub Entity Domain Object 
 * @author pg60809
 *
 */
public class M2PostCshEqEntityMapper extends M2PostCshEqCitiFIXToEntityMapper {

	private static final long serialVersionUID = 3835959589944237085L;

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCshEqEntityMapper.class);
	
	/**
	 * Constructor To Set the Flow and Stream.
	 * @param stream
	 * @param flow
	 */
	public M2PostCshEqEntityMapper(String stream, String flow) {
		super(stream, flow);
	}
	
	/**
	 * This methods populates the Entity Objects and its a two step process:
	 * 1. Populates all the Entity Instance Feilds.
	 * 2. Populates the Embedded info Map object with corresponding key value pairs.
	 */
	/* (non-Javadoc)
	 * @see com.citi.reghub.m2post.commons.mappers.AbstractCitiFIXToEntityMapper#mapToEntity(java.lang.Object, com.citi.reghub.core.Entity)
	 */
	@Override
	public Entity mapToEntity(Object message, Entity entity) {

		LOG.info("Mapping for Input FIX message [Message Object] to Entity Domain object started ...");
		
		super.mapToEntity(message, entity);
		
		setZExecId(entity, citifixTrade);
		setCloRdId(entity, citifixTrade);
		setExecType(entity, citifixTrade);
		setExDestination(entity, citifixTrade);
		setExecLinkId(entity, citifixTrade);
		setExecId(entity, citifixTrade);
		setExecRefId(entity, citifixTrade);
		setLastPx(entity, citifixTrade);
		setLastQty(entity, citifixTrade);
		setOrderCapacity(entity, citifixTrade);
		setOrderId(entity, citifixTrade);
		setSetlDate(entity, citifixTrade);
		setTraderIdInfo(entity, citifixTrade);
		setTradingAcct(entity, citifixTrade);
		setBargainConditions(entity, citifixTrade);
		setContraAccount(entity, citifixTrade);
		setSenderCompId(entity, citifixTrade);
		setTargetCompId(entity, citifixTrade);
		setTargetSubId(entity, citifixTrade);
		setOrdStatus(entity, citifixTrade);
		setLastCapacity(entity, citifixTrade);
		setSymbol(entity, citifixTrade);
		setAcceptedTimeStamp(entity, citifixTrade);
		setNoOfContarBrokers(entity, citifixTrade);
		setContraBrokers(entity, citifixTrade);
		setSrcSystemId(entity, citifixTrade);
		setSecurityId(entity, citifixTrade);
		setSecurityIdSource(entity, citifixTrade);
		setSide(entity, citifixTrade);
		setLastMkt(entity, citifixTrade);
		setPrice(entity, citifixTrade);
		setTradeDate(entity, citifixTrade);
		setOrderQty(entity, citifixTrade);
		setSecAltIdDetails(entity, citifixTrade);
		setCurrency(entity, citifixTrade);
		setNoTempContraBrokers(entity, citifixTrade);
		setExecComments(entity, citifixTrade);
		setAvgPriceAcct(entity, citifixTrade);
		setSalesPersonId(entity, citifixTrade);
		setExecutedBy(entity, citifixTrade);
		setOverrrideFlag(entity, citifixTrade);
		setRelatedmarketCenter(entity, citifixTrade);
		setCrossId(entity, citifixTrade);
		setClearingAccount(entity, citifixTrade);
		setSecurityExchange(entity, citifixTrade);
		setSetlCurrency(entity, citifixTrade);
		setReportToExch(entity, citifixTrade);
		setSymbolsFx(entity, citifixTrade);
		setSenderSubId(entity, citifixTrade);
		setAccountGrpInfo(entity, citifixTrade);
		setInstrIdentCode(entity,citifixTrade);
		setInstrIdentCodeType(entity,citifixTrade);
		
		entity.generateRegReportingRef();
		
		LOG.info("Mapping for Input FIX message [Message Object] to Entity Domain object completed ...");
		
		return entity;
	}

}
