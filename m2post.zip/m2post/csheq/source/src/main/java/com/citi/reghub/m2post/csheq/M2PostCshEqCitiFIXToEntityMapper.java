package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ACCEPTED_TIMESTAMP;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.AVG_PRICE_ACCT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.BARGAIN_CONDITIONS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CLEARING_ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CLO_RD_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CONTRA_ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CONTRA_BROKER;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CROSS_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXECUTED_BY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_COMMENTS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_LINK_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_REF_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EX_DESTINATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_CAPACITY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_MKT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_PX;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTEMPCONTRABROKERS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_CONTRA_BROKERS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_CAPACITY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORD_STATUS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OVERRIDE_FLAG;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.RELATED_MARKET_CENTER;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.REPORT_TO_EXCH;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SALES_PERSON_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_EXCHANGE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ID_SOURCE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SENDER_COMP_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SENDER_SUB_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SETTL_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SETTL_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SIDE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SRC_SYSTEM_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SYMBOL;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SYMBOLS_FX;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TARGET_COMP_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TARGET_SUB_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADING_ACCT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Z_EXEC_ID;
import static  com.citi.reghub.m2post.utils.constants.M2PostConstants.*;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.get.rio.intf.RIODistributionMsg;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.constants.EntityStatus;
import com.citigroup.get.quantum.intf.ParseException;

/**
 * This is an abstract for transforming the incoming CITIFIX to Entity Domain
 * Object. It provide Impls for the common attributes, specific ones needs to be
 * overridden.
 * 
 * @author pg60809
 *
 */
public class M2PostCshEqCitiFIXToEntityMapper implements EntityMapper {

	private static final long serialVersionUID = 7541674854006811210L;

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCshEqCitiFIXToEntityMapper.class);

	private String flow;
	private String stream;
	protected RIODistributionMsg citifixTrade;

	/**
	 * This methods populates the Entity Objects and its a two step process: 1.
	 * Populates all the Entity Instance Feilds. 2. Populates the Embedded info
	 * Map object with corresponding key value pairs. 3. Populates the feilds in
	 * Entity using TAG objects
	 * 
	 * @param stream
	 * @param flow
	 */
	public M2PostCshEqCitiFIXToEntityMapper(String stream, String flow) {
		this.flow = flow;
		this.stream = stream;
	}

	/**
	 * 
	 */
	@Override
	public Entity mapToEntity(Object RIODistributionMsg, Entity entity) {

		citifixTrade = (RIODistributionMsg) RIODistributionMsg;
		populateMandatoryEntityAttributesFromInputRIOMessage(entity, citifixTrade);

		return entity;
	}

	/**
	 * This method maps all the required feilds in Entity Domain Object from
	 * input RIODistributionMsg Object.
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void populateMandatoryEntityAttributesFromInputRIOMessage(Entity entity, RIODistributionMsg citifixTrade) {

		entity.status = EntityStatus.REPORTABLE;
		entity.flow = flow;
		entity.stream = stream;
		entity.receivedTs = LocalDateTime.now();
		entity.sourceId = citifixTrade.getTraderID();
		entity.publishedTs = citifixTrade.getOrigSendingTime() != null
				? LocalDateTime.ofInstant(citifixTrade.getOrigSendingTime().toInstant(), ZoneId.of(TIMEZONE_UTC)) : null;
		entity.sourceSystem = citifixTrade.getSrcSystemID().toString().replace(_SRCSYS_ID, "");
		entity.executionTs = citifixTrade.getTransactTime() != null ? LocalDateTime.ofInstant(citifixTrade.getTransactTime().toInstant(),ZoneId.of(TIMEZONE_UTC)) : null;
		//TODO: Below hard coding needs to be removed for message status
		entity.sourceStatus = "NEW";
	}

	/**
	 * 
	 * @param entity
	 * @param inputFieldValue
	 * @param entityInfoKey
	 */
	private void populateEntityInfoUsingFeildsFormTradeObject(Entity entity, Object inputFieldValue,
			String entityInfoKey) {

		if (null != inputFieldValue) {
			entity.info.put(entityInfoKey, inputFieldValue);
		}

	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 * @param entityInfoKey
	 * @param tagNumber
	 */
	private void populateEntiyInforUsingTagNumber(Entity entity, RIODistributionMsg citifixTrade, String entityInfoKey,int tagNumber) {

		if (!StringUtils.isBlank(citifixTrade.getTag(tagNumber))) {
			entity.info.put(entityInfoKey, citifixTrade.getTag(tagNumber));
		}

	}

	/**
	 * Populate ZExecID
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setZExecId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getZExecID(), Z_EXEC_ID);
	}

	/**
	 * Set Symbol from CITI FX RIODistributionMsg in Entity Object
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSymbolsFx(Entity entity, RIODistributionMsg citifixTrade) {
		
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSymbolSfx(), SYMBOLS_FX);
	}

	/**
	 * Set sec exchange from CITI FX RIODistributionMsg in Entity Object
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSecurityExchange(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSecurityExchange(), SECURITY_EXCHANGE);
	}

	/**
	 * Set cross id from CITI FX RIODistributionMsg in Entity Object
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setCrossId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getCrossID(), CROSS_ID);
	}

	/**
	 * Set rel mkt center from CITI FX RIODistributionMsg in Entity Object
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setRelatedmarketCenter(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getRelatedMarketCenter(), RELATED_MARKET_CENTER);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOverrrideFlag(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntiyInforUsingTagNumber(entity, citifixTrade, OVERRIDE_FLAG, 9854);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecutedBy(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject (entity, citifixTrade.getExecutedBy(), EXECUTED_BY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSalesPersonId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject (entity, citifixTrade.getSalesPersonID(), SALES_PERSON_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setAvgPriceAcct(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getAvgPriceAcct(), AVG_PRICE_ACCT);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecComments(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExecComments(), EXEC_COMMENTS);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setNoTempContraBrokers(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getTempContraBrokersGrp(), NOTEMPCONTRABROKERS);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setContraBrokers(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getTempContraBrokersGrp(), CONTRA_BROKER);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setNoOfContarBrokers(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getContraGrp(), NO_CONTRA_BROKERS);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrdStatus(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getOrderStatus(), ORD_STATUS);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setContraAccount(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getContraAccount(), CONTRA_ACCOUNT);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setBargainConditions(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getBargainConditions(), BARGAIN_CONDITIONS);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradingAcct(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getTradingAcct(), TRADING_ACCT);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrderId(Entity entity, RIODistributionMsg citifixTrade) {
		String orderId = citifixTrade.getOrderID();
		populateEntityInfoUsingFeildsFormTradeObject(entity, orderId, ORDER_ID);
		if (StringUtils.isBlank(entity.sourceId) && !(StringUtils.isBlank(orderId))) {
			entity.sourceId = orderId;
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrderCapacity(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getOrderCapacity(), ORDER_CAPACITY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExecID(), EXEC_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecLinkId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExecLinkID(), EXEC_LINK_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExDestination(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExDestination(), EX_DESTINATION);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecType(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExecType(), EXEC_TYPE);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setCloRdId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getClOrdID(), CLO_RD_ID);
	}

	/**
	 * Transforms the Accepted Time stamp to DateTime format
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setAcceptedTimeStamp(Entity entity, RIODistributionMsg citifixTrade) {
		if(ObjectUtils.allNotNull(citifixTrade.getAcceptedTimeStamp())){
			if (!StringUtils.isBlank(citifixTrade.getAcceptedTimeStamp().toString())) {
				SimpleDateFormat sdf = new SimpleDateFormat(ACCEPTED_TIMESTAMP_FORMAT);
				Date parsedDate;
				try {
					parsedDate = sdf.parse(citifixTrade.getAcceptedTimeStamp().toString());
					Calendar convertedToCalendar = Calendar.getInstance();
					convertedToCalendar.setTime(parsedDate);
					entity.info.put(ACCEPTED_TIMESTAMP,
							LocalDateTime.ofInstant(convertedToCalendar.toInstant(), ZoneId.systemDefault()).toLocalDate());
				} catch (UnsupportedOperationException e) {
					LOG.error("UnsupportedOperationException occurred while parsing accepted Timestamp field : " + e);
					throw e;
				} catch (ParseException e) {
					LOG.error("ParseException occurred while parsing accepted Timestamp field : " + e);
					throw e;
				} catch (java.text.ParseException e) {
					LOG.error("java.text.ParseException occurred while parsing accepted Timestamp field : " + e);
					throw new RuntimeException(
							"java.text.ParseException occurred while parsing accepted Timestamp field : " + e);
				}
			}
		}
	}


	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setAccountGrpInfo(Entity entity, RIODistributionMsg citifixTrade) {
		//TODO; Account group???
	/*	Arrays.stream(Optional.ofNullable(citifixTrade.getacctg()).orElse(new AccountGrp[0]))
				.forEach(accountGroup -> {
					entity.info.put(ACCOUNT + "~" + accountGroup.getAccount(), accountGroup.getAccount());
				});*/
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSenderSubId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSenderSubID(), SENDER_SUB_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setReportToExch(Entity entity, RIODistributionMsg citifixTrade) {
		
		if (null != citifixTrade.getReportToExch()) {
			entity.info.put(REPORT_TO_EXCH, citifixTrade.getReportToExch().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSetlCurrency(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSettlCurrency(), SETTL_CURRENCY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setClearingAccount(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getClearingAccount(), CLEARING_ACCOUNT);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setCurrency(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getCurrency(), CURRENCY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSecAltIdDetails(Entity entity, RIODistributionMsg citifixTrade) {
		//TODO: seciruty Alt group??
		/*Arrays.stream(Optional.ofNullable(citifixTrade.getsecurityaltgr()).orElse(new SecAltIDGrp[0]))
				.forEach(secAltIDGrp -> {
					entity.info.put(SECURITY_ALT_ID + "~" + secAltIDGrp.getSecurityAltIDSource(),
							secAltIDGrp.getSecurityAltID());
					entity.info.put(SECURITY_ALT_ID_SOURCE + "~" + secAltIDGrp.getSecurityAltID(),
							secAltIDGrp.getSecurityAltIDSource() != null
									? secAltIDGrp.getSecurityAltIDSource().toString() : null);
				});*/
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setOrderQty(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getOrderQty(), ORDER_QTY);
	}


	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTradeDate(Entity entity, RIODistributionMsg citifixTrade) {
		if (null != citifixTrade.getTradeDate()) {
			entity.info.put(TRADE_DATE, LocalDateTime.ofInstant(citifixTrade.getTradeDate().toInstant(), ZoneId.systemDefault()).toLocalDate());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setPrice(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getPrice(), PRICE);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastMkt(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getLastMkt(), LAST_MKT);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSide(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSide().toString(), SIDE);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSecurityIdSource(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSecurityIDSource().value(), SECURITY_ID_SOURCE);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSecurityId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSecurityID(), SECURITY_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSrcSystemId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSrcSystemID(), SRC_SYSTEM_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastCapacity(Entity entity, RIODistributionMsg citifixTrade) {
		if(citifixTrade.getLastCapacity() != null && !StringUtils.isBlank(citifixTrade.getLastCapacity().value()))
		{	
			entity.info.put(LAST_CAPACITY, citifixTrade.getLastCapacity().value());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTargetSubId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getTargetSubID(), TARGET_SUB_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTargetCompId(Entity entity, RIODistributionMsg citifixTrade) {
		//TODO: To be HARDCODED as per environment SRRECHO or SRRECHOTEST
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getTargetCompID(), TARGET_COMP_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSenderCompId(Entity entity, RIODistributionMsg citifixTrade) {
		// TODO : To be HARDCODED with M2POST TradeEcho User ID
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSenderCompID(), SENDER_COMP_ID);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setTraderIdInfo(Entity entity, RIODistributionMsg citifixTrade) {
		//TODO : Trader Group??
		/*Arrays.stream(Optional.ofNullable(citifixTrade.getTraderGrp()).orElse(new TraderGrp[0])).forEach(traderGrp -> {
			entity.info.put(TRADER_ID + "~" + traderGrp.getTraderID(), traderGrp.getTraderID());
		});*/
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setSetlDate(Entity entity, RIODistributionMsg citifixTrade) {
		if (null != citifixTrade.getSettlDate()) {
			entity.info.put(SETTL_DATE, LocalDateTime.ofInstant(citifixTrade.getSettlDate().toInstant(), ZoneId.systemDefault()).toLocalDate());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastQty(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getLastQty(), LAST_QTY);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setLastPx(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getLastPx(), LAST_PX);
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setExecRefId(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getExecRefID(), EXEC_REF_ID);
	}

	protected void setSymbol(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSymbol(), SYMBOL);
	}
	
	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setInstrIdentCodeType(Entity entity, RIODistributionMsg citifixTrade) {
		if(null != citifixTrade.getSecurityIDSource()) {
			entity.info.put(INSTR_IDENT_CODE_TYPE, citifixTrade.getSecurityIDSource().toString());
		}
	}

	/**
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	protected void setInstrIdentCode(Entity entity, RIODistributionMsg citifixTrade) {
		populateEntityInfoUsingFeildsFormTradeObject(entity, citifixTrade.getSecurityID(), INSTR_IDENT_CODE);
	}
}
