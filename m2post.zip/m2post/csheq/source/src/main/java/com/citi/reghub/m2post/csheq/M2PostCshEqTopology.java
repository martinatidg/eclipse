package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.CITIFIX_PARSER_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.CSH_EQ_FLOW;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.MAP_TO_ENTITY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.MERGE_ENTITY_FOR_REPLAY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPLAY_DMN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPLAY_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPLAY_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RIO_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RIO_SPOUT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.STREAM;

import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EntityMapperBolt;
import com.citi.reghub.core.ReplayEntityBolt;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;
import com.citi.reghub.core.rio.spouts.RioSpout;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;



/**
 * This class creates the Topology for the Sourcing Flow from RIO to RegHib for Equities Asset Class.
 * @author pg60809
 *
 */
public class M2PostCshEqTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
        new M2PostCshEqTopology().runTopology(args);
	}

	/**
	 * The below method configures the Spouts and Bolts for the Sourcing Topology.
	 * 1. Creates a RIO spout which will read/stream the data form RIO Messaging Infrastructure.
	 * 2. Two Bolts are associated with this RIO spout : RAW Bolt and Message Parse Bolt.
	 * 	  RAW Bolt wills tore the Incoming RAW Message into Mongo through Common Service.
	 * 	  Message Bolt parses the Message to corresponding MOTRdeMessage object.
	 * 3. Once processed this data is forwarded for MOTradeMessage to Entity COnversion.
	 * 4. If any exceptions, the messages are sent to exception Queue.
	 * 
	 * @param topologyConfig
	 * @return  StormTopology
	 * @throws Exception
	 * 
	 */
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		TopologyBuilder builder = new TopologyBuilder();
		
		String sourceKafkaTopics = topologyConfig.get(REPLAY_TOPIC_NAME);
		String rawMessageTopicName = topologyConfig.get(RAW_MSG_TOPIC_NAME);
		String domainTopicName= topologyConfig.get(DOMAIN_TOPIC_NAME);
		String auditTopicName= topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);
		
		builder.setSpout(RIO_SPOUT_ID, new RioSpout(topologyConfig,RIO_SPOUT_NAME));
		
		RegHubKafkaSpout<String, String> replayKafkaSpout = RegHubKafkaSpout.builder(sourceKafkaTopics, INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM, topologyConfig)
                .setKeyDesClazz(StringDeserializer.class)
                .setValueDesClazz(StringDeserializer.class)
                .build();

		builder.setSpout(REPLAY_SPOUT_ID, replayKafkaSpout.getSpout());
		
		builder.setBolt(RAW_MSG_BOLT_ID,StormSpoutBoltGenerator.generateKafkaBolt(rawMessageTopicName, RAW_MSG_BOLT_NAME,topologyConfig))
		.shuffleGrouping(RIO_SPOUT_ID);
		
		builder.setBolt(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID, new M2PostCshEqCitifixParserBolt()).
		shuffleGrouping(REPLAY_SPOUT_ID, INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM);
		
		builder.setBolt(CITIFIX_PARSER_BOLT_ID, new M2PostCshEqCitifixParserBolt()).shuffleGrouping(RIO_SPOUT_ID);
		
		builder.setBolt(MAP_TO_ENTITY_BOLT_ID, new EntityMapperBolt(new M2PostCshEqEntityMapper(STREAM, CSH_EQ_FLOW))).shuffleGrouping(CITIFIX_PARSER_BOLT_ID, StormStreams.SOURCE);
		
		builder.setBolt(DOMAIN_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(domainTopicName, DOMAIN_BOLT_NAME,topologyConfig))
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID, StormStreams.SOURCE);
		
		builder.setBolt(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID, new EntityMapperBolt(new M2PostCshEqEntityMapper(STREAM, CSH_EQ_FLOW)))
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
	
		builder.setBolt(MERGE_ENTITY_FOR_REPLAY_BOLT_ID, new ReplayEntityBolt())
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(REPLAY_DMN_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(domainTopicName, DOMAIN_BOLT_NAME,topologyConfig))
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME,topologyConfig))
		.shuffleGrouping(CITIFIX_PARSER_BOLT_ID, StormStreams.AUDIT)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID, StormStreams.AUDIT)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID, StormStreams.AUDIT)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT);
		
		builder.setBolt(EXCEPTION_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME,topologyConfig))
		.shuffleGrouping(CITIFIX_PARSER_BOLT_ID, StormStreams.EXCEPTION)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID, StormStreams.EXCEPTION)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID, StormStreams.EXCEPTION)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION);
		
		return builder.createTopology();
	}
}
