package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ACCEPTED_TIMESTAMP;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.AVG_PRICE_ACCT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.BARGAIN_CONDITIONS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CLEARING_ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CLO_RD_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CONTRA_ACCOUNT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CONTRA_BROKER;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CROSS_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXECUTED_BY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_COMMENTS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_LINK_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_REF_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EXEC_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.EX_DESTINATION;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.INSTR_IDENT_CODE_TYPE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_CAPACITY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_MKT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_PX;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.LAST_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NOTEMPCONTRABROKERS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.NO_CONTRA_BROKERS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_CAPACITY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORDER_QTY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.ORD_STATUS;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OVERRIDE_FLAG;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.PRICE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.RELATED_MARKET_CENTER;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.REPORT_TO_EXCH;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SALES_PERSON_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ALT_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_ALT_ID_SOURCE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SECURITY_EXCHANGE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SENDER_COMP_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SENDER_SUB_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SETTL_CURRENCY;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SETTL_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SIDE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SRC_SYSTEM_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SYMBOL;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.SYMBOLS_FX;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TARGET_COMP_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TARGET_SUB_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADER_ID;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_DATE;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADING_ACCT;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.Z_EXEC_ID;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Scanner;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.Test;

import com.citi.get.rio.intf.RIODistributionMsg;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.EntityMapperBolt;
import com.citigroup.get.quantum.intf.MessageFactory;
import com.citigroup.get.zcc.intf.MessageFactoryImpl;

public class M2PostCshEqEntityMapperTest {
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	private Tuple mockNormalTuple(Object obj1, Object obj2) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("key")).thenReturn(obj1);
		when(tuple.getValueByField("message")).thenReturn(obj2);
		return tuple;
	}
	
	@SuppressWarnings({ "resource", "rawtypes", "unchecked" })
	@Test
	public void shouldPopulateEntityInfoObjectWhenInputProvidedIsAValidFIXMessage(){
		
		String fixMsg = new Scanner(getClass().getClassLoader().getResourceAsStream("m2poSampleTrade.fix")).useDelimiter("\\A").next();
		MessageFactory msgFactory = MessageFactoryImpl.getInstance();
		RIODistributionMsg parsedMsg = (RIODistributionMsg) msgFactory.getMessage(fixMsg);
		
		HashMap map = new HashMap<>();
		map.put("topology.stream.name", "M2POST");
		map.put("topology.flow.name", "CSHEQ");
		
		EntityMapper entityMapper = new M2PostCshEqEntityMapper("M2POST", "CSHEQ");
		EntityMapperBolt mapper = new EntityMapperBolt(entityMapper);
		mapper.prepare(map, mock(TopologyContext.class), mock(OutputCollector.class));
		Entity entity = mapper.createExceptionEntity(mockNormalTuple("M2POSTCSHEQ123456", parsedMsg));
		Entity output = entityMapper.mapToEntity(parsedMsg, entity);
		
		Entity expected = new EntityBuilder().build();
		
		//Assert Mandatory Attributes
		
		assertEquals(expected.executionTs, output.executionTs);
		assertEquals(expected.flow, output.flow);
		assertEquals(expected.regHubId, output.regHubId);
		assertEquals(expected.regReportingRef, output.regReportingRef);
		assertEquals(expected.sourceId, output.sourceId);
		assertEquals(expected.sourceStatus, output.sourceStatus);
		assertEquals(expected.sourceUId, output.sourceUId);
		assertEquals(expected.status, output.status);
		assertEquals(expected.stream, output.stream);
		assertEquals(expected.sourceSystem, output.sourceSystem);
		
		//Assert infoable pojo object 
		assertEquals(expected.info.get(Z_EXEC_ID), output.info.get(Z_EXEC_ID));
		assertEquals(expected.info.get(EXEC_REF_ID), output.info.get(EXEC_REF_ID));
		assertEquals(expected.info.get(LAST_PX), output.info.get(LAST_PX));
		assertEquals(expected.info.get(LAST_QTY), output.info.get(LAST_QTY));
		assertEquals(expected.info.get(SETTL_DATE), output.info.get(SETTL_DATE));
		assertEquals(expected.info.get(TRADER_ID), output.info.get(TRADER_ID));
		assertEquals(expected.info.get(SENDER_COMP_ID), output.info.get(SENDER_COMP_ID));
		assertEquals(expected.info.get(TARGET_COMP_ID), output.info.get(TARGET_COMP_ID));
		assertEquals(expected.info.get(TARGET_SUB_ID), output.info.get(TARGET_SUB_ID));
		assertEquals(expected.info.get(LAST_CAPACITY), output.info.get(LAST_CAPACITY));
		assertEquals(expected.info.get(SYMBOL), output.info.get(SYMBOL));
		assertEquals(expected.info.get(SRC_SYSTEM_ID), output.info.get(SRC_SYSTEM_ID));
		assertEquals(expected.info.get(INSTR_IDENT_CODE), output.info.get(INSTR_IDENT_CODE));
		assertEquals(expected.info.get(INSTR_IDENT_CODE_TYPE), output.info.get(INSTR_IDENT_CODE_TYPE));
		assertEquals(expected.info.get(SIDE), output.info.get(SIDE));
		assertEquals(expected.info.get(LAST_MKT), output.info.get(LAST_MKT));
		assertEquals(expected.info.get(PRICE), output.info.get(PRICE));
		assertEquals(expected.info.get(TRADE_DATE), output.info.get(TRADE_DATE));
		assertEquals(expected.info.get(ORDER_QTY), output.info.get(ORDER_QTY));
		assertEquals(expected.info.get(SECURITY_ALT_ID), output.info.get(SECURITY_ALT_ID));
		assertEquals(expected.info.get(SECURITY_ALT_ID_SOURCE), output.info.get(SECURITY_ALT_ID_SOURCE));
		assertEquals(expected.info.get(CURRENCY), output.info.get(CURRENCY));
		assertEquals(expected.info.get(CLEARING_ACCOUNT), output.info.get(CLEARING_ACCOUNT));
		assertEquals(expected.info.get(SETTL_CURRENCY), output.info.get(SETTL_CURRENCY));
		assertEquals(expected.info.get(SENDER_SUB_ID), output.info.get(SENDER_SUB_ID));
		assertEquals(expected.info.get(REPORT_TO_EXCH), output.info.get(REPORT_TO_EXCH));
		assertEquals(expected.info.get(ACCOUNT+"~"+"SAVINGS"), output.info.get(ACCOUNT+"~"+"SAVINGS"));
		
		//Assert infoable pojo objects fields created from custom map.
		assertEquals(expected.info.get(CLO_RD_ID), output.info.get(CLO_RD_ID));
		assertEquals(expected.info.get(EXEC_TYPE), output.info.get(EXEC_TYPE));
		assertEquals(expected.info.get(EX_DESTINATION), output.info.get(EX_DESTINATION));
		assertEquals(expected.info.get(EXEC_LINK_ID), output.info.get(EXEC_LINK_ID));
		assertEquals(expected.info.get(EXEC_ID), output.info.get(EXEC_ID));
		assertEquals(expected.info.get(ORDER_CAPACITY), output.info.get(ORDER_CAPACITY));
		assertEquals(expected.info.get(ORDER_ID), output.info.get(ORDER_ID));
		assertEquals(expected.info.get(TRADING_ACCT), output.info.get(TRADING_ACCT));
		assertEquals(expected.info.get(BARGAIN_CONDITIONS), output.info.get(BARGAIN_CONDITIONS));
		assertEquals(expected.info.get(CONTRA_ACCOUNT), output.info.get(CONTRA_ACCOUNT));
		assertEquals(expected.info.get(ORD_STATUS), output.info.get(ORD_STATUS));
		assertEquals(expected.info.get(ACCEPTED_TIMESTAMP), output.info.get(ACCEPTED_TIMESTAMP));
		assertEquals(expected.info.get(NO_CONTRA_BROKERS), output.info.get(NO_CONTRA_BROKERS));
		assertEquals(expected.info.get(CONTRA_BROKER), output.info.get(CONTRA_BROKER));
		assertEquals(expected.info.get(NOTEMPCONTRABROKERS), output.info.get(NOTEMPCONTRABROKERS));
		assertEquals(expected.info.get(EXEC_COMMENTS), output.info.get(EXEC_COMMENTS));
		assertEquals(expected.info.get(AVG_PRICE_ACCT), output.info.get(AVG_PRICE_ACCT));
		assertEquals(expected.info.get(EXECUTED_BY), output.info.get(EXECUTED_BY));
		assertEquals(expected.info.get(SALES_PERSON_ID), output.info.get(SALES_PERSON_ID));
		assertEquals(expected.info.get(OVERRIDE_FLAG), output.info.get(OVERRIDE_FLAG));
		assertEquals(expected.info.get(RELATED_MARKET_CENTER), output.info.get(RELATED_MARKET_CENTER));
		assertEquals(expected.info.get(CROSS_ID), output.info.get(CROSS_ID));
		assertEquals(expected.info.get(SECURITY_EXCHANGE), output.info.get(SECURITY_EXCHANGE));
		assertEquals(expected.info.get(SYMBOLS_FX), output.info.get(SYMBOLS_FX));
		
	}

}
