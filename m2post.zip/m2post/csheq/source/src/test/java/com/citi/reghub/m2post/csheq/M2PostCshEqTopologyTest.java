package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_TOPIC_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;
import com.citi.reghub.core.rio.RioPublisher;

@RunWith(JUnit4.class)
public class M2PostCshEqTopologyTest {
	
	private static final Logger LOG = LoggerFactory.getLogger(M2PostCshEqTopologyTest.class);
	private static Map<String, String> appProps;

	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(19092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(),
			EntityKafkaSerializerDeserializer.class.getCanonicalName());

	private static LocalCluster cluster;
	
	private static Properties rawInboundConsumerProps = null;
	private static Properties domainConsumerProps = null;
	private static Properties auditConsumerProps = null;
	private static String domainInputTopic = null;
	private static String rawInboundMessageTopic = null;
	private static String auditLogTopic = null;
	
	@BeforeClass
	public static void setUp() throws Exception {

		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());

		domainInputTopic = appProps.get(DOMAIN_TOPIC_NAME);
		rawInboundMessageTopic = appProps.get(RAW_MSG_TOPIC_NAME);
		auditLogTopic = appProps.get(AUDIT_TOPIC_NAME);
		
//		Thread.sleep(6000);

		domainConsumerProps = new Properties();
		domainConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		domainConsumerProps.put("auto.offset.reset", "earliest");
		domainConsumerProps.put("group.id", "domainInput_group_1");
		domainConsumerProps.put("value.deserializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		
		auditConsumerProps = new Properties();
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		
		rawInboundConsumerProps = new Properties();
		rawInboundConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		rawInboundConsumerProps.put("auto.offset.reset", "earliest");
		rawInboundConsumerProps.put("group.id", "rawinput_group_1");
		rawInboundConsumerProps.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		
		
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(false);
		conf.put("topologyConfig", appProps);
		cluster.submitTopology(M2PostCshEqTopology.class.getSimpleName(), conf,
				new M2PostCshEqTopology().buildTopology(appProps));
		// Wait till topology to get started
		Thread.sleep(15000);
	}
	
	@Test
	public void shouldConsumeMessagesFromRioAndEmitToDomainKafkaTopics() throws Exception {
		new RioPublisher().msgCount(1).publish();
		Thread.sleep(1000);
		List <Entity>domainResult= kafkaUnitRule.getKafkaUnit().consumeFromTopic(domainInputTopic, domainConsumerProps);
		assertThat(domainResult.isEmpty(), is(false));
		assertTrue(domainResult.size() >= 1);
	}
	
	@Test
	public void shouldConsumeMessagesFromRioAndEmitToAuditKafkaTopics() throws Exception {
		new RioPublisher().msgCount(1).publish();
		Thread.sleep(1000);
		List <Audit>auditResult= kafkaUnitRule.getKafkaUnit().consumeFromTopic(auditLogTopic, auditConsumerProps);
		assertThat(auditResult.isEmpty(), is(false));
		assertTrue(auditResult.size() >= 1);
	}
	
	@Test
	public void shouldConsumeMessagesFromRioAndEmitToRawInboundKafkaTopics() throws Exception {
		new RioPublisher().msgCount(1).publish();
		Thread.sleep(1000);
		List <String>rawInboundResult= kafkaUnitRule.getKafkaUnit().consumeFromTopic(rawInboundMessageTopic, rawInboundConsumerProps);
		assertThat(rawInboundResult.isEmpty(), is(false));
		assertTrue(rawInboundResult.size() >= 1);
	}
	
	@AfterClass
	public static void teardown() throws Exception {
		//cluster.killTopology(M2PostCshEqTopologyTest.class.getSimpleName());
	}
	
}
