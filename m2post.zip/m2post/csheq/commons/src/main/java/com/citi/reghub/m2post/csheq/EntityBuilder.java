package com.citi.reghub.m2post.csheq;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.citi.reghub.core.Entity;

public class EntityBuilder {
	
	private Entity entity;
	
	public EntityBuilder(){
		this.entity = new Entity();
		entity.sourceId="9876";
		entity.status="REPORTABLE";
		entity.stream="M2POST";
		entity.flow="CSHEQ";
		entity.sourceVersion="3";
		entity.sourceSystem="TPS";
		
		Calendar settlDateCal = new GregorianCalendar(2017, 3, 20, 9, 8, 16);
		Calendar tradeDateCal = new GregorianCalendar(2016, 3, 4, 10, 20, 20);
		Calendar acceptedTimeStampCal = new GregorianCalendar(2016, 2, 4, 10, 20, 20);
		
		entity.info.put(Z_EXEC_ID,"170ph");
		entity.info.put(EXEC_REF_ID, "123-asv");
		entity.info.put(LAST_PX, Double.valueOf(100.20));
		entity.info.put(LAST_QTY, Double.valueOf(500));
		entity.info.put(SETTL_DATE, LocalDateTime.ofInstant(settlDateCal.toInstant(), ZoneId.systemDefault()).toLocalDate());
		entity.info.put(SENDER_COMP_ID, "CITI");
		entity.info.put(TARGET_COMP_ID, "ICIC");
		entity.info.put(TARGET_SUB_ID, "HSBC");
		entity.info.put(LAST_CAPACITY, "R");
		entity.info.put(SYMBOL, "ALRS.MM");
		entity.info.put(SRC_SYSTEM_ID, "TPS_SRCSYS_ID");
		entity.info.put(INSTR_IDENT_CODE, "IS12345");
		entity.info.put(INSTR_IDENT_CODE_TYPE, "CUSIP");
		entity.info.put(SIDE, "SELL");
		entity.info.put(LAST_MKT, "EUR");
		entity.info.put(PRICE, Double.valueOf(120.34));
		entity.info.put(TRADE_DATE, LocalDateTime.ofInstant(tradeDateCal.toInstant(), ZoneId.systemDefault()).toLocalDate());
		entity.info.put(ORDER_QTY, Double.valueOf(50000.0));
		entity.info.put(SECURITY_ALT_ID+"~"+"SMCP", "356987");
		entity.info.put(SECURITY_ALT_ID_SOURCE+"~"+"356987", "SMCP");
		entity.info.put(CURRENCY, "AUD");
		entity.info.put(CLEARING_ACCOUNT, "12345");
		entity.info.put(SETTL_CURRENCY, "GBP");
		entity.info.put(SENDER_SUB_ID, "ABCD");
		entity.info.put(REPORT_TO_EXCH, "RPTINDF");
		entity.info.put(TRADER_ID+"~"+"P232", "P232");
		entity.info.put(ACCOUNT+"~"+"SAVINGS", "SAVINGS");
		
		entity.info.put(CLO_RD_ID, "CLORID123");
		entity.info.put(EXEC_TYPE, "SELL");
		entity.info.put(EX_DESTINATION, "LQ");
		entity.info.put(EXEC_LINK_ID, "1234.567");
		entity.info.put(EXEC_ID, "665.98");
		entity.info.put(ORDER_CAPACITY, "10");
		entity.info.put(ORDER_ID, "9876");
		entity.info.put(TRADING_ACCT, "DEPOT");
		entity.info.put(BARGAIN_CONDITIONS, "Yes");
		entity.info.put(CONTRA_ACCOUNT, "123");
		entity.info.put(ORD_STATUS, "NEW");
		entity.info.put(ACCEPTED_TIMESTAMP, LocalDateTime.ofInstant(acceptedTimeStampCal.toInstant(), ZoneId.systemDefault()).toLocalDate());
		entity.info.put(NO_CONTRA_BROKERS, 1);
		entity.info.put(CONTRA_BROKER, "1");
		entity.info.put(NOTEMPCONTRABROKERS, "2");
		entity.info.put(EXEC_COMMENTS, "Test Comments");
		entity.info.put(AVG_PRICE_ACCT, "ACCTAVG");
		entity.info.put(SALES_PERSON_ID, "SID123");
		entity.info.put(EXECUTED_BY, "SI");
		entity.info.put(OVERRIDE_FLAG, "Y");
		entity.info.put(RELATED_MARKET_CENTER, "Y");
		entity.info.put(CROSS_ID, "12345");
		entity.info.put(SECURITY_EXCHANGE, "NSE");
		entity.info.put(SYMBOLS_FX, "AUD");

		entity.regHubId=entity.stream+entity.flow+"123456";
		entity.executionTs=LocalDateTime.parse("2017-06-05 10:11:11.155", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
		entity.publishedTs=LocalDateTime.parse("2016-01-07 06:41:38.205", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
		entity.receivedTs=LocalDateTime.parse("2016-01-07 06:41:38.205", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
		entity.generateRegReportingRef();
	}
	
	public EntityBuilder regHubId(String reghubId){
		entity.regHubId = reghubId;
		return this;
	}
	
	public EntityBuilder sourceStatus(String sourceStatus){
		entity.sourceStatus = sourceStatus;
		return this;
	}
	
	public EntityBuilder sourceId(String sourceId){
		entity.sourceId = sourceId;
		return this;
	}
	
	public EntityBuilder sourceUid(String sourceUid){
		entity.sourceUId = sourceUid;
		return this;
	}
	
	public EntityBuilder executionTs(LocalDateTime executionTs){
		entity.executionTs = executionTs;
		return this;
	}
	
	public EntityBuilder publishedTs(LocalDateTime publishedTs){
		entity.publishedTs = publishedTs;
		return this;
	}
	
	public EntityBuilder receivedTs(LocalDateTime receivedTs){
		entity.receivedTs = receivedTs;
		return this;
	}
	
	public EntityBuilder sourceVersion(String sourceVersion){
		entity.sourceVersion = sourceVersion;
		return this;
	}
	
	public EntityBuilder info(String key,Object value){
		entity.info.put(key, value);
		return this;
	}
	
	public Entity build(){
		return entity;
	}

}
