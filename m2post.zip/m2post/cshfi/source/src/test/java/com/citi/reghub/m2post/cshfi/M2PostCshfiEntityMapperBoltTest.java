package com.citi.reghub.m2post.cshfi;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Scanner;
import static org.mockito.Mockito.*;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.utils.MockTupleHelpers;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.CSH_FI_FLOW;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.STREAM;
import static org.junit.Assert.*;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityMapper;
import com.citi.reghub.core.EntityMapperBolt;
import com.citigroup.get.quantum.intf.MessageFactory;
import com.citigroup.get.zcc.intf.MOTradeMessage;
import com.citigroup.get.zcc.intf.MessageFactoryImpl;

public class M2PostCshfiEntityMapperBoltTest {

	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";

	private Tuple mockNormalTuple(Object obj1, Object obj2) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("key")).thenReturn(obj1);
		when(tuple.getValueByField("message")).thenReturn(obj2);
		return tuple;
	}

	@Test
	public void test(){

		String fixMsg = new Scanner(getClass().getClassLoader().getResourceAsStream("m2poSampleTrade.fix")).useDelimiter("\\A").next();
		MessageFactory msgFactory = MessageFactoryImpl.getInstance();
		MOTradeMessage parsedMsg = (MOTradeMessage) msgFactory.getMessage(fixMsg);
		HashMap map = new HashMap<>();
		map.put("topology.stream", "m2post");
		map.put("topology.flow", "cshfi");
		EntityMapper entityMapper = new M2PostCshfiEntityMapper(STREAM, CSH_FI_FLOW);
		EntityMapperBolt mapper = new EntityMapperBolt(entityMapper);
		mapper.prepare(map, mock(TopologyContext.class), mock(OutputCollector.class));
		Entity entity = mapper.createExceptionEntity(mockNormalTuple("M2POCSHFI123456", parsedMsg));
		Entity output = entityMapper.mapToEntity(parsedMsg, entity);
		Entity expected = getM2postCshfiEntity();
		 
		assertEquals(expected.reasonCodes, output.reasonCodes);
		assertEquals(expected.executionTs, output.executionTs);
		assertEquals(expected.flow, output.flow);
		assertEquals(expected.publishedTs, output.publishedTs);
		assertEquals(expected.regHubId, output.regHubId);
		assertEquals(expected.regReportingRef, output.regReportingRef);
		assertEquals(expected.sourceId, output.sourceId);
		//assertEquals(expected.sourceStatus, output.sourceStatus);
		assertEquals(expected.sourceUId, output.sourceUId);
		assertEquals(expected.sourceVersion, output.sourceVersion);
		assertEquals(expected.status, output.status);
		assertEquals(expected.stream, output.stream);
		assertEquals(expected.sourceSystem, output.sourceSystem);
		
	/* for infor fields*/
		assertEquals(expected.info.get("quantity"), output.info.get("quantity"));
		//assertEquals(expected.info.get("cptyAccountmnemonicAccountType"), output.info.get("cptyAccountmnemonicAccountType"));
		assertEquals(expected.info.get("priceType"), output.info.get("priceType"));
		//assertEquals(expected.info.get("cptyAccountmnemonicAlternateGfc"), output.info.get("cptyAccountmnemonicAlternateGfc"));
		//assertEquals(expected.info.get("securityId"), output.info.get("securityId"));
		//assertEquals(expected.info.get("cptyAccountmnemonicNoAltAccounts"), output.info.get("cptyAccountmnemonicNoAltAccounts"));
		//assertEquals(expected.info.get("bookAccountmnemonicAccountType"), output.info.get("bookAccountmnemonicAccountType"));
		assertEquals(expected.info.get("tradeDate"), output.info.get("tradeDate"));
		//assertEquals(expected.info.get("settlementDate"), output.info.get("settlementDate"));
		//assertEquals(expected.info.get("bookAccountmnemonicAlternateGfc"), output.info.get("bookAccountmnemonicAlternateGfc"));
		//assertEquals(expected.info.get("securitySmcp"), output.info.get("securitySmcp"));
		assertEquals(expected.info.get("tradeExecType"), output.info.get("tradeExecType"));
		//assertEquals(expected.info.get("bookAccountmnemonicNoAltAccounts"), output.info.get("bookAccountmnemonicNoAltAccounts"));
		assertEquals(expected.info.get("lastMkt"), output.info.get("lastMkt"));
		assertEquals(expected.info.get("noAccounts"), output.info.get("noAccounts"));
		assertEquals(expected.info.get("price"), output.info.get("tradePrice"));
		//assertEquals(expected.info.get("securityIdSource"), output.info.get("securityIdSource"));
		assertEquals(expected.info.get("yield"), output.info.get("yield"));
		assertEquals(expected.info.get("previousSrcSystemId"), output.info.get("previousSrcSystemId"));
		assertEquals(expected.info.get("orderQty"), output.info.get("orderQty"));
		//assertEquals(expected.info.get("cptyAccountmnemonic"), output.info.get("cptyAccountmnemonic"));
		//assertEquals(expected.info.get("bookAccountmnemonic"), output.info.get("bookAccountmnemonic"));
		assertEquals(expected.info.get("side"), output.info.get("side"));
		assertEquals(expected.info.get("tradeStatus"), output.info.get("tradeStatus"));
		//lassertEquals(expected.info.get("txnRefNum"), output.info.get("txnRefNum"));
	}

	private Entity getM2postCshfiEntity(){
		Entity entity = new EntityBuilder()
				.sourceId("82125996")
				.stream("m2post")
				.flow("cshfi")
				.sourceVersion("3")
				.sourceSystem("TPS")
				.regHubId("M2POCSHFI123456")
				.sourceStatus(null)
				.sourceUid(null)
				.info("tradeSubType","TRADE")
		.info("quantity",Double.valueOf(5000000.0))
		.info("cptyAccountmnemonicAccountType","ACCOUNTCUSTOMER")
		.info("priceType", "PCT")
		.info("cptyAccountmnemonicAlternateGfc", "1013098812")
		.info("securityId", "74830A9G5")
		.info("cptyAccountmnemonicNoAltAccounts", 1)
		.info("bookAccountmnemonicAccountType", "FIRM")
		.info("tradeDate", LocalDate.of(2016, 1, 7))
		.info("settlementDate", LocalDate.of(2016, 1, 13))
		.info("bookAccountmnemonicAlternateGfc", "1000464046")
		.info("securitySmcp", "35897404")
		.info("tradeExecType", "PendingReplace")
		.info("bookAccountmnemonicNoAltAccounts", 1)
		.info("lastMkt", "LUX")
		.info("noAccounts", 2)
		.info("price", Double.valueOf(119.759))
		.info("securityIdSource", "CUSIP")
		.info("yield", Double.valueOf(3.09500574))
		.info("previousSrcSystemId", 150699)
		.info("orderQty", Double.valueOf(5000000.0))
		.info("cptyAccountmnemonic", "TMDRES")
		.info("bookAccountmnemonic", "SIGJNB")
		.info("side", "SELL")
		.info("tradeStatus", "Replaced")
		.info("txnRefNum",82126037)
		.executionTs(LocalDateTime.parse("2016-01-07 06:38:07", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
		.publishedTs(LocalDateTime.parse("2016-01-07 06:41:38.205", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")))
		.build();
		entity.generateRegReportingRef();
		return entity;
	}

}
