package com.citi.reghub.m2post.cshfi;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.Map;
import java.util.Properties;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.rio.RioConsumer;
import com.citi.reghub.core.rio.RioPublisher;



public class M2PostCshFiSourceTopologyTest {
/*	
	private Map<String, String> appProps;
	private LocalCluster cluster;
	private TestKafkaBroker broker;
	private TestKafkaProducerConsumer<String, String> kafkaRawInboundProdConsumer;
	private TestKafkaProducerConsumer<String, Audit> kafkaAuditProdConsumer;
	private TestKafkaProducerConsumer<String, Entity> kafkaDomainProdConsumer;
	private TestKafkaProducerConsumer<String, Entity> kafkaExceptionProdConsumer;
	
	@Before
	public void setUp() throws Exception {
		new RioConsumer().subscribe(1000);
		Thread.sleep(1000);
		broker = new TestKafkaBroker();
		
		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", broker.getBrokerConnectionString());
		
		Properties rawInboundProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "raw-inbound-kafka-bolt");
		Properties domainProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "domain-kafka-bolt");
		Properties auditProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "audit-bolt");
		Properties exceptionProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "exception-bolt");
		
		Properties rawInboundConsumerProps = new Properties();
		Properties domainConsumerProps = new Properties();
		Properties auditConsumerProps = new Properties();
		Properties exceptionConsumerProps = new Properties();
		
		rawInboundConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		rawInboundConsumerProps.put("auto.offset.reset", "earliest");
		rawInboundConsumerProps.put("group.id", "source_group_1");
		rawInboundConsumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		rawInboundConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		domainConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		domainConsumerProps.put("auto.offset.reset", "earliest");
		domainConsumerProps.put("group.id", "source_group_1");
		domainConsumerProps.put("value.deserializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		domainConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		exceptionConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		exceptionConsumerProps.put("auto.offset.reset", "earliest");
		exceptionConsumerProps.put("group.id", "source_group_1");
		exceptionConsumerProps.put("value.deserializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		exceptionConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		auditConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		//initialize kafka producer & consumer
		kafkaRawInboundProdConsumer = new TestKafkaProducerConsumer<String, String>( rawInboundProducerProps, rawInboundConsumerProps);
		kafkaAuditProdConsumer = new TestKafkaProducerConsumer<String, Audit>( auditProducerProps, auditConsumerProps);
		kafkaDomainProdConsumer = new TestKafkaProducerConsumer<String, Entity>( domainProducerProps, domainConsumerProps);
		kafkaExceptionProdConsumer = new TestKafkaProducerConsumer<String, Entity>( exceptionProducerProps, exceptionConsumerProps);
		
		Thread.sleep(3000);
		
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(false);
		conf.put(GlobalProperties.TOPOLOGY_CONFIG, appProps);
		
		cluster.submitTopology(M2PostCshFiSourceTopologyTest.class.getSimpleName(), conf, new M2PostCshFiSourceTopology().buildTopology(appProps));

		// Wait till topology to get started
		Thread.sleep(15000);
	}
	
	@Test
	public void shouldConsumeMessagesFromRioAndEmitSourceRawAndAuditStreams() throws Exception {
		new RioPublisher().msgCount(10).publish();
		Thread.sleep(1000);
		Map<String, String> rawInboundResult = kafkaRawInboundProdConsumer.consumeFromTopic(appProps.get("raw-inbound-kafka-bolt.kafka.topic.names"));
		Map<String, Entity> domainResult = kafkaDomainProdConsumer.consumeFromTopic(appProps.get("domain-kafka-bolt.kafka.topic.names"));
		Map<String, Audit> auditResult = kafkaAuditProdConsumer.consumeFromTopic(appProps.get("audit-bolt.kafka.topic.names"));
		Map<String, Entity> exceptionResult = kafkaExceptionProdConsumer.consumeFromTopic(appProps.get("exception-bolt.kafka.topic.names"));
		assertThat(rawInboundResult.isEmpty(), is(false));
		assertThat(domainResult.isEmpty(), is(false));
		assertThat(auditResult.isEmpty(), is(false));
		assertTrue(rawInboundResult.size() >= 10);
		assertTrue(domainResult.size() >= 10);
		assertTrue(auditResult.size() >= 10);
	}
	
	@Test
	public void shouldConsumeMessagesFromRioAndEmitSourceRawExceptionAndAuditStreams() throws Exception {
		new RioPublisher().msgCount(10).messageFile("dummy.txt").publish();
		Thread.sleep(10000);
		Map<String, String> rawInboundResult = kafkaRawInboundProdConsumer.consumeFromTopic(appProps.get("raw-inbound-kafka-bolt.kafka.topic.names"));
		Map<String, Entity> domainResult = kafkaDomainProdConsumer.consumeFromTopic(appProps.get("domain-kafka-bolt.kafka.topic.names"));
		Map<String, Audit> auditResult = kafkaAuditProdConsumer.consumeFromTopic(appProps.get("audit-bolt.kafka.topic.names"));
		Map<String, Entity> exceptionResult = kafkaExceptionProdConsumer.consumeFromTopic(appProps.get("exception-bolt.kafka.topic.names"));
		Thread.sleep(1000);
		assertThat(rawInboundResult.isEmpty(), is(false));
		assertThat(auditResult.isEmpty(), is(false));
		assertThat(exceptionResult.isEmpty(), is(false));
		assertTrue(rawInboundResult.size() >= 10);
		assertTrue(exceptionResult.size() >= 10);
		assertTrue(auditResult.size() >= 10);
		
	}
	
	
	@After
	public void teardown() throws Exception{
		kafkaRawInboundProdConsumer.stop();
		kafkaAuditProdConsumer.stop();
		kafkaExceptionProdConsumer.stop();
		kafkaDomainProdConsumer.stop();
		broker.shutdown();
		cluster.killTopology(M2PostCshFiSourceTopologyTest.class.getSimpleName());
	}
*/
}
