package com.citi.reghub.m2post.cshfi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.sourcetoentitymappers.AbstractCitiFIXToEntityMapper;
import com.citigroup.get.zcc.intf.MOTradeMessage;

/**
 * This class transforms the incoming FIX Message Java representation to the corresponding
 * RegHub Entity Domain Object 
 * @author pg60809
 *
 */
public class M2PostCshfiEntityMapper extends AbstractCitiFIXToEntityMapper {
	
	private static final long serialVersionUID = 5521740267151456530L;
	
	private static final Logger LOG = LoggerFactory.getLogger(M2PostCshfiEntityMapper.class);

	/**
	 * Constructor To Set the Flow and Stream.
	 * @param stream
	 * @param flow
	 */
	public M2PostCshfiEntityMapper(String stream, String flow) {
		super(stream, flow);
	}
	
	/**
	 * This methods populates the Entity Objects and its a two step process:
	 * 1. Populates all the Entity Instance Feilds.
	 * 2. Populates the Embedded info Map object with corresponding key value pairs.
	 */
	@Override
	public Entity mapToEntity(Object message,Entity entity) {
		
		LOG.info("Mapping for CSH FI Input FIX message [MOTradeMessage Object] to Entity Domain object started ...");
		super.mapToEntity(message, entity);
		populateEntityInfoObjectFromTagIds(entity, citifixTrade);
		populateEmbeddedEntityInfoObjectFromInputFixMessage(entity, citifixTrade);
		entity.generateRegReportingRef();
		LOG.info("Mapping for CSH FI Input FIX message [MOTradeMessage Object] to Entity Domain object completed ...");
		
		return entity;
	}
	
	/**
	 * The below method is used to map all the tags which are required or
	 * Equities flow, but does not have getters in MOTradeMessage object. - *
	 * Such values are available from getTag API provided in MOTradeMessage.
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	private void populateEntityInfoObjectFromTagIds(Entity entity, MOTradeMessage citifixTrade) {
		setCloRdId(entity, citifixTrade);
		setExecType(entity, citifixTrade);
		setExDestination(entity, citifixTrade);
		setExecLinkId(entity, citifixTrade);
		setExecId(entity, citifixTrade);
		setOrderCapacity(entity, citifixTrade);

		setOrderId(entity, citifixTrade);

		setTradingAcct(entity, citifixTrade);
		setBargainConditions(entity, citifixTrade);
		setContraAccount(entity, citifixTrade);
		setOrdStatus(entity, citifixTrade);

		setAcceptedTimeStamp(entity, citifixTrade);

		setNoOfContarBrokers(entity, citifixTrade);
		setContraBrokers(entity, citifixTrade);
		setNoTempContraBrokers(entity, citifixTrade);
		setExecComments(entity, citifixTrade);
		setAvgPriceAcct(entity, citifixTrade);
		setSalesPersonId(entity, citifixTrade);
		setExecutedBy(entity, citifixTrade);
		setOverrrideFlag(entity, citifixTrade);
		setRelatedmarketCenter(entity, citifixTrade);
		setCrossId(entity, citifixTrade);
		setSecurityExchange(entity, citifixTrade);
		setSymbolsFx(entity, citifixTrade);
	}

	/**
	 * This method populates the Embedded object Entity.info with the
	 * corresponding key/value pair for input MOTradeMessage Object.
	 * 
	 * @param entity
	 * @param citifixTrade
	 */
	private void populateEmbeddedEntityInfoObjectFromInputFixMessage(Entity entity, MOTradeMessage citifixTrade) {
		setZExecId(entity, citifixTrade);
		setExecRefId(entity, citifixTrade);
		setLastPx(entity, citifixTrade);
		setLastQty(entity, citifixTrade);
		setSetlDate(entity, citifixTrade);

		setTraderIdInfo(entity, citifixTrade);

		setSenderCompId(entity, citifixTrade);
		setTargetCompId(entity, citifixTrade);
		setTargetSubId(entity, citifixTrade);
		setLastCapacity(entity, citifixTrade);
		setSymbol(entity, citifixTrade);
		setSrcSystemId(entity, citifixTrade);
		setInstrIdentCode(entity, citifixTrade);
		setInstrIdentCodeType(entity, citifixTrade);
		setSide(entity, citifixTrade);
		setLastMkt(entity, citifixTrade);
		setPrice(entity, citifixTrade);
		setPriceType(entity, citifixTrade);
		setTradeDate(entity, citifixTrade);
		setTradeSubType(entity, citifixTrade);
		setTradeExecType(entity, citifixTrade);
		setTradeStatus(entity, citifixTrade);
		setOrderQty(entity, citifixTrade);

		setSecAltIdDetails(entity, citifixTrade);

		setCurrency(entity, citifixTrade);
		setClearingAccount(entity, citifixTrade);
		setSetlCurrency(entity, citifixTrade);
		setReportToExch(entity, citifixTrade);
		setSenderSubId(entity, citifixTrade);
		setNoOfAccnts(entity, citifixTrade);
		setAccountGrpInfo(entity, citifixTrade);

		setPreviousSrcSystemId(entity, citifixTrade);
		setYield(entity, citifixTrade);
		setQty(entity, citifixTrade);
	}

}
