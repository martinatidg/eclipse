package com.citi.reghub.m2post.cshfi;



import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.*;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.CitifixParserBolt;
import com.citi.reghub.core.EntityMapperBolt;
import com.citi.reghub.core.ReplayEntityBolt;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.rio.spouts.RioSpout;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

/**
 * This class creates the Topology for the Sourcing Flow from RIO to RegHub for CSH FI Asset Class.
 * @author pg60809
 *
 */
public class M2PostCshFiSourceTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
        new M2PostCshFiSourceTopology().runTopology(args);
	}

	/**
	 * The below method configures the Spouts and Bolts for the CSH FI Sourcing Topology.
	 * 1. Creates a RIO spout which will read/stream the data form RIO Messaging Infrastructure.
	 * 2. Two Bolts are associated with this RIO spout : RAW Bolt and Message Parse Bolt.
	 * 	  RAW Bolt wills tore the Incoming RAW Message into Mongo through Common Service.
	 * 	  Message Bolt parses the CITIFIX .
	 * 3. Once processed this data is forwarded for CITIFIX to Entity Conversion.
	 * 4. If any exceptions, the messages are sent to exception Queue.
	 * 
	 * @param  topologyConfig
	 * @return StormTopology
	 * @throws Exception
	 * 
	 */
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		TopologyBuilder builder = new TopologyBuilder();
		
		String sourceKafkaTopics = topologyConfig.get(REPLAY_TOPIC_NAME);
		String rawMessageDestinationTopicName = topologyConfig.get(RAW_MSG_TOPIC_NAME);
		String domainDestinationTopicName = topologyConfig.get(DOMAIN_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);
		
		builder.setSpout(RIO_SPOUT_ID, new RioSpout(topologyConfig,RIO_SPOUT_NAME));
		
		builder.setSpout(REPLAY_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM, topologyConfig));
		
		builder.setBolt(RAW_MSG_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(rawMessageDestinationTopicName, RAW_MSG_BOLT_NAME, topologyConfig),3).shuffleGrouping(RIO_SPOUT_ID);
		
		builder.setBolt(CITIFIX_PARSER_BOLT_ID, new CitifixParserBolt(),3)
		.shuffleGrouping(RIO_SPOUT_ID);
		
		builder.setBolt(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID, new CitifixParserBolt(),3).
		shuffleGrouping(REPLAY_SPOUT_ID, INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM);
		
		builder.setBolt(MAP_TO_ENTITY_BOLT_ID, new EntityMapperBolt(new M2PostCshfiEntityMapper(STREAM, CSH_FI_FLOW)),3)
		.shuffleGrouping(CITIFIX_PARSER_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID, new EntityMapperBolt(new M2PostCshfiEntityMapper(STREAM, CSH_FI_FLOW)),3)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(MERGE_ENTITY_FOR_REPLAY_BOLT_ID, new ReplayEntityBolt(),3)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(DOMAIN_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(domainDestinationTopicName, DOMAIN_BOLT_NAME, topologyConfig),3)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(REPLAY_DMN_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(domainDestinationTopicName, DOMAIN_BOLT_NAME, topologyConfig),3)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig),3)
		.shuffleGrouping(CITIFIX_PARSER_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT);
		
		builder.setBolt(EXCEPTION_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME, topologyConfig),3)
		.shuffleGrouping(CITIFIX_PARSER_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION);
		
		return builder.createTopology();
	}
}
