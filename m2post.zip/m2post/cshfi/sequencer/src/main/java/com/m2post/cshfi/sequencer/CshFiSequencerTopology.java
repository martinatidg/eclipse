package com.m2post.cshfi.sequencer;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.*;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.custombolts.SequencerRealTimeBolt;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

public class CshFiSequencerTopology extends BaseTopology{
		
	public static void main(String[] args) throws Exception {
		new CshFiSequencerTopology().runTopology(args);
	}
	
	
	@Override
	protected StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		final TopologyBuilder topologyBuilder = new TopologyBuilder();
		
		
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopicName = topologyConfig.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String sequencedOutboundTopicName = topologyConfig.get(SEQUENCED_OUTBOUND_TOPIC_NAME);
		String reportableTopicName = topologyConfig.get(REPORTABLE_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		
		topologyBuilder.setSpout(SEQUENCER_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SEQUENCER_STORM_STREAM, topologyConfig), 1);
		
		topologyBuilder.setBolt(SEQUENCER_BOLT_ID, new SequencerRealTimeBolt(), 1).shuffleGrouping(SEQUENCER_SPOUT_ID, INBOUND_M2POST_SEQUENCER_STORM_STREAM);

		topologyBuilder.setBolt(REPORTABLE_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableOutboundTopicName, REPORTABLE_OUTBOUND_BOLT_NAME, topologyConfig), 1)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.PUSHBACK_REPORTABLE_STREAM);

		topologyBuilder.setBolt(SEQUENCED_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(sequencedOutboundTopicName, SEQUENCED_OUTBOUND_BOLT_NAME, topologyConfig), 1)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.SEQUENCED_OUTBOUND_STREAM);

		topologyBuilder.setBolt(REPORTABLE_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableTopicName, REPORTABLE_BOLT_NAME, topologyConfig), 1)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.COMMON_REPORTABLE_STREAM);

		topologyBuilder.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 1)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.AUDIT);
		
		return topologyBuilder.createTopology();
	}
	
}