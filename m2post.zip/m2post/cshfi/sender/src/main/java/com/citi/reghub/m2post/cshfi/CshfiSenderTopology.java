package com.citi.reghub.m2post.cshfi;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.*;

import java.util.Map;

import org.apache.storm.Config;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.APASenderBolt;
import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.constants.RegulatoryReportingBody;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.custombolts.APATradeIdEnrichmentBolt;
import com.citi.reghub.m2post.utils.custombolts.FixMsgGenerationBolt;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

public class CshfiSenderTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
		new CshfiSenderTopology().runTopology(args);
	}

	public Config getTopologyConfig() {
		Config config = new Config();
		config.setDebug(true);
		return config;
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		final TopologyBuilder tp = new TopologyBuilder();

		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String rawOutboundTopicName = topologyConfig.get(RAW_OUTBOUND_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);

		tp.setSpout(SENDER_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics,
				INBOUND_M2POST_SENDER_STORM_STREAM, topologyConfig), 1);

		tp.setBolt(APA_TRADE_ID_ENRICHMENT_BOLT_ID, new APATradeIdEnrichmentBolt(), 3).fieldsGrouping(SENDER_SPOUT_ID,
				INBOUND_M2POST_SENDER_STORM_STREAM, new Fields("key"));

		tp.setBolt(APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(sourceKafkaTopics,
				APA_TRADE_ID_NON_ACKNOWLEDGED_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(APA_TRADE_ID_ENRICHMENT_BOLT_ID, StormStreams.SOURCE);

		tp.setBolt(FIX_MSG_GEN_BOLT_ID,
				new FixMsgGenerationBolt(RawOutboundRecord.OutboundMessageType.FIX, RegulatoryReportingBody.APA,
						new CshfiEntityToFixConverter()),
				3).fieldsGrouping(APA_TRADE_ID_ENRICHMENT_BOLT_ID, StormStreams.REPORTABLE, new Fields("key"));

		tp.setBolt(APA_SENDER_BOLT_ID, new APASenderBolt()).fieldsGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.FIX_MSG,
				new Fields("sourceId"));

		tp.setBolt(RAW_MSG_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(rawOutboundTopicName,
				RAW_MSG_OUTBOUND_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.RAW_OUTBOUND_OBJECT);

		tp.setBolt(AUDIT_BOLT_ID,
				StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.AUDIT);

		tp.setBolt(EXCEPTION_BOLT_ID,
				StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.EXCEPTION);

		return tp.createTopology();
	}
}