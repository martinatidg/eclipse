package com.citi.reghub.m2post.cshfi;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.converter.ConvertRecordToString;

public class CshfiEntityToFixConverter implements ConvertRecordToString, Serializable {

	final String delimiter= "^B";
	private static final long serialVersionUID = 6842509178329170127L;
	protected static final Logger LOG = LoggerFactory.getLogger(CshfiEntityToFixConverter.class);

	@Override
	public String convert(List<Entity> entityList) throws Exception {
		
		LOG.debug("Convert Cshfi entities to FIX started.");
		
		StringBuilder sb = new StringBuilder();
		for (Entity entity : entityList) {
			CshfiFixObject ffo = new CshfiFixObject(entity);
			//sb.append(DELIMITER);
			sb.append(ffo.toString());
		}
		
		LOG.debug("Convert Cshfi entities to FIX finished.");
		return sb.toString();

		
	}
	
	@Override
	public String convert(List<Entity> entity, Boolean headerRequired) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
