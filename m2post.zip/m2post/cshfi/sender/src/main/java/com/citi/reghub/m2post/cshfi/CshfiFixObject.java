package com.citi.reghub.m2post.cshfi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.fix.FixObject;

import quickfix.ConfigError;
import quickfix.FieldNotFound;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;

@SuppressWarnings("serial")
public class CshfiFixObject extends FixObject {

	private static final Logger LOG = LoggerFactory.getLogger(CshfiFixObject.class);

	public CshfiFixObject(Entity e) throws ConfigError {
		super(e);
		try {
			LOG.debug("validating Cshfi fix object with dictionary.");
			getDictionary().validate(this, true);
			LOG.debug("validated Cshfi fix object with dictionary.");
		} catch (IncorrectTagValue | FieldNotFound | IncorrectDataFormat exception) {
			LOG.error("Error while validating cshfi FIX object with dictionary.", exception);
			throw new ConfigError(exception);
		}

	}

}
