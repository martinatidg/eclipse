package com.citi.reghub.m2post.cshfi;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.Entity;



@RunWith(JUnit4.class)
public class CshfiFixObjectTest {

	@Test
	public void testFrom() throws Exception {
	Entity e=new EntityBuilder().build();
		CshfiFixObject cshObject=new CshfiFixObject(e);
		assertNotNull(cshObject);
		
	}

}
