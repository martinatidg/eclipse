package com.citi.reghub.m2post.cshfi;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.NON_REPORTABLE_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_TOPIC_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.stream.IntStream;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;

@RunWith(JUnit4.class)
public class M2PostCshFiDomainTopologyTest {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCshFiDomainTopologyTest.class);
	private static Map<String, String> appProps;
	private static LocalCluster cluster;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@ClassRule
	public static KafkaUnitRule<String, Entity> kafkaUnitRule = new KafkaUnitRule(19092,
			EntityKafkaSerializerDeserializer.class.getCanonicalName(), EntityKafkaSerializerDeserializer.class.getCanonicalName());
	
	
	private static List<LocalDate> tradeDateList = Arrays.asList(LocalDate.now(), LocalDate.of(2017, 01, 20),
			LocalDate.of(2012, 12, 21), LocalDate.of(2007, 11, 4), LocalDate.of(2007, 11, 5), LocalDate.of(2007, 11, 6),
			LocalDate.of(1990, 01, 01));

	@SuppressWarnings("unchecked")
	void populateTopicEntityData(String topicName, int msgCount) {
        List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new EntityBuilder()
					.info("tradeDate", (LocalDate) getRandomItemFromInput(tradeDateList))
					.build();
		    t.regHubId = "" + value;
			messages.add(t);
		});
		
		try {
			kafkaUnitRule.getKafkaUnit().createTopicAndSendMessage(topicName, messages);
		} catch (Exception e) {
			LOG.error("Error sending messages to kafka", e);
		}
    }

	@BeforeClass
	public static void setUp() throws Exception {
		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", kafkaUnitRule.getKafkaUnit().getBrokerConnectionString());
		
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(false);
		conf.put(GlobalProperties.TOPOLOGY_CONFIG, appProps);
		cluster.submitTopology(M2PostCshFiDomainTopologyTest.class.getSimpleName(), conf, new CshFiDomainTopology().buildTopology(appProps));
		Thread.sleep(15000);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void shouldBeAbleToSendAndReceiveTrades() throws Exception {
		final String topic = "KafkakConnectTestTopic";
		populateTopicEntityData(topic, 10);
		Thread.sleep(3000);
	    List< Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopicListResponse(topic);
		assertThat(result.isEmpty(), is(false));
		assertThat(result.size(), is(10));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void shouldRunEligibilityBoltAndPostToKafkaTopics() throws Exception{
		String inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopic = appProps.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String nonReportableTopic = appProps.get(NON_REPORTABLE_TOPIC_NAME);
		String exceptionTopic = appProps.get(EXCEPTION_TOPIC_NAME);
		
		populateTopicEntityData(inputTopic, 2);
		
		// Rules execution delay
		Thread.sleep(10000);
		Map<String, Entity> reportableOutboundResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(reportableOutboundTopic);
		Thread.sleep(3000);
		Map<String, Entity> nonReportableResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(nonReportableTopic);
		Thread.sleep(3000);
		Map<String, Entity> exceptionResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(exceptionTopic);
		Thread.sleep(3000);
		// Test Reportable topic trades
		assertThat(reportableOutboundResult.isEmpty(), is(false));
		assertThat((reportableOutboundResult.size() + nonReportableResult.size() + exceptionResult.size()), is(2));
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	@Test
	public void reportabilityFlowTest() throws Exception{
		String inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopic = appProps.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String nonReportableTopic = appProps.get(NON_REPORTABLE_TOPIC_NAME);
		String exceptionTopic = appProps.get(EXCEPTION_TOPIC_NAME);
		
		populateTopicEntityData(inputTopic, 10);
		
		// Rules execution delay
		Thread.sleep(3000);
		Map<String, Entity> reportableOutboundResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(reportableOutboundTopic);
		Thread.sleep(3000);
		Map<String, Entity> nonReportableResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(nonReportableTopic);
		Thread.sleep(3000);
		Map<String, Entity> exceptionResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(exceptionTopic);
		
		// Test Reportable topic trades
		assertThat(reportableOutboundResult.isEmpty(), is(false));
		
		reportableOutboundResult.forEach((id, trade) -> {
			assertThat(trade.status, is(EntityStatus.REPORTABLE));
			assert(!(LocalDate.of(2007, 11, 5).isAfter(trade.getLocalDate("tradeDate"))));
			});
	}
	
	@SuppressWarnings({ "unused", "unchecked" })
	@Test
	public void nonReportabilityFlowTest() throws Exception{
		String inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopic = appProps.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String nonReportableTopic = appProps.get(NON_REPORTABLE_TOPIC_NAME);
		String exceptionTopic = appProps.get(EXCEPTION_TOPIC_NAME);
		
		// send test messages on input topic
		populateTopicEntityData(inputTopic, 100);
		
		// Rules execution delay
		Thread.sleep(3000);
		
		// read the data from out topic, as topology will publish all non reportable messages here
		Map<String, Entity> result = kafkaUnitRule.getKafkaUnit().consumeFromTopic(nonReportableTopic);
		Map<String, Entity> reportableOutboundResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(reportableOutboundTopic);
		Map<String, Entity> exceptionResult = kafkaUnitRule.getKafkaUnit().consumeFromTopic(exceptionTopic);
		
		// Test Non-Reportable topic trades
		assertThat(result.isEmpty(), is(false));
		
		result.forEach((id, trade) -> {
			assertThat(trade.status, is(EntityStatus.NON_REPORTABLE));	
			assert((LocalDate.of(2007, 11, 5).isAfter(trade.getLocalDate("tradeDate"))));
		});
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void auditPublishTest() throws Exception{
		String inputTopic = appProps.get(KAFKA_TOPIC_NAMES);
		String auditTopic = appProps.get(AUDIT_TOPIC_NAME);
		
		// send test messages on input topic
		populateTopicEntityData(inputTopic, 100);
		
		// Rules execution delay
		Thread.sleep(3000);
		Properties auditConsumerProps = new Properties();
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		// read the data from out topic, as topology will publish all non reportable messages here
		List< Audit> audit = kafkaUnitRule.getKafkaUnit().consumeFromTopic(auditTopic,auditConsumerProps);
		
		// Test Non-Reportable topic trades
		assertThat(audit.isEmpty(), is(false));
	}

	@AfterClass
	public static void teardown() throws Exception{
		cluster.killTopology(M2PostCshFiDomainTopologyTest.class.getSimpleName());
	}
	
	public static Object getRandomItemFromInput(List<?> dateList){
		return dateList.get((new Random()).nextInt(dateList.size()));
	}

}