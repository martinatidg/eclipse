package com.citi.reghub.m2post.cshfi;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.citi.reghub.core.Entity;

public class SimpleProducer {
	public static void main(String[] args) {
		
		String topicName = "m2post_cshfi_source";
		Properties props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("acks", "all");
		props.put("retries", 0);
		props.put("batch.size", 16384);
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);

		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		props.put("value.serializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");

		Producer<String, Entity> producer = new KafkaProducer<>(props);

		for (int i = 0; i < 1; i++) {
			Entity entity = new Entity();
			
			entity.regHubId = "reghubId" + Integer.toString(i)+"1";
			entity.status = "testStatus" + Integer.toString(i);
			entity.info.put("tradeType", "tradeType" + Integer.toString(i));
			entity.info.put("tradeExecType", "NEW");
			entity.sourceUId="reghub"+i;
			if(i%3==0)
				entity.sourceStatus="CANCEL";
			else if(i%2==0)
				entity.sourceStatus="AMEND";
			else
				entity.sourceStatus="NEW";
			
			if(i%2==0)
				entity.sourceId="123123423423";
			else
				entity.sourceId="123123425454";
			entity.sourceStatus="CANCEL";
			entity.sourceId="sourcem2trcsheq369034019";
			entity.stream="m2tr";
			entity.flow="csheq";
			System.out.println("sending entity");
			producer.send(new ProducerRecord<String, Entity>(topicName, Integer.toString(i), entity));
		}
		producer.close();
	}
	
}
