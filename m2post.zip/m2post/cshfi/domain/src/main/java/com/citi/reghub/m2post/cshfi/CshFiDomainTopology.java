package com.citi.reghub.m2post.cshfi;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.*;
import static com.citi.reghub.m2post.utils.constants.RuleGraphConstants.PRE_ELIGIBILITY_RULE_GRAPH;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EligibilityBolt;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

public class CshFiDomainTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
		new CshFiDomainTopology().runTopology(args);

	}

	@Override
	protected StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		final TopologyBuilder tp = new TopologyBuilder();
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopicName = topologyConfig.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String nonReportableTopicName = topologyConfig.get(NON_REPORTABLE_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);

		tp.setSpout(DOMAIN_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics,
				INBOUND_M2POST_DOMAIN_STORM_STREAM, topologyConfig));

		tp.setBolt(PRE_ELIGIBILITY_RULES_BOLT_ID, new EligibilityBolt(PRE_ELIGIBILITY_RULE_GRAPH), 3)
				.shuffleGrouping(DOMAIN_SPOUT_ID, INBOUND_M2POST_DOMAIN_STORM_STREAM);

		// TODO : below commented to be incorporated
		/*
		 * tp.setBolt("enrichment", new
		 * EnrichmentBolt(CshEqConstants.ENRICHMENT_PLAN_NAME), 3)
		 * .shuffleGrouping("pre_eligibility", StormStreams.REPORTABLE);
		 * 
		 * tp.setBolt("post_enrichment_eligibility", new
		 * EligibilityBolt(CshEqConstants.POST_ENRICHMENT_ELIGIBILITY_RULE_GRAPH
		 * ), 3) .shuffleGrouping("enrichment", StormStreams.REPORTABLE);
		 * 
		 * tp.setBolt("post_enrichment_biz_exception", new
		 * EligibilityBolt(CshEqConstants.
		 * POST_ENRICHMENT_BIZ_EXCEPTION_RULE_GRAPH), 3)
		 * .shuffleGrouping("post_enrichment_eligibility",
		 * StormStreams.REPORTABLE);
		 * 
		 * tp.setBolt("post_enrichment_tech_exception", new
		 * EligibilityBolt(CshEqConstants.
		 * POST_ENRICHMENT_TECH_EXCEPTION_RULE_GRAPH), 3)
		 * .shuffleGrouping("post_enrichment_biz_exception",
		 * StormStreams.REPORTABLE);
		 */

		tp.setBolt(REPORTABLE_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableOutboundTopicName,
				REPORTABLE_OUTBOUND_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.REPORTABLE);

		tp.setBolt(NON_REPORTABLE_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(nonReportableTopicName,
				NON_REPORTABLE_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.NON_REPORTABLE);

		tp.setBolt(EXCEPTION_BOLT_ID,
				StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.EXCEPTION);

		tp.setBolt(AUDIT_BOLT_ID,
				StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.AUDIT);

		return tp.createTopology();
	}
}
