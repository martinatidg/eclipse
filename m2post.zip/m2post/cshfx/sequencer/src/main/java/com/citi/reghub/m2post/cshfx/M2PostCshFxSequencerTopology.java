package com.citi.reghub.m2post.cshfx;


import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SEQUENCER_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCER_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCER_SPOUT_ID;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.custombolts.SequencerRealTimeBolt;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

public class M2PostCshFxSequencerTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
		new M2PostCshFxSequencerTopology().runTopology(args);
	}

	@Override
	protected StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		
		final TopologyBuilder topologyBuilder = new TopologyBuilder();
		
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopicName = topologyConfig.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String sequencedOutboundTopicName = topologyConfig.get(SEQUENCED_OUTBOUND_TOPIC_NAME);
		String reportableTopicName = topologyConfig.get(REPORTABLE_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		
		
		topologyBuilder.setSpout(SEQUENCER_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SEQUENCER_STORM_STREAM, topologyConfig), 3);
		//topologyBuilder.setSpout(SEQUENCER_SPOUT_ID, KafkaSpoutFactory.getKafkaSpout(topologyConfig, sourceKafkaTopics, INBOUND_M2POST_SEQUENCER_STORM_STREAM), 1);

		topologyBuilder.setBolt(SEQUENCER_BOLT_ID, new SequencerRealTimeBolt(), 1).shuffleGrouping(SEQUENCER_SPOUT_ID, INBOUND_M2POST_SEQUENCER_STORM_STREAM);

		topologyBuilder.setBolt(REPORTABLE_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableOutboundTopicName, REPORTABLE_OUTBOUND_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.PUSHBACK_REPORTABLE_STREAM);

		topologyBuilder.setBolt(SEQUENCED_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(sequencedOutboundTopicName, SEQUENCED_OUTBOUND_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.SEQUENCED_OUTBOUND_STREAM);

		topologyBuilder.setBolt(REPORTABLE_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableTopicName, REPORTABLE_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.COMMON_REPORTABLE_STREAM);

		topologyBuilder.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.AUDIT);

		return topologyBuilder.createTopology();
	}

}