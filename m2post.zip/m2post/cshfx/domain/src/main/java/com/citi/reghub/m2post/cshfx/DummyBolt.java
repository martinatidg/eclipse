package com.citi.reghub.m2post.cshfx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.rules.client.RuleGraph;
import com.citi.reghub.core.rules.client.RuleGraphResult;
import com.citi.reghub.core.rules.client.RulesClient;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

public class DummyBolt extends RegHubBolt {

	protected static final Logger LOG = LoggerFactory.getLogger(DummyBolt.class);
	private static final long serialVersionUID = 1L;
	
	private OutputCollector _collector;
	
	public DummyBolt(){
		super();
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
	}

	private String getStreamIdByEntityStatus(String status) {
		if(EntityStatus.REPORTABLE.equalsIgnoreCase(status)){
			return StormStreams.REPORTABLE;
		} else if(EntityStatus.NON_REPORTABLE.equalsIgnoreCase(status)) {
			return StormStreams.NON_REPORTABLE;
		} else {
			return StormStreams.EXCEPTION;
		}
	}

	@Override
	public void process(Tuple input) {
		
		Entity message = (Entity) input.getValueByField("message");	
		_collector.emit(getStreamIdByEntityStatus(message.status), new Values(message.sourceId, message));
		_collector.ack(input);		
	}

	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.NON_REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.DOMAIN_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.DOMAIN);
		return exceptionTags;
	}

}
