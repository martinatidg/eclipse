package com.citi.reghub.m2post.cshfx;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_DOMAIN_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SENDER_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.PRE_ELIGIBILITY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.RuleGraphConstants.PRE_ELIGIBILITY_RULE_GRAPH;

import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.Config;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.kafka.bolt.KafkaBolt;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EligibilityBolt;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityKafkaSerializerDeserializer;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.kafka.RegHubKafkaBolt;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;

public class TestTopology extends BaseTopology{
	public static void main(String[] args) throws Exception {
		new TestTopology().runTopology(args);
	}

	public Config getTopologyConfig(){
		Config config = new Config();
		config.setDebug(true);
		return config;
	}

	
	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		
		final TopologyBuilder tp = new TopologyBuilder();
		String inputTopicNames = "abc";
		
		
		
		
		RegHubKafkaSpout<String, Entity> regKafkaSpout = RegHubKafkaSpout.builder(inputTopicNames, INBOUND_M2POST_DOMAIN_STORM_STREAM, topologyConfig)
                .setKeyDesClazz(StringDeserializer.class)
                .setValueDesClazz(EntityKafkaSerializerDeserializer.class)
                .build();
		
		KafkaBolt<Object, Object> kafkaBolt = RegHubKafkaBolt.getKafkaBolt(topologyConfig, "mytopic", "non-reportable-bolt");
		
		
		
		tp.setSpout(DOMAIN_SPOUT_ID, regKafkaSpout.getSpout(), 1);
		
		
		
		tp.setBolt(PRE_ELIGIBILITY_BOLT_ID, new EligibilityBolt(PRE_ELIGIBILITY_RULE_GRAPH), 3)
		.fieldsGrouping(DOMAIN_SPOUT_ID, INBOUND_M2POST_DOMAIN_STORM_STREAM, new Fields("key"));
		//.shuffleGrouping(DOMAIN_SPOUT_ID, INBOUND_M2POST_SENDER_STORM_STREAM);
		
		
		tp.setBolt("kakfaboltname", kafkaBolt, 3).fieldsGrouping(PRE_ELIGIBILITY_BOLT_ID, StormStreams.REPORTABLE, new Fields("key"));
		
		
		
		
		
		return tp.createTopology();
	}
}
