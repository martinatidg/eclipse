package com.citi.reghub.m2post.cshfx;

import java.time.LocalDate;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;

public class SimpleProducer {
	public static void main(String[] args) {

		String topicName = "abc";
		Properties props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("acks", "all");
		props.put("retries", 0);
		props.put("batch.size", 16384);
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);

		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		props.put("value.serializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");

		Producer<String, Entity> producer = new KafkaProducer<>(props);

		for (int i = 0; i < 100; i++) {
			Entity entity = new Entity();
			entity.info.put("tradeType", "tradeType" + Integer.toString(i));
			entity.status = EntityStatus.REPORTABLE;
			entity.info.put("tradeExecType", "NEW");
			entity.sourceUId = "reghub12s3" + i;
			entity.sourceStatus = "NEW";
			entity.stream = "testStatus" + Integer.toString(i);
			;
			entity.flow = "csheq";
			// entity.info.put("tradeDate", LocalDate.now().minusDays(3650));
			entity.info.put("tradeDate", LocalDate.now().minusDays(30));
			for (int j = 0; j < 10; j++) {
				entity.regHubId = "reghubId" + Integer.toString(i) + Integer.toString(j);
				entity.sourceId = "sourceId" + Integer.toString(i);
				System.out.println("sending entity");
				producer.send(new ProducerRecord<String, Entity>(topicName, entity.sourceId, entity));
			}
		}
		producer.close();
	}

}
