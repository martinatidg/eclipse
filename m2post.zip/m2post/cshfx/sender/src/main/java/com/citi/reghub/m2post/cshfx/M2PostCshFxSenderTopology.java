package com.citi.reghub.m2post.cshfx;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.APA_SENDER_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.FIX_MSG_GEN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SENDER_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SENDER_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_TOPIC_NAME;

import java.util.Map;

import org.apache.storm.Config;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.APASenderBolt;
import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.RawOutboundRecord;
import com.citi.reghub.core.constants.RegulatoryReportingBody;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.custombolts.FixMsgGenerationBolt;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;
public class M2PostCshFxSenderTopology extends BaseTopology {

	public static void main(String[] args) throws Exception {
		new M2PostCshFxSenderTopology().runTopology(args);
	}

	public Config getTopologyConfig(){
		Config config = new Config();
		config.setDebug(true);
		return config;
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		final TopologyBuilder tp = new TopologyBuilder();
		
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String rawOutboundTopicName = topologyConfig.get(RAW_OUTBOUND_TOPIC_NAME);
		String sequencedOutboundTopicName = topologyConfig.get(SEQUENCED_OUTBOUND_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);

		
		
		tp.setSpout(SENDER_SPOUT_ID,  StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SENDER_STORM_STREAM, topologyConfig), 3);
		
		tp.setBolt(FIX_MSG_GEN_BOLT_ID, new FixMsgGenerationBolt(RawOutboundRecord.OutboundMessageType.FIX, RegulatoryReportingBody.APA, new CshFxEntityToFixConverter()))
		
			.shuffleGrouping(SENDER_SPOUT_ID, INBOUND_M2POST_SENDER_STORM_STREAM);

		
		tp.setBolt(RAW_MSG_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(rawOutboundTopicName, RAW_MSG_OUTBOUND_BOLT_NAME, topologyConfig), 3)
		.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.RAW_OUTBOUND_OBJECT);

		
		
		tp.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
		.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.AUDIT);
	
		
		tp.setBolt(SEQUENCED_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(sequencedOutboundTopicName, SEQUENCED_OUTBOUND_BOLT_NAME, topologyConfig), 3)
		.shuffleGrouping(FIX_MSG_GEN_BOLT_ID, StormStreams.SEQUENCED_OUTBOUND_STREAM);

		return tp.createTopology();
	}
}