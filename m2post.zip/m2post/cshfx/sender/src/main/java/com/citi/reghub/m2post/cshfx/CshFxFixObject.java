package com.citi.reghub.m2post.cshfx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.fix.FixObject;

import quickfix.ConfigError;
import quickfix.FieldNotFound;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;

@SuppressWarnings("serial")
public class CshFxFixObject extends FixObject {

	private static final Logger LOG = LoggerFactory.getLogger(CshFxFixObject.class);

	public CshFxFixObject(Entity e) throws ConfigError {

		super(e);
		try {
			LOG.debug("validating CSHFX fix object with dictionary.");
			getDictionary().validate(this, true);
			LOG.debug("validated CSHFX fix object with dictionary.");
		} catch (IncorrectTagValue | FieldNotFound | IncorrectDataFormat exception) {
			LOG.error("Error while validating CSHFX FIX object with dictionary.", exception);
			throw new ConfigError(exception);
		}
	}
}
