package com.citi.reghub.m2post.cshfx;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.converter.ConvertRecordToString;

public class CshFxEntityToFixConverter implements ConvertRecordToString, Serializable {

	final String delimiter= "^B";
	private static final long serialVersionUID = 6842509178329170127L;
	protected static final Logger LOG = LoggerFactory.getLogger(CshFxEntityToFixConverter.class);

	@Override
	public String convert(List<Entity> entityList) throws Exception {
		
		LOG.debug("Convert CSHFX entities to FIX started.");
		
		StringBuilder sb = new StringBuilder();
		for (Entity entity : entityList) {
			CshFxFixObject ffo = new CshFxFixObject(entity);
			//sb.append(DELIMITER);
			sb.append(ffo.toString());
		}
		
		LOG.debug("Convert CSHFX entities to FIX finished.");
		return sb.toString();
	}

	@Override
	public String convert(List<Entity> entity, Boolean headerRequired) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	

	
	
	
}
