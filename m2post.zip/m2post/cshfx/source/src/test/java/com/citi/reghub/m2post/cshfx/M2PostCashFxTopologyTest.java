package com.citi.reghub.m2post.cshfx;

/**
 * @author ak48298
 *
 */
public class M2PostCashFxTopologyTest {
	
	/*private Map<String, String> appProps;
	private LocalCluster cluster;
	private TestKafkaBroker broker;
	private TestKafkaProducerConsumer<String, String> kafkaRawInboundProdConsumer;
	private TestKafkaProducerConsumer<String, Audit> kafkaAuditProdConsumer;
	private TestKafkaProducerConsumer<String, Entity> kafkaDomainProdConsumer;
	private TestKafkaProducerConsumer<String, Entity> kafkaExceptionProdConsumer;
	
	*//**
	 * @throws Exception
	 *//*
	@Before
	public void setUp() throws Exception {
		
		RioConsumer rioConsumer = new RioConsumer();
		rioConsumer.subscriptionKey("170530-SUB_M2POST_ALL_TEST-004");
		rioConsumer.environment("DEV");
		rioConsumer.subscribe(1000);
		Thread.sleep(1000);
		broker = new TestKafkaBroker();
		
		// Fetch properties
		appProps = new PropertiesLoader().getProperties("test");
		appProps.put("kafka.commons.bootstrap.servers", broker.getBrokerConnectionString());
		
		Properties rawInboundProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "raw-inbound-kafka-bolt");
		Properties domainProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "domain-kafka-bolt");
		Properties auditProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "audit-bolt");
		Properties exceptionProducerProps = KafkaPropertiesFactory.getKafkaProducerProps(appProps, "exception-bolt");
		
		Properties rawInboundConsumerProps = new Properties();
		Properties domainConsumerProps = new Properties();
		Properties auditConsumerProps = new Properties();
		Properties exceptionConsumerProps = new Properties();
		
		rawInboundConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		rawInboundConsumerProps.put("auto.offset.reset", "earliest");
		rawInboundConsumerProps.put("group.id", "source_group_1");
		rawInboundConsumerProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		rawInboundConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		domainConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		domainConsumerProps.put("auto.offset.reset", "earliest");
		domainConsumerProps.put("group.id", "source_group_1");
		domainConsumerProps.put("value.deserializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		domainConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		exceptionConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		exceptionConsumerProps.put("auto.offset.reset", "earliest");
		exceptionConsumerProps.put("group.id", "source_group_1");
		exceptionConsumerProps.put("value.deserializer", "com.citi.reghub.core.EntityKafkaSerializerDeserializer");
		exceptionConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		auditConsumerProps.putAll(KafkaPropertiesFactory.getKafkaConsumerProps(appProps));
		auditConsumerProps.put("auto.offset.reset", "earliest");
		auditConsumerProps.put("group.id", "audit_group_1");
		auditConsumerProps.put("value.deserializer", "com.citi.reghub.core.AuditKafkaSerializerDeserializer");
		auditConsumerProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		//initialize kafka producer & consumer
		kafkaRawInboundProdConsumer = new TestKafkaProducerConsumer<String, String>( rawInboundProducerProps, rawInboundConsumerProps);
		kafkaAuditProdConsumer = new TestKafkaProducerConsumer<String, Audit>( auditProducerProps, auditConsumerProps);
		kafkaDomainProdConsumer = new TestKafkaProducerConsumer<String, Entity>( domainProducerProps, domainConsumerProps);
		kafkaExceptionProdConsumer = new TestKafkaProducerConsumer<String, Entity>( exceptionProducerProps, exceptionConsumerProps);
		
		Thread.sleep(3000);
		
		cluster = new LocalCluster();
		Config conf = new Config();
		conf.setDebug(false);
		
		cluster.submitTopology(M2PostCashFxTopologyTest.class.getSimpleName(), conf, new M2PostCashFxSourceTopology().buildTopology(appProps));

		// Wait till topology to get started
		Thread.sleep(15000);
	}
	
	*//**
	 * @throws Exception
	 *//*
	@Test
	public void shouldConsumeMessagesFromRioAndEmitSourceRawAndAuditStreams() throws Exception {
		new RioPublisher().msgType("CITIML").msgCount(5).messageFile("citiml.xml").publish();
		Thread.sleep(1000);
		Map<String, String> rawInboundResult = kafkaRawInboundProdConsumer.consumeFromTopic(appProps.get("raw-inbound-kafka-bolt.kafka.topic.names"));
		Map<String, Entity> domainResult = kafkaDomainProdConsumer.consumeFromTopic(appProps.get("domain-kafka-bolt.kafka.topic.names"));
		Map<String, Audit> auditResult = kafkaAuditProdConsumer.consumeFromTopic(appProps.get("audit-bolt.kafka.topic.names"));
		Map<String, Entity> exceptionResult = kafkaExceptionProdConsumer.consumeFromTopic(appProps.get("exception-bolt.kafka.topic.names"));
		assertThat(rawInboundResult.isEmpty(), is(false));
		assertThat(domainResult.isEmpty(), is(false));
		assertThat(auditResult.isEmpty(), is(false));
		assertTrue(rawInboundResult.size() >= 5);
		assertTrue(domainResult.size() >= 5);
		assertTrue(auditResult.size() >= 5);
		
	}
	
	*//**
	 * @throws Exception
	 *//*
	@Test
	public void shouldConsumeMessagesFromRioAndEmitSourceRawExceptionAndAuditStreams() throws Exception {
		new RioPublisher().msgCount(5).messageFile("dummy.txt").publish();
		Thread.sleep(10000);
		Map<String, String> rawInboundResult = kafkaRawInboundProdConsumer.consumeFromTopic(appProps.get("raw-inbound-kafka-bolt.kafka.topic.names"));
		Map<String, Entity> domainResult = kafkaDomainProdConsumer.consumeFromTopic(appProps.get("domain-kafka-bolt.kafka.topic.names"));
		Map<String, Audit> auditResult = kafkaAuditProdConsumer.consumeFromTopic(appProps.get("audit-bolt.kafka.topic.names"));
		Map<String, Entity> exceptionResult = kafkaExceptionProdConsumer.consumeFromTopic(appProps.get("exception-bolt.kafka.topic.names"));
		Thread.sleep(1000);
		assertThat(rawInboundResult.isEmpty(), is(false));
		assertThat(auditResult.isEmpty(), is(false));
		assertThat(exceptionResult.isEmpty(), is(false));
		assertTrue(rawInboundResult.size() >= 5);
		assertTrue(exceptionResult.size() >= 5);
		assertTrue(auditResult.size() >= 5);
		
	}
	
	
	*//**
	 * @throws Exception
	 *//*
	@After
	public void teardown() throws Exception{
		kafkaRawInboundProdConsumer.stop();
		kafkaAuditProdConsumer.stop();
		kafkaExceptionProdConsumer.stop();
		kafkaDomainProdConsumer.stop();
		broker.shutdown();
		cluster.killTopology(M2PostCashFxTopologyTest.class.getSimpleName());
	}

*/}
