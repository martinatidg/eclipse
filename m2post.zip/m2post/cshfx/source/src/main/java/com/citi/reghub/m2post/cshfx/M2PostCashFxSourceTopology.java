package com.citi.reghub.m2post.cshfx;



import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.BOLT_THREAD_COUNT;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.CITIML_PARSER_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.CSH_FX_FLOW;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.DOMAIN_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.EXCEPTION_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.MAP_TO_ENTITY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.MERGE_ENTITY_FOR_REPLAY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RAW_MSG_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPLAY_DMN_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPLAY_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPLAY_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RIO_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.RIO_SPOUT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.STREAM;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.CitimlParserBolt;
import com.citi.reghub.core.EntityMapperBolt;
import com.citi.reghub.core.ReplayEntityBolt;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.rio.spouts.RioSpout;
//import com.citi.reghub.core.storm.commons.BaseTopology;
//import com.citi.reghub.core.storm.commons.CitimlParserBolt;
//import com.citi.reghub.core.storm.commons.EntityMapperBolt;
//import com.citi.reghub.core.storm.commons.ReplayEntityBolt;
//import com.citi.reghub.core.storm.kafka.KafkaBoltFactory;
//import com.citi.reghub.core.storm.kafka.KafkaSpoutFactory;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

/**
 * This class creates the Topology for the Sourcing Flow from RIO to RegHub for Commodities Asset Class.
 * @author ak48298
 *
 */
public class M2PostCashFxSourceTopology extends BaseTopology {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCashFxSourceTopology.class);
	
	public static void main(String[] args) throws Exception {
        new M2PostCashFxSourceTopology().runTopology(args);
	}

	/**
	 * The below method configures the Spouts and Bolts for the Commodities Sourcing Topology.
	 * 1. Creates a RIO spout which will read/stream the data form RIO Messaging Infrastructure.
	 * 2. Two Bolts are associated with this RIO spout : RAW Bolt and Message Parse Bolt.
	 * 	  RAW Bolt wills tore the Incoming RAW Message into Mongo through Common Service.
	 * 	  Message Bolt parses the CITIML XML to DOM.
	 * 3. Once processed this data is forwarded for DOM to Entity Conversion.
	 * 4. If any exceptions, the messages are sent to exception Queue.
	 * 
	 * @param  topologyConfig
	 * @return StormTopology
	 * @throws Exception
	 * 
	 */
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		
		LOG.info("Topology creation Started for CSHFX");
		
		String sourceKafkaTopics = topologyConfig.get(REPLAY_TOPIC_NAME);
		String domainDestinationTopicName = topologyConfig.get(DOMAIN_TOPIC_NAME);
		String rawMessageDestinationTopicName = topologyConfig.get(RAW_MSG_TOPIC_NAME);
		Integer boltThreadCount = Integer.parseInt(topologyConfig.get(BOLT_THREAD_COUNT));
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);
		
		TopologyBuilder builder = new TopologyBuilder();
		
		builder.setSpout(RIO_SPOUT_ID, new RioSpout(topologyConfig,RIO_SPOUT_NAME));
		
		builder.setSpout(REPLAY_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM, topologyConfig));
		
		
		builder.setBolt(RAW_MSG_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(rawMessageDestinationTopicName, RAW_MSG_BOLT_NAME, topologyConfig), boltThreadCount).shuffleGrouping(RIO_SPOUT_ID);
		
		builder.setBolt(CITIML_PARSER_BOLT_ID, new CitimlParserBolt()).shuffleGrouping(RIO_SPOUT_ID);
		
		builder.setBolt(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID, new CitimlParserBolt()).
		shuffleGrouping(REPLAY_SPOUT_ID, INBOUND_M2POST_SOURCE_REPLAY_STORM_STREAM);
		
		builder.setBolt(MAP_TO_ENTITY_BOLT_ID, new EntityMapperBolt(new M2PostCshFxEntityMapper(CSH_FX_FLOW, STREAM)))
		.shuffleGrouping(CITIML_PARSER_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID, new EntityMapperBolt(new M2PostCshFxEntityMapper(CSH_FX_FLOW, STREAM)))
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(MERGE_ENTITY_FOR_REPLAY_BOLT_ID, new ReplayEntityBolt())
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		builder.setBolt(DOMAIN_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(domainDestinationTopicName, DOMAIN_BOLT_NAME, topologyConfig), boltThreadCount)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID,StormStreams.SOURCE);
		
		
		
		builder.setBolt(REPLAY_DMN_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(domainDestinationTopicName, DOMAIN_BOLT_NAME, topologyConfig), boltThreadCount)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.SOURCE);
		
		
		
		builder.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), boltThreadCount)
		.shuffleGrouping(CITIML_PARSER_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.AUDIT);
		
		
		
		builder.setBolt(EXCEPTION_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME, topologyConfig), boltThreadCount)
		.shuffleGrouping(CITIML_PARSER_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MAP_TO_ENTITY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(PARSE_FIX_MSG_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MAP_TO_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION)
		.shuffleGrouping(MERGE_ENTITY_FOR_REPLAY_BOLT_ID,StormStreams.EXCEPTION);
		
		
		LOG.info("Topology creation Completed for CSHFX");
		return builder.createTopology();
	}
}
