package com.citi.reghub.m2post.cshfx;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;
import static com.citi.reghub.m2post.utils.xpath.XPathExpressions.*;

import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.citi.reghub.core.Entity;
import com.citi.reghub.m2post.utils.sourcetoentitymappers.AbstractCitiMLToEntityMapper;
import com.citi.reghub.m2post.utils.xpath.XPathUtils;

/**
 * @author ak48298
 *
 */
/**
 * @author ak48298
 *
 */
public class M2PostCshFxEntityMapper extends AbstractCitiMLToEntityMapper{

	private static final long serialVersionUID = 656563698720817301L;
	private static final Logger LOG = LoggerFactory.getLogger(M2PostCshFxEntityMapper.class);

	public M2PostCshFxEntityMapper(String flow, String stream) {
		super(flow, stream);
	}
	
	/**
	 * This methods works on the CITIML DOM using XPATHs. For the corresponding
	 * XPATH provided, it extracts the value from DOM. Converts in into the
	 * expected Data Type and populates the Entity Domain Object.
	 * 
	 * @param message
	 * @param entity
	 * @return Entity
	 * 
	 */
	
	@Override
	public Entity mapToEntity(Object message, Entity entity) {
	
		try {
			
			entity = super.mapToEntity(message, entity);
			
			populateMandatoryFeildsInEntityObject();
			
			setTradeExecutionTs();
			setExecutionVenueType();
			setQtyInMeasurementUnit();
			setVenueOfExecution();
			setPrice();
			setInstrIdentTypeCode();
			setNotionalCurrency();
			setPriceNotation();
			setNotationOfQtyInMeasurementUnit();
			setNotationalAmount();
			setTransactionToClear();
			setOtcPostTradeIndicator();
			setTradedQuantity();
			setInstrumentIdentification();
			setTradeVenueTransactionId();
			setexecutingEntityIdentityficationCode();
			setVenueTrade();
			setLastCapacity();
			setNoPartyIds();
			setAllocationTrades();
			setNonToTvInstrument();
			setFxSpot();
			setPriceDiscoveryAndNegotiatedTransaction();
			setPartyRole();
			setTradeType();
			setOrderCategory();
			setTradeSubtype();
			setBuyerIdentificationCode();
			setTradeReportTransType();
			setFirmTrade();
			setQuantityType();
			setUnitOfMeasureQty();
			setSecondaryTrdType();
			setAlgorithmicTradeIndicator();
			setTradePublishIndicator();
			setTradePriceCondition();
			setSellerIdentificationCode();

		} catch (Exception e) {
			LOG.error(String.format("Exception Occurred while Mapping Entity Object for CSHFX Asset Class : %s",e.getMessage()));
			throw new RuntimeException(e);
		}
		LOG.info(String.format(
				"Mapping for Entity Object Completed for CSHFX Asset Class, created Entity Object : %s", entity));
		return entity;
	}

	/**
	 * This method populates the Price in Entity Domain Object
	 * PNDG Flag is populated if priceType is missing which in turn says Price is Missing
	 * If PriceType is present, Price has to be present.
	 * @throws XPathExpressionException
	 */
	@Override
	protected void setPrice() throws XPathExpressionException {

		String priceType = getNodeValue(PRICE_TYPE_XPATH);

		if (!StringUtils.isBlank(priceType) && (FIXED_PRICE.equals(priceType) || PREMIUM.equals(priceType))) {
			String amount = getNodeValue(PRICE_NOTATION_AMT_XPATH);
			if (null != amount) {
				getDoubleValue(PRICE, amount);
			}
		} else {
			populateEntityFlagList(PNDG);
		}

	}
	
	@Override
	protected void setVenueOfExecution() throws XPathExpressionException {
		populateEntityInfoForStringValues(VENUE_OF_EXECUTION, String.format(PARTY_XPATH, EXEC_FACILITY, EXEC_FAC_ID_SCHEME));
	}
	
	private void setexecutingEntityIdentityficationCode() throws XPathExpressionException {

		String executingEntity_acctmnemonic = getNodeValue(String.format(PARTY_XPATH, EXECUTING_ENTITY, ACCT_MNEMONIC));
		String executingEntity_gfcid = getNodeValue(String.format(PARTY_XPATH, EXECUTING_ENTITY, GFCID));

		populateEntityInfoMap(EXECENTITY_ACCTMNEMONIC, executingEntity_acctmnemonic);
		populateEntityInfoMap(EXECENTITY_GFCID, executingEntity_gfcid);
	}

	private void setFxSpot() throws XPathExpressionException {
		populateEntityInfoForStringValues(FX_SPOT, PRODUCT_DELIVERY_TYPE_XPATH);
	}


	/**
	 * @throws XPathExpressionException
	 */
	private void setTradePriceCondition() throws XPathExpressionException {
		populateEntityInfoForStringValues(TRADE_PRICE_CONDITION, OTC_POST_TRADE_INDICATOR_XPATH);
	}

}
