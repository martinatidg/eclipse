package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.AUDIT_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.INBOUND_M2POST_SEQUENCER_STORM_STREAM;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.KAFKA_TOPIC_NAMES;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.REPORTABLE_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_BOLT_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCED_OUTBOUND_TOPIC_NAME;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCER_BOLT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.SEQUENCER_SPOUT_ID;
import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.TRADE_STATUS_TRANSLATION_BOLT_ID;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.custombolts.SequencerRealTimeBolt;
import com.citi.reghub.m2post.utils.custombolts.StatusTranslationBolt;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;
import com.citi.reghub.m2post.utils.translators.TradeStatusTranslationEligibilityFinder;

/**
 * This class creates the Topology for the Processing the Entity object dispatched by Sourcing. 
 * @author pg60809
 *
 */
public class M2PostCommoditiesSequencerTopology extends BaseTopology {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCommoditiesSequencerTopology.class);
	
	public static void main(String[] args) throws Exception {
		new M2PostCommoditiesSequencerTopology().runTopology(args);
	}

	/**
	 * The below method configures the Spouts and Bolts for the Commodities Sequencer Topology.
	 * 1. Creates a spout which will read/stream the data from Kafka Topic on which Domain will input the data.
	 * 2. Various bolts are associated with the Stream Spout for Rules Processing.
	 * 	2.1. Sequencer Real Time Bolt : This bolt will check the trade status and performs logic based on it to sequence the trade or save it for later.
	 * 3. Once processed this data is forwarded to Sender Sequenced topic.
	 * 4. If any exceptions, the messages are sent to exception Queue.
	 * 
	 * @param  topologyConfig
	 * @return StormTopology
	 * @throws Exception
	 * 
	 */
	@Override
	protected StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		
		LOG.info("Sequencer Topology creation Started for Commodities");
		
		final TopologyBuilder topologyBuilder = new TopologyBuilder();
		
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopicName = topologyConfig.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String sequencedOutboundTopicName = topologyConfig.get(SEQUENCED_OUTBOUND_TOPIC_NAME);
		String reportableTopicName = topologyConfig.get(REPORTABLE_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);

		topologyBuilder.setSpout(SEQUENCER_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_SEQUENCER_STORM_STREAM, topologyConfig), 3);

		topologyBuilder.setBolt(TRADE_STATUS_TRANSLATION_BOLT_ID, new StatusTranslationBolt(new TradeStatusTranslationEligibilityFinder() {}), 3).shuffleGrouping(SEQUENCER_SPOUT_ID, INBOUND_M2POST_SEQUENCER_STORM_STREAM);
		
		topologyBuilder.setBolt(SEQUENCER_BOLT_ID, new SequencerRealTimeBolt(), 3).shuffleGrouping(TRADE_STATUS_TRANSLATION_BOLT_ID, INBOUND_M2POST_SEQUENCER_STORM_STREAM);

		topologyBuilder.setBolt(REPORTABLE_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableOutboundTopicName, REPORTABLE_OUTBOUND_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.PUSHBACK_REPORTABLE_STREAM);

		topologyBuilder.setBolt(SEQUENCED_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(sequencedOutboundTopicName, SEQUENCED_OUTBOUND_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.SEQUENCED_OUTBOUND_STREAM);

		topologyBuilder.setBolt(REPORTABLE_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableTopicName, REPORTABLE_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.COMMON_REPORTABLE_STREAM);

		topologyBuilder.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
				.shuffleGrouping(SEQUENCER_BOLT_ID, StormStreams.AUDIT);

		LOG.info("Sequencer Topology creation Completed for Commodities");
		
		return topologyBuilder.createTopology();
	}

}