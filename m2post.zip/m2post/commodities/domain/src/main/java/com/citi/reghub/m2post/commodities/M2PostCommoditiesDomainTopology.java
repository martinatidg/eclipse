package com.citi.reghub.m2post.commodities;

import static com.citi.reghub.m2post.utils.constants.KafkaStormTopologyConstants.*;
import static com.citi.reghub.m2post.utils.constants.RuleGraphConstants.PRE_ELIGIBILITY_RULE_GRAPH;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EligibilityBolt;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.m2post.utils.storm.StormSpoutBoltGenerator;

/**
 * This class creates the Topology for the Processing the Entity object dispatched by Sourcing. 
 * @author pg60809
 *
 */
public class M2PostCommoditiesDomainTopology extends BaseTopology {

	private static final Logger LOG = LoggerFactory.getLogger(M2PostCommoditiesDomainTopology.class);
	
	public static void main(String[] args) throws Exception {
		new M2PostCommoditiesDomainTopology().runTopology(args);

	}

	/**
	 * The below method configures the Spouts and Bolts for the Commodities Domain Topology.
	 * 1. Creates a spout which will read/stream the data from kafka Topic on which Sourcing will input the data.
	 * 2. Various bolts are associated with the STream Spout for Rules Processing.
	 * 	2.1. Pre Eligibility Bolt : This will valdiate the input for format correct ness as well will do mandatory checks for Non Reportability criteria.
	 * 3. Once processed this data is forwarded to Seqeuncer topic.
	 * 4. If any exceptions, the messages are sent to exception Queue.
	 * 
	 * @param  topologyConfig
	 * @return StormTopology
	 * @throws Exception
	 * 
	 */
	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		LOG.info("Domain Topology creation Started for Commodities");
		
		final TopologyBuilder tp = new TopologyBuilder();
		String sourceKafkaTopics = topologyConfig.get(KAFKA_TOPIC_NAMES);
		String reportableOutboundTopicName = topologyConfig.get(REPORTABLE_OUTBOUND_TOPIC_NAME);
		String nonReportableTopicName = topologyConfig.get(NON_REPORTABLE_TOPIC_NAME);
		String auditTopicName = topologyConfig.get(AUDIT_TOPIC_NAME);
		String exceptionTopicName = topologyConfig.get(EXCEPTION_TOPIC_NAME);

		tp.setSpout(DOMAIN_SPOUT_ID, StormSpoutBoltGenerator.generatekafkaSpout(sourceKafkaTopics, INBOUND_M2POST_DOMAIN_STORM_STREAM, topologyConfig)); 
		
		tp.setBolt(PRE_ELIGIBILITY_RULES_BOLT_ID, new EligibilityBolt(PRE_ELIGIBILITY_RULE_GRAPH), 3).shuffleGrouping(DOMAIN_SPOUT_ID, INBOUND_M2POST_DOMAIN_STORM_STREAM);
		
		//TODO : below commented to be incorporated
		/*tp.setBolt("enrichment", new EnrichmentBolt(CshEqConstants.ENRICHMENT_PLAN_NAME), 3)
		.shuffleGrouping("pre_eligibility", StormStreams.REPORTABLE);

		tp.setBolt("post_enrichment_eligibility", new EligibilityBolt(CshEqConstants.POST_ENRICHMENT_ELIGIBILITY_RULE_GRAPH), 3)
		.shuffleGrouping("enrichment", StormStreams.REPORTABLE);

		tp.setBolt("post_enrichment_biz_exception", new EligibilityBolt(CshEqConstants.POST_ENRICHMENT_BIZ_EXCEPTION_RULE_GRAPH), 3)
		.shuffleGrouping("post_enrichment_eligibility", StormStreams.REPORTABLE);

		tp.setBolt("post_enrichment_tech_exception", new EligibilityBolt(CshEqConstants.POST_ENRICHMENT_TECH_EXCEPTION_RULE_GRAPH), 3)
		.shuffleGrouping("post_enrichment_biz_exception", StormStreams.REPORTABLE);*/
		
		tp.setBolt(REPORTABLE_OUTBOUND_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(reportableOutboundTopicName, REPORTABLE_OUTBOUND_BOLT_NAME, topologyConfig), 3) 
		.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.REPORTABLE);
		
		tp.setBolt(NON_REPORTABLE_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(nonReportableTopicName, NON_REPORTABLE_BOLT_NAME, topologyConfig), 3)
		.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.NON_REPORTABLE);
		
		tp.setBolt(EXCEPTION_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(exceptionTopicName, EXCEPTION_BOLT_NAME, topologyConfig), 3)
		.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.EXCEPTION);
		
		tp.setBolt(AUDIT_BOLT_ID, StormSpoutBoltGenerator.generateKafkaBolt(auditTopicName, AUDIT_BOLT_NAME, topologyConfig), 3)
		.shuffleGrouping(PRE_ELIGIBILITY_RULES_BOLT_ID, StormStreams.AUDIT);

		LOG.info("Domain Topology creation completed for Commodities");
		
		return tp.createTopology();
	}
}
