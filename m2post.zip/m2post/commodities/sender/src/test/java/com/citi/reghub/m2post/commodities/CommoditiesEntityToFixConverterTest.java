package com.citi.reghub.m2post.commodities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;

public class CommoditiesEntityToFixConverterTest {

	private List<Entity> populateTopicData(int msgCount) {
		final int randomNum = new Random().nextInt(1000000) + 1;
		List<Entity> messages = new ArrayList<>();
		IntStream.range(0, msgCount).forEach(value -> {
			Entity t = new Entity();

		    t.regHubId = "" + (randomNum + value);
			t.status = EntityStatus.REPORTABLE;
		    t.info.put("securityID", "ADTBTE567");
		    t.info.put("quantity", 71647.7816);
		    t.info.put("previouslyReported",true);
		    t.info.put("tradeReportID","AFGRV767");
		    t.info.put("lastQty",6776.17346);
		    t.info.put("lastPx",63746134.13);
		    t.info.put("tradeDate",LocalDate.now());
		    t.info.put("symbol","BGR");

		    messages.add(t);
		});
		return messages;
    }
	
	@Test
	public void shouldConvertToFixWhenInputListOfEntitiesProvided () throws Exception {
		
		String expected = "8=FIXT.1.19=12435=AE31=63746134.1332=6776.1734648=ADTBTE567581=11430=O453=2448=DummyLEI447=N452=1448=DummyLEI447=N452=17552=110=209";
		
		CommoditiesEntityToFixConverter testClass = new CommoditiesEntityToFixConverter();
		String outputFix = testClass.convert(populateTopicData(1));
		System.out.println(outputFix);
		Assert.assertEquals(expected, outputFix);
		
	}
	
}
