package com.citi.reghub.m2post.commodities;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;


@RunWith(JUnit4.class)
public class CshfiFixObjectTest {

	@Test
	public void testFrom() throws Exception {
	//Entity e=new EntityBuilder().build();
		//CshfiFixObject cshObject=CshfiFixObject.from(e);
		//System.out.println(cshObject.message);
		//System.out.println(AssitedReport.NO);
		//assertNotNull(cshObject);
		
	}

}
