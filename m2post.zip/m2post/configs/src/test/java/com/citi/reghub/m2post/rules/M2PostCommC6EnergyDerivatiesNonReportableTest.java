package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class M2PostCommC6EnergyDerivatiesNonReportableTest {

	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_com_c6_energy_derivaties_non_reportable_rule.json","comodities");
	}

	@Test
	public void M2PostCommC6EnergyDerrivatiesNonReportableTest1(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("instrumentClassification", "Commodity:Energy:Coal:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommC6EnergyDerrivatiesNonReportableTest2(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("instrumentClassification", "Commodity:Energy:Oil:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommC6EnergyDerrivatiesNonReportableTest3(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("instrumentClassification", "Commodity:Energy:Oil:Physical1");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommC6EnergyDerrivatiesNonReportableTest4(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("instrumentClassification", "Commodity:Energy:Oil1:Physical1");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommC6EnergyDerrivatiesNonReportableTest5(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("instrumentClassification", "Commodity:Energy:Oil1:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
}
