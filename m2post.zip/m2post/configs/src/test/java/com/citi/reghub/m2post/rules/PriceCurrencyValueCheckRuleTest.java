package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class PriceCurrencyValueCheckRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_price_currency_format_check_rule.json","common");
	}

	@Test
	public void shouldRaiseExceptionWhenPriceCurrencyIsNull(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", null).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_Price_currecny_1", result.code);
	}

	@Test
	public void shouldRaiseExceptionWhenPriceCurrencyIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", "").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_Price_currecny_1", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenPriceCurrencyIslessThan3CharsLong(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", "US").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_Price_currecny_1", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenPriceCurrencyIsMoreThan3CharsLong(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", "USDD").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_Price_currecny_1", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenPriceCurrencyIsSmallLetters(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", "usd").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_Price_currecny_1", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenPriceCurrencyIsValid_INR(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", "INR").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_Price_currecny_1", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenPriceCurrencyIsValid_USD(){

		Entity csheqEntity = new EntityBuilder().info("priceCurrency", "USD").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_Price_currecny_1", result.code);
	}
}
