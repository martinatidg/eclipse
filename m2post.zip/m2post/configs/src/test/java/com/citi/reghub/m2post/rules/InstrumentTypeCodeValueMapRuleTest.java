package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class InstrumentTypeCodeValueMapRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_instr_ident_type_code_value_map_rule.json","common");
	}

	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsNull(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", null).build();
		
		assertNull(csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertNull(csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "").build();
		
		assertEquals("", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("", csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsInvalid(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ABCD").build();
		
		assertEquals("ABCD", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("ABCD", csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
	@Test
	public void shouldMapValueTo1WhenInstrIdentTypeCodeIsCUSIP(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "CUSIP").build();
		
		assertEquals("CUSIP", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(1, csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
	@Test
	public void shouldMapValueTo101WhenInstrIdentTypeCodeIsFII(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "FII").build();
		
		assertEquals("FII", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(101, csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
	@Test
	public void shouldMapValueTo4WhenInstrIdentTypeCodeIsISIN(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		
		assertEquals("ISIN", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(4, csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
	@Test
	public void shouldMapValueTo2WhenInstrIdentTypeCodeIsSEDOL(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "SEDOL").build();
		
		assertEquals("SEDOL", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(2, csheqEntity.info.get("instrIdentCodeType"));
		
	}
	
}
