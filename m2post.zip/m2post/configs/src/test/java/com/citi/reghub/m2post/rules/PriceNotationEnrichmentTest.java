package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class PriceNotationEnrichmentTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_price_notation_enrichment_rule.json","common");
	}

	@Test
	public void shouldRaiseBusinessExceptionWhenPriceNotationValueIsNull(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", null).build();
		assertNull(csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertNull(csheqEntity.info.get("priceNotation"));
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenPriceNotationValueIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "").build();
		assertEquals("",csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals("",csheqEntity.info.get("priceNotation"));
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenPriceNotationValueIsNotNullOrEmptyButInvalid(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "ABCD").build();
		assertEquals("ABCD",csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals("ABCD",csheqEntity.info.get("priceNotation"));
	}

	@Test
	public void shouldMapTo2WhenPriceNotationValueIsMONE(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "MONE").build();
		assertEquals("MONE",csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(2,csheqEntity.info.get("priceNotation"));
	}
	
	@Test
	public void shouldMapTo1WhenPriceNotationValueIsPERC(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		assertEquals("PERC",csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(1,csheqEntity.info.get("priceNotation"));
	}
	
	@Test
	public void shouldMapTo9WhenPriceNotationValueIsYIEL(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "YIEL").build();
		assertEquals("YIEL",csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(9,csheqEntity.info.get("priceNotation"));
	}
	
	@Test
	public void shouldMapTo22WhenPriceNotationValueIsBAPO(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "BAPO").build();
		assertEquals("BAPO",csheqEntity.info.get("priceNotation"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(22,csheqEntity.info.get("priceNotation"));
	}
	
}
