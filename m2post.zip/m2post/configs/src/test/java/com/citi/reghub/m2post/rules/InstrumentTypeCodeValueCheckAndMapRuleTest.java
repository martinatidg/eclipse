package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class InstrumentTypeCodeValueCheckAndMapRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_instr_ident_type_code_value_check_and_map_rule.json","common");
	}

	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsNull(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", null).build();
		
		assertNull(csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertNull(csheqEntity.info.get("instrIdentCodeType"));
		
		assertEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "").build();
		
		assertEquals("", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("", csheqEntity.info.get("instrIdentCodeType"));
		
		assertEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsInvalid(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ABCD").build();
		
		assertEquals("ABCD", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("ABCD", csheqEntity.info.get("instrIdentCodeType"));
		
		assertEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsCUSIP(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "CUSIP").build();
		
		assertEquals("CUSIP", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("CUSIP", csheqEntity.info.get("instrIdentCodeType"));
		
		assertNotEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsFII(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "FII").build();
		
		assertEquals("FII", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("FII", csheqEntity.info.get("instrIdentCodeType"));
		
		assertNotEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsISIN(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		
		assertEquals("ISIN", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("ISIN", csheqEntity.info.get("instrIdentCodeType"));
		
		assertNotEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenInstrIdentTypeCodeIsSEDOL(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "SEDOL").build();
		
		assertEquals("SEDOL", csheqEntity.info.get("instrIdentCodeType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("SEDOL", csheqEntity.info.get("instrIdentCodeType"));
		
		assertNotEquals("business_exception_instr_ident_code_type_not_of_defined_value", result.code);
	}
	
}
