package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class NotationalCurrencyValueCheckRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_notational_currency_format_check_rule.json","common");
	}

	@Test
	public void shouldRaiseExceptionWhenNotationalCurrencyIsNull(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", null).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_notational_currecny_1", result.code);
	}

	@Test
	public void shouldRaiseExceptionWhenNotationalCurrencyIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", "").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_notational_currecny_1", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenNotationalCurrencyIslessThan3CharsLong(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", "US").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_notational_currecny_1", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenNotationalCurrencyIsMoreThan3CharsLong(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", "USDD").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_notational_currecny_1", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenNotationalCurrencyIsSmallLetters(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", "usd").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_notational_currecny_1", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenNotationalCurrencyIsValid_INR(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", "INR").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_notational_currecny_1", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenNotationalCurrencyIsValid_USD(){

		Entity csheqEntity = new EntityBuilder().info("notionalCurrency", "USD").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_notational_currecny_1", result.code);
	}
}
