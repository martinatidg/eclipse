package com.citi.reghub.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.enrichment.client.enricher.Enricher;
import com.citi.reghub.core.rules.client.DroolsEngine;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MockMetadataEnricher extends Enricher{

	@Override
	public EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefreshCache) {
		Map<String, Object> metadata = parseMetadataJsonFile((String)enricherConfig.configuration.get("lookupKey"));
		Rule enrichmentRule = new Rule(
				enricherConfig.enricherId,
				enricherConfig.enricherName,
				(String)enricherConfig.configuration.get(UPDATE_DEFINITION),
				null,
				new ArrayList<>()
		);
		RuleResult ruleResult = DroolsEngine.getEngine().execute(enrichmentRule, root, metadata, forceRefreshCache); 
		return new EnricherResult(ruleResult.ruleName, ruleResult.comments, ruleResult.value);
	}

	private Map<String, Object> parseMetadataJsonFile(String filename){
		if(filename == null || "".equals(filename)) {
			return new HashMap<>();
		}
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/metadata/"+filename + ".json"));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map metaMap = objMapper.readValue(jsonData, Map.class);
			return (Map<String, Object>) metaMap.get("value");
		} catch (IOException e) {
			throw new RuntimeException("Error loading rule json file: " + filename, e);
		}
	}
}
