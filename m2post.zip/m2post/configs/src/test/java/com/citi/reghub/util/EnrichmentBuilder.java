package com.citi.reghub.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherFactory;
import com.citi.reghub.core.enrichment.client.EnrichmentClientConfig;
import com.citi.reghub.core.enrichment.client.enricher.Enricher;
import com.citi.reghub.core.metadata.client.Metadata;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EnrichmentBuilder {
	
	public EnricherConfig build(String filename, EnrichmentClientConfig enrichmentClientConfig) {
		return parseEnrichmentConfigJsonFile(filename); 
	}
	
	public static Enricher getEnricher(EnricherConfig enricherConfig, EnrichmentClientConfig enrichmentClientConfig){
		if("metadata".equalsIgnoreCase(enricherConfig.type)) {
			return new MockMetadataEnricher().setConfig(enrichmentClientConfig);
		}
		return EnricherFactory.getEnricher(enricherConfig.type).setConfig(enrichmentClientConfig);
	}
	
	public EnricherConfig parseEnrichmentConfigJsonFile(String filename){
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/enricher/"+filename));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			EnricherConfig enrichmentConfig = objMapper.readValue(jsonData, EnricherConfig.class);
			buildeEnrichmentDefinition(enrichmentConfig);
			return enrichmentConfig;
		} catch (IOException e) {
			throw new RuntimeException("Error loading encrichment json file: " + filename, e);
		}
	}
	
	private void buildeEnrichmentDefinition(EnricherConfig enrichmentConfig) {
		Pattern p = Pattern.compile("encodeFileAsBase64\\((.*?)\\)");
		Matcher updateDefMatcher = p.matcher(enrichmentConfig.configuration.get("updateDefinition").toString());
		if(updateDefMatcher.matches()){
			enrichmentConfig.configuration.put("updateDefinition", definitionAsBase64Encoding(updateDefMatcher.group(1)));
		}
		if (enrichmentConfig.configuration.get("lookupKeyDefinition") != null){
			Matcher lookupKeyMatcher = p.matcher(enrichmentConfig.configuration.get("lookupKeyDefinition").toString());
			if(lookupKeyMatcher.matches()){
				enrichmentConfig.configuration.put("lookupKeyDefinition", definitionAsBase64Encoding(lookupKeyMatcher.group(1)));
			}	
		}		
	}
	
	public String definitionAsBase64Encoding(String filePath) {
		try {
			Path resourcePath =  Paths.get(new File(filePath).getAbsoluteFile().toURI());
			byte[] definition = Files.readAllBytes(resourcePath);
			byte[] encodedDefinition = Base64.getEncoder().encode(definition);
			return new String(encodedDefinition);
		} catch (IOException e) {
			throw new RuntimeException("Error loading drools file: " + filePath, e);
		}
	}
	
	private Metadata parseMetadataJsonFile(String filename){
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/metadata/"+filename));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map metaMap = objMapper.readValue(jsonData, Map.class);
			return new Metadata(metaMap);
		} catch (IOException e) {
			throw new RuntimeException("Error loading rule json file: " + filename, e);
		}
	}
}
