package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;

public class M2PostCommJurisdictionRemitNonReportableTest {

	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_com_jurisdiction_remit_non_reportable.json","comodities");
	}

	@Test
	public void M2PostCommJurisdictionRemitNonReportableTest1(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(JURISDICTION, "REMIT");
		commEntityBuilder.info(VENUE_OF_EXECUTION, "OTF");
		commEntityBuilder.info(INSTRUMENT_CLASSIFICATION, "Commodity:Energy:Elec:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommJurisdictionRemitNonReportableTest2(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(JURISDICTION, "REMIT");
		commEntityBuilder.info(VENUE_OF_EXECUTION, "OTF");
		commEntityBuilder.info(INSTRUMENT_CLASSIFICATION, "Commodity:Energy:Gas:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommJurisdictionRemitNonReportableTest3(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(JURISDICTION, "REMIT");
		commEntityBuilder.info(VENUE_OF_EXECUTION, "OTF");
		commEntityBuilder.info(INSTRUMENT_CLASSIFICATION, "Commodity:Energy:Oil:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommJurisdictionRemitNonReportableTest4(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(JURISDICTION, "REMIT");
		commEntityBuilder.info(VENUE_OF_EXECUTION, "OTF1");
		commEntityBuilder.info(INSTRUMENT_CLASSIFICATION, "Commodity:Energy:Elec:Physical");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCommJurisdictionRemitNonReportableTest5(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(JURISDICTION, "REMIT");
		commEntityBuilder.info(VENUE_OF_EXECUTION, "OTF");
		commEntityBuilder.info(INSTRUMENT_CLASSIFICATION, "Commodity:Energy:Elec:Physical1");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
}
