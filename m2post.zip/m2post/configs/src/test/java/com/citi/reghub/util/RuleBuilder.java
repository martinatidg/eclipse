package com.citi.reghub.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.citi.reghub.core.metadata.client.Metadata;
import com.citi.reghub.core.rules.client.Rule;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RuleBuilder {

	public Rule build(String filename, String flowName) {
		Rule rule = parseRuleJsonFile(filename,flowName);
		rule.metadata.forEach(meta -> {
			meta.value = parseMetadataJsonFile(meta.name + ".json",flowName).value;
		});
		return rule;
	}

	public String definitionAsBase64Encoding(String filePath) {
		try {
			byte[] ruleDefinition = Files.readAllBytes(Paths.get(filePath));
			byte[] encodedRule = Base64.getEncoder().encode(ruleDefinition);
			return new String(encodedRule);
		} catch (Exception e) {
			throw new RuntimeException("Error loading drools rule file: " + filePath, e);
		}
	}

	public Rule parseRuleJsonFile(String filename, String flowName) {
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/"+flowName+"/rules/" + filename));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Rule rule = objMapper.readValue(jsonData, MockRule.class);
			buildeRuleDefinition(rule);
			return rule;
		} catch (IOException e) {
			throw new RuntimeException("Error loading rule json file: " + filename, e);
		}
	}

	private void buildeRuleDefinition(Rule rule) {
		Pattern p = Pattern.compile("encodeFileAsBase64\\((.*?)\\)");
		Matcher m = p.matcher(rule.definition);
		if (m.matches()) {
			rule.definition = definitionAsBase64Encoding(m.group(1));
		}
	}

	private Metadata parseMetadataJsonFile(String filename,String flowName) {
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/"+flowName+"/metadata/" + filename));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map metaMap = objMapper.readValue(jsonData, Map.class);
			return new Metadata(metaMap);
		} catch (IOException e) {
			throw new RuntimeException("Error loading rule json file: " + filename, e);
		}
	}

}
