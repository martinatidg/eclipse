package com.citi.reghub.m2post.rulegraph;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.NonRepotableCode;
import com.citi.reghub.core.rules.client.RuleGraph;
import com.citi.reghub.core.rules.client.RuleGraphResult;
import com.citi.reghub.util.RuleGraphBuilder;

public class PreEligibilityRuleGraphTests {
	
	RuleGraph ruleGraph;

	@Before
	public void setUp(){
		ruleGraph = new RuleGraphBuilder().build("m2p0st_all_eligibility_check.json");
	}

	@Test
	public void testPreEligibilityRuleGraphReportable(){
		Entity csheqEntity = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 12, 12)).build();
		RuleGraphResult result = ruleGraph.execute(csheqEntity, new HashMap<String, Object>(), true);
		Assert.assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		Assert.assertEquals(EntityStatus.REPORTABLE, result.getStatus());
	}
	
	@Test
	public void testPreEligibilityRuleGraphNonReportable(){
		Entity csheqEntity = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 04)).build();
		RuleGraphResult result = ruleGraph.execute(csheqEntity, new HashMap<String, Object>(), true);
		Assert.assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		Assert.assertEquals(EntityStatus.NON_REPORTABLE, result.getStatus());
		assertEquals(NonRepotableCode.NON_REPORTABLE_PRE_MIFID_TRADE, result.resultCodes.get(0));
	}

}
