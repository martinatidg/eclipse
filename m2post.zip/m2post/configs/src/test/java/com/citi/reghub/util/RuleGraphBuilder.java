package com.citi.reghub.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleGraph;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RuleGraphBuilder {

	private RuleGraph ruleGraph;

	public RuleGraph build(String filename){
		parseRuleGraphJson(filename);
		prepareRuleGraph();
		return ruleGraph;
	}
	
	private String getFlowName(String ruleName){
		String [] ruleTokens = ruleName.split("_");
		if(ruleTokens.length>2 && null!=ruleTokens[2]){
			if(ruleTokens[1].equalsIgnoreCase("All"))
				return "common";
			else
				return ruleTokens[1];
				
		}
		return "common";
	}

	private void prepareRuleGraph() {
		// TODO Auto-generated method stub
		List<Rule> rules = new ArrayList<Rule>();
		ruleGraph.rules.forEach(rule -> {
			rules.add(new RuleBuilder().build(rule.name+".json",getFlowName(rule.name)));
		});
		ruleGraph.rules = rules;
	}

	private void parseRuleGraphJson(String filename) {
		// TODO Auto-generated method stub
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/"+getFlowName(filename)+"/rule_graphs/"+filename));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map<String,Object> ruleGraphJsonMap= objMapper.readValue(jsonData, HashMap.class);
			ruleGraph = new RuleGraph();
			ruleGraph.id = (String) ruleGraphJsonMap.get("id");
			ruleGraph.name = (String) ruleGraphJsonMap.get("name");
			ruleGraph.group = (String) ruleGraphJsonMap.get("group");
			ruleGraph.description = (String) ruleGraphJsonMap.get("description");
			ruleGraph.type = (String) ruleGraphJsonMap.get("type");
			List<Map<String,String>> ruleNameList = (List<Map<String,String>>) ruleGraphJsonMap.get("rules");
			ruleNameList.forEach(ruleName ->{
				Rule rule = new Rule();
				rule.name = ruleName.get("ruleName");
				ruleGraph.rules.add(rule);
			});
		} catch (IOException e) {
			throw new RuntimeException("Error loading rule json file: " + filename, e);
		}
	}


}

