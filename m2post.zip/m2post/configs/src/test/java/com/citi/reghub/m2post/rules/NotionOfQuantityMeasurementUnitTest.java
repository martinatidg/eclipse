package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class NotionOfQuantityMeasurementUnitTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_notation_of_qty_value_check_rule.json","common");
	}

	@Test
	public void testQuantityMeasurementUnit1(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit",null).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testQuantityMeasurementUnit2(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit3(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "ABCD").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit4(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "ABCDEFGHIJKLMNOPQRSTUVWXYZ1").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testQuantityMeasurementUnit5(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "TOCD").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit6(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "ABCDEFGHIJKLMNOPQRSTUVWX1").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit7(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "53").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit8(){

		Entity entity = new EntityBuilder().info("notationOfQtyInMsrmntUnit", "1abcd").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	
}
