package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class PreMifidRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_pre_mifid_rule.json","common");
	}

	@Test
	public void testPreMifidRuleReportable(){

		Entity csheqEntity = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 6)).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	@Test
	public void testPreMifidRuleNonReportable(){

		Entity csheqEntity = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 4)).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
		assertEquals("non_reportable_pre_mifid_trade", result.code);
	}

	@Test
	public void testPreMifidRuleBoundaryCondition(){

		Entity csheqEntity = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 5)).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);	
	}
}
