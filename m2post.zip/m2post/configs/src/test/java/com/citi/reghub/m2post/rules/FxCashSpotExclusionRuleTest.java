package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class FxCashSpotExclusionRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_cshfx_spot_instrument_exclude.json","cshfx");
	}

	@Test
	public void testCashFxSpotInstrumentRuleReportable(){

		Entity cshfxEntity = new EntityBuilder().info("productDeliveryType", "FX_CASH").build();
		RuleResult result = rule.execute(cshfxEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, cshfxEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	@Test
	public void testCashFxSpotInstrumentNonRuleReportable(){

		Entity cshfxEntity = new EntityBuilder().info("productDeliveryType", "FX_SPOT").build();
		RuleResult result = rule.execute(cshfxEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, cshfxEntity.status);	
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
		assertEquals("non_reportable_cshfx_spot_instrument", result.code);
	}
}
