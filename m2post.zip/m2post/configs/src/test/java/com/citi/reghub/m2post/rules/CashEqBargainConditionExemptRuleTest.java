package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants;
import com.citi.reghub.util.RuleBuilder;

public class CashEqBargainConditionExemptRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_csheq_bargain_c0nditi0n_exempt_rule.json","csheq");
	}

	@Test
	public void testTradeReportBargainConditonExemptNonReportable(){

		Entity csheqEntity = new EntityBuilder().build();
		csheqEntity.info.put(InfoMapKeyStringConstants.BARGAIN_CONDITIONS, "RP");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
	}
	
	@Test
	public void testTradeReportBargainConditonExemptReportable(){

		Entity csheqEntity = new EntityBuilder().build();
		csheqEntity.info.put(InfoMapKeyStringConstants.EX_DESTINATION, "ZZ");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertNotEquals(EntityStatus.NON_REPORTABLE, result.status);
	}

}
