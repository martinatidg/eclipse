package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class ComEmissionAllowanceValueCheckAndMapRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_com_emission_allowance_type_value_check_and_map_rule.json","comodities");
	}

	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsNull(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", null).build();
		
		assertNull(csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertNull(csheqEntity.info.get("emissionAllowanceType"));
		
		assertEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "").build();
		
		assertEquals("", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("", csheqEntity.info.get("emissionAllowanceType"));
		
		assertEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsInvalid(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "ABCD").build();
		
		assertEquals("ABCD", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("ABCD", csheqEntity.info.get("emissionAllowanceType"));
		
		assertEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsEUAE(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "EUAE").build();
		
		assertEquals("EUAE", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("EUAE", csheqEntity.info.get("emissionAllowanceType"));
		
		assertNotEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsCERE(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "CERE").build();
		
		assertEquals("CERE", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("CERE", csheqEntity.info.get("emissionAllowanceType"));
		
		assertNotEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsERUE(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "ERUE").build();
		
		assertEquals("ERUE", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("ERUE", csheqEntity.info.get("emissionAllowanceType"));
		
		assertNotEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsEUAA(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "EUAA").build();
		
		assertEquals("EUAA", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("EUAA", csheqEntity.info.get("emissionAllowanceType"));
		
		assertNotEquals("business_exception_emission_allowance_type_not_of_defined_value", result.code);
	}
	
}
