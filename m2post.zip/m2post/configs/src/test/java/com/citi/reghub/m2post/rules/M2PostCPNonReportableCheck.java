package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class M2PostCPNonReportableCheck {

Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_cp_non_reportable.json","common");
	}

	@Test
	public void M2PostCommJurisdictionRemitNonReportableTest1(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("CP", "EEA");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
	}
	
	@Test
	public void M2PostCPNonReportableCheck2(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info("CP", "NON_EEA");
		Entity commEntity = commEntityBuilder.build();
		RuleResult result = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
}
