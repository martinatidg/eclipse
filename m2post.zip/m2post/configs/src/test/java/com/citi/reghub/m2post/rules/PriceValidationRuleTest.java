package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.math.BigDecimal;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class PriceValidationRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_price_validation_rule.json","common");
	}

	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsNull(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", null).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsMONEButPriceIsNull(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "MONE").build();
		csheqEntity.info.put("price", null);
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsPERCButPriceIsNull(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		csheqEntity.info.put("price", null);
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsMONEButPriceIsNotOfGivenBigDecimalFormat(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "MONE").build();
		csheqEntity.info.put("price", new BigDecimal("1.12345678987654324567"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsPERCButPriceIsNotOfGivenBigDecimalFormat(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		csheqEntity.info.put("price", new BigDecimal("155555.12345678987654324567"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenpriceNotationIsMONEButPriceIsOfGivenBigDecimalFormat_1(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "MONE").build();
		csheqEntity.info.put("price", new BigDecimal("1.12365478541254789"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenpriceNotationIsPERCButPriceIsOfGivenBigDecimalFormat_1(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		csheqEntity.info.put("price", new BigDecimal("14256.3652147854123"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenpriceNotationIsMONEButPriceIsOfGivenBigDecimalFormat_2(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "MONE").build();
		csheqEntity.info.put("price", new BigDecimal("12541254789652321.2"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenpriceNotationIsPERCButPriceIsOfGivenBigDecimalFormat_2(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		csheqEntity.info.put("price", new BigDecimal("0.0125478541236"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
		assertNotEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsPERCButPriceIsOfGivenBigDecimalFormatIsHavingMoreThan13Precision(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		csheqEntity.info.put("price", new BigDecimal("0.01254785412547856"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenpriceNotationIsMONEButPriceIsOfGivenBigDecimalFormatIsHavingMoreThan17Precision(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		csheqEntity.info.put("price", new BigDecimal("1.12547896541236589745"));
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_invalid_price_format", result.code);
	}
	
}
