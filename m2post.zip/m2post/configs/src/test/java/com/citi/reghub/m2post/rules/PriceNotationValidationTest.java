package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class PriceNotationValidationTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_price_notation_value_check_rule.json","common");
	}

	@Test
	public void shouldRaiseBusinessExceptionWhenPriceNotationValueIsNull(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", null).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("business_exception_price_notation_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenPriceNotationValueIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("business_exception_price_notation_not_of_defined_value", result.code);
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenPriceNotationValueIsNotNullOrEmptyButInvalid(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "ABCD").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("business_exception_price_notation_not_of_defined_value", result.code);
	}

	@Test
	public void shouldNotRaiseBusinessExceptionWhenPriceNotationValueIsMONE(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "MONE").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void shouldNotRaiseBusinessExceptionWhenPriceNotationValueIsPERC(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "PERC").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void shouldNotRaiseBusinessExceptionWhenPriceNotationValueIsYIEL(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "YIEL").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void shouldNotRaiseBusinessExceptionWhenPriceNotationValueIsBAPO(){

		Entity csheqEntity = new EntityBuilder().info("priceNotation", "BAPO").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
}
