package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class VenueOfExecutionFormatCheckRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_venue_of_execution_format_check_rule.json","common");
	}

	@Test
	public void shouldRaiseExceptionWhenVenueOfExecutionIsNull(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", null).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}

	@Test
	public void shouldRaiseExceptionWhenVenueOfExecutionIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenVenueOfExecutionIsLessThan4CharsLong(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "XAB").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenVenueOfExecutionIsMoreThan4CharsLong(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "XABCC").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenVenueOfExecutionDoesNotStartWithX(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "ABCC").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
	
	@Test
	public void shouldRaiseExceptionWhenVenueOfExecutionIsSmallLetters(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "xabc").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenVenueOfExecutionDoesStartWithXand4CharsLong_XOFF(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "XOFF").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertNotEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenVenueOfExecutionDoesStartWithXand4CharsLong_XEUR(){

		Entity csheqEntity = new EntityBuilder().info("venueOfExecution", "XEUR").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);
		assertNotEquals("biz_exception_incorrect_venue_of_execution_format", result.code);
	}
}
