package com.citi.reghub.m2post.rules;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRANSACTION_TO_CLEAR;
import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class TransactionToBeClearedTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_transaction_to_be_cleared_check_rule.json","common");
	}

	@Test
	public void testQuantityMeasurementUnit1(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR,null).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testQuantityMeasurementUnit2(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit3(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "abc").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit4(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "ABCabc123").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit5(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "123").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testQuantityMeasurementUnit6(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "true").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit7(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "True").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit8(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "False").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit9(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "false").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit10(){

		Entity entity = new EntityBuilder().info(TRANSACTION_TO_CLEAR, "FALSE").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	
}
