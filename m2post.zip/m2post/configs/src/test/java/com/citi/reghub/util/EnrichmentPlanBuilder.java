package com.citi.reghub.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnrichmentClientConfig;
import com.citi.reghub.core.enrichment.client.EnrichmentPlan;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EnrichmentPlanBuilder {

	private EnrichmentPlan enrichmentPlan;
	private EnrichmentClientConfig enrichmentClientConfig;
	
	public EnrichmentPlan build(String filename, EnrichmentClientConfig enrichmentClientConfig){
		this.enrichmentClientConfig = enrichmentClientConfig;
		parseEnrichmentPlanJson(filename);
		prepareEnrichmentPlan();
		return enrichmentPlan;
	}

	private void prepareEnrichmentPlan() {
		List<EnricherConfig> enrichers = new ArrayList<>();
		enrichmentPlan.enricherConfigs.forEach(enricher -> {
			enrichers.add(new EnrichmentBuilder().build(enricher.enricherName + ".json", enrichmentClientConfig));
		});
		enrichmentPlan.enricherConfigs = enrichers;
		
	}

	private void parseEnrichmentPlanJson(String filename) {
		try {
			byte[] jsonData = Files.readAllBytes(Paths.get("seed/enrichment_plan/"+filename));
			ObjectMapper objMapper = new ObjectMapper();
			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Map<String,Object> enrichmentPlanJsonMap = objMapper.readValue(jsonData, HashMap.class);
			enrichmentPlan = new EnrichmentPlan();
			enrichmentPlan.id = (String) enrichmentPlanJsonMap.get("id");
			enrichmentPlan.name = (String) enrichmentPlanJsonMap.get("name");
			enrichmentPlan.group = (String) enrichmentPlanJsonMap.get("group");
			enrichmentPlan.description = (String) enrichmentPlanJsonMap.get("description");
			enrichmentPlan.type = (String) enrichmentPlanJsonMap.get("type");
			List<Map<String,String>> enrichersNameList = (List<Map<String,String>>) enrichmentPlanJsonMap.get("enrichers");
			enrichersNameList.forEach(enricherName ->{
				EnricherConfig enricher = new EnricherConfig();
				enricher.enricherName = enricherName.get("enricherName");
				enrichmentPlan.enricherConfigs.add(enricher);
			});
		} catch (IOException e) {
			throw new RuntimeException("Error loading rule json file: " + filename, e);
		}
	}
}
