package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class AllocationStatusRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_allocation_status_exclude.json","common");
	}

	@Test
	public void testAllocationTradeStatusReportable(){

		Entity csheqEntity = new EntityBuilder().info("allocationTradeStatus", "block").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);	
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	@Test
	public void testAllocationTradeStatusNonReportable(){

		Entity csheqEntity = new EntityBuilder().info("allocationTradeStatus", "alloc").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, result.status);
		assertEquals("non_reportable_tradeType_allocated", result.code);
	}
	
	@Test
	public void testAllocationTradeStatusNonReportableNullkey(){

		Entity csheqEntity = new EntityBuilder().build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
}
