package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;
import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;

public class M2PostMicCodeCheck {

	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_citi_mic_code_check.json","common");
	}

	@Test
	public void M2PostCitiLegalEntityCheck1(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(VENUE_OF_EXECUTION, "XOFF");
		Entity commEntity = commEntityBuilder.build();
		RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostCitiLegalEntityCheck2(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(VENUE_OF_EXECUTION, "XOFG");
		Entity commEntity = commEntityBuilder.build();
		RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
}
