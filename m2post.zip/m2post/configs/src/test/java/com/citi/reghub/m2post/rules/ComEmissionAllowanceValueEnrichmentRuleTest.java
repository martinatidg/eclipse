package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class ComEmissionAllowanceValueEnrichmentRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_com_emission_allowance_type_enrichment_rule.json","comodities");
	}

	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsNull(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", null).build();
		
		assertNull(csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertNull(csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "").build();
		
		assertEquals("", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("", csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
	@Test
	public void shouldRaiseBusinessExceptionWhenemissionAllowanceTypeIsInvalid(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "ABCD").build();
		
		assertEquals("ABCD", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("ABCD", csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
	@Test
	public void shouldMapToEUAWhenemissionAllowanceTypeIsEUAE(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "EUAE").build();
		
		assertEquals("EUAE", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("EUA", csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
	@Test
	public void shouldMapToCERWhenemissionAllowanceTypeIsCERE(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "CERE").build();
		
		assertEquals("CERE", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);

		assertEquals("CER", csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
	@Test
	public void shouldMapToERUWhenemissionAllowanceTypeIsERUE(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "ERUE").build();
		
		assertEquals("ERUE", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("ERU", csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
	@Test
	public void shouldMapToEUAAWhenemissionAllowanceTypeIsEUAA(){

		Entity csheqEntity = new EntityBuilder().info("emissionAllowanceType", "EUAA").build();
		
		assertEquals("EUAA", csheqEntity.info.get("emissionAllowanceType"));
		
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		
		assertEquals("EUAA", csheqEntity.info.get("emissionAllowanceType"));
		
	}
	
}
