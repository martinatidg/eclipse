package com.citi.reghub.m2post.rules;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.OTC_POST_TRADE_INDICATOR;
import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class OTCPostTradeIndicatorTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_OTC_p0st_trade_indicator_check_rule.json","common");
	}

	@Test
	public void otcPostTradeIndiator1(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR,null).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void otcPostTradeIndiator2(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator3(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "ABCD").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator4(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "abcd").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator5(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "BENC;CANC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator6(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "BENCCANC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator7(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "AMND,TPAC,XFPHA").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator8(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "AMND,TPAC,XFPHBENC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator9(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "BENC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator10(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "ACTX").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	@Test
	public void otcPostTradeIndiator11(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "LRGS").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator12(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "ILQD").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator13(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "SIZE").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator14(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "CANC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator15(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "AMND").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator16(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "SDIV").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator17(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "RPRI").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator18(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "DUPL").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator19(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "TNCP").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator20(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "TPAC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	
	@Test
	public void otcPostTradeIndiator21(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "BENC,ACTX").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator22(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "CANC,AMND,SDIV,TPAC").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator23(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "XFPH").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator24(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "XFPH,   TPAC, SDIV , SIZE ,ILQD").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator25(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "BENC, ACTX, LRGS, ILQD, SIZE, CANC, AMND, SDIV, RPRI, DUPL, TNCP, TPAC, XFPH").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	
	@Test
	public void otcPostTradeIndiator26(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "benc, actx, lrgs, ilqd, size, canc, amnd, sdiv, rpri, dupl, tncp, tpac, xfph").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator27(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "benc, actx, lrgs, ilqd, size, canc, AMND, SDIV, RPRI, DUPL, TNCP, TPAC, XFPH").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void otcPostTradeIndiator28(){

		Entity entity = new EntityBuilder().info(OTC_POST_TRADE_INDICATOR, "  benc  , actx  , lrgs  , ilqd  , size  , canc  , AMND  , SDIV, RPRI  , DUPL  , TNCP, TPAC  , XFPH  ").build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	

	
}
