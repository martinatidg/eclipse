package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class NotionalAmountTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_notational_amount_format_check_rule.json","common");
	}

	@Test
	public void testQuantityMeasurementUnit1(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("0.012345")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit2(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("123456789012345678.0")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit3(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("1234567890123456789")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit4(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("12345678901234.01234")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit5(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal(".012345")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit6(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("123456789.01234")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit7(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("0.01234")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testQuantityMeasurementUnit8(){

		Entity entity = new EntityBuilder().info("notationalAmount", new BigDecimal("12345678901234567.0")).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	
}
