package com.citi.reghub.m2post.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class ISINValidationRuleTest {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_isin_format_validation_rule.json","common");
	}

	@Test
	public void shouldRaiseExceptionWhenIdentCodeIsNull(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", null).build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "").build();
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueIsNull(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", null);
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueIsEmpty(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueContainesOnlyAplhabets(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "INRTYUIKJNHG");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueContainesOnlyNumbers(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "1234567896");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueContainesMoreThenTwoInitAplhabets(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "IND123456789");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueLengthIsLessThen12(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "IN1234569");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldRaiseExceptionWhenIdentCodeValueLengthIsMoreThen12(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "IN1234569");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenIdentCodeValueIsOfValidFormat(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "IN9876789540");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
	@Test
	public void shouldNotRaiseExceptionWhenIdentCodeValueIsOfInCorrectCasingButOfValidFormat(){

		Entity csheqEntity = new EntityBuilder().info("instrIdentCodeType", "ISIN").build();
		csheqEntity.info.put("instrIdentCode", "In9876789540");
		RuleResult result = rule.execute(csheqEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, csheqEntity.status);
		assertNotEquals(EntityStatus.BIZ_EXCEPTION, result.status);	
	}
	
}
