package com.citi.reghub.m2post.rules;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.*;
import static org.junit.Assert.assertEquals;
import java.util.HashMap;
import org.junit.Before;
import org.junit.Test;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class M2PostBuySellSiAssistingReporting {

	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_buy_sell_si_assisted_reporting.json","common");
	}

	@Test
	public void M2PostBuySellSiAssistingReporting1(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(BUY_SELL_IND, "Buy");
		commEntityBuilder.info(EXEC_FIRM_SI, "N");
		commEntityBuilder.info(CPTY_FIRM_SI, "N");
		commEntityBuilder.info(ASSISTED_REPORT, "Y");
		commEntityBuilder.info(CPTY_REGION, "NON_EEA");
		Entity commEntity = commEntityBuilder.build();
		RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting2(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(BUY_SELL_IND, "Buy");
		commEntityBuilder.info(EXEC_FIRM_SI, "N");
		commEntityBuilder.info(CPTY_FIRM_SI, "N");
		commEntityBuilder.info(ASSISTED_REPORT, "N");
		commEntityBuilder.info(CPTY_REGION, "EEA");
		Entity commEntity = commEntityBuilder.build();
		RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.NON_REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting3(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(BUY_SELL_IND, "Buy");
		commEntityBuilder.info(EXEC_FIRM_SI, "N");
		commEntityBuilder.info(CPTY_FIRM_SI, "N");
		commEntityBuilder.info(ASSISTED_REPORT, "N");
		commEntityBuilder.info(CPTY_REGION, "NON_EEA");
		Entity commEntity = commEntityBuilder.build();
		RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting4(){
		EntityBuilder commEntityBuilder = new EntityBuilder();
		commEntityBuilder.info(BUY_SELL_IND, "Buy");
		commEntityBuilder.info(EXEC_FIRM_SI, "N");
		commEntityBuilder.info(CPTY_FIRM_SI, "Y");
		commEntityBuilder.info(ASSISTED_REPORT, "Y");
		commEntityBuilder.info(CPTY_REGION, "NON_EEA");
		Entity commEntity = commEntityBuilder.build();
		RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting5(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Buy");
			commEntityBuilder.info(EXEC_FIRM_SI, "N");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.NON_REPORTABLE, ruleResult.status);
	}
	 
	@Test
	public void M2PostBuySellSiAssistingReporting6(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Buy");
			commEntityBuilder.info(EXEC_FIRM_SI, "N");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting7(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Buy");
			commEntityBuilder.info(EXEC_FIRM_SI, "Y");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "Y");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting8(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Buy");
			commEntityBuilder.info(EXEC_FIRM_SI, "Y");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.NON_REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting9(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Buy");
			commEntityBuilder.info(EXEC_FIRM_SI, "Y");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting10(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Sell");
			commEntityBuilder.info(EXEC_FIRM_SI, "N");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "Y");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting11(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Sell");
			commEntityBuilder.info(EXEC_FIRM_SI, "N");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.NON_REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting12(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Sell");
			commEntityBuilder.info(EXEC_FIRM_SI, "N");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}

	@Test
	public void M2PostBuySellSiAssistingReporting13(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Buy");
			commEntityBuilder.info(EXEC_FIRM_SI, "Y");
			commEntityBuilder.info(CPTY_FIRM_SI, "N");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting14(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Sell");
			commEntityBuilder.info(EXEC_FIRM_SI, "N");
			commEntityBuilder.info(CPTY_FIRM_SI, "N");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting15(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Sell");
			commEntityBuilder.info(EXEC_FIRM_SI, "Y");
			commEntityBuilder.info(CPTY_FIRM_SI, "N");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
	
	@Test
	public void M2PostBuySellSiAssistingReporting16(){
			EntityBuilder commEntityBuilder = new EntityBuilder();
			commEntityBuilder.info(BUY_SELL_IND, "Sell");
			commEntityBuilder.info(EXEC_FIRM_SI, "Y");
			commEntityBuilder.info(CPTY_FIRM_SI, "Y");
			commEntityBuilder.info(ASSISTED_REPORT, "N");
			commEntityBuilder.info(CPTY_REGION, "NON_EEA");
			Entity commEntity = commEntityBuilder.build();
			RuleResult ruleResult = rule.execute(commEntity, new HashMap<String,Object>(), true);
			assertEquals(EntityStatus.REPORTABLE, ruleResult.status);
	}
}
