package com.citi.reghub.m2post.rules;

import static com.citi.reghub.m2post.utils.constants.InfoMapKeyStringConstants.TRADE_DATE;
import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;
import com.citi.reghub.util.RuleBuilder;

public class TradingDateTimeTest  {
	
	Rule rule;
	
	@Before
	public void setUp(){
		rule = new RuleBuilder().build("m2p0st_all_trading_date_time_check_rule.json","common");
	}

	@Test
	public void testDateTime1(){

		Entity entity = new EntityBuilder().info(TRADE_DATE,null).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testDateTime2(){

		Entity entity = new EntityBuilder().info(TRADE_DATE, LocalDateTime.parse("2019-06-22T10:11:00.123456789", DateTimeFormatter.ISO_DATE_TIME)).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testDateTime5(){

		Entity entity = new EntityBuilder().info(TRADE_DATE, LocalDateTime.parse("2019-06-22T10:11:00", DateTimeFormatter.ISO_DATE_TIME)).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.BIZ_EXCEPTION, result.status);
	}
	
	
	@Test
	public void testDateTime6(){

		Entity entity = new EntityBuilder().info(TRADE_DATE, LocalDateTime.parse("2015-06-22T10:11:00", DateTimeFormatter.ISO_DATE_TIME)).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testDateTime7(){

		Entity entity = new EntityBuilder().info(TRADE_DATE, LocalDateTime.parse("2015-06-22T10:11:00.0123", DateTimeFormatter.ISO_DATE_TIME)).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testDateTime8(){

		Entity entity = new EntityBuilder().info(TRADE_DATE, LocalDateTime.parse("2015-06-22T10:11:00.45165156", DateTimeFormatter.ISO_DATE_TIME)).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}
	
	@Test
	public void testDateTime9(){

		Entity entity = new EntityBuilder().info(TRADE_DATE, LocalDateTime.parse("2015-06-22T10:11:00.00", DateTimeFormatter.ISO_DATE_TIME)).build();
		RuleResult result = rule.execute(entity, new HashMap<String,Object>(), true);
		assertEquals(EntityStatus.REPORTABLE, result.status);
	}

	
}
