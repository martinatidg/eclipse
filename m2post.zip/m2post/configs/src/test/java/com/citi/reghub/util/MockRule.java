package com.citi.reghub.util;

import com.citi.reghub.core.metadata.client.Metadata;
import com.citi.reghub.core.rules.client.Rule;


public class MockRule extends Rule {
	
	@Override
	protected Object fetchMetadata(Metadata m) {
		// TODO Auto-generated method stub
		return m.value;
	}

}
