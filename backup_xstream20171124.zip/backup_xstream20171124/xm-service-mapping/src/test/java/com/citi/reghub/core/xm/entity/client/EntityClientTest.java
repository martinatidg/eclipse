package com.citi.reghub.core.xm.entity.client;

import org.apache.http.impl.client.HttpClients;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.Entity;
//import com.citi.reghub.core.client.RestClient;
//import com.citi.reghub.core.entity.client.EntityClientConfig;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.entity.client.EntityClientConfig;

public class EntityClientTest {

	// Disabled on repository. uncomment when developing on local repository.

	@Test
	public void testGetLatestEntityBySourceId2() {
//		// SIT
//		String stream = "m2tr";
//		String flow = "csheq";
//		String sourceID = "489580745";		// SIT
//		String host = "sd-c3af-37ba";	// SIT

//		// QAT
//		String stream = "m2tr";
//		String flow = "otceqd";
//		String sourceID = "PFS-9890134-39344541-1-UITID";		// QAT
//		String host = "sd-3b5d-e5fb";		// QAT

//		// UAT
		String stream = "m2tr";
		String flow = "cshfx";
		String sourceID = "139809602";
		//String host = "sd-87b5-53ae";	// UAT
		String host = "sd-608f-3cd9"; // nginx

		//String ENTITY_URL_VALUE = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
		//String ENTITY_URL_VALUE = "http://" + host + ".nam.nsroot.net:9088/reghub-api/entity-service/entities";
		String ENTITY_URL_VALUE = "http://sd-608f-3cd9.nam.nsroot.net/reghub-api/entity-service/entities";		// Nginx
		EntityClientConfig entityClientConfig = new EntityClientConfig();
		RestClient restClient = new RestClient(HttpClients.createDefault());
		entityClientConfig.set(EntityClientConfig.REST_CLIENT, restClient);
		entityClientConfig.set(EntityClientConfig.ENTITY_URL_KEY, ENTITY_URL_VALUE);
		entityClientConfig.set(XmEntityClient.ALT_URL_KEY, XmEntityClient.ALT_URL_VALUE);

		XmEntityClient entityClient = new XmEntityClient(entityClientConfig);

		Entity entity = entityClient.getLatestEntity(stream, flow, sourceID);

		System.out.println("entity:\n" + entity);
//		Assert.assertNotNull("The entity is null", entity);
	}
}
