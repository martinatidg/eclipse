package com.citi.reghub.core.response.handler;

import com.citi.reghub.core.ParsedResponse;

public interface ResponseMessageParser {

	public String getMessageType();
	
	public ParsedResponse parseMessage(String message);
	
}
