package com.citi.reghub.core.converter;

import java.util.List;

import com.citi.reghub.core.Entity;

public interface ConvertRecordToString {

	public String convert(List<Entity>entity, Boolean headerRequired)throws Exception;
	public String convert(List<Entity>entity )throws Exception;

}
