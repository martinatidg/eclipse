package com.citi.reghub.core.converter;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ZonedDateTimeConverter implements TypeConverter<String, ZonedDateTime> {

	public ZonedDateTime convert(String obj, String format) {
		// TODO Auto-generated method stub
		if(format == null || format.isEmpty())
			return ZonedDateTime.parse(obj);
		return ZonedDateTime.parse(obj, DateTimeFormatter.ofPattern(format));
	}

}
