package com.citi.reghub.core.entity.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonEntityClient {

    private static EntityClient instance;
    private static final Logger LOGGER = LoggerFactory.getLogger(SingletonEntityClient.class);

    public static EntityClient getInstance(){
        if(instance == null) {
        	LOGGER.error("EntityClient instance='{}'", instance, new RuntimeException("Instance of Entity client is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonEntityClient");
        }return instance;
    }

    public static void setInstance(EntityClientConfig config){
        instance = new EntityClient(config);
    }

}
