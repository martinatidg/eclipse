package com.citi.reghub.core.enrichment.client;

import java.util.Base64;
import java.util.Map;

public class EnricherConfig {

	public String enricherId;
	public String enricherName;
	public String type;
	public String description;
	public Map<String, Object> configuration;
	private String	version;
		


	public EnricherConfig() {
		
	}
	
	public EnricherConfig(String id, String enricherName, String type, Map<String, Object> configMap, String version) {
		this.enricherId = id;
		this.enricherName = enricherName;
		this.type = type;
		this.configuration = configMap;
		this.version = version;
	}

	public String getBase64DecodedString(String key) {
		return new String(Base64.getDecoder().decode((String)configuration.get(key)));
	}
	
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
}
