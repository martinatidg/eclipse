package com.citi.reghub.core.exception.client;


public class NotesUpdatePostResponse { 
	
	private String id;                  //RegHub Exception unique id
	private boolean add;                //true for add, false for delete
	private boolean success;            //operation success or failure
	private String  errorMessage;       //error message in case of failure
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public boolean isAdd() {
		return add;
	}
	public void setAdd(boolean add) {
		this.add = add;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
		
}
