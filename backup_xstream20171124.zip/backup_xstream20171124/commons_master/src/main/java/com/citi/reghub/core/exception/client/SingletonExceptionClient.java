package com.citi.reghub.core.exception.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonExceptionClient {

    private static ExceptionClient instance;
    private static final Logger LOGGER = LoggerFactory.getLogger(SingletonExceptionClient.class);

    private SingletonExceptionClient() {
    	
    }
    public static ExceptionClient getInstance() {
        if(instance == null) {
        	LOGGER.error("ExceptionClient instance='{}'", instance, new RuntimeException("Instance of Exception client is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonExceptionClient");
        }return instance;
    }

    public static void setInstance(ExceptionClientConfig config){
        instance = new ExceptionClient(config);
    }
    
    

}
