package com.citi.reghub.core;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Audit extends InfoablePojo {
	
	public String regHubId;
	public String stream;
	public String flow;

	public String event;
	public String result;
	public List<String> tags = new ArrayList<String>();	
	private String version;

	public LocalDateTime auditTs;
	
	public Audit() {
		this.auditTs = new NanoClock().now();
	}
	
	public Audit(Entity e) {
		this.auditTs = new NanoClock().now();
		this.regHubId = e.regHubId;
		this.stream = e.stream;
		this.flow = e.flow;		
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}	
	
	
}

