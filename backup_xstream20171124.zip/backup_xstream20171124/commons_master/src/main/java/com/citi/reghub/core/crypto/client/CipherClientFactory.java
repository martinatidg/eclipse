package com.citi.reghub.core.crypto.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public class CipherClientFactory {
	
	public static final String CIPHER_KEY_STORE = "cipher.key.store";
	public static final String FILE_KEY_STORE = "file";

    public static Logger LOGGER = LoggerFactory.getLogger(CipherClientFactory.class);

	public static CipherClient getInstance(Map<String,String> config, CacheClient cacheClient) {
		String cipherKeyStore = config.get(CIPHER_KEY_STORE);
		if (FILE_KEY_STORE.equals(cipherKeyStore)) {
			FileStoreCipherClient cipherClient = new FileStoreCipherClient(config, cacheClient);
			LOGGER.debug("File Store Cipher Initialised");
			return cipherClient;
		} else {
			throw new RuntimeException ("Invalid cipher.key.store " + cipherKeyStore);
		}
	}
}
