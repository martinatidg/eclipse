package com.citi.reghub.core;

import java.util.Base64;
import java.util.HashMap;

public class RawLineMsgObject extends RawMsgObject {
	
	private static final long serialVersionUID = -7236020335687499291L;
	
	private String sourceUId;

	public RawLineMsgObject() {
		super();		
	}

	public RawLineMsgObject(String sourceUId, String message) {
		super();
		this.sourceUId=sourceUId;
		this.message=Base64.getEncoder().encodeToString(message.getBytes());
		map = new HashMap<String, Object>();
	}

	public void put(String key, Object value) {
		map.put(key, value);
	}

	public Object get(String key) {
		return map.get(key);
	}

	public String getSourceUId() {
		return sourceUId;
	}

}
