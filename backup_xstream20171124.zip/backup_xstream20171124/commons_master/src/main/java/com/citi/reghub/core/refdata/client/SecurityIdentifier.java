package com.citi.reghub.core.refdata.client;

public enum SecurityIdentifier {
	FII, ISIN, CUSIP, SMCP, OCEAN_ID, RIC;
}
