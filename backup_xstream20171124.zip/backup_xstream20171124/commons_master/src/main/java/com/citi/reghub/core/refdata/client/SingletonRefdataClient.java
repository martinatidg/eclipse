package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonRefdataClient {

	private static RefdataClient instance;
	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonRefdataClient.class);

	public static RefdataClient getInstance() {
		if (instance == null) {
			RuntimeException ex = new RuntimeException("Invalid instance of RefdataClient");
			LOGGER.error("Instance of refdata client is null", ex);
			throw ex;
		}
		return instance;
	}

	public static void setInstance(Map<String, String> props) {
		instance = new RefdataClient(props);
	}
	
	public static void setInstance(RefdataClient refdataClient) {
		instance = refdataClient;
	}

}

