package com.citi.reghub.core.refdata.client;

public enum AccountIdentifier {
	OCEAN_ID("OCEAN_ID"), GFC("GFC"), GFCID("GFCID"), ACTID("ACTID"), SLANG("SLANG"), MNEMONIC(
			"MNEMONIC"), ACCOUNTMNEMONIC("ACCOUNTMNEMONIC");

	private String value;

	public String getValue() {
		return value;
	}

	private AccountIdentifier(String value) {
		this.value = value;
	}
}
