package com.citi.reghub.core.rules.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.EntityStatus;

public class RuleGraphResult extends Result {

	private static final Map<String, Integer> 	PRECEDENCE_MAP;
	private static final List<String> 			PRECEDENCE_LIST;
	
	static {
		List<String> l = new ArrayList<String>(5);
		l.add(EntityStatus.APP_EXCEPTION);
		l.add(EntityStatus.NON_REPORTABLE);
		l.add(EntityStatus.TECH_EXCEPTION);
		l.add(EntityStatus.BIZ_EXCEPTION);
		l.add(EntityStatus.REPORTABLE);
		
		PRECEDENCE_LIST = Collections.unmodifiableList(l);
		
		Map<String, Integer> m = new HashMap<String, Integer>(5);
		m.put(EntityStatus.APP_EXCEPTION, 0);
		m.put(EntityStatus.NON_REPORTABLE, 1);
		m.put(EntityStatus.TECH_EXCEPTION, 2);
		m.put(EntityStatus.BIZ_EXCEPTION, 3);
		m.put(EntityStatus.REPORTABLE, 4);
		
		PRECEDENCE_MAP = Collections.unmodifiableMap(m);
	}

	public  List<String> 	 resultCodes;
	private List<RuleResult> ruleResults;

	public RuleGraphResult() {
		super();
		this.ruleResults = new ArrayList<RuleResult>();
		this.resultCodes = new ArrayList<String>();
	}
	
	public RuleGraphResult(int size) {
		super();
		this.ruleResults = new ArrayList<RuleResult>(size);
		this.resultCodes = new ArrayList<String>(size);
	}

	public RuleGraphResult(List<RuleResult> ruleResults) {
		super();
		setRuleResults(ruleResults);
		this.resultCodes = new ArrayList<String>();
	}
	
    public List<RuleResult> getRuleResults() {
        return ruleResults;
    }
    
    public void addRuleResult(RuleResult rr) {
    	this.ruleResults.add(rr);
    }

	public void setRuleResults(List<RuleResult> ruleResults) {
		this.ruleResults = ruleResults;
		markRuleResult();
	}

	public void markRuleResult() {
		int lowestr = -1;
		for (RuleResult r : ruleResults) {
			Integer i = PRECEDENCE_MAP.get(r.status);
			if (i != null && (lowestr == -1 || i < lowestr)) {
				lowestr = i;
			}
			
			if (r.code != null) {
				this.resultCodes.add(r.code);
			}
		}
		
		if (lowestr > -1 && lowestr < PRECEDENCE_LIST.size()) {
			this.mark(PRECEDENCE_LIST.get(lowestr));
		}
	}
	

	public Audit toAudit(Audit a) {
		a.result = this.status;

		for (RuleResult r : this.ruleResults) {
			 a.info.put(r.ruleName, r.toMap(r));
		}

		return a;
	}

}
