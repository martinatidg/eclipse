package com.citi.reghub.core.entity.client;

import org.apache.http.impl.client.HttpClients;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.client.RestClient;

public class EntityClientTest {

	// Disabled. The test case is useful only when the Entity service is available.

	@Test
	public void testGetLatestEntityBySourceId2() {
		String sourceID = "139809602";		// SIT
		String host = "sd-c3af-37ba";	// SIT

//		String sourceID = "perf4fi101748"; 	// QAT
//		String host = "sd-3b5d-e5fb";		// QAT

		// UAT
//		String sourceID = "Nc3062fd190f45a0b4a58624369cd31d";
		//String sourceID = "CTR:09808:0";
//		String host = "sd-87b5-53ae";
//
		String ENTITY_URL_VALUE = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
//		String ENTITY_URL_VALUE = "http://sd-3b5d-e5fb.nam.nsroot.net:9088/reghub-api/entity-service/entities/generic";
		//String ENTITY_URL_VALUE = "http://" + host + ".nam.nsroot.net:9088/reghub-api/entity-service/entities/generic";		// SIT
		EntityClientConfig entityClientConfig = new EntityClientConfig();
		RestClient restClient = new RestClient(HttpClients.createDefault());
		entityClientConfig.set(EntityClientConfig.REST_CLIENT, restClient);
		entityClientConfig.set(EntityClientConfig.ENTITY_URL_KEY, ENTITY_URL_VALUE);

		EntityClient entityClient = new EntityClient(entityClientConfig);
		//Entity entity = entityClient.getLatestEntityBySourceId("perf5eq1100613");
		Entity entity = entityClient.getLatestEntityBySourceId(sourceID);

		System.out.println("entity:\n" + entity);
		Assert.assertNotNull("The entity is null", entity);
//
//		entity = entityClient.getLatestEntityBySourceId(sourceID);
//
//		System.out.println("entity:\n" + entity);
//		Assert.assertNotNull("The entity is null", entity);

	}
}
