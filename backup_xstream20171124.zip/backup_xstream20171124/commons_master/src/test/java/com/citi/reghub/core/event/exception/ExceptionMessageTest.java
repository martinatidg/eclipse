package com.citi.reghub.core.event.exception;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;


public class ExceptionMessageTest {
	private String attrKey = "mifidTradingCapacity";
	private String attrValue = "DEAL";

	private String id = "f8efc619-3e47-4d9b-9eb1-76736615e813";
	private String sourceId = "139809602";
	private String regHubId = "m2trcshfx20150595684633303";
	private String regReportingRef = "CSHFXFXLMREG20170921139809602";
	private String stream = "m2tr";
	private String flow = "cshfx";

	private String reasonCode = "m2tr_all_trading_capacity_exception";
	private String ruleVersion = "";
	private String description = "The Trading capacity  must not be NULL or blank";

	private boolean xstreamEligible = true;
	private Note note = getNote();
	private Map<String, Object> attributes = getAttributes();

	private String updatedSource = "XM-CONSUMER";

	private ExceptionStatus status = ExceptionStatus.OPEN;
	private FunctionalOwner functionalOwner = FunctionalOwner.BUS;
	private ExceptionType type = ExceptionType.NACK;
	private ExceptionLevel level = ExceptionLevel.EXCEPTION;
	private String closedByRegHubId = "m2trcshfx20150595684633303";
	
	@Test
	public void testExceptionMessageBuilder() {
		ExceptionMessage exception = new ExceptionMessageBuilder().newException().withId(id).withSourceId(sourceId).withRegHubId(regHubId)
				.withRegReportingRef(regReportingRef).withStream(stream).withFlow(flow).withReasonCode(reasonCode).withRuleVersion(ruleVersion)
				.withDescription(description).isXstreamEligible(xstreamEligible).addNote(note).addAttribute(attrKey, attrValue).withUpdatedSource(updatedSource)
				.withStatus(status).withOwner(functionalOwner).withType(type).withLevel(level).withClosedByRegHubId(closedByRegHubId).build();

		Assert.assertEquals("Not equal", id, exception.getId());
		Assert.assertEquals("Not equal", sourceId, exception.getSourceId());
		Assert.assertEquals("Not equal", regHubId, exception.getRegHubId());
		Assert.assertEquals("Not equal", regReportingRef, exception.getRegReportingRef());
		Assert.assertEquals("Not equal", stream, exception.getStream());
		Assert.assertEquals("Not equal", flow, exception.getFlow());
		Assert.assertEquals("Not equal", reasonCode, exception.getReasonCode());
		Assert.assertEquals("Not equal", ruleVersion, exception.getRuleVersion());
		Assert.assertEquals("Not equal", description, exception.getDescription());
		Assert.assertEquals("Not equal", xstreamEligible, exception.isXstreamEligible());
		Assert.assertEquals("Not equal", note, exception.getNotes().get(0));
		Assert.assertEquals("Not equal", attributes, exception.getAttributes());
		Assert.assertEquals("Not equal", updatedSource, exception.getUpdatedSource());
		Assert.assertEquals("Not equal", status, exception.getStatus());
		Assert.assertEquals("Not equal", functionalOwner, exception.getFunctionalOwner());
		Assert.assertEquals("Not equal", type, exception.getType());
		Assert.assertEquals("Not equal", level, exception.getLevel());
		Assert.assertEquals("Not equal", closedByRegHubId, exception.getClosedByRegHubId());
	}

	private Note getNote() {
		Note note = new Note();
		note.setCreatedBy("RegHub");
		note.setCreatedTS(System.currentTimeMillis());
		note.setNote("unit test.");
		note.setSource(NoteSource.XSTREAM);
		
		return note;
	}

	private Map<String, Object> getAttributes() {
		Map<String, Object> map = new HashMap<>();
		map.put(attrKey, attrValue);

		return map;
	}
}
