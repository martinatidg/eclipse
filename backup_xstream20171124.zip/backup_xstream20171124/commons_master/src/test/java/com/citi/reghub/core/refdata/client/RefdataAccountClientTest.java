package com.citi.reghub.core.refdata.client;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;

import com.citi.ocean.dataobject.account.OceanAccountInfo;
import com.citi.ocean.dataobject.account.OceanAccountSummary;
import com.citi.ocean.dataobject.account.OceanGFCDetail;

public class RefdataAccountClientTest {

	RefdataAccountClient refdataAccountClient;
	OceanGemfireCacheClient oceanGemfireCacheClient;
	
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();
	
	@Before
	public void setup() {
		oceanGemfireCacheClient = Mockito.mock(OceanGemfireCacheClient.class);
		refdataAccountClient = new RefdataAccountClient(oceanGemfireCacheClient);
	}
   
	@Test
	public void shouldReturnAccountDetailsByOceanId() {
		OceanAccountSummary oceanAccountSummary = new OceanAccountSummary();
		oceanAccountSummary.setOceanAcctId(926716551L);
		oceanAccountSummary.setActi(20392447);
		oceanAccountSummary.setAcctMnemonic("Q7WB640");
		oceanAccountSummary.setGfci("1000451742");
		
		when(oceanGemfireCacheClient.getAccountByOceanId(926716551L)).thenReturn(oceanAccountSummary);
		
		Map<String, Object> result = refdataAccountClient.getData("OCEAN_ID", 926716551L);
		assertEquals(926716551L, result.get("oceanAcctId"));
		assertEquals("Q7WB640", result.get("acctMnemonic"));
		assertEquals("1000451742", result.get("gfci"));
		assertEquals(20392447, result.get("acti"));
	}

    @Test
	public void shouldReturnAccountDetailsByAccountMnemonic() {
    	OceanAccountSummary oceanAccountSummary = new OceanAccountSummary();
		oceanAccountSummary.setOceanAcctId(926716551L);
		oceanAccountSummary.setActi(20392447);
		oceanAccountSummary.setAcctMnemonic("Q7WB640");
		oceanAccountSummary.setGfci("1000451742");
		
		when(oceanGemfireCacheClient.getAccountByMnemonic("Q7WB640")).thenReturn(oceanAccountSummary);
		
		Map<String, Object> result = refdataAccountClient.getData("MNEMONIC", "Q7WB640");
		assertEquals(926716551L, result.get("oceanAcctId"));
		assertEquals("Q7WB640", result.get("acctMnemonic"));
		assertEquals("1000451742", result.get("gfci"));
		assertEquals(20392447, result.get("acti"));
		
		result = refdataAccountClient.getData("ACCOUNTMNEMONIC", "Q7WB640");
		assertEquals(926716551L, result.get("oceanAcctId"));
		assertEquals("Q7WB640", result.get("acctMnemonic"));
		assertEquals("1000451742", result.get("gfci"));
		assertEquals(20392447, result.get("acti"));
	}

    @Test
	public void shouldReturnAccountDetailsByGfci() {
		OceanGFCDetail oceanGFCDetail = new OceanGFCDetail();
		oceanGFCDetail.setGfci("1004178773");
		oceanGFCDetail.setGfcLongname("FREESCALE SEMICONDUCTOR INC");
		oceanGFCDetail.setCgmlLargeTrader("N");
		oceanGFCDetail.setTaxId("20-0443182");
		oceanGFCDetail.setParentGfpid("1010374134");
		oceanGFCDetail.setDomicileAddressCountry("US");
		
		when(oceanGemfireCacheClient.getAccountByGFCID("1004178773")).thenReturn(oceanGFCDetail);
		
		Map<String, Object> result = refdataAccountClient.getData("GFCID", "1004178773");
		assertEquals("1004178773", result.get("gfci"));
		assertEquals("FREESCALE SEMICONDUCTOR INC", result.get("gfcLongname"));
		assertEquals("N", result.get("cgmlLargeTrader"));
		assertEquals("20-0443182", result.get("taxId"));
		assertEquals("1010374134", result.get("parentGfpid"));
		assertEquals("US", result.get("domicileAddressCountry"));
		
		result = refdataAccountClient.getData("GFC", "1004178773");
		assertEquals("1004178773", result.get("gfci"));
		assertEquals("FREESCALE SEMICONDUCTOR INC", result.get("gfcLongname"));
		assertEquals("N", result.get("cgmlLargeTrader"));
		assertEquals("20-0443182", result.get("taxId"));
		assertEquals("1010374134", result.get("parentGfpid"));
		assertEquals("US", result.get("domicileAddressCountry"));
	}

    @Test
	public void shouldReturnAccountDetailsByActi() {
    	OceanAccountSummary oceanAccountSummary = new OceanAccountSummary();
		oceanAccountSummary.setOceanAcctId(926716551L);
		oceanAccountSummary.setActi(20392447);
		oceanAccountSummary.setAcctMnemonic("Q7WB640");
		oceanAccountSummary.setGfci("1000451742");
		
		when(oceanGemfireCacheClient.getAccountByActi(20392447)).thenReturn(oceanAccountSummary);
		
		Map<String, Object> result = refdataAccountClient.getData("ACTID", 20392447L);
		assertEquals(926716551L, result.get("oceanAcctId"));
		assertEquals("Q7WB640", result.get("acctMnemonic"));
		assertEquals("1000451742", result.get("gfci"));
		assertEquals(20392447, result.get("acti"));
	}
	
    @Test
	public void shouldThrowErrorWhenInvalidAccountIdentifier() {
		expectedEx.expect(RuntimeException.class);
		expectedEx.expectMessage("Invalid input Account Identifier: ACT_ID");
		refdataAccountClient.getData("ACT_ID", 20392447L);
	}
    
    @Test
	public void shouldReturnAccountDetailsBySlang() {
    	OceanAccountInfo oceanAccountInfo = new OceanAccountInfo();
		oceanAccountInfo.setOceanAcctId(926716551L);
		oceanAccountInfo.setActi(20392447);
		oceanAccountInfo.setAcctMnemonic("Q7WB640");
		oceanAccountInfo.setGfci("1000451742");
		
		when(oceanGemfireCacheClient.getAccountBySlang("testSlang")).thenReturn(oceanAccountInfo);
		
		Map<String, Object> result = refdataAccountClient.getData("SLANG", "testSlang");
		assertEquals(926716551L, result.get("oceanAcctId"));
		assertEquals("Q7WB640", result.get("acctMnemonic"));
		assertEquals("1000451742", result.get("gfci"));
		assertEquals(20392447, result.get("acti"));
	}
}
