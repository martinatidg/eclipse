package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

public class EntityTest {

	private Entity entity;
	

	private LocalDateTime executionTs;

	private String date;
	
	@Before
	public void setup() {
		
		MockitoAnnotations.initMocks(this);
		executionTs = LocalDateTime.now();
		entity = new Entity();
		entity.executionTs = this.executionTs;
		date = executionTs.toLocalDate().format(DateTimeFormatter.ofPattern("yyyyMMdd")); 
	}
	
	@Test
	public void testGenerateRegReportingRef_case1() {
		entity.flow = "comderv";
		entity.stream = "M2tr";
		entity.sourceSystem = "abcd";
		entity.sourceId = "asdf";
		entity.generateRegReportingRef();
		assertEquals(entity.regReportingRef,("comderv"+"abcd"+date+"asdf").toUpperCase());
	}
	
	@Test
	public void testGenerateRegReportingRef_case2() {
		entity.flow = "comderv";
		entity.stream = "M2tr";
		entity.sourceSystem = "abcd";
		entity.sourceId = null;
		entity.generateRegReportingRef();
		assertEquals(entity.regReportingRef,("comderv"+"abcd"+date+"null").toUpperCase());
	}
}
