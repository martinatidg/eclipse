package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;

import java.io.InputStream;
import java.io.OutputStream;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.NoteSource;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class EventEnvelopeSerializerTest {

	private StreamFactory sf;
	private Kryo kryo;
	
	@Before
	public void setup() {
		kryo = new Kryo();
		sf = new StreamFactory() {
			public Output createOutput(OutputStream os) {
				return new Output(os);
			}

			public Output createOutput(OutputStream os, int size) {
				return new Output(os, size);
			}

			public Output createOutput(int size, int limit) {
				return new Output(size, limit);
			}

			public Input createInput(InputStream os, int size) {
				return new Input(os, size);
			}

			public Input createInput(byte[] buffer) {
				return new Input(buffer);
			}
		};
	}

/*	@Test
	public void testSerialization() throws IOException {
		EventBuilder b = new EventBuilder();
		ExceptionMessageBuilder emb = new ExceptionMessageBuilder();
		
		Note note = new com.citi.reghub.core.event.exception.Note();
		note.setNote("Note");
		note.setCreatedBy("XM_XSTREAM");
		note.setSource(NoteSource.XSTREAM);
		note.setCreatedTS(System.currentTimeMillis());

		ExceptionMessage exceptionMessage = emb.newException().withDescription("Testing exception message serializer").addNote(note).build();
		
		EventEnvelope envelope = b.newEvent().ofTypeException().withEventName(EventName.EXCEPTION_CREATED).withEventSource(EventSource.CORE_UI).withEventData(exceptionMessage).build();
		
		EventEnvelopeSerializer s = new EventEnvelopeSerializer();
		byte[] serialize = s.serialize("", envelope);
		System.out.println("");
	}*/
	
	@Test
	public void testEnvelopeAddtionalFieldsDeserialization() {
	
		byte[] noteExEnvelope = {1, 6, 69, 118, 101, 110, 116, 69, 110, 118, 101, 108, 111, 112, 101, 46, 101, 118, 101, 110, 116, 68, 97, 116, -31, 69, 118, 101, 110, 116, 69, 110, 118, 101, 108, 111, 112, 101, 46, 101, 118, 101, 110, 116, 78, 97, 109, -27, 69, 118, 101, 110, 116, 69, 110, 118, 101, 108, 111, 112, 101, 46, 101, 118, 101, 110, 116, 83, 111, 117, 114, 99, -27, 69, 118, 101, 110, 116, 69, 110, 118, 101, 108, 111, 112, 101, 46, 101, 118, 101, 110, 116, 84, 105, 109, -27, 69, 118, 101, 110, 116, 69, 110, 118, 101, 108, 111, 112, 101, 46, 101, 118, 101, 110, 116, 84, 121, 112, -27, 69, 118, 101, 110, 116, 69, 110, 118, 101, 108, 111, 112, 101, 46, 101, 118, 101, 110, 116, 86, 101, 114, 115, 105, 111, -18, -98, 4, 13, 1, 20, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 97, 116, 116, 114, 105, 98, 117, 116, 101, -13, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 99, 114, 101, 97, 116, 101, 100, 84, -45, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 100, 101, 115, 99, 114, 105, 112, 116, 105, 111, -18, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 102, 108, 111, -9, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 102, 117, 110, 99, 116, 105, 111, 110, 97, 108, 79, 119, 110, 101, -14, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 105, -28, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 108, 101, 118, 101, -20, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 110, 111, 116, 101, -13, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 114, 101, 97, 115, 111, 110, 67, 111, 100, -27, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 114, 101, 103, 72, 117, 98, 73, -28, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 114, 101, 103, 82, 101, 112, 111, 114, 116, 105, 110, 103, 82, 101, -26, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 114, 101, 113, 117, 101, 115, 116, 101, 100, 84, -45, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 114, 117, 108, 101, 86, 101, 114, 115, 105, 111, -18, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 115, 111, 117, 114, 99, 101, 73, -28, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 115, 116, 97, 116, 117, -13, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 115, 116, 114, 101, 97, -19, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 116, 121, 112, -27, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 117, 112, 100, 97, 116, 101, 100, 83, 111, 117, 114, 99, -27, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 117, 112, 100, 97, 116, 101, 100, 84, -45, 69, 120, 99, 101, 112, 116, 105, 111, 110, 77, 101, 115, 115, 97, 103, 101, 46, 120, 115, 116, 114, 101, 97, 109, 69, 108, 105, 103, 105, 98, 108, -27, 21, 1, 0, 106, 97, 118, 97, 46, 117, 116, 105, 108, 46, 72, 97, 115, 104, 77, 97, -16, 1, 0, 3, 0, 1, 0, 39, 0, 37, 1, 84, 101, 115, 116, 105, 110, 103, 32, 101, 120, 99, 101, 112, 116, 105, 111, 110, 32, 109, 101, 115, 115, 97, 103, 101, 32, 115, 101, 114, 105, 97, 108, 105, 122, 101, -14, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 98, 0, 96, 1, 1, 106, 97, 118, 97, 46, 117, 116, 105, 108, 46, 76, 105, 110, 107, 101, 100, 76, 105, 115, -12, 1, 1, 14, 1, 4, 78, 111, 116, 101, 46, 99, 114, 101, 97, 116, 101, 100, 66, -7, 78, 111, 116, 101, 46, 99, 114, 101, 97, 116, 101, 100, 84, -45, 78, 111, 116, 101, 46, 101, 120, 99, 101, 112, 116, 105, 111, 110, 78, 111, 116, -27, 78, 111, 116, 101, 46, 115, 111, 117, 114, 99, -27, 11, 1, 88, 77, 95, 88, 83, 84, 82, 69, 65, -51, 9, 8, 0, 6, -80, -124, -81, -26, -30, 87, 8, 7, 0, 5, 1, 78, 111, 116, -27, 5, 4, 0, 2, 1, 2, 2, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 3, 0, 1, 0, 1, 0, 0, 2, 1, 1, 0, 2, 1, 4, 0, 6, -22, -87, -81, -26, -30, 87, 0, 2, 1, 1, 0, 2, 1, 1, 0};
		EventEnvelopeSerializer s = new EventEnvelopeSerializer();
		EventEnvelope deserializeWithNote = s.deserialize("", noteExEnvelope);
		s.close();
		assertEquals( ((ExceptionMessage)deserializeWithNote.getEventData()).getNotes().get(0).getSource(), NoteSource.XSTREAM);
	} 
	
 
	static interface StreamFactory {
		public Output createOutput(OutputStream os);

		public Output createOutput(OutputStream os, int size);

		public Output createOutput(int size, int limit);

		public Input createInput(InputStream os, int size);

		public Input createInput(byte[] buffer);
	}
}
