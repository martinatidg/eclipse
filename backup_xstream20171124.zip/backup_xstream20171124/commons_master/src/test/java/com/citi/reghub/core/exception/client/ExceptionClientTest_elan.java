package com.citi.reghub.core.exception.client;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.client.SingletonRestClient;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExceptionClientTest_elan {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionClientTest_elan.class);
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
	}

	@Test
	public void getExceptionsFromServiceById() throws JsonProcessingException {
		ExceptionClientConfig xmClientConfig = new ExceptionClientConfig();
        xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, "http://sd-9e8c-2b9f.nam.nsroot.net/reghub-api/xm-service/exceptions");
        
        xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, SingletonRestClient.getInstance());
		Map<String, Object> filterBy = new HashMap<>();
		//filterBy.put("id", "d96fcf89-ca0a-44c1-ba3e-87f033a0a4fb");

        ExceptionClient client = new ExceptionClient(xmClientConfig);
        LOGGER.info("Calling getExceptionsFromService");
        List<ExceptionMessage> exceptions = client.getExceptionsFromService();
        ObjectMapper mapper = new ObjectMapper();
        String exceptionsAsJSONString = mapper.writeValueAsString(exceptions);
        LOGGER.info(exceptionsAsJSONString);
        
        LOGGER.info("Calling getExceptionsFromServiceById");
        ExceptionMessage exceptions1 = client.getExceptionsFromServiceById("d96fcf89-ca0a-44c1-ba3e-87f033a0a4fb");
        //List<ExceptionMessage> exceptions1 = client.getExceptionsByFilter(filterBy);
        
        exceptionsAsJSONString = mapper.writeValueAsString(exceptions1);
        LOGGER.info(exceptionsAsJSONString);
        System.out.println(exceptionsAsJSONString);

	}

//	@Test
//	public void getExceptionsFromServiceByFilter() {
//		List<ExceptionMessage> exceptions = new ArrayList<>();
//		ExceptionsViewWrapper evw = new ExceptionsViewWrapper();
//		evw.setExceptionsList(exceptions);
//		evw.setTotalRecords(0);
//		List<ExceptionMessage> exceptionsResult;
//		try {
//			List<String> status = new ArrayList<>();
//			status.add("CLOSED");
//			Map<String, Object> filterBy = new HashMap<>();
//			filterBy.put("status", status);
//			when(restClient.doPost(filterBy,"http://localhost:8090/exceptions",ExceptionsViewWrapper.class, false))
//	        .thenReturn(evw);
//			exceptionsResult = client.getExceptionsByFilter(filterBy);
//			assertTrue(exceptionsResult.isEmpty());
//		} catch (JsonProcessingException e) {
//			
//			e.printStackTrace();
//		}
//		
//	}

}
