package com.citi.reghub.core.exception.client;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.client.SingletonRestClient;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExceptionClientTest_UAT {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionClientTest_UAT.class);
	static ExceptionClient client;
	static ExceptionClientConfig xmClientConfig;
	static RestClient restClient;
	
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
//		//restClient = mock(RestClient.class);
//		xmClientConfig = new ExceptionClientConfig();
//		xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, SingletonRestClient.getInstance());
//		xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, "http://sd-87b5-53ae.nam.nsroot.net:8090/reghub-api/xm-service/exceptions");
//
//		client = new ExceptionClient(xmClientConfig);
//		ExceptionMessage exceptions1 = client.getExceptionsFromServiceById("221c595b-3e6b-4899-bc0a-9a25a9bfb9e9");
		
//		restClient = new RestClient(HttpClients.createDefault());
//
//		//xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, "http://localhost:8090/exceptions");
//		
//		xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, restClient);
//		client = new ExceptionClient(xmClientConfig);
			
	}


	@Test
	public void getExceptionsFromServiceById() throws JsonProcessingException {

		//ExceptionMessage exceptionsResult;
		try {
            //Example implementation. Please change url and filters to suit your needs
            ExceptionClientConfig xmClientConfig = new ExceptionClientConfig();
            xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, "http://sd-87b5-53ae.nam.nsroot.net:8090/reghub-api/xm-service/exceptions");
            
            xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, SingletonRestClient.getInstance());
            
            ExceptionClient client = new ExceptionClient(xmClientConfig);
            LOGGER.info("Calling getExceptionsFromService");
            List<ExceptionMessage> exceptions = client.getExceptionsFromService();
            ObjectMapper mapper = new ObjectMapper();
            String exceptionsAsJSONString = mapper.writeValueAsString(exceptions);
            LOGGER.info(exceptionsAsJSONString);
            
            LOGGER.info("Calling getExceptionsFromServiceById");
            ExceptionMessage exceptions1 = client.getExceptionsFromServiceById("f8efc619-3e47-4d9b-9eb1-76736615e813");
                  
            exceptionsAsJSONString = mapper.writeValueAsString(exceptions1);
            LOGGER.info(exceptionsAsJSONString);
			System.out.println("exceptionsResult:\n" + exceptions1);

		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		
	}


}
