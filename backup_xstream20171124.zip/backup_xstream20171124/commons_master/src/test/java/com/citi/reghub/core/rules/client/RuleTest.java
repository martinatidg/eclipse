package com.citi.reghub.core.rules.client;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;

public class RuleTest {
    RestClient restClient;
    MetadataClientConfig config;
    CacheClient cacheClient;

    @Before
    public void setUp() throws Exception {
        restClient = mock(RestClient.class);
        cacheClient = mock(CacheClient.class);
        config = new MetadataClientConfig().set(MetadataClientConfig.REST_CLIENT, restClient)
        		.set(MetadataClientConfig.FLOW_CODE, "FLOWA")
        		.set(MetadataClientConfig.CACHE_CLIENT, cacheClient).setDefaultMetadataUrl();
        Map<String,Object> metadata = new MetadataBuilder().value(Arrays.asList("NYSE","NASDAQ")).buildAsMap();
        when(restClient.get("http://localhost:8082/reghub-api/metadata-service/metadata/exchangeCodes",Map.class))
                .thenReturn(metadata);
        SingletonMetadataClient.setInstance(config);
    }


    @Test
    public void testExchangeEligibilityCheckAsNonReportable() throws Exception {
        Trade trade = new Trade(){{
            this.exchangeCode = "NYSE";
        }};
        Rule rule = new RuleBuilder()
                .metadata("exchangeCodes","exchangeCodes",null)
                .build("ruleId", "test", "exchange-eligibility-check.drl", "RESULT_CODE_1");

        RuleResult result = rule.execute(trade, new HashMap<>(),true);

        assertThat(result.getStatus(),equalTo("NON_REPORTABLE"));

    }

}