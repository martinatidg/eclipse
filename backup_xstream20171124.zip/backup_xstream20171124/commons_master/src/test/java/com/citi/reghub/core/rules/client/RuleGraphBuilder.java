package com.citi.reghub.core.rules.client;

import java.util.ArrayList;
import java.util.List;

public class RuleGraphBuilder {
    private String id = "55d4527b795633d28e3dfce9";
    private String name;
    private String type = "Sequential";
    private String version = "1.0";
    private List<Rule> rules = new ArrayList<Rule>();

    public RuleGraphBuilder name(String name) {
        this.name = name;
        return this;
    }

    public RuleGraphBuilder rule(String name, String fileName, String resultCode) {
        Rule rule = new RuleBuilder().build("ruleId" + fileName, name, fileName, resultCode);
        rules.add(rule);
        return this;
    }
    
    public RuleGraphBuilder rule(String name, String fileName, String resultCode, String type, String level, String version, List<String> attributes) {
        Rule rule = new RuleBuilder().build("ruleId" + fileName, name, fileName, resultCode);
        rule.setType(type);
        rule.setLevel(level);
        rule.setVersion(version);
        rule.setAttributes(attributes);
        rules.add(rule);
        return this;
    }

    public RuleGraphBuilder rule(String name, String fileName, String metadataName, String metadataKey, String resultCode, String metadataCacheName) {
        Rule rule = new RuleBuilder().metadata(metadataName,metadataKey,metadataCacheName).build("ruleId" + fileName, name, fileName, resultCode);
        rules.add(rule);
        return this;
    }

    public RuleGraph build() {
        return new RuleGraph(id,name,type,rules, version);
    }
}
