package com.citi.reghub.core.xm.xstream.topology;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.storm.jms.JmsTupleProducer;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XstreamTupleProducer implements JmsTupleProducer {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(XstreamTupleProducer.class);

	private static final String TUPLE_KEY = "key";
	private static final String TUPLE_MESSAGE = "message";
	private static final String XSTREAM_RESPONSE = "xstream_response";

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public Values toTuple(Message message) throws JMSException {

		if (message == null) {
			LOGGER.error("Received message is null: {}", message);
			throw new JMSException("Received message is null");
		}

		String xml = ((TextMessage) message).getText();
		LOGGER.info("Received from xstream ={}", xml);

		return new Values(XSTREAM_RESPONSE, xml);
	}
}
