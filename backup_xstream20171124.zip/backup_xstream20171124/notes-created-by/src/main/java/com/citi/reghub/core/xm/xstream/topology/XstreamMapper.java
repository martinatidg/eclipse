package com.citi.reghub.core.xm.xstream.topology;

import java.lang.reflect.Constructor;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.NanoClock;
import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.event.exception.Note;
import com.citi.reghub.core.event.exception.NoteSource;
import com.citi.reghub.core.xm.xstream.schema.inbound.Action;
import com.citi.reghub.core.xm.xstream.schema.inbound.ExceptionType;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOEntityCode;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgException;
import com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory;
import com.citi.reghub.core.xm.xstream.schema.inbound.SenderStatus;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound.OutBoundNotificationMsg;

public class XstreamMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(XstreamMapper.class);
	private static final String FORWARD_TO_FN_OWNER = "Forward To FnOwner";
	private static final String OWNER_TYPE_TECH = "Tech";
	private static final long NANOSECONDS = 1000_000L; 
	private static final int MAX_DATE_LENGTH = 14; 

	private ObjectFactory factory = new ObjectFactory();
	private String regHubId = "";

	public Optional<XmFeedMsg> toXstream(ExceptionMessage exception, Entity entity, EventName eventName) {
		LOGGER.debug("entering...");
		Optional<ExceptionMessage> msgOpt = Optional.ofNullable(exception);
		Optional<Entity> entityOpt = Optional.ofNullable(entity);
		
		if (!msgOpt.isPresent() || !entityOpt.isPresent()) {
			LOGGER.error("null check failed: exception = {}, entity = {}", exception, entity);
			return Optional.empty();
		}

		LOGGER.debug("exception:\n{}", exception);
		LOGGER.debug("entity.regHubId = {},  entity.sourceId = {}, entity.info:\n{}", entity.regHubId, entity.sourceId, entity.info);

		regHubId = entity.regHubId;
		//Create Entity				
		MOMsgEntity momsgEntity = createEntity(entity);
		LOGGER.debug("momsgEntity:\n{}", momsgEntity);

		//create Exception
		MOMsgException momsgException = createException(exception, eventName);
		LOGGER.debug("momsgException:\n{}",momsgException);
		
		//create XMFeed
		XmFeedMsg feedMsg = factory.createXmFeedMsg();
		feedMsg.setMoEntity(momsgEntity);
		feedMsg.getMoException().add(momsgException);
		feedMsg.setRequestId("REGHUB_" + exception.getSourceId());
		feedMsg.setSenderCompID("REGHUB"); 						// required
		feedMsg.setTimestamp(this.getXMLGregorianCalendar()); 	// required

		
		return Optional.ofNullable(feedMsg);
	}

	private MOMsgException createException(ExceptionMessage exception, EventName eventName) {
		MOMsgException moMsgException = factory.createMOMsgException();
		
		moMsgException.setCreatedBy(exception.getFunctionalOwner().value());
		moMsgException.setDescription(exception.getDescription()); 			// 48 in mapping, required
		moMsgException.setFirstRaisedDatetime(exception.getCreatedTS());	// 28 in mapping
		moMsgException.setSenderCompID("REGHUB");							// 47
		moMsgException.setSenderExceptionID(exception.getId()); 			// 26 in mapping table, required
		moMsgException.setSenderExceptionVersion(0);

		moMsgException.setSrcSysID(exception.getSourceId()); // required

		ExceptionType et = factory.createExceptionType();

		if (ExceptionLevel.NACK == exception.getLevel()) {					// 45 in mapping table
			et.setTypeName("Reghub Rejection NACK");
		}
		else {
			et.setTypeName("Reghub Business Exception");
		}

		switch (eventName) {
		case EXCEPTION_CLOSED:
			et.getAction().add(Action.CLOSE);
			moMsgException.setSenderStatus(SenderStatus.RESOLVED);
			break;
		case EXCEPTION_CREATED:
			et.getAction().add(Action.ACCEPT);
			moMsgException.setSenderStatus(SenderStatus.OPEN);
			break;
		case EXCEPTION_UPDATED:
		default:
			et.getAction().add(Action.UPDATE);
			moMsgException.setSenderStatus(SenderStatus.OPEN);
		}

		moMsgException.setExceptionType(et);

		return moMsgException;
	}

	private MOMsgEntity createEntity(Entity entity) {

		LOGGER.debug("XmMapper.outboundMap(), entity = \n{}", entity);

		MOMsgEntity outmsg = factory.createMOMsgEntity();

		Optional<Map<String, Object>> infoOpt = Optional.ofNullable(entity.info);
		
		if (!infoOpt.isPresent()) {
			LOGGER.warn("entity.info does not exist and an empty MOMsgEntity instance will be sent to XI seestream.");
			return outmsg;
		}

		Map<String, Object> info = infoOpt.get();

		outmsg.setEntityCode(MOEntityCode.TRADE);

		outmsg.setSrcSystemRef(entity.sourceId); 									// 1
		outmsg.setSrcSystemID(getStringValue(info, "SourceFrontOfficeSystem"));		// 2
		outmsg.setTradeID(entity.sourceUId);										// 3
		outmsg.setTradeVersion(getValue(entity.sourceVersion, Integer.class, "sourceVersion")); // 4
		outmsg.setQuantity(getDoubleValue(info, "tradeQty")); 					// 5
		outmsg.setPrice(getDoubleValue(info, "tradePrice")); 					// 6
		outmsg.setExecCurrency(getStringValue(info, "tradePriceCcy"));			// 7 
		outmsg.setSide(getStringValue(info, "buySellInd")); 					// 8
		outmsg.setTraderID(getStringValue(info, "traderId")); 					// 9

		outmsg.setLegalEntity(getStringValue(info, "sourceFirmLEI")); 			// 10
		outmsg.setClientLegalEntity(getStringValue(info, "sourceCptyLEI")); 	// 11

		outmsg.setSecurityID(getStringValue(info, "securityId")); 				// 12
		outmsg.setSecurityIDSource(getStringValue(info, "securityIdType")); 	// 13

		outmsg.setFirmMnemonic(getStringValue(info, "firmAcctId")); 			// 14
		outmsg.setUnderlyingInstrumentCode(getStringValue(info, "underlyingInstrumentCode"));	// 15
		outmsg.setCustAccount(getStringValue(info, "cptyAcctId"));				// 16
		outmsg.setAccountMnc(getStringValue(info, "cptyAcctId"));				// 16a
		outmsg.setProductName(getStringValue(info, "productType"));				// 17
		outmsg.setSrcSystemID(getStringValue(info, "sourceSystem"));			// 18
		outmsg.setProductType(getStringValue(info, "primaryAssetClass"));		// 19
		outmsg.setUnderlyingInstrumentName(getStringValue(info, "underlyingInstrumentName"));	// 20
		outmsg.setCitiGfcId(getStringValue(info, "sourceFirmGFCID"));			// 21
		outmsg.setClientGfcId(getStringValue(info, "sourceCptyGFCID"));			// 22
		outmsg.setMessageID(getStringValue(info, "messageID")); 				// 23
		outmsg.setMessageType(getStringValue(info, "messageType")); 			// 24
		outmsg.setMessageCategory(getStringValue(info, "messageCategory")); 	// 25
//		outmsg.setExceptionID(exception.getId()); 								// 26, set in MOMsgException
		outmsg.setExceptionClass(getStringValue(info, "exceptionClass")); 		// 27
//		outmsg.setFirstRaisedDatetime(getLong(entity.receivedTs));				// 28, set in MOMsgException
		outmsg.setLastExecTime(getLong(entity.executionTs));					// 29
		outmsg.setTradeStatus(getStringValue(info, "tradeStatus"));				// 30
		outmsg.setTradeDate(getLongValue(info, "tradeDate")); 					// 31
		outmsg.setSiFlag(getStringValue(info, "refSIFlag"));					// 32
		outmsg.setTradeRefVersion(getStringValue(info, "tradeSubVersion"));		// 33
		outmsg.setTotvFlag(getStringValue(info, "totvFlag"));					// 34
		outmsg.setAssistedReportingFlag(getStringValue(info, "refIsAssistedReport"));	// 35
		outmsg.setTradedonEEAvenueFlag(getStringValue(info, "refTradeEEAVenue"));		// 36
		outmsg.setCfiCode(getStringValue(info, "refcfiCode"));					// 37
		outmsg.setExecutionVenue(getStringValue(info, "executionVenue"));		// 38
		outmsg.setSstiFlag(getStringValue(info, "sstiFlag"));					// 39
		outmsg.setLisFlag(getStringValue(info, "lisFlag"));						// 40
		outmsg.setLiquidityFlag(getStringValue(info, "liquidityFlag"));			// 41
		outmsg.setMifidCountryCode(getStringValue(info, "mifidCountryCode"));	// 42
		outmsg.setCountry(getStringValue(info, "exchangeCountry"));				// 43
		outmsg.setMicId(getStringValue(info, "micId"));							// 44
//		outmsg.setTypeName(getStringValue(info, "typeName"));					// 45, set in ExceptionType of MOMsgException
		outmsg.setSenderStatus(getStringValue(info, "senderStatus"));			// 46
//		outmsg.setSenderCompID(getStringValue(info, "senderCompID"));			// 47, set in MMsgException
//		outmsg.setDescription()													// 48, set in MMsgException
//		outmsg.setReportStatus()												// 49, missing from schema, no mapping
//		outmsg.setReflsCptySi();												// 50, missing from schema, no mapping

		return outmsg;
	}

	public Long getLong(LocalDateTime time) {
		return time.atZone(Clock.systemUTC().getZone()).toInstant().toEpochMilli();
	}

	public String getStringValue (Map<String, Object> map, String name) {
		Object obj = map.get(name);
		return getValue(obj, String.class, name);
	}

	public Double getDoubleValue (Map<String, Object> map, String name) {
		Object obj = map.get(name);
		return getValue(obj, Double.class, name);
	}

	public Long getLongValue (Map<String, Object> map, String name) {
		Object obj = map.get(name);
		Long longDate = getValue(obj, Long.class, name);

		if (longDate == null) {
			return null;
		}

		// if length is greater than 13, than it's nano seconds
		int length = String.valueOf(longDate).length();

		return length < MAX_DATE_LENGTH ? longDate : (longDate/NANOSECONDS);
	}

	public <T> T getValue (Object value, Class<T> cls, String name) {
		if (value == null) {
			return null;
		}
		
		if(cls.isInstance(value)) {
			return	cls.cast(value);
		} else {
			T newInstance =null;
			
			try {
				String valueOf = String.valueOf(value);
				Constructor<T> con = cls.getConstructor(String.class);
				newInstance = con.newInstance(valueOf);
			} catch (Exception e){
				LOGGER.error("RegHubId: {}, {}: value \"{}\" expected to be of type {}, but got  {}. Error:\n{}",
						regHubId, name, value, cls, value.getClass(), e);
				return null;
			}
			return newInstance;
		}
	}

	public List<EventEnvelope> fromXstream(OutBoundNotificationMsg nmsg, ExceptionMessage exception) {
		List<MsgExceptionNote> xnotes = nmsg.getNote();
		List<EventEnvelope> envelopes = new ArrayList<>();

		if (nmsg.getStatus() != null) {
			ExceptionMessage exceptionMsg = new ExceptionMessageBuilder().newException().withId(nmsg.getSrcSystemRefId())
					.withRegHubId(exception.getRegHubId())
					.withStatus(ExceptionStatus.ACTED).withStream(exception.getStream()).withFlow(exception.getFlow()).build();
			envelopes.add(new EventBuilder().newEvent().withEventName(EventName.EXCEPTION_STATUS_UPDATED)
					.withEventSource(EventSource.XM_XSTREAM).withEventData(exceptionMsg).ofTypeException().build());
		}

		if (xnotes != null && !xnotes.isEmpty()) {
			MsgExceptionNote xnote = xnotes.get(0);
			Note note = new Note();
			note.setNote(xnote.getNote());
			note.setCreatedBy(xnote.getLastUpdatedBy());
			note.setSource(NoteSource.XSTREAM);
			note.setCreatedTS(NanoClock.convertMilliToNano(xnote.getNoteTimestamp()));

			ExceptionMessage exceptionMsg = new ExceptionMessageBuilder().newException().withId(nmsg.getSrcSystemRefId())
					.withRegHubId(exception.getRegHubId())
					.withStream(exception.getStream()).withFlow(exception.getFlow()).addNote(note).build();
			envelopes.add(new EventBuilder().newEvent().withEventName(EventName.EXCEPTION_NOTE_ADDED)
					.withEventSource(EventSource.XM_XSTREAM).withEventData(exceptionMsg).ofTypeException().build());

			if (FORWARD_TO_FN_OWNER.equalsIgnoreCase(xnote.getUserAction())) {
				String ownerType = nmsg.getTypeOfOwner();
				if (OWNER_TYPE_TECH.equalsIgnoreCase(ownerType)) {
	
					exceptionMsg = new ExceptionMessageBuilder().newException().withId(nmsg.getSrcSystemRefId())
							.withStatus(ExceptionStatus.ACTED).withOwner(FunctionalOwner.TECH).isXstreamEligible(false)
							.withRegHubId(exception.getRegHubId())
							.withStream(exception.getStream()).withFlow(exception.getFlow()).build();
					envelopes.add(new EventBuilder().newEvent().withEventName(EventName.EXCEPTION_UPDATED)
							.withEventSource(EventSource.XM_XSTREAM).withEventData(exceptionMsg).ofTypeException().build());
				}
			}
		}

		return envelopes;
	}

	private XMLGregorianCalendar getXMLGregorianCalendar() {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		GregorianCalendar gregorianCalendar = new GregorianCalendar();

		try {
			DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
			xmlGregorianCalendar = dataTypeFactory.newXMLGregorianCalendar(gregorianCalendar);
		} catch (Exception e) {
			LOGGER.error("Exception in conversion of Date to XMLGregorianCalendar: {}", e);
		}

		return xmlGregorianCalendar;
	}
}
