package com.citi.reghub.core.xm.entity.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.entity.client.EntityClientConfig;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;

public class XmEntityClient {
	private EntityClientConfig entityClientConfig;
	private static final Logger LOGGER = LoggerFactory.getLogger(XmEntityClient.class);
	public static final String ALT_URL_KEY = "altUrlKey";
	public static final String ALT_URL_VALUE = "generic";

	public XmEntityClient(EntityClientConfig entityClientConfig) {
		if (entityClientConfig == null) {
			LOGGER.warn("Entity client config passed is null, using default configuration");
		}

		this.entityClientConfig = entityClientConfig == null ? new EntityClientConfig() : entityClientConfig;

		if (!this.entityClientConfig.containsKey(MetadataClientConfig.METADATA_URL_KEY)) {
			this.entityClientConfig.setDefaultMetadataUrl();
		}

		LOGGER.info("Instantiated Enrichment client instance with config='{}'", entityClientConfig);
	}

	public Entity getLatestEntity(String stream, String flow, String sourceId) {
		LOGGER.debug("Hitting Entity Service for stream: '{}', flow: '{}', sourceId: '{}'", stream, flow, sourceId);

		StringBuilder url = new StringBuilder(entityClientConfig.getEntityUrl());
		if (stream == null || flow == null) {
			String altUrl = (String) entityClientConfig.get(ALT_URL_KEY);
			url.append("/").append(altUrl).append("?");
		}
		else {
			url.append("?stream=").append(stream).append("&flow=").append(flow).append("&");
		}
		
		url.append("sourceId=").append(sourceId).append("&limit=1").append("&summaryView=").append(false);

		LOGGER.info("Entity service URL: '{}'", url);

		List<Entity> entity = entityClientConfig.getRestClient().getValues(url.toString(), Entity.class);

		if (entity == null || entity.isEmpty()) {
			return null;
		}

		return entity.get(0);
	}
}
