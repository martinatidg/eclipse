package com.citi.reghub.core.xm.xstream.topology;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.storm.jms.JmsMessageProducer;
import org.apache.storm.tuple.ITuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XstreamMessageProducer implements JmsMessageProducer {
	private static final Logger LOGGER = LoggerFactory.getLogger(XstreamMessageProducer.class);
	private static final long serialVersionUID = 1L;
	private static final String TUPLE_MESSAGE = "message";

	@Override
	public Message toMessage(Session session, ITuple input) throws JMSException {

		if(input==null){
			LOGGER.error("Skipping processing due to tuple being null: {}", input);
			return null;
		}
		
		Object message = input.getValueByField(TUPLE_MESSAGE);
		if(message==null){
			LOGGER.error("Skipping processing due to message being null: {}", input);
			return null;
		}
	
		if(!(message instanceof String)){
			LOGGER.error("Skipping processing due to message being not of EmitMsag type: {}", input);
			return null;
		}
		
		String xmlMsg = (String)input.getValueByField(TUPLE_MESSAGE);
		LOGGER.info("XstreamMessageProducer.toMessage(), xml to be sent to Xstream JMS queue: \n{}", xmlMsg);

		TextMessage sessionMessage = session.createTextMessage();
		sessionMessage.setText(xmlMsg);

		return sessionMessage;
	}
}
