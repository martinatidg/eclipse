package com.citi.reghub.core.xm.xstream.topology;

import java.util.Map;
import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.storm.jms.JmsProvider;

import com.citi.reghub.core.xm.xstream.Key;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class XstreamJmsProvider implements JmsProvider {
	private static final long serialVersionUID = 1L;
	private static final String FACTORY_NAME = TibjmsInitialContextFactory.class.getName();
	private String connectionJndi;
	private String destination;
	private String providerUrl;

	private transient InitialContext context;

	public XstreamJmsProvider(Map<String, String> config, boolean isOutbound) throws NamingException {
		this.connectionJndi = config.get(Key.CONNECTION_JNDI.value());
		providerUrl = config.get(Key.PROVIDER_URL.value());
		if (isOutbound) {
			this.destination = config.get(Key.QUEUE_REQUEST.value());
		}
		else {
			this.destination = config.get(Key.QUEUE_RESPONSE.value());
		}
	}

	@Override
	public ConnectionFactory connectionFactory() throws Exception {
		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, FACTORY_NAME);
		env.put(Context.PROVIDER_URL, providerUrl);
		context = new InitialContext(env);

		return (QueueConnectionFactory) context.lookup(connectionJndi);
	}

	@Override
	public Destination destination() throws Exception {
		return (Destination)context.lookup(destination);
	}
}
