package com.citi.reghub.core.xm.xstream.topology;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.JAXBException;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.xm.xstream.schema.XstreamMarshaller;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;

public class ToXstreamBolt extends RegHubBolt {
	private static final Logger LOGGER = LoggerFactory.getLogger(ToXstreamBolt.class);
	private static final long serialVersionUID = 1L;
	private transient OutputCollector collector;

	@Override
	public void process(Tuple input) throws Exception {
		LOGGER.debug("ToXstreamBolt.process(), input:\n{}", input);

		if(input==null){
			LOGGER.error("Skipping processing due to tuple being null: {}", input);
			collector.ack(input);
			return;
		}
		
		Object message = input.getValueByField(TUPLE_MESSAGE);
		if(message==null){
			LOGGER.error("Skipping processing due to message being null: {}", input);
			collector.ack(input);
			return;
		}
	
		if(!(message instanceof EmitMsg)){
			LOGGER.error("Skipping processing due to message being not of EmitMsag type: {}", input);
			collector.ack(input);
			return;
		}
		
		EmitMsg boltMsg  = (EmitMsg )message;
		
		LOGGER.debug("ToXstreamBolt.process(), boltMsg:\n{}", boltMsg);
		XstreamMapper mapper = new XstreamMapper();
		Optional<XmFeedMsg> regmsgOpt = mapper.toXstream(boltMsg.getException(), boltMsg.getEntity(), boltMsg.getEventName());
		
		if (!regmsgOpt.isPresent()) {
			LOGGER.error("Failed to map from exception message and entity to XmFeedMsg: {}", input);
			collector.ack(input);
			return;
		}

		String xmlMsg=null;
		try {
			xmlMsg = XstreamMarshaller.marshalXmFeedMsg(regmsgOpt.get());
		} catch (JAXBException e) {
			LOGGER.error("Failed to marshal the object: {}, due to: {}",regmsgOpt.get(), e);
			collector.ack(input);
			return;
		}

		LOGGER.debug("ToXstreamBolt.process(), before emit.");
		collector.emit(StormStreams.XM_EXCEPTION_MESSAGE_STREAM,new Values(boltMsg.getException().getId(), xmlMsg));
		collector.ack(input);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.XM_EXCEPTION_MESSAGE_STREAM, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}

	@SuppressWarnings({"rawtypes"})
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}
	

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}
