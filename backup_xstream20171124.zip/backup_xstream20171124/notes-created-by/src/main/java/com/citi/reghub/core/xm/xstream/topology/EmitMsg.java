package com.citi.reghub.core.xm.xstream.topology;

import java.io.Serializable;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.exception.ExceptionMessage;

public class EmitMsg implements Serializable {
	private static final long serialVersionUID = 1L;

	private ExceptionMessage exception;
	private Entity entity;
	private EventName  eventName;

	public EmitMsg(ExceptionMessage exception, Entity entity, EventName  eventName) {
		this.exception = exception;
		this.entity = entity;
		this.eventName = eventName;
	}

	public ExceptionMessage getException() {
		return exception;
	}

	public EventName getEventName() {
		return eventName;
	}

	public void setException(ExceptionMessage exception) {
		this.exception = exception;
	}

	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}
}
