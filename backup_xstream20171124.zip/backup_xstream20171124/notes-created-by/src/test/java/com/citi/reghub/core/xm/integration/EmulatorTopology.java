package com.citi.reghub.core.xm.integration;

import java.util.Map;

import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EventEnvelopeSerializer;
import com.citi.reghub.core.kafka.RegHubKafkaBolt;
import com.citi.reghub.core.xm.xstream.Key;

public class EmulatorTopology extends BaseTopology {
	public static void main(String[] args) throws Exception {
		new EmulatorTopology().runTopology(args);
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		final TopologyBuilder tp = new TopologyBuilder();
		topologyConfig.put(Key.KAFKA_KEY_SERIALIZER.value(), StringSerializer.class.getName());
		topologyConfig.put(Key.KAFKA_VALUE_SERIALIZER.value(), EventEnvelopeSerializer.class.getName());

		System.out.println("EmulatorTopology.buildTopology, sourceKafkaTopics = " + topologyConfig.get(Key.KAFKA_TOPIC.value()));
		for (Map.Entry<String, String> entry : topologyConfig.entrySet()) {
			System.out.println("EmulatorTopology.buildTopology(), key = " + entry.getKey() + ", value = " + entry.getValue());
		}

		tp.setSpout("xmSpout", new XmSpout(), 3);

		tp.setBolt("xm_bolt", RegHubKafkaBolt.getKafkaBolt(topologyConfig, topologyConfig.get(Key.KAFKA_TOPIC.value()), "xmSpout"), 3)
				.shuffleGrouping("xmSpout");

		return tp.createTopology();
	}
}
