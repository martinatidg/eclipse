package com.citi.reghub.core.xm.integration;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.Optional;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.EventType;
import com.citi.reghub.core.event.EventVersion;
import com.citi.reghub.core.event.exception.ExceptionLevel;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionMessageBuilder;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.citi.reghub.core.event.exception.ExceptionType;
import com.citi.reghub.core.event.exception.FunctionalOwner;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgException;
import com.citi.reghub.core.xm.xstream.schema.inbound.SenderStatus;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound. OutBoundNotificationMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.Status;


public class TestData {
	private static com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory infactory = new com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory();
	private static com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory outfactory = new com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory();

	private static int mark = 0;
	
	private static String[] ids_uat = {
			 "b2bd628d-f291-4a0b-8520-91593cb7204f,489580638,m2trcsheq502435484,CSHEQPRIMO20170927489580638,m2tr,csheq,m2tr_all_trading_capacity_exception,The Trading capacity  must not be NULL or blank",
			 "9a5ffe11-3747-4b0c-ab22-f00c237c98dc,484523181,m2trcsheq502435472,CSHEQPRIMO20170927484523181,m2tr,csheq,m2tr_all_trading_capacity_exception,The Trading capacity  must not be NULL or blank",
	};
	
	private static String[] ids_qat = {
			 "287764e6-4fdb-47b2-8c68-76ed66f4694d,PFS-9890134-39344541-1-UITID,m2trotceqd10150640926563608,OTCEQDPFS20170719PFS9890134393445411UITID,m2tr,otceqd,m2tr_otceqd_firm_account_lei_exception,Length of Firm account LEI should be String of 20 characters; where 1-18 characters are either capital letters or numbers and 19-20 characters are numbers"
	};

	private static String[] ids_sit = {
			"6c888a04-e7cc-47f4-b620-1725ccfb2270,035506:00LDN823402690,m2trcshfx20150595684509777,CSHFXFXLMREG2017092003550600LDN823402690,m2tr,cshfx,m2tr_all_firm_account_lei_exception,Length of Firm account LEI should be String of 20 characters; where 1-18 characters are either capital letters or numbers and 19-20 characters are numbers",
			"10c6cf82-2fa0-40aa-bb76-fba9a8d4e897,N14527300NYK20170921240102,m2trcshfx20150595684651033,CSHFXFXLMREG20170921N14527300NYK20170921240102,m2tr,cshfx,m2tr_all_firm_account_lei_exception,Length of Firm account LEI should be String of 20 characters; where 1-18 characters are either capital letters or numbers and 19-20 characters are numbers"
	};

	public static ExceptionMessage getExMsg() {
		String[] ida = getExceptionId().split(",");
		mark++;

		ExceptionMessage exmsg = new ExceptionMessageBuilder().newException()
				.withId(ida[0])
				.withSourceId(ida[1])
				.withRegHubId(ida[2])
				.withRegReportingRef(ida[3])
				.withStream(ida[4])
				.withFlow(ida[5])
				.withStatus(ExceptionStatus.OPEN)
				.withReasonCode(ida[6])
				.withRuleVersion("1.0")
				.withDescription(ida[7])
				.withOwner(FunctionalOwner.BUS)
				.isXstreamEligible(true)
				.withType(ExceptionType.DATA_QUALITY)
				.withLevel(ExceptionLevel.NACK)
				.withUpdatedSource(EventSource.XM_CONSUMER.value()).build();

		exmsg.setCreatedTS(System.currentTimeMillis());

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope envelope = new EventEnvelope();
		envelope.setEventName(EventName.EXCEPTION_CREATED);
		envelope.setEventSource(EventSource.XM_CONSUMER);
		envelope.setEventType(EventType.EXCEPTION);
		envelope.setEventVersion(EventVersion.V_1);
		envelope.setEventData(getExMsg());

		return envelope;
	}

	public static OutBoundNotificationMsg getNoteMsg(XmFeedMsg xmmsg) {
		 OutBoundNotificationMsg notemsg = outfactory.createOutBoundNotificationMsg();
		MsgExceptionNote exNote = outfactory.createMsgExceptionNote();

		MOMsgEntity msgObj = xmmsg.getMoEntity();
		exNote.setNote("from local JMS client");
		exNote.setLastUpdatedBy("Xm-Stream");
		exNote.setNoteTimestamp(msgObj.getLastExecTime());
		exNote.setUserAction("Add Note");
		
		Optional<List<MOMsgException>> moMsgExs = Optional.ofNullable(xmmsg.getMoException());
		Optional<MOMsgException> moMsg = moMsgExs.map(l -> l.get(0));
		
		

		notemsg.setSrcSystemRefId(moMsg.map(m -> m.getSenderExceptionID()).get());
		notemsg.setExceptionRefNumber(moMsg.map(m -> m.getSenderExceptionID()).get());
		notemsg.setStatus(Status.OPEN);
		notemsg.setTypeOfOwner(msgObj.getTraderID());
		notemsg.getNote().add(exNote);

		return notemsg;
	}

	public static XmFeedMsg getXmFeedMsg() {
		XmFeedMsg msg = infactory.createXmFeedMsg();

		MOMsgEntity moEntity = infactory.createMOMsgEntity();
		moEntity.setSrcSystemID("19884416");
		moEntity.setTradeVersion(1);
		moEntity.setQuantity(0.0);
		moEntity.setPrice(0.0);
		moEntity.setSide("BUY");
		moEntity.setSecurityID("934998M77");
		moEntity.setSecurityIDSource("CUSIP");
		moEntity.setLastExecTime(1490613884L);
		moEntity.setTradeDate(1490572800L);
		//moEntity.setTradeStatus("Open");

		MOMsgException moException = infactory.createMOMsgException();
		moException.setSrcSysID("19884416");
		moException.setDescription("test data");
		moException.setSenderCompID("REGHUB");
		moException.setSenderExceptionID("943168035");
		moException.setSenderStatus(SenderStatus.OPEN);
		moException.setCreatedBy("BUS");
		moException.setFirstRaisedDatetime(1505325255618L);

		msg.setRequestId("10001");
		msg.setTimestamp(getXMLGregorianCalendar());
		msg.setMoEntity(moEntity);
		msg.getMoException().add(moException);

		return msg;
	}

	private static XMLGregorianCalendar getXMLGregorianCalendar() {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		GregorianCalendar gregorianCalendar = new GregorianCalendar();

		try {
			DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
			xmlGregorianCalendar = dataTypeFactory.newXMLGregorianCalendar(gregorianCalendar);
		} catch (Exception e) {
			System.out.println("Exception in conversion of Date to XMLGregorianCalendar" + e);
		}

		return xmlGregorianCalendar;
	}

	private static String getExceptionId() {
		if (mark >= ids_sit.length) {
			mark = mark % ids_sit.length;
		}
		return ids_sit[mark];
	}
}
