package com.citi.reghub.core.xm.xstream.topology;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.client.SingletonRestClient;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.exception.client.ExceptionClient;
import com.citi.reghub.core.exception.client.ExceptionClientConfig;
import com.citi.reghub.core.exception.client.ExceptionsViewWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;

public class FromXstreamBoltTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(FromXstreamBoltTest.class);

	// the test works only when the service with the url available.
	@Test
	public void getExceptionsFromServiceById() throws JsonProcessingException {
//		//String xm_service_url = "http://sd-608f-3cd9.nam.nsroot.net/reghub-api/xm-service/exceptions";
//		//String xm_service_url = "http://sd-87b5-53ae.nam.nsroot.net:8090/reghub-api/xm-service/exceptions";
//		String xm_service_url = "http://sd-608f-3cd9.nam.nsroot.net/reghub-api/xm-service/exceptions";
//		ExceptionClientConfig xmClientConfig = new ExceptionClientConfig();
//        xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, xm_service_url);
//        
//        xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, SingletonRestClient.getInstance());
//
//        ExceptionClient client = new ExceptionClient(xmClientConfig);
//        LOGGER.info("Calling getExceptionsFromService");
//        ExceptionMessage exception = client.getExceptionsById("f8efc619-3e47-4d9b-9eb1-76736615e813");
//
//        System.out.println( exception);
	}
}
