package com.citi.reghub.core.xm.xstream.topology;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.tuple.Tuple;
import org.junit.Test;

import com.citi.reghub.core.Entity;

public class ToXstreamBoltTest {
	private Tuple tuple = mock(Tuple.class);
	private Object msg = mock(EmitMsg.class);
	private OutputCollector collector = mock(OutputCollector.class);
	private Entity entity = mock(Entity.class);
	
	private EventBolt bolt = mock(EventBolt.class);
	
	@Test
	public void testProcessNullValidation() throws Exception {
		when(tuple.getValueByField("message")).thenReturn(msg);
		when(((EmitMsg)msg).getEntity()).thenReturn(entity);
		when(bolt.getCollector()).thenReturn(collector);

		tuple = null;
		bolt.process(tuple);
	}
	@Test
	public void testProcessNullValidationNullEmitMsg() throws Exception {
		when(tuple.getValueByField("message")).thenReturn(null);
		when(((EmitMsg)msg).getEntity()).thenReturn(null);
		when(((EmitMsg)msg).getException()).thenReturn(null);
		when(bolt.getCollector()).thenReturn(collector);

		bolt.process(tuple);
	}
}