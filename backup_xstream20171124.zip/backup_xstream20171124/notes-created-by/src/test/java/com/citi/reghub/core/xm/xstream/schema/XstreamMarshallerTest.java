package com.citi.reghub.core.xm.xstream.schema;

import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.xm.integration.TestData;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.OutBoundNotificationMsg;
import com.citi.reghub.core.xm.xstream.topology.XstreamMapper;

public class XstreamMarshallerTest {

	@Test
	public void testMarshal() throws JAXBException {
		XmFeedMsg msg = TestData.getXmFeedMsg();

		String xml = XstreamMarshaller.marshalXmFeedMsg(msg);
		System.out.println("xml = \n" + xml);
		Assert.assertNotNull("Marshalled from XmFeedMsg failed.", xml);

		XmFeedMsg remsg = XstreamMarshaller.unmarshalXmFeedMsg(xml);
		System.out.println("remsg = \n" + remsg);
		Assert.assertNotNull("un-marshalling to XmFeedMsg failed.", remsg);

		OutBoundNotificationMsg noteMsg = TestData.getNoteMsg(remsg);
		String oxml = XstreamMarshaller.marshalNotificationMsg(noteMsg);
		System.out.println("noteMsg = \n" + noteMsg);
		Assert.assertNotNull("marshalling from OutBoundNotificationMsg failed.", noteMsg);

		OutBoundNotificationMsg remsg2 = XstreamMarshaller.unmarshalNotificationMsg(oxml);
		System.out.println("remsg2 = \n" + remsg2);
		Assert.assertNotNull("un-marshalling to OutBoundNotificationMsg failed.", remsg2);

		EventEnvelope envelope = TestData.getEvtMsg();
		System.out.println("envelope = \n" + envelope);
		Assert.assertNotNull("The generated EventEnvelope is null.", envelope);
	}

	@Test
	public void testUnmarshal() throws JAXBException {
		String noteXml_good = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
							+ "<OutBoundNotificationMsg srcSystemRefId=\"f8efc619-3e47-4d9b-9eb1-76736615e813\" "
							+ "status=\"Open\" exceptionRefNumber=\"7c3b6732-5029-499c-bf0e-7fe2cf766460\" "
							+ "xmlns:ns2=\"http://www.citi.com/xstream/schemas\">"
							+ "<ns2:note note=\"from local JMS client\" noteTimestamp=\"1507822185\" "
							+ "lastUpdatedBy=\"Xm-Stream\" userAction=\"Add Note\" />"
							+ "</OutBoundNotificationMsg>";
		System.out.println("noteXml_good = \n" + noteXml_good);

		String noteXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
				+ "<OutBoundNotificationMsg srcSystemRefId=\"f8efc619-3e47-4d9b-9eb1-76736615e813\" "
				+ "status=\"Open\" exceptionRefNumber=\"60227969\" xmlns=\"http://www.citi.com/xstream/schemas\">"
				+ "<note note=\"xstream UI test 9, add notes, uat	Ref Data\" "
				+ "noteTimestamp=\"1508126400000\" lastUpdatedBy=\"mt66710\" userAction=\"Add Note\" />"
				+ "</OutBoundNotificationMsg>";

		System.out.println("noteXml = \n" + noteXml);		

		OutBoundNotificationMsg note_good = XstreamMarshaller.unmarshalNotificationMsg(noteXml_good);
		System.out.println("note_good = \n" + note_good);
		Assert.assertNotNull("The unmarshalled note is null.", note_good);

		OutBoundNotificationMsg note = XstreamMarshaller.unmarshalNotificationMsg(noteXml);
		System.out.println("note = \n" + note);
		Assert.assertNotNull("The unmarshalled note is null.", note);

		// the code below will be executed only when the service with the url available.
//		String url = "http://sd-87b5-53ae.nam.nsroot.net:8090/reghub-api/xm-service/exceptions";
//		XstreamMapper mapper = new XstreamMapper();
//		List<EventEnvelope> envelopes = mapper.fromXstream(note, url);
//		System.out.println("envelopes.size() = " + envelopes.size() + ", envelopes = \n" + envelopes);

	}
}
