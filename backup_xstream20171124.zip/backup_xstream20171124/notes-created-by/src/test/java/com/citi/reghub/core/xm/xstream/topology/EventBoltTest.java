package com.citi.reghub.core.xm.xstream.topology;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.tuple.Tuple;
import org.junit.Test;

import com.citi.reghub.core.event.EventData;
import com.citi.reghub.core.event.EventEnvelope;

public class EventBoltTest {
	private Tuple tuple = mock(Tuple.class);
	private Object envelope = mock(EventEnvelope.class);
	private EventData data = mock(EventData.class);
	private OutputCollector collector = mock(OutputCollector.class);
	
	private EventBolt bolt = mock(EventBolt.class);
	
	@Test
	public void testProcessNullValidation() throws Exception {
		when(tuple.getValueByField("message")).thenReturn(null);
		when(((EventEnvelope)envelope).getEventData()).thenReturn(null);
		when(bolt.getCollector()).thenReturn(collector);

		bolt.process(tuple);

		when(tuple.getValueByField("message")).thenReturn(null);
		when(((EventEnvelope)envelope).getEventData()).thenReturn(data);
		when(bolt.getCollector()).thenReturn(collector);

		bolt.process(tuple);

		when(tuple.getValueByField("message")).thenReturn(envelope);
		when(((EventEnvelope)envelope).getEventData()).thenReturn(null);
		when(bolt.getCollector()).thenReturn(collector);

		bolt.process(tuple);
	}

}
