package com.citi.reghub.core.xm.integration;

import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class JmsConsumer implements MessageListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(JmsConsumer.class);

	private static final String CONNECTION_JNDI = "citi.cibtech.na.gicapbpm_153176.XAQueueCF";
	private static final String PROVIDER_URL = "tcp://icgemsmw01u.nam.nsroot.net:7222,tcp://icgemsmw02u.nam.nsroot.net:7222";
	private String factoryName = TibjmsInitialContextFactory.class.getName();
	private static final String QUEUE_REQUEST  = "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue";

	private Connection connection;
	private InitialContext context;

	public static void main(String[] args) throws NamingException, JMSException {
		JmsConsumer xmconsumer = new JmsConsumer();
		try {
			xmconsumer.startListener();
			LOGGER.info("Xstream UI JMS client started....");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	public JmsConsumer() throws NamingException, JMSException {
		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		env.put(Context.PROVIDER_URL, PROVIDER_URL);
		context = new InitialContext(env);
		ConnectionFactory connectionFactory = (QueueConnectionFactory) context.lookup(CONNECTION_JNDI);

		connection = connectionFactory.createConnection();
		connection.start();
	}

	public void onMessage(Message message) {
		try {
			String xml = ((TextMessage) message).getText();
			LOGGER.info("Message received from xstream UI:\n{}", xml);

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void startListener() throws NamingException {
		try {
			Queue reqQueue = (Queue) context.lookup(QUEUE_REQUEST);
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(reqQueue);
			consumer.setMessageListener(this);
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

}
