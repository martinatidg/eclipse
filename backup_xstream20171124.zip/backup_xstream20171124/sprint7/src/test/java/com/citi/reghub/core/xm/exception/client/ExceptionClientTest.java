package com.citi.reghub.core.xm.exception.client;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.client.SingletonRestClient;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.exception.client.ExceptionClientConfig;
import com.fasterxml.jackson.core.JsonProcessingException;

public class ExceptionClientTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionClientTest.class);
	@BeforeClass
	public  static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException {
	}

	// the test works only when the service with the url available.
	@Test
	public void getExceptionsFromServiceById() throws JsonProcessingException {
//		ExceptionClientConfig xmClientConfig = new ExceptionClientConfig();
//        xmClientConfig.set(ExceptionClientConfig.XM_SERVICE_URL_KEY, "http://sd-87b5-53ae.nam.nsroot.net:8090/reghub-api/xm-service/exceptions");
//        
//        xmClientConfig.set(ExceptionClientConfig.REST_CLIENT, SingletonRestClient.getInstance());
//
//        ExceptionClient client = new ExceptionClient(xmClientConfig);
//        LOGGER.info("Calling getExceptionsFromService");
//        ExceptionMessage exceptions1 = client.getExceptionsFromServiceById("f8efc619-3e47-4d9b-9eb1-76736615e813");
//
//        System.out.println( exceptions1);

	}
}
