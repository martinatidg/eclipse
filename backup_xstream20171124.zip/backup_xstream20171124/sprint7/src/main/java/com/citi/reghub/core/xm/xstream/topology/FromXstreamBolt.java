package com.citi.reghub.core.xm.xstream.topology;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.JAXBException;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.xm.xstream.Key;
import com.citi.reghub.core.xm.xstream.schema.XstreamMarshaller;
import com.citi.reghub.core.xm.xstream.schema.outbound.OutBoundNotificationMsg;

public class FromXstreamBolt extends RegHubBolt {
	private static final Logger LOGGER = LoggerFactory.getLogger(FromXstreamBolt.class);

	private static final long serialVersionUID = 1L;
	private transient OutputCollector collector;
	private String url;

	@Override
	public void process(Tuple input) throws Exception {
		Optional<String> msgOpt = Optional.ofNullable(input)
				.map((Tuple t) -> (String)t.getValueByField(TUPLE_MESSAGE));

		if (!msgOpt.isPresent()) {
			LOGGER.error("Failed to process typule: {}", input);
			collector.ack(input);
			return;
		}
		
		String msg = msgOpt.get();
		LOGGER.debug("response from xstream:\n{}", msg);

		OutBoundNotificationMsg nmsg = null;
		try {
			nmsg = XstreamMarshaller.unmarshalNotificationMsg(msg);
		} catch (JAXBException e) {
			LOGGER.error("Failed to marshall the message: {}", e);
			collector.ack(input);
			return;
		}

		XstreamMapper mapper = new XstreamMapper();
		List<EventEnvelope> envelopes = mapper.fromXstream(nmsg, url);
		
		if (envelopes.isEmpty()) {
			LOGGER.warn("Status not exists and no notes added. No events emited.");
			collector.ack(input);
			return;
		}

		LOGGER.debug("{} events to be emitted:\n{}", envelopes.size(), envelopes);
		for (EventEnvelope envelope : envelopes) {
			getCollector().emit(Arrays.asList(envelope));
		}

		LOGGER.debug("Finish processing the message and acknowledge.");
		collector.ack(input);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
		
		Map<String, String> config = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		this.collector = collector;
		url = config.get(Key.XM_SERVICE_URL.value());
		LOGGER.debug("xm service url = {}", url);
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}
