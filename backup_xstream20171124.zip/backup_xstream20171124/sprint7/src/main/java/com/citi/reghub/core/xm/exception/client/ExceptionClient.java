package com.citi.reghub.core.xm.exception.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.exception.client.ExceptionClientConfig;
import com.citi.reghub.core.exception.client.ExceptionsViewWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;

public class ExceptionClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionClientTest.class);
	private ExceptionClientConfig exceptionClientConfig = new ExceptionClientConfig();
	
	public static final String ALT_URL_KEY = "altUrlKey";
	public static final String ALT_URL_VALUE = "generic";

	public ExceptionClient(ExceptionClientConfig exceptionClientConfig) {
		if (exceptionClientConfig == null) {
			LOGGER.warn("Entity client config passed is null, using default configuration");
		}

		this.exceptionClientConfig = exceptionClientConfig == null ? new ExceptionClientConfig() : exceptionClientConfig;

		if (!this.exceptionClientConfig.containsKey(ExceptionClientConfig.XM_SERVICE_URL_KEY))
			this.exceptionClientConfig.setDefaultXmServiceUrl();
		LOGGER.info("Instantiated Exception client instance with config='{}'", exceptionClientConfig);
	}

	public ExceptionMessage getExceptionsFromServiceById(String exceptionId) throws JsonProcessingException {
        LOGGER.debug("Hitting xm-service for getExceptionsFromServiceById with exceptionId='{}'", exceptionId);
        Map<String, Object> query = new HashMap<>();
        List<String> ids = new ArrayList<>();
        ids.add(exceptionId);
        query.put("id", ids);
        ExceptionsViewWrapper exceptionsVW = exceptionClientConfig.getRestClient().doPost(query , exceptionClientConfig.getXmServiceUrl(), ExceptionsViewWrapper.class,false);
        if(exceptionsVW.getTotalRecords() != 0){
               return exceptionsVW.getExceptionsList().get(0);
        }
        return null;
 }

}
