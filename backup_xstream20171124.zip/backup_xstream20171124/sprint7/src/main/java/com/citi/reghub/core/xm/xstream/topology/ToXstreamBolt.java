package com.citi.reghub.core.xm.xstream.topology;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.JAXBException;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.xm.xstream.schema.XstreamMarshaller;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;

public class ToXstreamBolt extends RegHubBolt {
	private static final Logger LOGGER = LoggerFactory.getLogger(ToXstreamBolt.class);
	private static final long serialVersionUID = 1L;
	private transient OutputCollector collector;

	@Override
	public void process(Tuple input) throws Exception {
		Optional<EmitMsg> msgOpt = Optional.ofNullable(input)
				.map((Tuple t) -> (EmitMsg)t.getValueByField(TUPLE_MESSAGE));

		if (!msgOpt.isPresent()) {
			LOGGER.error("Failed to process typule: {}", input);
			collector.ack(input);
			return;
		}

		EmitMsg boltMsg = msgOpt.get();

		XstreamMapper mapper = new XstreamMapper();
		Optional<XmFeedMsg> regmsgOpt = mapper.toXstream(boltMsg.getException(), boltMsg.getEntity(), boltMsg.getEventName());
		
		if (!regmsgOpt.isPresent()) {
			LOGGER.error("Failed to map from exception message and entity to XmFeedMsg: {}", input);
			collector.ack(input);
			return;
		}

		String xmlMsg;
		try {
			xmlMsg = XstreamMarshaller.marshalXmFeedMsg(regmsgOpt.get());
		} catch (JAXBException e) {
			LOGGER.error("Failed to marshal the object: {}", e);
			collector.ack(input);
			return;
		}

		collector.emit(Arrays.asList(xmlMsg));
		collector.ack(input);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}

	@SuppressWarnings({"rawtypes"})
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}
