package com.citi.reghub.core.xm.xstream.topology;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.storm.jms.JmsTupleProducer;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.RegHubBolt;

public class XstreamTupleProducer implements JmsTupleProducer {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(XstreamTupleProducer.class);

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(RegHubBolt.TUPLE_MESSAGE));
	}

	@Override
	public Values toTuple(Message message) throws JMSException {
		String xml = ((TextMessage)message).getText();
		LOGGER.info("XstreamTupleProducer.toTuple(), received from xstream, xml:\n{}", xml);

		return new Values(xml);
	}
}
