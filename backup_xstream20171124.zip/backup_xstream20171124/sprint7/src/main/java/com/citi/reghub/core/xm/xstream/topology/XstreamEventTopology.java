package com.citi.reghub.core.xm.xstream.topology;

import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.Config;
import org.apache.storm.jms.bolt.JmsBolt;
import org.apache.storm.topology.TopologyBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EventEnvelopeSerializer;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;
import com.citi.reghub.core.xm.xstream.Constants;

public class XstreamEventTopology extends BaseTopology {
	private static final Logger LOGGER = LoggerFactory.getLogger(BaseTopology.class);
	private static final String KAFKA_INPUT_TOPIC_NAMES = "kafka.input.topic.names";
	private static final String TOPOLOGY_NAME = "xstream_event_topology";

	public static void main(String[] args) throws Exception {
		new XstreamEventTopology().runTopology(args);
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		topologyConfig.put(GlobalProperties.TOPOLOGY_NAME, TOPOLOGY_NAME);
		LOGGER.info("Start to build topology: {}", topologyConfig.get(GlobalProperties.TOPOLOGY_NAME));

		final TopologyBuilder topologyBuilder = new TopologyBuilder();
		String inputTopicNames = topologyConfig.get(KAFKA_INPUT_TOPIC_NAMES);
		XstreamMessageProducer messageProducer = new XstreamMessageProducer();
		XstreamJmsProvider provider = new XstreamJmsProvider(topologyConfig, true);
		JmsBolt jmsBolt = new JmsBolt();
		jmsBolt.setJmsProvider(provider);
		jmsBolt.setJmsMessageProducer(messageProducer);

		RegHubKafkaSpout<String, EventEnvelope> regKafkaSpout = RegHubKafkaSpout
				.builder(inputTopicNames, StormStreams.INBOUND_KAFKA_STREAM_NAME, topologyConfig)
				.setKeyDesClazz(StringDeserializer.class).setValueDesClazz(EventEnvelopeSerializer.class)
				.build();

		topologyBuilder.setSpout(Constants.KAFKA_SPOUT.value(), regKafkaSpout.getSpout(), 3);
		topologyBuilder.setBolt(Constants.EVENT_BOLT.value(),
				new EventBolt(), 3).shuffleGrouping(Constants.KAFKA_SPOUT.value(),
				StormStreams.INBOUND_KAFKA_STREAM_NAME);
		topologyBuilder.setBolt(Constants.TO_XM_BOLT.value(),
				new ToXstreamBolt(), 3).shuffleGrouping(Constants.EVENT_BOLT.value());
		topologyBuilder.setBolt(Constants.JMS_BOLT.value(), jmsBolt, 3).shuffleGrouping(Constants.TO_XM_BOLT.value());

		return topologyBuilder.createTopology();
	}

	@Override
	protected Config getTopologyConfig() {
		Config conf = new Config();
		conf.setDebug(false);
		conf.setNumWorkers(3);
    	conf.put(Config.TOPOLOGY_BACKPRESSURE_ENABLE,            true);
      	conf.put(Config.TOPOLOGY_EXECUTOR_RECEIVE_BUFFER_SIZE, 1024);
    	conf.put(Config.TOPOLOGY_EXECUTOR_SEND_BUFFER_SIZE,    1024);
    	conf.put(Config.BACKPRESSURE_DISRUPTOR_HIGH_WATERMARK,    0.8);
    	conf.put(Config.BACKPRESSURE_DISRUPTOR_LOW_WATERMARK,    0.5);
    	conf.put(Config.TOPOLOGY_WORKER_MAX_HEAP_SIZE_MB, 2048);
        conf.put(Config.WORKER_HEAP_MEMORY_MB, 2048);
      	conf.setMessageTimeoutSecs(60);
      	conf.setMaxSpoutPending(5000);
      	//conf.registerSerialization(Entity.class);
      	//conf.registerSerialization(Audit.class);
    	return conf;
	}
}
