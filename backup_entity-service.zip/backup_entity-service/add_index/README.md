# Entity Service 

## Entity MicroService Built using Spring Boot

Entity service provides API to fetch entity information from  Mongo DB. 



