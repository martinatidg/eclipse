package com.citi.reghub.core.changerequest;

import java.time.LocalDateTime;

public class ChangeRequestPayloadBuilder {
	
	public static LocalDateTime now = LocalDateTime.now();
	private static LocalDateTime lastMonth = LocalDateTime.now().minusMonths(1);
	private static LocalDateTime nextMonth = LocalDateTime.now().plusMonths(1);

	private static String basicPayloadWithoutBraces = 
            "\"stream\": \"streamReplacable\"," +
            "\"maker\": \"SP18336\"," +
            "\"makerComments\": \"testing comments\"," +
            "\"type\": \"EXCEPTION\"," +
            "\"reasonCode\": \"abc\"," +
            "\"attributes\": [" +
                    "{" +
                        "\"fieldName\": \"fieldOne\"," +
                        "\"oldValue\": \"old_value_1\"," +
                        "\"newValue\": \"new_value_2\"" +
                    "}"+
                "]," +
            "\"exception\": [" +
                "{" +
                    "\"exceptionId\": \"xceptionOne\"," +
                    "\"regHubId\": \"IdReplaceable\"," +
                    "\"regReportingRef\": \"csheqnull123\"," +
                    "\"flow\": \"flowREplaceable\"," +
                    "\"sourceId\": \"source1\"" +
                "}"+
            "]" ;
	
	private static String searchPayloadWithoutBraces = 
			              "\"offset\": \"0\"," + 
							 "\"limit\": \"50\"," +
							 "\"filter\": {"+
							 "\"createdTs\": [\"" + lastMonth + "\",\""+ nextMonth +"\"]," +
			                 "\"stream\": ["+
			                  " \"streamReplacable\"" +
			                 "]," +
			                 "\"flow\": ["+
			                  " \"flowREplaceable\""+
			                 "]"+
				           "}";
	
	private static String approvePayload = "[{ \"id\": \"idREplaceable\", \"exceptionId\" : \"Exception5\", \"regHubId\" : \"ID-5\", \"regReportingRef\" : \"1234\", \"flow\" : \"csheq\", \"sourceId\" : \"03550600LDN822356352\", \"reasonCode\": \"m2tr_all_trade_price_exception\", \"stream\" : \"m2tr\", \"maker\" : \"sl84003\", \"makerComments\" : \"upstream updated\", \"type\" : \"EXCEPTION\", \"requestedAction\" : \"SUBMIT\", \"attributes\": [{ \"fieldName\" : \"tradeCapacity\", \"newValue\" : \"123\"  }] , \"checker\" : \"BA23456\" , \"checkerComments\" : \"This request can be approved\",  \"requestAction\" : \"SUBMIT\"" +
						"}]";
						
	
	public static String payloadWithRequestActionAndStreamFlow(String action, String stream, String flow) {
		
		return "{" + "\"requestAction\": \""+ action.toString() + "\","  + 
					basicPayloadWithoutBraces.replaceFirst("streamReplacable", stream).replaceFirst("flowREplaceable", flow).replaceFirst("IdReplaceable", "123")
					+ "}" ;
	}
	public static String payloadWithRequestActionAndStreamFlow(String action, String stream, String flow, String id) {
		
		return "{" + "\"requestAction\": \""+ action.toString() + "\","  + 
					basicPayloadWithoutBraces.replaceFirst("streamReplacable", stream).replaceFirst("flowREplaceable", flow).replaceFirst("IdReplaceable", id)
					+ "}" ;
	}
	
	public static String searchPayloadwithStreamFlow( String stream, String flow) {
		return "{" + searchPayloadWithoutBraces.replaceFirst("streamReplacable", stream).replaceFirst("flowREplaceable", flow) + "}";
	}
	
	public static String rejectPayloadWithOnlyId(String string) {
		return "[{ \"id\": \"" + string + "\", \"checker\" : \"AB12345\" , \"checkerComments\" : \"This is not Valid\" }]";
	}
	
	public static String approvePayloadWithOnlyId(String string) {
		//return "[{ \"id\": \"" + string + "\", \"checker\" : \"BA23456\" , \"checkerComments\" : \"This request can be approved\", \"requestAction\" : \"SUBMIT\" }]";
		return approvePayload.replaceFirst("idREplaceable", string);
	}

}