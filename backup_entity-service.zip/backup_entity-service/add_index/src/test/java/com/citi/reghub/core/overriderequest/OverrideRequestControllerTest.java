package com.citi.reghub.core.overriderequest;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.EventTypes;
import com.citi.reghub.core.entities.BaseControllerTest;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.util.Map;

import static com.citi.reghub.core.overriderequest.OverrideRequest.STATUS_REQUESTED;
import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class OverrideRequestControllerTest  extends BaseControllerTest {

    @Test
    public void shouldInsertOverrideRequest() throws Exception {
        String payload =
                "{" +
                    "\"stream\": \"M2TR\"," +
                    "\"flow\": \"CSHEQ\"," +
                    "\"regHubIds\": [\"ID-1\"]," +
                    "\"changes\": [" +
                            "{" +
                                "\"fieldName\": \"fieldOne\"," +
                                "\"oldValue\": \"old_value_1\"," +
                                "\"newValue\": \"new_value_2\"," +
                                "\"reasonCode\": \"EX_CODE_1\"" +
                            "}"+
                        "]," +
                    "\"maker\": \"SP18336\"," +
                    "\"makerComments\": \"testing comments\"" +
                "}";

        ResultActions result = mvc.perform(post("/overrideRequests")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",notNullValue()))
                .andExpect(jsonPath("$.message",equalTo("Successfully saved override request.")))
                .andDo(restDoc("insertOverrideRequest"))
        ;


        result = mvc.perform(get("/overrideRequests?stream=M2TR&flow=CSHEQ&status=" + STATUS_REQUESTED).accept(MediaType.APPLICATION_JSON));
        
        
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].makerTs", notNullValue()))
                .andExpect(jsonPath("$[0].checkerTs").doesNotExist())
                .andExpect(jsonPath("$[0].maker", equalTo("SP18336")))
                .andExpect(jsonPath("$[0].makerComments", equalTo("testing comments")))
                .andExpect(jsonPath("$[0].checker").doesNotExist())
                .andExpect(jsonPath("$[0].checkerComments").doesNotExist())
                .andExpect(jsonPath("$[0].regHubIds", equalTo(Arrays.asList("ID-1"))))
                .andExpect(jsonPath("$[0].changes[0].fieldName", equalTo("fieldOne")))
                .andExpect(jsonPath("$[0].changes[0].oldValue", equalTo("old_value_1")))
                .andExpect(jsonPath("$[0].changes[0].newValue", equalTo("new_value_2")))
                .andExpect(jsonPath("$[0].changes[0].reasonCode", equalTo("EX_CODE_1")))
        ;
        
      
		Thread.sleep(3000);
        Map<String, Audit> ct = KafkaUnitRule.getKafkaUnit().consumeFromTopic(auditTopicName);
        

        String key ="ID-1";
        
        assertTrue("M2TR".equals(ct.get(key).stream));
        assertTrue("CSHEQ".equals(ct.get(key).flow));
        assertTrue(ct.containsKey(key));
        assertTrue(EventTypes.MAKER_ENTITY_UPDATE.equals(ct.get(key).event));
        assertTrue("EX_CODE_1".equals(((Map) ((List) ct.get(key).info.get("changes")).get(0)).get("reasonCode")));

    }


    @Test
    public void shouldGetAllOverrideRequestForGivenStatus() throws Exception {
        OverrideRequest request = new OverrideRequestBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ")
                .change("fieldOne","old_value_1","new_value_2","EX_CODE_1")
                .maker("SP18336","my comments to override").build();
        overrideRequestRepository.save(request);


        ResultActions result = mvc.perform(get("/overrideRequests?stream=M2TR&flow=CSHEQ&status=" + STATUS_REQUESTED).accept(MediaType.APPLICATION_JSON));
        
        
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].makerTs", equalTo(request.createdTs.format(ISO_LOCAL_DATE_TIME))))
                .andExpect(jsonPath("$[0].checkerTs").doesNotExist())
                .andExpect(jsonPath("$[0].maker", equalTo("SP18336")))
                .andExpect(jsonPath("$[0].makerComments", equalTo("my comments to override")))
                .andExpect(jsonPath("$[0].checker").doesNotExist())
                .andExpect(jsonPath("$[0].checkerComments").doesNotExist())
                .andExpect(jsonPath("$[0].regHubIds", equalTo(Arrays.asList("ID-3"))))
                .andExpect(jsonPath("$[0].changes[0].fieldName", equalTo("fieldOne")))
                .andExpect(jsonPath("$[0].changes[0].oldValue", equalTo("old_value_1")))
                .andExpect(jsonPath("$[0].changes[0].newValue", equalTo("new_value_2")))
                .andExpect(jsonPath("$[0].changes[0].reasonCode", equalTo("EX_CODE_1")))
                .andDo(restDoc("getAllOverrideRequest"))
        ;

    }

}