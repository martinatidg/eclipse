package com.citi.reghub.core.common;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.*;

import org.junit.*;
import org.junit.runner.*;
import org.mockito.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.*;

import com.citi.cmot.armada.report.generator.Report;
import com.citi.reghub.core.dto.Header;
import com.citi.reghub.core.dto.TransactionSearchRequestDto;
import com.citi.reghub.core.entities.Entity;
import com.citi.reghub.core.entities.EntityBuilder;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
public class EntityExportServiceTest {
	
	@Mock
	private EntityExportService entityExportServiceMock;
	
	@Test
	public void shouldFormatDateTime() throws Exception {
    	LocalDateTime dateValue = LocalDateTime.of(2017, Month.AUGUST, 2, 13, 17, 30, 38);
    	String mockFormattedDateTime = "2017-08-02 13:17:30.000.000.038";
    	
    	when(entityExportServiceMock.formatDateTimeToNanoDateTime(dateValue)).thenCallRealMethod();
    	
    	String formattedDateTime = entityExportServiceMock.formatDateTimeToNanoDateTime(dateValue);
    	assertThat(formattedDateTime, is(equalTo(mockFormattedDateTime)));
    }
	
	@Test
	public void shouldCreateQueryCriteria() throws Exception {
		TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2post");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        
        when(entityExportServiceMock.buildTransactionQueryCriteria(transactionSearchRequestDto)).thenCallRealMethod();
        
        QueryCriteria queryCriteria = entityExportServiceMock.buildTransactionQueryCriteria(transactionSearchRequestDto);
        assertNotNull(queryCriteria);
	}
	
	@Test
	public void shouldCreateQueryCriteriaWithExecutionTs() throws Exception {
		TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2post");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> executionTs = new ArrayList<>();
        executionTs.add("2017-08-19T16:04:26.844");
        executionTs.add("2017-09-02T16:04:26.844");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        map.put("executionTs", executionTs);
        
        when(entityExportServiceMock.buildTransactionQueryCriteria(transactionSearchRequestDto)).thenCallRealMethod();
        
        QueryCriteria queryCriteria = entityExportServiceMock.buildTransactionQueryCriteria(transactionSearchRequestDto);
        assertNotNull(queryCriteria);
	}
	
	@Test
	public void shouldReturnHTTPDefaultHeaders() {
		String fileName = "RegHub_Transaction.xlsx";
		
		when(entityExportServiceMock.getFileHttpHeaders(fileName)).thenCallRealMethod();
		
		HttpHeaders responseHeaders = entityExportServiceMock.getFileHttpHeaders(fileName);
		assertNotNull(responseHeaders);
	}
	
	@Test
	public void shouldSetCSVHeaders() throws Exception {
		Header mockheader = new Header();
		mockheader.setField1("RPRT_STATUS");
		mockheader.setField2("REG_RPRT_REF");
		mockheader.setField3("SRC_TXN_REF");
		
		String Field1Header = "RPRT_STATUS";
		when(entityExportServiceMock.getCSVHeader()).thenReturn(mockheader);
		assertThat(mockheader.getField1(), is(equalTo(Field1Header)));
	}
	

	@Test
	public void shouldGenerateExcelReport() throws Exception {
		Report excelReport = null;
		Report mockExcelReport = new Report();
		String fileName = "RegHub_Transaction.xlsx";
		File file = new File(fileName);
		mockExcelReport.setReportFile(file);
		
		Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447")
				.sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452")
        		.sourceId("441623").streamFlow("m2tr", "csheq").build();
        List<Entity> entityList = new ArrayList<>();
        entityList.add(entity1);
        entityList.add(entity2);
        
        when(entityExportServiceMock.generateReportAsExcel(entityList, fileName)).
        thenReturn(mockExcelReport);
        
        excelReport = entityExportServiceMock.generateReportAsExcel(entityList, fileName);
        
        assertThat(excelReport.getReportFile(), is(equalTo(file)));
		
	}
	
	@Test
	public void shouldReturnCSVHeaders() throws Exception {
		String FieldHeader1="RPRT STATUS";
		String FieldHeader2="REG RPRT REF";
		String FieldHeader3="SRC TXN REF";
		String FieldHeader4="SOURCE UID";
		String FieldHeader5="SRC EVENT TYPE";
		String FieldHeader6="INVST FIRM IND";
		String FieldHeader7="TXN DATE TIME";
		String FieldHeader8="TRADING CAPACITY";
		String FieldHeader9="TRD QUANTITY";
		String FieldHeader10="TRD PRICE";
		String FieldHeader11="TRD QTY CCY";
		String FieldHeader12="TRD PRICE CCY";
		String FieldHeader13="ORIG SRC SYS";
		String FieldHeader14="FIRM ACT ID";
		String FieldHeader15="FIRM ACT TYPE";
		String FieldHeader16="CPTY ACT ID";
		String FieldHeader17="CPTY ID TYPE";
		String FieldHeader18="LGL ENTY CD";
		String FieldHeader19="SECURITY ID";
		String FieldHeader20="SECURITY ID TYPE";
		String FieldHeader21="TRADER ID";
		String FieldHeader22="EXEC DESCN MKR ID";
		String FieldHeader23="BUY SELL IND";
		String FieldHeader24="TRD SRC SYS";
		String FieldHeader25="TRD VENUE";
		String FieldHeader26="TRD VENUE REF";
		String FieldHeader27="BUYER BRNCH CNTRY";
		String FieldHeader28="SELLER BRNCH CNTRY";
		String FieldHeader29="BRNCH MMBR CNTRY";
		String FieldHeader30="NOTN CRCY ONE";
		String FieldHeader31="INSTRMNT ID";
		String FieldHeader32="INSTRMNT NAME";
		String FieldHeader33="NOTN CRCY TWO";
		String FieldHeader34="SFT IND";
		String FieldHeader35="EXEC ENTY ID";
		String FieldHeader36="SBMT ENTY ID";
		String FieldHeader37="BUYER ID";
		String FieldHeader38="BUYER DESCN MKR ID";
		String FieldHeader39="SELLER ID";
		String FieldHeader40="SELLER DESCN MKR ID";
		String FieldHeader41="DERV NOTN CHNG";
		String FieldHeader42="NET AMOUNT";
		String FieldHeader43="UPFRONT PAYMENT";
		String FieldHeader44="UPFRONT PAYMENT CRCY";
		String FieldHeader45="COMPLEX TRD REF";
		String FieldHeader46="PRICE MLTPLR";
		String FieldHeader47="UNDL INSTRMNT ID";
		String FieldHeader48="UNDL INDEX NAME";
		String FieldHeader49="UNDL INDEX TERM";
		String FieldHeader50="OPTION TYPE";
		String FieldHeader51="STRIKE PRICE";
		String FieldHeader52="STRIKE PRICE CCY";
		String FieldHeader53="OPTION STYLE";
		String FieldHeader54="MAT DATE";
		String FieldHeader55="EXP DATE";
		String FieldHeader56="DLVRY TYPE";
		String FieldHeader57="WAVR IND";
		String FieldHeader58="OTC POST TRD IND";
		String FieldHeader59="COMD DERV IND";
		String FieldHeader60="INVST DESCN ID";
		String FieldHeader61="INSTRMNT CFI";
		String FieldHeader62="LIFE CYCL STAT";
		String FieldHeader63="ACTION TYPE";
		String FieldHeader64="EVENT TYPE";
		String FieldHeader65="FIRM ACT GFCID";
		String FieldHeader66="CPTY ACT GFCID";
		String FieldHeader67="CLC FLT CAP RATE";
		String FieldHeader68="CLC FLT FLR RATE";
		String FieldHeader69="STLM TYPE";
		String FieldHeader70="ALGO ID";
		String FieldHeader71="IS BSKT CONSTI";
		String FieldHeader72="SMCP";
		String FieldHeader73="NOTN ONE AMNT";
		String FieldHeader74="PRC TYPE";
		String FieldHeader75="STRIKE PRC TYPE";
		String FieldHeader76="INTNL CLNT IDNT";
		String FieldHeader77="SEC TYPE ONE";
		String FieldHeader78="SEC TYPE TWO";
		String FieldHeader79="SEC TYPE THREE";
		String FieldHeader80="SRC EXEC STATUS";
		String FieldHeader81="RULE GROUP";
		String FieldHeader82="SHORT SELL IDENT";
		String FieldHeader83="IS CORR";
		String FieldHeader84="UV INSTRMNT CLASS";
		String FieldHeader85="UV INDEX CLASS";
		String FieldHeader86="PRIOR SRC TRD REF";
		String FieldHeader87="SWAP RPRT PURPOSE";
		String FieldHeader88="PAY REC IND";
		String FieldHeader89="NOTN TWO AMNT";

		when(entityExportServiceMock.getCSVHeader()).thenCallRealMethod();
		Header csvHeader = entityExportServiceMock.getCSVHeader();
		assertThat(csvHeader.getField1(), is(equalTo(FieldHeader1)));
		assertThat(csvHeader.getField2(), is(equalTo(FieldHeader2)));
		assertThat(csvHeader.getField3(), is(equalTo(FieldHeader3)));
		assertThat(csvHeader.getField4(), is(equalTo(FieldHeader4)));
		assertThat(csvHeader.getField5(), is(equalTo(FieldHeader5)));
		assertThat(csvHeader.getField6(), is(equalTo(FieldHeader6)));
		assertThat(csvHeader.getField7(), is(equalTo(FieldHeader7)));
		assertThat(csvHeader.getField8(), is(equalTo(FieldHeader8)));
		assertThat(csvHeader.getField9(), is(equalTo(FieldHeader9)));
		assertThat(csvHeader.getField10(), is(equalTo(FieldHeader10)));
		assertThat(csvHeader.getField11(), is(equalTo(FieldHeader11)));
		assertThat(csvHeader.getField12(), is(equalTo(FieldHeader12)));
		assertThat(csvHeader.getField13(), is(equalTo(FieldHeader13)));
		assertThat(csvHeader.getField14(), is(equalTo(FieldHeader14)));
		assertThat(csvHeader.getField15(), is(equalTo(FieldHeader15)));
		assertThat(csvHeader.getField16(), is(equalTo(FieldHeader16)));
		assertThat(csvHeader.getField17(), is(equalTo(FieldHeader17)));
		assertThat(csvHeader.getField18(), is(equalTo(FieldHeader18)));
		assertThat(csvHeader.getField19(), is(equalTo(FieldHeader19)));
		assertThat(csvHeader.getField20(), is(equalTo(FieldHeader20)));
		assertThat(csvHeader.getField21(), is(equalTo(FieldHeader21)));
		assertThat(csvHeader.getField22(), is(equalTo(FieldHeader22)));
		assertThat(csvHeader.getField23(), is(equalTo(FieldHeader23)));
		assertThat(csvHeader.getField24(), is(equalTo(FieldHeader24)));
		assertThat(csvHeader.getField25(), is(equalTo(FieldHeader25)));
		assertThat(csvHeader.getField26(), is(equalTo(FieldHeader26)));
		assertThat(csvHeader.getField27(), is(equalTo(FieldHeader27)));
		assertThat(csvHeader.getField28(), is(equalTo(FieldHeader28)));
		assertThat(csvHeader.getField29(), is(equalTo(FieldHeader29)));
		assertThat(csvHeader.getField30(), is(equalTo(FieldHeader30)));
		assertThat(csvHeader.getField31(), is(equalTo(FieldHeader31)));
		assertThat(csvHeader.getField32(), is(equalTo(FieldHeader32)));
		assertThat(csvHeader.getField33(), is(equalTo(FieldHeader33)));
		assertThat(csvHeader.getField34(), is(equalTo(FieldHeader34)));
		assertThat(csvHeader.getField35(), is(equalTo(FieldHeader35)));
		assertThat(csvHeader.getField36(), is(equalTo(FieldHeader36)));
		assertThat(csvHeader.getField37(), is(equalTo(FieldHeader37)));
		assertThat(csvHeader.getField38(), is(equalTo(FieldHeader38)));
		assertThat(csvHeader.getField39(), is(equalTo(FieldHeader39)));
		assertThat(csvHeader.getField40(), is(equalTo(FieldHeader40)));
		assertThat(csvHeader.getField41(), is(equalTo(FieldHeader41)));
		assertThat(csvHeader.getField42(), is(equalTo(FieldHeader42)));
		assertThat(csvHeader.getField43(), is(equalTo(FieldHeader43)));
		assertThat(csvHeader.getField44(), is(equalTo(FieldHeader44)));
		assertThat(csvHeader.getField45(), is(equalTo(FieldHeader45)));
		assertThat(csvHeader.getField46(), is(equalTo(FieldHeader46)));
		assertThat(csvHeader.getField47(), is(equalTo(FieldHeader47)));
		assertThat(csvHeader.getField48(), is(equalTo(FieldHeader48)));
		assertThat(csvHeader.getField49(), is(equalTo(FieldHeader49)));
		assertThat(csvHeader.getField50(), is(equalTo(FieldHeader50)));
		assertThat(csvHeader.getField51(), is(equalTo(FieldHeader51)));
		assertThat(csvHeader.getField52(), is(equalTo(FieldHeader52)));
		assertThat(csvHeader.getField53(), is(equalTo(FieldHeader53)));
		assertThat(csvHeader.getField54(), is(equalTo(FieldHeader54)));
		assertThat(csvHeader.getField55(), is(equalTo(FieldHeader55)));
		assertThat(csvHeader.getField56(), is(equalTo(FieldHeader56)));
		assertThat(csvHeader.getField57(), is(equalTo(FieldHeader57)));
		assertThat(csvHeader.getField58(), is(equalTo(FieldHeader58)));
		assertThat(csvHeader.getField59(), is(equalTo(FieldHeader59)));
		assertThat(csvHeader.getField60(), is(equalTo(FieldHeader60)));
		assertThat(csvHeader.getField61(), is(equalTo(FieldHeader61)));
		assertThat(csvHeader.getField62(), is(equalTo(FieldHeader62)));
		assertThat(csvHeader.getField63(), is(equalTo(FieldHeader63)));
		assertThat(csvHeader.getField64(), is(equalTo(FieldHeader64)));
		assertThat(csvHeader.getField65(), is(equalTo(FieldHeader65)));
		assertThat(csvHeader.getField66(), is(equalTo(FieldHeader66)));
		assertThat(csvHeader.getField67(), is(equalTo(FieldHeader67)));
		assertThat(csvHeader.getField68(), is(equalTo(FieldHeader68)));
		assertThat(csvHeader.getField69(), is(equalTo(FieldHeader69)));
		assertThat(csvHeader.getField70(), is(equalTo(FieldHeader70)));
		assertThat(csvHeader.getField71(), is(equalTo(FieldHeader71)));
		assertThat(csvHeader.getField72(), is(equalTo(FieldHeader72)));
		assertThat(csvHeader.getField73(), is(equalTo(FieldHeader73)));
		assertThat(csvHeader.getField74(), is(equalTo(FieldHeader74)));
		assertThat(csvHeader.getField75(), is(equalTo(FieldHeader75)));
		assertThat(csvHeader.getField76(), is(equalTo(FieldHeader76)));
		assertThat(csvHeader.getField77(), is(equalTo(FieldHeader77)));
		assertThat(csvHeader.getField78(), is(equalTo(FieldHeader78)));
		assertThat(csvHeader.getField79(), is(equalTo(FieldHeader79)));
		assertThat(csvHeader.getField80(), is(equalTo(FieldHeader80)));
		assertThat(csvHeader.getField81(), is(equalTo(FieldHeader81)));
		assertThat(csvHeader.getField82(), is(equalTo(FieldHeader82)));
		assertThat(csvHeader.getField83(), is(equalTo(FieldHeader83)));
		assertThat(csvHeader.getField84(), is(equalTo(FieldHeader84)));
		assertThat(csvHeader.getField85(), is(equalTo(FieldHeader85)));
		assertThat(csvHeader.getField86(), is(equalTo(FieldHeader86)));
		assertThat(csvHeader.getField87(), is(equalTo(FieldHeader87)));
		assertThat(csvHeader.getField88(), is(equalTo(FieldHeader88)));
		assertThat(csvHeader.getField89(), is(equalTo(FieldHeader89)));
	}
}
