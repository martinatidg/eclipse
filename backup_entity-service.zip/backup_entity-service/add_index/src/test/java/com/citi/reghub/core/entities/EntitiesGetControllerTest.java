package com.citi.reghub.core.entities;

import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import com.citi.reghub.core.metadata.client.Metadata;
import com.citi.reghub.core.metadata.client.MetadataClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;


public class EntitiesGetControllerTest extends BaseControllerTest {

	@MockBean
	private MetadataClient metadataClient;
	
	
	List<ExceptionCode> exceptions = new ArrayList<ExceptionCode>();

    @Test
    public void shouldReturnEntityForGivenId() throws Exception {
        Entity entity = new EntityBuilder().regHubId("REG_HUB_ID-1").streamFlow("M2TR", "CSHEQ").info("keyOne","value1").build();
        repository.save(entity);
        repository.save(new EntityBuilder().regHubId("REG_HUB_ID-2").streamFlow("M2TR", "CSHFI").build());

        ResultActions result = mvc.perform(get("/entities/REG_HUB_ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("REG_HUB_ID-1")))
                .andExpect(jsonPath("$.rdsEligible", equalTo(true)))
                .andExpect(jsonPath("$.info.keyOne", equalTo("value1")))
                .andDo(restDoc("getEntityById"))
        ;
    }

    //@Test #test not needed as objectnotfoundexception has been handled
    public void shouldReturn404ForInvalidId() throws Exception {
        ResultActions result = mvc.perform(get("/entities/REGHUBID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isNotFound())
        .andDo(restDoc("getEntityById404"));
    }
    
    @Test
    public void shouldReturnRelatedEntitiesExceptThePassedReghubId() throws Exception {
    	repository.save(new EntityBuilder().regHubId("REG_HUB_ID-1").streamFlow("M2TR", "CSHEQ").sourceId("SOURCEID").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("REG_HUB_ID-2").streamFlow("M2TR", "CSHEQ").sourceId("SOURCEID").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("REG_HUB_ID-3").streamFlow("M2TR", "CSHEQ").sourceId("SOURCEID").info("keyOne","value1").build());
        
        ResultActions result = mvc.perform(get("/entities/relatedEntities/REG_HUB_ID-1?stream=M2TR&flow=CSHEQ&sourceId=SOURCEID").accept(MediaType.APPLICATION_JSON));

        
        result.andExpect(status().isOk())
        	//.andExpect(jsonPath("$", hasSize(2)))
        	.andExpect(jsonPath("$[0].regHubId", equalTo("REG_HUB_ID-2")))
        	.andExpect(jsonPath("$[0].sourceId", equalTo("SOURCEID")))
        	.andExpect(jsonPath("$[1].regHubId", equalTo("REG_HUB_ID-3")))
        	.andExpect(jsonPath("$[1].sourceId", equalTo("SOURCEID")))
        	.andDo(restDoc("getRelatedEntitiesExceptThePassedReghubId"))
        	;
    }

    @Test
    public void shouldReturnEntitiesWithExceptionStatus() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHFI").exception("EX_CODE2").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ").exception("EX_CODE3").info("keyOne","value1").build());

        ResultActions result = mvc.perform(get("/entities?stream=M2TR&flow=CSHEQ&status=EXCEPTION").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-3")))
                .andExpect(jsonPath("$[0].info").doesNotExist())
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$[1].info").doesNotExist())
                .andDo(restDoc("getEntitiesWithExceptionStatus"))
        ;
    }

    @Test
    public void shouldReturnEntitiesWithMultipleStatus() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").reportable().info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHFI").exception("EX_CODE2").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ").reported().info("keyOne","value1").build());

        ResultActions result = mvc.perform(get("/entities?stream=M2TR&flow=CSHEQ&statuses=REPORTABLE&statuses=REPORTED").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-3")))
                .andExpect(jsonPath("$[0].info").doesNotExist())
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$[1].info").doesNotExist())
                .andDo(restDoc("getEntitiesWithMultipleStatus"))
        ;
    }

    @Test
    public void shouldReturnEntitiesWithExceptionStatusAndFullDetails() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHFI").exception("EX_CODE2").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ").exception("EX_CODE3").info("keyOne","value1").build());

        ResultActions result = mvc.perform(get("/entities?stream=M2TR&flow=CSHEQ&status=EXCEPTION&summaryView=false").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-3")))
                .andExpect(jsonPath("$[0].info.keyOne", equalTo("value1")))
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$[1].info.keyOne", equalTo("value1")))
                .andDo(restDoc("getEntitiesWithExceptionStatusAndFullDetails"))
        ;
    }

    @Test
    public void shouldReturnZeroEntitiesForExceptionStatus() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHFI").exception("EX_CODE2").build());

        ResultActions result = mvc.perform(get("/entities?stream=M2TR&flow=CSHEQ&status=EXCEPTION").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)))
                .andDo(restDoc("getZeroEntitiesWithExceptionStatus"))
        ;
    }

    @Test
    public void shouldReturnEntitiesForExceptionStatusReceivedBetweenGivenTime() throws Exception {
        LocalDateTime time10AM = LocalDateTime.of(2017, 4, 28, 10, 0);
        repository.save(new EntityBuilder(clock(time10AM.minusMinutes(2))).regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("EX_CODE2").build());
        repository.save(new EntityBuilder(clock(time10AM.plusMinutes(2))).regHubId("ID-2").streamFlow("M2TR", "CSHEQ").exception("EX_CODE2").build());
        repository.save(new EntityBuilder(clock(time10AM.plusMinutes(5))).regHubId("ID-3").streamFlow("M2TR", "CSHEQ").exception("EX_CODE2").build());
        repository.save(new EntityBuilder(clock(time10AM.plusMinutes(5))).regHubId("ID-4").streamFlow("M2TR", "CSHEQ").build());
        repository.save(new EntityBuilder(clock(time10AM.plusHours(2))).regHubId("ID-5").streamFlow("M2TR", "CSHEQ").exception("EX_CODE2").build());

        String receivedSince10AM = time10AM.format(ISO_LOCAL_DATE_TIME);
        String receivedUntil11AM = time10AM.plusHours(1).format(ISO_LOCAL_DATE_TIME);
        ResultActions result = mvc.perform(
                get("/entities?stream=M2TR&flow=CSHEQ&status=EXCEPTION&receivedSince=" + receivedSince10AM + "&receivedUntil=" + receivedUntil11AM)
                        .accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-3")))
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-2")))
                .andDo(restDoc("getEntitiesWithExceptionStatusReceivedBetweenGivenTime"))
        ;
    }

    @Test
    public void shouldThrow500ErrorWhenWrongTimeFormatIsGiven() throws Exception {
        String receivedSince10AM = "wrong-format";
        String receivedUntil11AM = "totally-wrong-fromat";
        ResultActions result = mvc.perform(
                get("/entities?stream=M2TR&flow=CSHEQ&status=EXCEPTION&receivedSince=" + receivedSince10AM + "&receivedUntil=" + receivedUntil11AM)
                        .accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().is5xxServerError())
            .andDo(restDoc("get500ErrorWhenWrongTimeFormatIsGiven"));
    }
    
    @Test
    public void shouldReturnSourceIdsForGivenRegHubIds() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").sourceUId("UID-1").build());
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHEQ").sourceUId("UID-2").build());
        repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ").sourceUId("UID-3").build());

        ResultActions result = mvc.perform(post("/entities/getSourceUIds")
                .content("{ \"regHubIds\": [\"ID-1\",\"ID-2\"], \"stream\":\"M2TR\", \"flow\":\"CSHEQ\" } ")
                        .accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$[0].sourceUId", equalTo("UID-1")))
                .andExpect(jsonPath("$[0].stream").doesNotExist())
                .andExpect(jsonPath("$[0].flow").doesNotExist())
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-2")))
                .andExpect(jsonPath("$[1].sourceUId", equalTo("UID-2")))
                .andDo(restDoc("getEntitiesWithExceptionStatusReceivedBetweenGivenTime"))
                .andDo(restDoc("getEntityForGivenRegHubIdsList"))
        ;

    }
    
    
    
    @Test
    public void shouldReturnTransactionSummaryView() throws Exception {
  
    	//	Basic check added for passing test coverage. TODO- Add expected results
    	
         ResultActions result = mvc.perform(get("/entities/transactionSummary").accept(MediaType.APPLICATION_JSON));
         result.andExpect(status().isOk());
    }
    
    
    @Test
    public void shouldReturnExceptionSummaryView() throws Exception {
  
    		setupDataForExceptionSummary();
    	
         ResultActions result = mvc.perform(get("/entities/getExceptionSummaryView?stream=m2tr&flow=csheq").accept(MediaType.APPLICATION_JSON));
         
         result.andExpect(status().isOk())
         .andExpect(jsonPath("$", hasSize(4)))
         .andExpect(jsonPath("$[0].reasonCode", equalTo("EX_CODE2")))
         .andExpect(jsonPath("$[0].sourceSystem", equalTo("source2")))
         .andExpect(jsonPath("$[0].reasonCodeDesc", equalTo("Exception Code 2")))
         .andExpect(jsonPath("$[0].count", equalTo(1)))         
         .andExpect(jsonPath("$[3].reasonCode", equalTo("EX_CODE1")))
         .andExpect(jsonPath("$[3].sourceSystem", equalTo("source3")))
         .andExpect(jsonPath("$[3].reasonCodeDesc", equalTo("Exception Code 1")))
         .andExpect(jsonPath("$[3].count", equalTo(1)))         
         .andExpect(jsonPath("$[1].reasonCode", equalTo("EX_CODE2")))
         .andExpect(jsonPath("$[1].sourceSystem", equalTo("source4")))
         .andExpect(jsonPath("$[1].reasonCodeDesc", equalTo("Exception Code 2")))
         .andExpect(jsonPath("$[1].count", equalTo(1))) 
         .andExpect(jsonPath("$[2].reasonCode", equalTo("EX_CODE1")))
         .andExpect(jsonPath("$[2].sourceSystem", equalTo("source1")))
         .andExpect(jsonPath("$[2].reasonCodeDesc", equalTo("Exception Code 1")))
         .andExpect(jsonPath("$[2].count", equalTo(2))) 
         ;


    }
    
    @Test    
    public void shouldReturn500ForExceedingRecordLimit() throws Exception {
    	
    	setupDataForExceptionSummary();

         ResultActions result = mvc.perform(get("/entities/getExceptionSummaryView?stream=m2tr&flow=csheq&recordlimit=1").accept(MediaType.APPLICATION_JSON));
         result.andExpect(status().is5xxServerError());
         
    }
    
    private void setupDataForExceptionSummary()
    {
    	
    	exceptions.add
    	(new ExceptionCodeBuilder().exceptionCode("EX_CODE1").longDescription("Exception Code 1").overrideFields("field1","field2").build());

    	exceptions.add
    	(new ExceptionCodeBuilder().exceptionCode("EX_CODE2").longDescription("Exception Code 2").overrideFields("field3","field4").build());
    	
    	Map<String, Object> meta = new HashMap<String, Object>();
    	meta.put("value", exceptions);    	
    	Metadata metadata = new Metadata(meta);    	
    	
    	
    	Mockito.when(metadataClient.get(Mockito.anyString())).thenReturn(metadata.value);
    	Mockito.when(metadataClient.getMetadataClientConfig()).thenReturn(new MetadataClientConfig());		
		
    	 repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("m2tr", "csheq").sourceSystem("source1").exception("EX_CODE1").info("field1","value1").info("field2", "value2").build());
         repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("m2tr", "csheq").sourceSystem("source2").exception("EX_CODE2").info("field3","value3").info("field4", "value4").build());
         repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("m2tr", "csheq").sourceSystem("source3").exception("EX_CODE1").info("field1","value1").build());
         repository.save(new EntityBuilder().regHubId("ID-4").streamFlow("m2tr", "csheq").sourceSystem("source4").exception("EX_CODE2").info("field3","value3").build());
         repository.save(new EntityBuilder().regHubId("ID-5").streamFlow("m2tr", "csheq").sourceSystem("source1").exception("EX_CODE1").info("field1","value1").info("field2", "value2").build());

    	
    }

}