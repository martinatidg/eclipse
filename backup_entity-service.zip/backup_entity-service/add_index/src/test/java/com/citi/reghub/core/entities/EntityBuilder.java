package com.citi.reghub.core.entities;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class EntityBuilder {

    public EntityBuilder() {
        this(Clock.systemUTC());
    }

    public EntityBuilder(Clock clock) {
        this.clock = clock;
    }

    private Clock clock;

    private String stream = "M2TR";
    private String flow = "CSHEQ";

    private String regHubId = "" + stream + flow + new Random().nextLong();
    private String status = "REPORTABLE";
    private String[] reasonCodes = {};

    private String sourceUId;
    private String sourceId;
    private String sourceSystem;
    private Map<String,Object> info = new HashMap<>();


    public EntityBuilder regHubId(String regHubId) {
        this.regHubId = regHubId;
        return this;
    }

    public EntityBuilder streamFlow(String stream, String flow) {
        this.stream = stream;
        this.flow = flow;
        return this;
    }

    public EntityBuilder sourceUId(String sourceUId) {
        this.sourceUId = sourceUId;
        return this;
    }
    
    public EntityBuilder sourceId(String sourceId) {
        this.sourceId = sourceId;
        return this;
    }
    
    public EntityBuilder sourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
        return this;
    }

    public EntityBuilder reportable(String... reasonCodes) {
        this.reasonCodes = reasonCodes;
        status = "REPORTABLE";
        return this;
    }

    public EntityBuilder reported(String... reasonCodes) {
        this.reasonCodes = reasonCodes;
        status = "REPORTED";
        return this;
    }

    public EntityBuilder nonReportable(String... reasonCodes) {
        this.reasonCodes = reasonCodes;
        status = "NON_REPORTABLE";
        return this;
    }

    public EntityBuilder exception(String... reasonCodes) {
        this.reasonCodes = reasonCodes;
        this.status = "EXCEPTION";
        return this;
    }

    public Entity build() {
        Entity entity = new Entity();
        entity.id = regHubId;
        entity.stream = this.stream;
        entity.flow = this.flow;
        entity.status = this.status;
        entity.reasonCodes = Arrays.asList(reasonCodes);
        entity.sourceUId = this.sourceUId;
        entity.sourceId = this.sourceId;
        entity.receivedTs = LocalDateTime.now(clock);
        entity.publishedTs = entity.receivedTs.minusSeconds(5);
        entity.executionTs = entity.receivedTs.minusSeconds(10);
        entity.sourceSystem=this.sourceSystem;
        entity.info = info;
        entity.setRdsEligible(true);
        entity.setLastUpdatedTs(clock);
        return entity;
    }

    public EntityOverride buildOverride() {
        EntityOverride override = new EntityOverride();
        override.id = regHubId;
        override.stream = this.stream;
        override.flow = this.flow;
        override.status = this.status;
        override.info = info;
        override.setLastUpdatedTs(clock);
        return override;
    }

    public EntityBuilder info(String key, Object value) {
        info.put(key,value);
        return this;
    }
}
