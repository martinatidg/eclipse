package com.citi.reghub.core.entities;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import com.citi.reghub.core.constants.RestStatus;

@Ignore
public class EntitiesOverrideControllerTest extends BaseControllerTest {
    
	@Test
    public void shouldReturnEntityForGivenId() throws Exception {
        EntityOverride entity = new EntityBuilder().regHubId("REG_HUB_ID-1").streamFlow("M2TR", "CSHEQ").buildOverride();
        overrideRepository.save(entity);
        overrideRepository.save(new EntityBuilder().regHubId("REG_HUB_ID-2").streamFlow("M2TR", "CSHFI").buildOverride());

        ResultActions result = mvc.perform(get("/entities/override/REG_HUB_ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("REG_HUB_ID-1")))
                .andDo(restDoc("getOverrideEntityById"))
        ;
    }


    @Test
    public void shouldReturn404ForInvalidId() throws Exception {
        ResultActions result = mvc.perform(get("/entities/REGHUBID-1/override").accept(MediaType.APPLICATION_JSON));
        
        result.andExpect(status().isNotFound())
        	.andDo(restDoc("getOverrideEntityById404"));
    }


    @Test
    public void shouldPatchEntityWithStatusAsTopLevelField() throws Exception {
        overrideRepository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").reportable().buildOverride());
        String payload = "{ \"status\" : \"NON_REPORTABLE\", \"flow\" : \"CSHFI\" } ";


        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/override/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity override.")))
                .andDo(restDoc("patchOverrideEntityTopLevelField"))
        ;

        result = mvc.perform(get("/entities/override/ID-1?stream=M2TR&flow=CSHFI").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHFI")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
        ;
    }

    @Test
    public void shouldPatchEntityWithInfoLevelField() throws Exception {
        overrideRepository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").info("key1","VALUE1").info("key3", "VALUE3").buildOverride());
        String payload = "{ \"status\" : \"NON_REPORTABLE\", \"info\" : { \"key2\": \"VALUE2\", \"key3\": \"VALUE5\" } } ";


        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/override/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity override.")))
                .andDo(restDoc("patchOverrideEntityInfoLevelField"))
        ;

        result = mvc.perform(get("/entities/override/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHEQ")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.info.key1", equalTo("VALUE1")))
                .andExpect(jsonPath("$.info.key2", equalTo("VALUE2")))
                .andExpect(jsonPath("$.info.key3", equalTo("VALUE5")))
        ;
    }

    @Test
    public void shouldInsertEntityIfDoesNotExists() throws Exception {
        String payload = "{ \"id\": \"ID-1\",\"stream\": \"M2TR\",\"flow\": \"CSHEQ\", \"status\" : \"NON_REPORTABLE\", \"info\" : { \"key2\": \"VALUE2\", \"key3\": \"VALUE5\" } } ";

        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/override/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity override.")))
                .andDo(restDoc("insertOverrideEntityIfDoesNotExists"))
        ;

        result = mvc.perform(get("/entities/override/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHEQ")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.info.key2", equalTo("VALUE2")))
                .andExpect(jsonPath("$.info.key3", equalTo("VALUE5")))
        ;
    }


    @Test
    public void shouldPatchEntityWithClearingValueForTopLevelField() throws Exception {
        overrideRepository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("CODE_1").buildOverride());
        String payload = "{ \"status\" : \"NON_REPORTABLE\", \"flow\" : \"CSHFI\", \"reasonCodes\" : \"null\" } ";

        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/override/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity override.")))
                .andDo(restDoc("clearOverrideEntityFields"))
        ;

        result = mvc.perform(get("/entities/override/ID-1?stream=M2TR&flow=CSHFI").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHFI")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.reasonCodes").doesNotExist())
        ;
    }
}