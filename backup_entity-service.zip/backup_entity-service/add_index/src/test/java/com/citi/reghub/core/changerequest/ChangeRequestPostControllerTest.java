package com.citi.reghub.core.changerequest;

import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.ChangeRequestType;
import com.citi.reghub.core.constants.RequestAction;
import com.citi.reghub.core.entities.BaseControllerTest;

public class ChangeRequestPostControllerTest extends BaseControllerTest {

	@Value("${audit.topic.name}")
	private String auditTopicName;

	@Test
	public void shouldGetAllChangeRequestWithPostMethodCall() throws Exception {
		ChangeRequest request = new ChangeRequestBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHFX")
				.regReportingRef("cshfxnull2017080103550600LDN822356352")
				.typeAndRequest(ChangeRequestType.CHANGE_REQUEST_TYPE_EXCEPTION, RequestAction.REQUEST_ACTION_REPLAY).status("OPEN")
				.sourceId("03550600LDN822356352").reasonCode("m2tr_all_trade_price_exception")
				.exceptionId("Exception134").change("fieldOne", "old_value_1", "new_value_2")
				.maker("SP18336", "my comments to override").build();
		changeRequestRepository.save(request);

		ResultActions result = mvc.perform(
				post("/changerequests").content(ChangeRequestPayloadBuilder.searchPayloadwithStreamFlow("M2TR", "CSHFX"))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.requestViewList", hasSize(1)))
				.andExpect(jsonPath("$.totalRecords", equalTo(1)))
				.andExpect(jsonPath("$.requestViewList[0].regHubId", equalTo("ID-3")))
				.andExpect(jsonPath("$.requestViewList[0].makerTs",
						equalTo(request.createdTs.format(ISO_LOCAL_DATE_TIME))))
				.andExpect(jsonPath("$.requestViewList[0].checkerTs").doesNotExist())
				.andExpect(jsonPath("$.requestViewList[0].maker", equalTo("SP18336")))
				.andExpect(jsonPath("$.requestViewList[0].makerComments", equalTo("my comments to override")))
				.andExpect(jsonPath("$.requestViewList[0].checker").doesNotExist())
				.andExpect(jsonPath("$.requestViewList[0].checkerComments").doesNotExist())
				.andExpect(jsonPath("$.requestViewList[0].regReportingRef",
						equalTo("cshfxnull2017080103550600LDN822356352")))
				.andExpect(jsonPath("$.requestViewList[0].type", equalTo("EXCEPTION")))
				.andExpect(jsonPath("$.requestViewList[0].requestAction", equalTo("REPLAY")))
				.andExpect(jsonPath("$.requestViewList[0].status", equalTo("OPEN")))
				.andExpect(jsonPath("$.requestViewList[0].reasonCode", equalTo("m2tr_all_trade_price_exception")))
				.andExpect(jsonPath("$.requestViewList[0].exceptionId", equalTo("Exception134")))
				.andExpect(jsonPath("$.requestViewList[0].attributes[0].fieldName", equalTo("fieldOne")))
				.andExpect(jsonPath("$.requestViewList[0].attributes[0].oldValue", equalTo("old_value_1")))
				.andExpect(jsonPath("$.requestViewList[0].attributes[0].newValue", equalTo("new_value_2")))
				.andDo(restDoc("getAllChangeRequest"));

	}

	@Test
	public void shouldGetTotalChangeRequestRecords() throws Exception {
		ChangeRequest request = new ChangeRequestBuilder().regHubId("ID-4").streamFlow("M2TR", "CSHFX")
				.regReportingRef("cshfxnull2017080103550600LDN822356353")
				.typeAndRequest(ChangeRequestType.CHANGE_REQUEST_TYPE_EXCEPTION, RequestAction.REQUEST_ACTION_REPLAY).status("OPEN")
				.sourceId("03550600LDN822356352").reasonCode("m2tr_all_trade_price_exception")
				.exceptionId("Exception134").change("fieldOne", "old_value_1", "new_value_2")
				.maker("SP18336", "my comments to override").build();
		changeRequestRepository.save(request);

		ResultActions result = mvc.perform(post("/changerequest/count")
				.content(ChangeRequestPayloadBuilder.searchPayloadwithStreamFlow("M2TR", "CSHFX"))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.totalRecords", equalTo(1)))
				.andDo(restDoc("getAllChangeRequestCount"));
	}
	
	@Test
	public void shouldInsertChangeRequestWithSubmit() throws Exception {
		String payload = ChangeRequestPayloadBuilder.payloadWithRequestActionAndStreamFlow(RequestAction.REQUEST_ACTION_SUBMIT,
				"stream1", "flow1", "ID-1");

		ResultActions result = mvc.perform(post("/changerequest").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
				//.andExpect(jsonPath("$.message", equalTo("Successfully Created the changeRequest.")))
				.andDo(restDoc("SubmitRequestFLow"));

		result = mvc.perform(post("/changerequests")
				.content(ChangeRequestPayloadBuilder.searchPayloadwithStreamFlow("stream1", "flow1"))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(jsonPath("$.requestViewList[0].requestAction", equalTo("SUBMIT")))
				.andExpect(jsonPath("$.requestViewList[0].regHubId", equalTo("ID-1")));
		checkResultForInsertedChangeRequest(result);

		Thread.sleep(3000);
		Map<String, Audit> ct = KafkaUnitRule.getKafkaUnit().consumeFromTopic(auditTopicName);

		String key = "ID-1";

		assertTrue(ct.containsKey(key));
		assertTrue("stream1".equals(ct.get(key).stream));
		assertTrue("flow1".equals(ct.get(key).flow));
		assertTrue("UserAction-SUBMIT".equals(ct.get(key).event));
	}

	@Test
	public void shouldInsertChangeRequestWithIgnore() throws Exception {
		String payload = ChangeRequestPayloadBuilder.payloadWithRequestActionAndStreamFlow(RequestAction.REQUEST_ACTION_IGNORE,
				"stream2", "flow2", "test123");

		ResultActions result = mvc.perform(post("/changerequest").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
				//.andExpect(jsonPath("$.message", equalTo("Successfully Created the changeRequest.")))
				.andDo(restDoc("IgonreRequestFlow"));

		result = mvc.perform(post("/changerequests")
				.content(ChangeRequestPayloadBuilder.searchPayloadwithStreamFlow("stream2", "flow2"))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(jsonPath("$.requestViewList[0].requestAction", equalTo("IGNORE")))
				.andExpect(jsonPath("$.requestViewList[0].regHubId", equalTo("test123")));
		checkResultForInsertedChangeRequest(result);

		Thread.sleep(3000);
		Map<String, Audit> ct = KafkaUnitRule.getKafkaUnit().consumeFromTopic(auditTopicName);

		String key = "test123";

		assertTrue(ct.containsKey(key));
		assertTrue("stream2".equals(ct.get(key).stream));
		assertTrue("flow2".equals(ct.get(key).flow));
		assertTrue("UserAction-IGNORE".equals(ct.get(key).event));

	}
	
	@Test
	public void shouldAcknowledgeRequest() throws Exception {
		String payload = ChangeRequestPayloadBuilder.payloadWithRequestActionAndStreamFlow(RequestAction.REQUEST_ACTION_ACKNOWLEDGE,
				"stream6", "flow6");
		
		ResultActions result = mvc.perform(post("/acknowledge").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
				.andExpect(jsonPath("$.message", equalTo("Successfully acknowledged the request")))
				.andDo(restDoc("AcknowledgeRequestFlow"));
		
	}

	// @Test
	public void shouldReplayUnmodifiedChangeRequest() throws Exception {
		String payload = ChangeRequestPayloadBuilder.payloadWithRequestActionAndStreamFlow(RequestAction.REQUEST_ACTION_REPLAY,
				"stream3", "flow3");

		ResultActions result = mvc.perform(post("/changerequest").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
				.andExpect(jsonPath("$.message", equalTo("Successfully Created the changeRequest.")))
				.andDo(restDoc("ReplayRequestFlow"));

	}

	@Test
	public void shouldUpdateRejectedChangeRequestInDB() throws Exception {

		ChangeRequest request = new ChangeRequestBuilder().regHubId("ID-4").streamFlow("stream4", "flow4")
				.regReportingRef("cshfxnull2017080103550600LDN822356352")
				.typeAndRequest(ChangeRequestType.CHANGE_REQUEST_TYPE_EXCEPTION, RequestAction.REQUEST_ACTION_SUBMIT).status("OPEN")
				.sourceId("03550600LDN822356352").reasonCode("m2tr_all_trade_price_exception")
				.exceptionId("Exception134").change("fieldOne", "old_value_1", "new_value_2")
				.maker("SP18336", "my comments to override").build();
		request.id = new ObjectId("59c248c8c2686b3638e5445f");
		changeRequestRepository.save(request);

		String payload = ChangeRequestPayloadBuilder.rejectPayloadWithOnlyId("59c248c8c2686b3638e5445f");

		ResultActions result = mvc.perform(post("/changerequest/reject").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
				.andDo(restDoc("ReplayRequestFlow"));

		Optional<ChangeRequest> requestInDB = changeRequestRepository.findById(request.id);
		requestInDB.ifPresent(req -> {
			assertEquals(req.checker, "AB12345");
			assertEquals(req.checkerComments, "This is not Valid");
			assertEquals(req.status, "REJECTED");
		});
	}

	@Test
	public void shouldUpdateApprovedChangeRequestInDB() throws Exception {

		ChangeRequest request = new ChangeRequestBuilder().regHubId("ID-5").streamFlow("m2tr", "csheq")
				.regReportingRef("1234").typeAndRequest(ChangeRequestType.CHANGE_REQUEST_TYPE_EXCEPTION, RequestAction.REQUEST_ACTION_SUBMIT)
				.status("OPEN").sourceId("03550600LDN822356352").reasonCode("m2tr_all_trade_price_exception")
				.exceptionId("Exception5").change("tradeCapacity", "old_value_1", "123")
				.maker("sl84003", "upstream updated").build();
		request.id = new ObjectId("59b93e3bce826b30fca3d04a");
		changeRequestRepository.save(request);

		String payload = ChangeRequestPayloadBuilder.approvePayloadWithOnlyId("59b93e3bce826b30fca3d04a");

		ResultActions result = mvc.perform(post("/changerequest/approve").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
				//.andExpect(jsonPath("$.message", equalTo("Successfully Approved")))
				.andDo(restDoc("ReplayRequestFlow"));

		Optional<ChangeRequest> requestInDB = changeRequestRepository.findById(request.id);
		requestInDB.ifPresent(req -> {
			assertEquals(req.checker, "BA23456");
			assertEquals(req.checkerComments, "This request can be approved");
			assertEquals(req.status, "APPROVED");
		});
	}

	@Test
	public void shouldUpdateApprovedIgnoreChangeRequestInDB() throws Exception {

		ChangeRequest request = new ChangeRequestBuilder().regHubId("ID-5").streamFlow("m2tr", "csheq")
				.regReportingRef("1234").typeAndRequest(ChangeRequestType.CHANGE_REQUEST_TYPE_EXCEPTION, RequestAction.REQUEST_ACTION_IGNORE)
				.status("OPEN").sourceId("03550600LDN822356352").reasonCode("m2tr_all_trade_price_exception")
				.exceptionId("Exception5").change("tradeCapacity", "old_value_1", "123")
				.maker("sl84003", "upstream updated").build();
		request.id = new ObjectId("59b93e3bce826b30fca3d04b");
		changeRequestRepository.save(request);

		String payload = ChangeRequestPayloadBuilder.approvePayloadWithOnlyId("59b93e3bce826b30fca3d04b");

		ResultActions result = mvc.perform(post("/changerequest/approve").content(payload)
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

		result.andExpect(status().isOk())
		//.andExpect(jsonPath("$.message", equalTo("Successfully Approved")))
		.andDo(restDoc("ReplayRequestFlow"));

		
		Optional<ChangeRequest> requestInDB = changeRequestRepository.findById(request.id);
		requestInDB.ifPresent(req -> {
			assertEquals(req.checker, "BA23456");
			assertEquals(req.checkerComments, "This request can be approved");
			assertEquals(req.status, "APPROVED");
		});
	}

	private void checkResultForInsertedChangeRequest(ResultActions result) {
		try {
			result.andExpect(status().isOk()).andDo(print()).andExpect(jsonPath("$.totalRecords", equalTo(1)))
					.andExpect(jsonPath("$.requestViewList[0].makerTs", notNullValue()))
					.andExpect(jsonPath("$.requestViewList[0].checkerTs").doesNotExist())
					.andExpect(jsonPath("$.requestViewList[0].maker", equalTo("SP18336")))
					.andExpect(jsonPath("$.requestViewList[0].makerComments", equalTo("testing comments")))
					.andExpect(jsonPath("$.requestViewList[0].checker").doesNotExist())
					.andExpect(jsonPath("$.requestViewList[0].checkerComments").doesNotExist())
					.andExpect(jsonPath("$.requestViewList[0].reasonCode", equalTo("abc")))
					.andExpect(jsonPath("$.requestViewList[0].type", equalTo("EXCEPTION")))
					.andExpect(jsonPath("$.requestViewList[0].exceptionId", equalTo("xceptionOne")))
					.andExpect(jsonPath("$.requestViewList[0].status", equalTo("OPEN")))
					.andExpect(jsonPath("$.requestViewList[0].regReportingRef", equalTo("csheqnull123")))
					.andExpect(jsonPath("$.requestViewList[0].sourceId", equalTo("source1")))
					.andExpect(jsonPath("$.requestViewList[0].attributes[0].fieldName", equalTo("fieldOne")))
					.andExpect(jsonPath("$.requestViewList[0].attributes[0].oldValue", equalTo("old_value_1")))
					.andExpect(jsonPath("$.requestViewList[0].attributes[0].newValue", equalTo("new_value_2")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}