package com.citi.reghub.core.entities;

import java.time.LocalDateTime;
import java.util.Arrays;

public class ExceptionCodeBuilder {
	
	private String exceptionCode;
	private String longDescription;
	private String [] overrideFields = {};
	
	public ExceptionCodeBuilder exceptionCode(String exceptionCode)
	{
		this.exceptionCode = exceptionCode;
		
		return this;
		
	}
	
	public ExceptionCodeBuilder longDescription(String longDescription)
	{
		this.longDescription = longDescription;
		
		return this;
		
	}
	
	public ExceptionCodeBuilder overrideFields(String... overrideFields) {
        this.overrideFields = overrideFields;        
        return this;
    }
	
	public ExceptionCode build()
	{
		ExceptionCode exceptionCode = new ExceptionCode();
		exceptionCode.setExceptionCode(this.exceptionCode);
		exceptionCode.setLongDescription(this.longDescription);
		exceptionCode.setOverrideFields(Arrays.asList(this.overrideFields));
        return exceptionCode;
	}

}
