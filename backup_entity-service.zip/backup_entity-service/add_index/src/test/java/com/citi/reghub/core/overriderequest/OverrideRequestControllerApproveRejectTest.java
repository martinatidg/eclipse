package com.citi.reghub.core.overriderequest;


import java.util.concurrent.TimeUnit;









import javax.validation.constraints.AssertTrue;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.AuditConsumer;
import com.citi.reghub.core.AuditPublisher;
import com.citi.reghub.core.entities.BaseControllerTest;
import com.citi.reghub.core.entities.EntityBuilder;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static com.citi.reghub.core.overriderequest.OverrideRequest.STATUS_APPROVED;
import static com.citi.reghub.core.overriderequest.OverrideRequest.STATUS_REJECTED;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


public class OverrideRequestControllerApproveRejectTest extends BaseControllerTest {

	
	
    @Test
    public void shouldApproveOverrideRequests() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyTwo","value2").build());
        repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyTwo","value2").build());

        overrideRepository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").info("keyOne","overridden_1").info("keyTwo","value_2").buildOverride());

        String id1 = overrideRequestRepository.save(new OverrideRequestBuilder().regHubId("ID-1","ID-2").streamFlow("M2TR", "CSHEQ")
                .change("info.keyOne","value1","overridden_2","EX_CODE_1")
                .change("info.keyThree","","overridden_3","EX_CODE_2")
                .maker("SP18336","my comments to override").build()).id.toString();

        String payload =
                "{" +
                    "\"ids\": [\"" + id1 + "\"]," +
                    "\"checker\": \"SP18336\"," +
                    "\"checkerComments\": \"checker comments\"" +
                "}";

        ResultActions result = mvc.perform(post("/overrideRequests/approve")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.message",equalTo("Successfully approved override requests.")));

        // verify status is updated along with checker details
        result = mvc.perform(get("/overrideRequests?stream=M2TR&flow=CSHEQ&status=" + STATUS_APPROVED).accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].status", equalTo(STATUS_APPROVED)))
                .andExpect(jsonPath("$[0].checkerTs", notNullValue()))
                .andExpect(jsonPath("$[0].checker", equalTo("SP18336")))
                .andExpect(jsonPath("$[0].checkerComments", equalTo("checker comments")))
        ;

        // verify overrideEntity is updated
        result = mvc.perform(get("/entities/override/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.info.keyOne", equalTo("overridden_2")))
                .andExpect(jsonPath("$.info.keyTwo", equalTo("value_2")))
                .andExpect(jsonPath("$.info.keyThree", equalTo("overridden_3")))
        ;
        result = mvc.perform(get("/entities/override/ID-2?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-2")))
                .andExpect(jsonPath("$.info.keyOne", equalTo("overridden_2")))
                .andExpect(jsonPath("$.info.keyThree", equalTo("overridden_3")))
        ;
/*        result = mvc.perform(get("/entities/override/ID-3?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isNotFound());*/

        // verify entity is updated with instructions
        result = mvc.perform(get("/entities?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-3")))
                .andExpect(jsonPath("$[0].instructions").doesNotExist())
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-2")))
                .andExpect(jsonPath("$[1].instructions", contains("OVERRIDDEN")))
                .andExpect(jsonPath("$[2].regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$[2].instructions", contains("OVERRIDDEN")))
        ;
        

	   
    }




    @Test
    public void shouldRejectOverrideRequests() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyOne","value1").build());
        repository.save(new EntityBuilder().regHubId("ID-2").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyTwo","value2").build());
        repository.save(new EntityBuilder().regHubId("ID-3").streamFlow("M2TR", "CSHEQ").exception("EX_CODE1").info("keyTwo","value2").build());

        overrideRepository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").info("keyOne","overridden_1").info("keyTwo","value_2").buildOverride());

        String id1 = overrideRequestRepository.save(new OverrideRequestBuilder().regHubId("ID-1","ID-2").streamFlow("M2TR", "CSHEQ")
                .change("info.keyOne","value1","overridden_2","EX_CODE_1")
                .change("info.keyThree","","overridden_3","EX_CODE_2")
                .maker("SP18336","my comments to override").build()).id.toString();

        String payload =
                "{" +
                        "\"ids\": [\"" + id1 + "\"]," +
                        "\"checker\": \"SP18336\"," +
                        "\"checkerComments\": \"checker comments\"" +
                "}";

        ResultActions result = mvc.perform(post("/overrideRequests/reject")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.message",equalTo("Successfully rejected override requests.")));

        // verify status is updated along with checker details
        result = mvc.perform(get("/overrideRequests?stream=M2TR&flow=CSHEQ&status=" + STATUS_REJECTED).accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].status", equalTo(STATUS_REJECTED)))
                .andExpect(jsonPath("$[0].checkerTs", notNullValue()))
                .andExpect(jsonPath("$[0].checker", equalTo("SP18336")))
                .andExpect(jsonPath("$[0].checkerComments", equalTo("checker comments")))
        ;

        // verify overrideEntity is NOT updated
        result = mvc.perform(get("/entities/override/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.info.keyOne", equalTo("overridden_1")))
                .andExpect(jsonPath("$.info.keyTwo", equalTo("value_2")))
        ;
    /*    result = mvc.perform(get("/entities/override/ID-2?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isNotFound());
        result = mvc.perform(get("/entities/override/ID-3?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isNotFound());*/

        // verify entity is NOT updated with instructions
        result = mvc.perform(get("/entities?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)))
                .andExpect(jsonPath("$[0].regHubId", equalTo("ID-3")))
                .andExpect(jsonPath("$[0].instructions").doesNotExist())
                .andExpect(jsonPath("$[1].regHubId", equalTo("ID-2")))
                .andExpect(jsonPath("$[1].instructions").doesNotExist())
                .andExpect(jsonPath("$[2].regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$[2].instructions").doesNotExist())
        ;
        
        

    }


}