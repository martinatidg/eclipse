package com.citi.reghub.core.changerequest;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.citi.reghub.core.changerequest.Change;
import com.citi.reghub.core.changerequest.ChangeRequest;
import com.citi.reghub.core.changerequest.ChangeRequestBuilder;
import com.citi.reghub.core.changerequest.ChangeRequestPayloadBuilder;

public class ChangeRequestBuilder {
	
	public ChangeRequestBuilder() {
        this(Clock.systemUTC());
    }

    public ChangeRequestBuilder(Clock clock) {
        this.clock = clock;
    }

    private Clock clock;
    
    public String status; // override status (REQUESTED, APPROVED, REJECTED)
    public String exceptionId;
    public String regHubId;
    public String regReportingRef;
    public String reasonCode;
    public String description;
    public String maker;
    public String makerComments;
    public String checker;
    public String checkerComments;
    public String stream;
    public String flow;
    public String sourceId;
    
    public String requestAction;
    public LocalDateTime createdTs;
	public LocalDateTime lastUpdatedTs;
	public String type;
	
    private List<Change> attributes = new ArrayList<>();


    public ChangeRequestBuilder regHubId(String regHubId) {
        this.regHubId = regHubId;
        return this;
    }
    
    public ChangeRequestBuilder exceptionId(String exceptionId) {
        this.exceptionId = exceptionId;
        return this;
    }
    
    public ChangeRequestBuilder regReportingRef(String regReportingRef) {
        this.regReportingRef = regReportingRef;
        return this;
    }

    public ChangeRequestBuilder reasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
        return this;
    }
    
    public ChangeRequestBuilder description(String description) {
    	this.description = description;
    	return this;
    }

    public ChangeRequestBuilder typeAndRequest(String type, String requestAction) {
        this.type = type;
        this.requestAction = requestAction;
        return this;
    }   
    
    public ChangeRequestBuilder sourceId(String sourceId) {
        this.sourceId = sourceId;
        return this;
    }
    
    public ChangeRequestBuilder status(String status) {
        this.status = status;
        return this;
    }
    public ChangeRequestBuilder streamFlow(String stream, String flow) {
        this.stream = stream;
        this.flow = flow;
        return this;
    }

    public ChangeRequestBuilder maker(String maker, String comments) {
        this.maker = maker;
        this.makerComments = comments;
        return this;
    }

    public ChangeRequestBuilder checker(String checker, String comments) {
        this.checker = checker;
        this.checkerComments = comments;
        return this;
    }

    public ChangeRequestBuilder change(String fieldName, String oldValue, String newValue) {
    	attributes.add(new Change(fieldName,oldValue,newValue));
        return this;
    }

    public ChangeRequest build() {
		
    	ChangeRequest request = new ChangeRequest();
    	request.regHubId = this.regHubId;
    	request.exceptionId = this.exceptionId;
        request.status = this.status;
        request.regReportingRef = this.regReportingRef;
        request.reasonCode = this.reasonCode;
        request.description = this.description;
		request.stream = this.stream;
        request.flow = this.flow;
        request.attributes = this.attributes;
        request.maker = this.maker;
        request.checker = this.checker;
        request.makerComments = this.makerComments;
        request.checkerComments = this.checkerComments;
        request.createdTs = ChangeRequestPayloadBuilder.now;
        request.lastUpdatedTs = request.createdTs;
        request.sourceId = this.sourceId;
        request.requestAction = this.requestAction;
        request.type = this.type;
        return request;
	}
}