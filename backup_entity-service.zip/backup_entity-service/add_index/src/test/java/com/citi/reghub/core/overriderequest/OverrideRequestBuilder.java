package com.citi.reghub.core.overriderequest;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OverrideRequestBuilder {

    public OverrideRequestBuilder() {
        this(Clock.systemUTC());
    }

    public OverrideRequestBuilder(Clock clock) {
        this.clock = clock;
    }

    private Clock clock;

    private List<String> regHubIds= new ArrayList<>();
    private String stream = "M2TR";
    private String flow = "CSHEQ";
    private String status = "REQUESTED";
    private String maker = "AA00000";
    private String checker;
    private String makerComments = "maker comments";
    private String checkerComments;

    private List<Change> changes = new ArrayList<>();


    public OverrideRequestBuilder regHubId(String... regHubId) {
        regHubIds.addAll(Arrays.asList(regHubId));
        return this;
    }

    public OverrideRequestBuilder streamFlow(String stream, String flow) {
        this.stream = stream;
        this.flow = flow;
        return this;
    }

    public OverrideRequestBuilder maker(String maker, String comments) {
        this.maker = maker;
        this.makerComments = comments;
        return this;
    }

    public OverrideRequestBuilder checker(String checker, String comments) {
        this.checker = checker;
        this.checkerComments = comments;
        return this;
    }

    public OverrideRequestBuilder change(String fieldName, String oldValue, String newValue, String exCode) {
        changes.add(new Change(fieldName,oldValue,newValue,exCode));
        return this;
    }

    public OverrideRequest build() {
        OverrideRequest request = new OverrideRequest();
        request.regHubIds = this.regHubIds;
        request.status = this.status;
        request.stream = this.stream;
        request.flow = this.flow;
        request.changes = this.changes;
        request.maker = this.maker;
        request.checker = this.checker;
        request.makerComments = this.makerComments;
        request.checkerComments = this.checkerComments;
        request.createdTs = LocalDateTime.now(clock);
        request.lastUpdatedTs = request.createdTs;
        return request;
    }

}
