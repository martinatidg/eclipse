package com.citi.reghub.core.entities;

import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.removeHeaders;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;

import org.junit.Before;
import org.junit.ClassRule;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.restdocs.AutoConfigureRestDocs;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.restdocs.mockmvc.RestDocumentationResultHandler;
import org.springframework.restdocs.operation.preprocess.ContentModifyingOperationPreprocessor;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.AuditConsumer;
import com.citi.reghub.core.AuditPublisher;
import com.citi.reghub.core.EntityServiceApplication;
import com.citi.reghub.core.KafkaUnitRule;
import com.citi.reghub.core.changerequest.ChangeRequestRepository;
import com.citi.reghub.core.overriderequest.OverrideRequestRepository;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest
@AutoConfigureRestDocs(outputDir = "target/generated-snippets")
@AutoConfigureMockMvc
@ComponentScan
public abstract class BaseControllerTest {

	private static final int port = 59722;
	private static final String valueSerializer = "com.citi.reghub.core.AuditKafkaSerializerDeserializer";
	private static final String valueDeserializer = "com.citi.reghub.core.AuditKafkaSerializerDeserializer";

	@ClassRule
	public static KafkaUnitRule<String, Audit> KafkaUnitRule = new KafkaUnitRule<>(port, valueSerializer,
			valueDeserializer);

	@Autowired
	protected MockMvc mvc;

	@Autowired
	protected EntitiesRepository repository;

	@Autowired
	protected EntitiesOverrideRepository overrideRepository;
	//Cleanup Required here
	@Autowired
	protected OverrideRequestRepository overrideRequestRepository;
	
	@Autowired
	protected ChangeRequestRepository changeRequestRepository;

	@Value("${audit.topic.name}")
	protected String auditTopicName;

	/*@Autowired
	protected AuditPublisher auditPublisher;
	
	@Autowired
	protected AuditConsumer auditConsumer;*/

	@Before
	public void setup() {
		repository.deleteAll();
		overrideRepository.deleteAll();
		overrideRequestRepository.deleteAll();
		changeRequestRepository.deleteAll();
	}

	protected RestDocumentationResultHandler restDoc(String name) {
		ContentModifyingOperationPreprocessor jsonSource = new ContentModifyingOperationPreprocessor(
				new JsonSyntaxHighlighter());
		return document(name, preprocessRequest(removeHeaders("Host", "Content-Length"), prettyPrint()),
				preprocessResponse(removeHeaders("X-Application-Context", "Content-Length"), prettyPrint(),
						jsonSource));
	}

	public Clock clock(LocalDateTime time) {
		return Clock.fixed(time.toInstant(ZoneOffset.UTC), ZoneId.of("UTC"));
	}

}
