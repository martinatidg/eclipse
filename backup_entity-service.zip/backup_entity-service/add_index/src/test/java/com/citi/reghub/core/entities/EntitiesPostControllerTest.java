package com.citi.reghub.core.entities;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.Mock;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.ResultActions;

import com.citi.cmot.armada.report.generator.Report;
import com.citi.reghub.core.constants.RestStatus;
import com.citi.reghub.core.dto.TransactionSearchRequestDto;

public class EntitiesPostControllerTest extends BaseControllerTest  {
	
	@Mock
	private EntitiesPostController entitiesPostControllerMock;
	
    @Test
    public void shouldSaveEntityAsOverride() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").info("key1","VALUE1").info("key3", "VALUE3").build());
        String payload = "{ \"id\": \"ID-1\",\"stream\": \"M2TR\",\"flow\": \"CSHEQ\", \"status\" : \"NON_REPORTABLE\", \"info\" : { \"key2\": \"VALUE2\", \"key3\": \"VALUE5\" } } ";

        ResultActions result = mvc.perform(post("/entities")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully saved entity.")))
                .andDo(restDoc("saveEntityAsOverride"))
        ;

        result = mvc.perform(get("/entities/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHEQ")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.info.key1").doesNotExist())
                .andExpect(jsonPath("$.info.key2", equalTo("VALUE2")))
                .andExpect(jsonPath("$.info.key3", equalTo("VALUE5")))
        ;

    }


    @Test
    public void shouldPatchEntityWithStatusAsTopLevelField() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").reportable().build());

        String payload = "{ \"status\" : \"NON_REPORTABLE\", \"flow\" : \"CSHFI\" } ";
        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity.")))
                .andDo(restDoc("patchEntityTopLevelFields"))
        ;

        result = mvc.perform(get("/entities/ID-1?stream=M2TR&flow=CSHFI").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHFI")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
        ;
    }

    @Test
    public void shouldPatchEntityWithInfoLevelField() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").info("key1","VALUE1").info("key3", "VALUE3").build());

        String payload = "{ \"status\" : \"NON_REPORTABLE\", \"info\" : { \"key2\": \"VALUE2\", \"key3\": \"VALUE5\" } } ";
        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity.")))
                .andDo(restDoc("patchEntityInfoLevelFields"))
        ;

        result = mvc.perform(get("/entities/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHEQ")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.info.key1", equalTo("VALUE1")))
                .andExpect(jsonPath("$.info.key2", equalTo("VALUE2")))
                .andExpect(jsonPath("$.info.key3", equalTo("VALUE5")))
        ;
    }

    @Test
    public void shouldInsertEntityIfDoesNotExists() throws Exception {
        String payload = "{ \"id\": \"ID-1\",\"stream\": \"M2TR\",\"flow\": \"CSHEQ\", \"status\" : \"NON_REPORTABLE\", \"info\" : { \"key2\": \"VALUE2\", \"key3\": \"VALUE5\" } } ";

        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity.")))
                .andDo(restDoc("insertNewEntityIfDoesNotExists"))
        ;

        result = mvc.perform(get("/entities/ID-1?stream=M2TR&flow=CSHEQ").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHEQ")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.info.key2", equalTo("VALUE2")))
                .andExpect(jsonPath("$.info.key3", equalTo("VALUE5")))
        ;
    }


    @Test
    public void shouldPatchEntityWithClearingValueForTopLevelField() throws Exception {
        repository.save(new EntityBuilder().regHubId("ID-1").streamFlow("M2TR", "CSHEQ").exception("CODE_1").build());
        String payload = "{ \"status\" : \"NON_REPORTABLE\", \"flow\" : \"CSHFI\", \"reasonCodes\" : \"null\" } ";

        ResultActions result = mvc.perform(post("/entities/M2TR/CSHEQ/ID-1/patch")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.id",equalTo("ID-1")))
                .andExpect(jsonPath("$.status",equalTo(RestStatus.SUCCESS)))
                .andExpect(jsonPath("$.message",equalTo("Successfully patched entity.")))
                .andDo(restDoc("clearEntityTopLevelFields"))
        ;

        result = mvc.perform(get("/entities/ID-1?stream=M2TR&flow=CSHFI").accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.regHubId", equalTo("ID-1")))
                .andExpect(jsonPath("$.stream", equalTo("M2TR")))
                .andExpect(jsonPath("$.flow", equalTo("CSHFI")))
                .andExpect(jsonPath("$.status", equalTo("NON_REPORTABLE")))
                .andExpect(jsonPath("$.reasonCodes").doesNotExist())
        ;
    }
   
    @Test
    public void shouldReturnNullWhenNoRecordsFoundForCSVExport() throws Exception {
    	TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2post");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setSortOrder("desc");
        
        ResponseEntity<ByteArrayResource> mockResponse = new ResponseEntity<ByteArrayResource>(HttpStatus.ACCEPTED);
        
        when(entitiesPostControllerMock.exportTransactionsAsCsv(transactionSearchRequestDto)).thenReturn(mockResponse);
        
        ResponseEntity<ByteArrayResource> response = entitiesPostControllerMock.exportTransactionsAsCsv(transactionSearchRequestDto);
        assertThat(response, is(equalTo(mockResponse)));
    }

    @Test
    public void shouldExportTransactionsToExcel() throws Exception {
    	Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").build();
        
        List<EntityView> entityViewList = new ArrayList<>();
        EntityView view1 = new EntityView(entity1);
        EntityView view2 = new EntityView(entity2);
        entityViewList.add(view1);
        entityViewList.add(view2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2po");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> executionTs = new ArrayList<>();
        executionTs.add("2017-08-19T16:04:26.844");
        executionTs.add("2017-09-02T16:04:26.844");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        map.put("executionTs", executionTs);
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setSortOrder("desc");
        
        ResponseEntity mockResponseInputStream = new ResponseEntity(HttpStatus.ACCEPTED);
        when(entitiesPostControllerMock.exportTransactionsAsExcel(transactionSearchRequestDto)).thenReturn(mockResponseInputStream);
        
        ResponseEntity responseInputStream = entitiesPostControllerMock.exportTransactionsAsExcel(transactionSearchRequestDto);
    
    	assertThat(responseInputStream, is(equalTo(mockResponseInputStream)));
    }
    
    @Test
    public void shouldExportTransactionToCSV() throws Exception {
    	Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").reportable("ABC").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").exception("XYZ").build();
        
        List<Entity> entityList = new ArrayList<>();
        
        entityList.add(entity1);
        entityList.add(entity2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2post");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("EXCEPTION");
        status.add("REPORTABLE");
        List<String> executionTs = new ArrayList<>();
        status.add("2017-08-19T16:04:26.844");
        status.add("2017-09-02T16:04:26.844");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        map.put("executionTs", executionTs);
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setSortOrder("desc");
        
        ResponseEntity<ByteArrayResource> mockResponse = new ResponseEntity<ByteArrayResource>(HttpStatus.ACCEPTED);
        
        when(entitiesPostControllerMock.exportTransactionsAsCsv(transactionSearchRequestDto)).thenReturn(mockResponse);
        
        String payload = "{\"filter\":{\"stream\":[\"m2tr\",\"m2post\"],\"flow\":[\"csheq\",\"cshfi\"],\"status\":[\"BIZ_EXCEPTION\",\"REPORTABLE\"]},\"sortBy\":\"lastUpdatedTs\",\"sortOrder\":\"desc\",\"receivedTs\":[\"2017-08-20T16:04:26.844\",\"2017-09-01T16:04:26.844\"]}";

        ResponseEntity<ByteArrayResource> response = entitiesPostControllerMock.exportTransactionsAsCsv(transactionSearchRequestDto);
        assertThat(response, is(equalTo(mockResponse)));
    }

    @Test
    public void shouldPerformTransactionSearchWithExecutionTs() throws Exception {
        Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").build();
        
        List<EntityView> entityViewList = new ArrayList<>();
        EntityView view1 = new EntityView(entity1);
        EntityView view2 = new EntityView(entity2);
        entityViewList.add(view1);
        entityViewList.add(view2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2po");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> projection = new ArrayList<>();
        status.add("sourceUId");
        status.add("regReportingRef");
        List<String> executionTs = new ArrayList<>();
        status.add("2017-07-01T16:04:26.844");
        status.add("2017-09-01T16:04:26.844");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        map.put("executionTs",executionTs);
        
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setProjection(projection);
        transactionSearchRequestDto.setSortOrder("desc");
        
        when(entitiesPostControllerMock.getTransactions(transactionSearchRequestDto)).thenReturn(new EntityViewWraper(entityViewList, entityViewList.size()));
        
        String payload = "{\"filter\":{\"stream\":[\"m2tr\",\"m2po\"],\"flow\":[\"csheq\",\"cshfi\"],\"status\":[\"BIZ_EXCEPTION\",\"REPORTABLE\"],\"info.tradeExecType\":[\"New\"],\"info.firmAcctIdType\":[\"ACCOUNTMNEMONIC\"],\"info.traderId\":[\"P183\",\"3E09\"],\"executionTs\":[\"2017-07-01T16:04:26.844\",\"2017-09-01T16:04:26.844\"]},\"projection\":[\"sourceUId\",\"regReportingRef\",\"info.traderId\"],\"sortBy\":\"lastUpdatedTs\",\"sortOrder\":\"desc\",\"offset\":\"0\",\"limit\":\"100\"} ";

        ResultActions result = mvc.perform(post("/entities/transactions")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
        		.andExpect(content().contentType(new MediaType(MediaType.APPLICATION_JSON.getType(),MediaType.APPLICATION_JSON.getSubtype(),Charset.forName("utf8"))))
        		.andReturn().equals(new EntityViewWraper(entityViewList, entityViewList.size()))
        		
        ;

    }
    
    @Test
    public void shouldPerformTransactionSearchWithoutExecutionStatus() throws Exception {
        Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").build();
        
        List<EntityView> entityViewList = new ArrayList<>();
        EntityView view1 = new EntityView(entity1);
        EntityView view2 = new EntityView(entity2);
        entityViewList.add(view1);
        entityViewList.add(view2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2po");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> projection = new ArrayList<>();
        status.add("sourceUId");
        status.add("regReportingRef");
        List<String> executionTs = new ArrayList<>();
        status.add("2017-07-01T16:04:26.844");
        status.add("2017-09-01T16:04:26.844");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setProjection(projection);
        transactionSearchRequestDto.setSortOrder("desc");
        
        when(entitiesPostControllerMock.getTransactions(transactionSearchRequestDto)).thenReturn(new EntityViewWraper(entityViewList, entityViewList.size()));
        
        String payload = "{\"filter\":{\"stream\":[\"m2tr\",\"m2po\"],\"flow\":[\"csheq\",\"cshfi\"],\"status\":[\"BIZ_EXCEPTION\",\"REPORTABLE\"],\"info.tradeExecType\":[\"New\"],\"info.firmAcctIdType\":[\"ACCOUNTMNEMONIC\"],\"info.traderId\":[\"P183\",\"3E09\"]},\"projection\":[\"sourceUId\",\"regReportingRef\",\"info.traderId\"],\"sortBy\":\"lastUpdatedTs\",\"sortOrder\":\"desc\",\"offset\":\"0\",\"limit\":\"100\"} ";

        ResultActions result = mvc.perform(post("/entities/transactions")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
        		.andExpect(content().contentType(new MediaType(MediaType.APPLICATION_JSON.getType(),MediaType.APPLICATION_JSON.getSubtype(),Charset.forName("utf8"))))
        		.andReturn().equals(new EntityViewWraper(entityViewList, entityViewList.size()))
        		
        ;

    }
    
    @Test
	public void shouldReturnFileForCsvExport() throws Exception {
		File csvReportFile = null;
		
		Report mockCSVReport = new Report();
		String fileName = "RegHub_Transaction.csv";
		File file = new File(fileName);
		
		mockCSVReport.setReportFile(file);
		
		Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447")
				.sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452")
        		.sourceId("441623").streamFlow("m2tr", "csheq").build();
        Entity entity3 = new EntityBuilder().regHubId("m2trcsheq423240453")
        		.sourceId("441622").streamFlow("m2tr", "csheq").build();
        
        List<Entity> entityList = new ArrayList<>();
        entityList.add(entity1);
        entityList.add(entity2);
        entityList.add(entity3);
        
        when(entitiesPostControllerMock.generateReportAsCSV(entityList, fileName)).thenReturn(file);
        
        csvReportFile = entitiesPostControllerMock.generateReportAsCSV(entityList, fileName);
        
        assertThat(csvReportFile, is(equalTo(file)));
	}
    
    @Test
    public void shouldPerformExceptionSearchWithoutSourceSystem() throws Exception {
        Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").build();
        List<Entity> entityList = new ArrayList<>();
        entityList.add(entity1);
        entityList.add(entity2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2po");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> projection = new ArrayList<>();
        status.add("sourceUId");
        status.add("regReportingRef");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setProjection(projection);
        transactionSearchRequestDto.setSortOrder("desc");
        
        when(entitiesPostControllerMock.getExceptionWithReasonCodes(transactionSearchRequestDto)).thenReturn(new EntityWrapper(entityList, entityList.size()));
        
        String payload = "{\"filter\":{\"stream\":[\"m2tr\",\"m2po\"],\"flow\":[\"csheq\",\"cshfi\"],\"status\":[\"BIZ_EXCEPTION\",\"REPORTABLE\"],\"info.tradeExecType\":[\"New\"],\"info.firmAcctIdType\":[\"ACCOUNTMNEMONIC\"],\"info.traderId\":[\"P183\",\"3E09\"],\"executionTs\":[\"2017-07-01T16:04:26.844\",\"2017-09-01T16:04:26.844\"]},\"projection\":[\"sourceUId\",\"regReportingRef\",\"info.traderId\"],\"sortBy\":\"lastUpdatedTs\",\"sortOrder\":\"desc\",\"offset\":\"0\",\"limit\":\"100\"} ";
        
        ResultActions result = mvc.perform(post("/entities/exceptions")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
        		.andExpect(content().contentType(new MediaType(MediaType.APPLICATION_JSON.getType(),MediaType.APPLICATION_JSON.getSubtype(),Charset.forName("utf8"))))
        		.andReturn().equals(new EntityWrapper(entityList, entityList.size()));
    }
    
    @Test
    public void shouldPerformExceptionSearchWithoutSourceSystemAndProjection() throws Exception {
        Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").build();
        List<Entity> entityList = new ArrayList<>();
        entityList.add(entity1);
        entityList.add(entity2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2po");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> projection = new ArrayList<>();
        status.add("sourceUId");
        status.add("regReportingRef");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setProjection(projection);
        transactionSearchRequestDto.setSortOrder("desc");
        
        when(entitiesPostControllerMock.getExceptionWithReasonCodes(transactionSearchRequestDto)).thenReturn(new EntityWrapper(entityList, entityList.size()));
        
        String payload = "{\"filter\":{\"stream\":[\"m2tr\",\"m2po\"],\"flow\":[\"csheq\",\"cshfi\"],\"status\":[\"BIZ_EXCEPTION\",\"REPORTABLE\"],\"info.tradeExecType\":[\"New\"],\"info.firmAcctIdType\":[\"ACCOUNTMNEMONIC\"],\"info.traderId\":[\"P183\",\"3E09\"],\"executionTs\":[\"2017-07-01T16:04:26.844\",\"2017-09-01T16:04:26.844\"]},\"sortBy\":\"lastUpdatedTs\",\"sortOrder\":\"desc\",\"offset\":\"0\",\"limit\":\"100\"} ";
        
        ResultActions result = mvc.perform(post("/entities/exceptions")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
        		.andExpect(content().contentType(new MediaType(MediaType.APPLICATION_JSON.getType(),MediaType.APPLICATION_JSON.getSubtype(),Charset.forName("utf8"))))
        		.andReturn().equals(new EntityWrapper(entityList, entityList.size()));
    }
    
    @Test
    public void shouldPerformExceptionSearchWithSourceSystem() throws Exception {
        Entity entity1 = new EntityBuilder().regHubId("m2trcsheq477240447").sourceId("441234").streamFlow("m2tr", "csheq").build();
        Entity entity2 = new EntityBuilder().regHubId("m2trcsheq423240452").sourceId("441623").streamFlow("m2tr", "csheq").build();
        List<Entity> entityList = new ArrayList<>();
        entityList.add(entity1);
        entityList.add(entity2);
        
        TransactionSearchRequestDto transactionSearchRequestDto = new TransactionSearchRequestDto();
        List<String> streamlist = new ArrayList<>();
        streamlist.add("m2tr");
        streamlist.add("m2po");
        List<String> flowlist = new ArrayList<>();
        flowlist.add("csheq");
        flowlist.add("otc");
        List<String> status = new ArrayList<>();
        status.add("BIZ_EXCEPTION");
        status.add("REPORTABLE");
        List<String> projection = new ArrayList<>();
        status.add("sourceUId");
        status.add("regReportingRef");
        
        Map<String, List<String>> map = new HashMap<>();
        map.put("stream", streamlist);
        map.put("flowlist", flowlist);
        map.put("status", status);
        transactionSearchRequestDto.setFilter(map);
        transactionSearchRequestDto.setProjection(projection);
        transactionSearchRequestDto.setSortOrder("asc");
        
        when(entitiesPostControllerMock.getExceptionWithReasonCodes(transactionSearchRequestDto)).thenReturn(new EntityWrapper(entityList, entityList.size()));
        
        String payload = "{\"filter\":{\"stream\":[\"m2tr\",\"m2po\"],\"flow\":[\"csheq\",\"cshfi\"],\"status\":[\"BIZ_EXCEPTION\",\"REPORTABLE\"],\"sourceSystem\":[\"PRIMO\"],\"info.firmAcctIdType\":[\"ACCOUNTMNEMONIC\"],\"info.traderId\":[\"P183\",\"3E09\"],\"executionTs\":[\"2017-07-01T16:04:26.844\",\"2017-09-01T16:04:26.844\"]},\"projection\":[\"sourceUId\",\"regReportingRef\",\"info.traderId\"],\"sortBy\":\"lastUpdatedTs\",\"sortOrder\":\"asc\",\"offset\":\"0\",\"limit\":\"100\"} ";
        
        ResultActions result = mvc.perform(post("/entities/exceptions")
                .content(payload).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON));

        result.andExpect(status().isOk())
        		.andExpect(content().contentType(new MediaType(MediaType.APPLICATION_JSON.getType(),MediaType.APPLICATION_JSON.getSubtype(),Charset.forName("utf8"))))
        		.andReturn().equals(new EntityWrapper(entityList, entityList.size()));
    }
    
}