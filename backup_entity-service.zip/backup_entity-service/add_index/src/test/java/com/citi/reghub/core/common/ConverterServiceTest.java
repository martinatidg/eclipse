package com.citi.reghub.core.common;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.*;
import org.junit.runner.*;
import org.mockito.*;
import org.springframework.test.context.junit4.*;

@RunWith(SpringRunner.class)
public class ConverterServiceTest {
	
	@Mock
	private ConverterService converterServiceMock;

	@Test
	public void testDateStringToNano() throws Exception {
		ConverterService cs = new ConverterService();
		String dateString = "2017-08-01T10:20:41.881";
		String convertedDate = cs.dateStringToNano(dateString);
		assertNotNull(convertedDate);
		when(converterServiceMock.dateStringToNano(dateString)).thenReturn(new String());
	} 
}
