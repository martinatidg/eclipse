package com.citi.reghub.core.flatworm.convertor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import com.blackbear.flatworm.ConversionOption;
import com.blackbear.flatworm.converters.CoreConverters;
import com.citi.reghub.core.convertors.NanoLongToLocalDateConvertor;

public class CustomCoreConvertor extends CoreConverters {
	
	@Override
	public String convertChar(Object obj,Map<String, ConversionOption> options) {
		return (obj == null ) ? "" : obj.toString();
	}
	
	@Override
	public String convertDate(Object obj,Map<String, ConversionOption> options) {
		String formatDateTime = "";
		
		if (obj != null) {
			NanoLongToLocalDateConvertor longToDateConvertor = new NanoLongToLocalDateConvertor();
			LocalDateTime dateTime = longToDateConvertor.convert(Long.parseLong(obj.toString()));
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			
			Integer nanoSeconds = dateTime.getNano();
			String nanoSecStr = String.format("%09d", nanoSeconds);
			String[] nanoSecStrArr = nanoSecStr.split("(?<=\\G...)");
			String nanoSecFormattedString = String.join(".", nanoSecStrArr);
			
			formatDateTime = dateTime.format(formatter).toString() + "." + nanoSecFormattedString;
		}
		return formatDateTime;
	}
}
