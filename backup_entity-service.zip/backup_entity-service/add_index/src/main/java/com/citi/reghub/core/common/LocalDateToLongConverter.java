package com.citi.reghub.core.common;

import java.io.IOException;
import java.time.Clock;
import java.time.LocalDateTime;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class LocalDateToLongConverter extends StdSerializer<LocalDateTime> {

	private static final long serialVersionUID = 1L;

	public LocalDateToLongConverter() {
		this(null);
	}

	public LocalDateToLongConverter(Class<LocalDateTime> t) {
		super(t);
	}

	@Override
	public void serialize(LocalDateTime time, JsonGenerator gen, SerializerProvider arg2) throws IOException, JsonProcessingException {
		Long epochSec = time.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
		Integer nanos = time.getNano();
		gen.writeNumber((epochSec * 1000000000) + nanos);
	}

}