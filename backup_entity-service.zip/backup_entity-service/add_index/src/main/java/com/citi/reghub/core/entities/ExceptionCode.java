package com.citi.reghub.core.entities;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExceptionCode {
	
	private String exceptionCode;	
	private String shortDescription;	
	private String longDescription;	
	private List<String> overrideFields = new ArrayList<>();	
	private List<String> rules = new ArrayList<>();
	
	
	public ExceptionCode()
	{
		
	}
	
	
	public List<String> getRules() {
		return rules;
	}
	public void setRules(List<String> rules) {
		this.rules = rules;
	}
	public String getExceptionCode() {
		return exceptionCode;
	}
	public String getExceptionCode(ExceptionCode exceptionCode) {
		return exceptionCode.getExceptionCode();
	}
	public void setExceptionCode(String exceptionCode) {
		this.exceptionCode = exceptionCode;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	public List<String> getOverrideFields() {
		return overrideFields;
	}
	public void setOverrideFields(List<String> overrideFields) {
		this.overrideFields = overrideFields;
	}
	
	

}
