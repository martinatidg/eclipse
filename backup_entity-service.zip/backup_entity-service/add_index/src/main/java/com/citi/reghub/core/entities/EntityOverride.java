package com.citi.reghub.core.entities;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "entitiesOverride")
public class EntityOverride extends Entity {
}
