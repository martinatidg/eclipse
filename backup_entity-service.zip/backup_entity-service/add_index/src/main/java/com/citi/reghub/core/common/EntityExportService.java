package com.citi.reghub.core.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.citi.cmot.armada.report.generator.RGConstants;
import com.citi.cmot.armada.report.generator.Report;
import com.citi.cmot.armada.report.generator.ReportGenerationException;
import com.citi.cmot.armada.report.generator.ReportGenerator;
import com.citi.reghub.core.dto.Header;
import com.citi.reghub.core.dto.TransactionSearchRequestDto;
import com.citi.reghub.core.entities.Entity;

@Service
public class EntityExportService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EntityExportService.class);
	
	@Value("${max.excel.export.record.limit}")
	private String MAX_EXCEl_EXPORT_RECORD_LIMIT;

	@Value("${max.csv.export.record.limit}")
	private String MAX_CSV_EXPORT_RECORD_LIMIT;
	
	private static String executionTs = "executionTs";
	
	public String formatDateTimeToNanoDateTime(LocalDateTime dateValue) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		Integer nanoSeconds = dateValue.getNano();

		String nanoStr = String.format("%09d", nanoSeconds);
		String[] nanoSecArr = nanoStr.split("(?<=\\G...)");
		String nanoSecString = String.join(".", nanoSecArr);
		String formatDateTime = dateValue.format(formatter).toString() + "." + nanoSecString;

		return formatDateTime;
	}
	
	public QueryCriteria buildTransactionQueryCriteria(TransactionSearchRequestDto searchRequestDto) {
		QueryCriteria criteria = new QueryCriteria();

		Map<String, List<String>> payload = searchRequestDto.getFilter();

		if (null != payload) {
			if (null != payload.get(executionTs)) {
				List<String> executionTsList = new ArrayList<>();
				executionTsList = payload.get(executionTs);
				payload.remove(executionTs);
				payload.forEach((key, value) -> {
					criteria.addFilter(key, payload.get(key));
				});

				String executionSince = executionTsList.get(0);
				String executionUntil = executionTsList.get(1);
				criteria.between(executionTs, executionSince, executionUntil);

			} else {
				payload.forEach((key, value) -> {
					criteria.addFilter(key, payload.get(key));
				});
			}
		}

		if (null != searchRequestDto.getSortBy() && null != searchRequestDto.getSortOrder()) {
			criteria.sort(searchRequestDto.getSortBy(), searchRequestDto.getSortOrder());
			criteria.page(0, Integer.parseInt(MAX_CSV_EXPORT_RECORD_LIMIT));
		}

		return criteria;
	}
	
	public HttpHeaders getFileHttpHeaders(String fileName) {
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Cache-Control", "no-cache, no-store, must-revalidate");
		responseHeaders.add("Pragma", "no-cache");
		responseHeaders.add("Expires", "0");
		responseHeaders.add("content-disposition", "attachment; filename=" + fileName);
		responseHeaders.add("Content-Transfer-Encoding", "binary");
		responseHeaders.add("x-filename", fileName);
		responseHeaders.add("Access-Control-Allow-Headers", "content-disposition");
		responseHeaders.add("Access-Control-Expose-Headers", "content-disposition,x-filename");
		
		return responseHeaders;
	}
	
	public Report generateReportAsExcel(List<Entity> entityList, String fileName) {
		Report report = null;
		try {
			HashMap<String, Object> EntityHMap = new HashMap<String, Object>();
			EntityHMap.put("entity", entityList);

			Map<String, Object> exportEntityMap = new HashMap<String, Object>();

			exportEntityMap.put(RGConstants.XLS_REPORT_FILE_NAME_KEY, fileName);
			exportEntityMap.put(RGConstants.XLS_REPORT_MARSHALLING_MAP_KEY, EntityHMap);

			ReportGenerator reportGenerator = ReportGenerator.newInstance("export-transactions");

			report = reportGenerator.generateReport(exportEntityMap);
		} catch (ReportGenerationException e) {
			LOGGER.error("ReportGenerationException while generating XLSX.", e);
		}

		return report;
	}

	public Header getCSVHeader() {
		Header header = new Header();
		header.setField1("RPRT STATUS");
		header.setField2("REG RPRT REF");
		header.setField3("SRC TXN REF");
		header.setField4("SOURCE UID");
		header.setField5("SRC EVENT TYPE");
		header.setField6("INVST FIRM IND");
		header.setField7("TXN DATE TIME");
		header.setField8("TRADING CAPACITY");
		header.setField9("TRD QUANTITY");
		header.setField10("TRD PRICE");
		header.setField11("TRD QTY CCY");
		header.setField12("TRD PRICE CCY");
		header.setField13("ORIG SRC SYS");
		header.setField14("FIRM ACT ID");
		header.setField15("FIRM ACT TYPE");
		header.setField16("CPTY ACT ID");
		header.setField17("CPTY ID TYPE");
		header.setField18("LGL ENTY CD");
		header.setField19("SECURITY ID");
		header.setField20("SECURITY ID TYPE");
		header.setField21("TRADER ID");
		header.setField22("EXEC DESCN MKR ID");
		header.setField23("BUY SELL IND");
		header.setField24("TRD SRC SYS");
		header.setField25("TRD VENUE");
		header.setField26("TRD VENUE REF");
		header.setField27("BUYER BRNCH CNTRY");
		header.setField28("SELLER BRNCH CNTRY");
		header.setField29("BRNCH MMBR CNTRY");
		header.setField30("NOTN CRCY ONE");
		header.setField31("INSTRMNT ID");
		header.setField32("INSTRMNT NAME");
		header.setField33("NOTN CRCY TWO");
		header.setField34("SFT IND");
		header.setField35("EXEC ENTY ID");
		header.setField36("SBMT ENTY ID");
		header.setField37("BUYER ID");
		header.setField38("BUYER DESCN MKR ID");
		header.setField39("SELLER ID");
		header.setField40("SELLER DESCN MKR ID");
		header.setField41("DERV NOTN CHNG");
		header.setField42("NET AMOUNT");
		header.setField43("UPFRONT PAYMENT");
		header.setField44("UPFRONT PAYMENT CRCY");
		header.setField45("COMPLEX TRD REF");
		header.setField46("PRICE MLTPLR");
		header.setField47("UNDL INSTRMNT ID");
		header.setField48("UNDL INDEX NAME");
		header.setField49("UNDL INDEX TERM");
		header.setField50("OPTION TYPE");
		header.setField51("STRIKE PRICE");
		header.setField52("STRIKE PRICE CCY");
		header.setField53("OPTION STYLE");
		header.setField54("MAT DATE");
		header.setField55("EXP DATE");
		header.setField56("DLVRY TYPE");
		header.setField57("WAVR IND");
		header.setField58("OTC POST TRD IND");
		header.setField59("COMD DERV IND");
		header.setField60("INVST DESCN ID");
		header.setField61("INSTRMNT CFI");
		header.setField62("LIFE CYCL STAT");
		header.setField63("ACTION TYPE");
		header.setField64("EVENT TYPE");
		header.setField65("FIRM ACT GFCID");
		header.setField66("CPTY ACT GFCID");
		header.setField67("CLC FLT CAP RATE");
		header.setField68("CLC FLT FLR RATE");
		header.setField69("STLM TYPE");
		header.setField70("ALGO ID");
		header.setField71("IS BSKT CONSTI");
		header.setField72("SMCP");
		header.setField73("NOTN ONE AMNT");
		header.setField74("PRC TYPE");
		header.setField75("STRIKE PRC TYPE");
		header.setField76("INTNL CLNT IDNT");
		header.setField77("SEC TYPE ONE");
		header.setField78("SEC TYPE TWO");
		header.setField79("SEC TYPE THREE");
		header.setField80("SRC EXEC STATUS");
		header.setField81("RULE GROUP");
		header.setField82("SHORT SELL IDENT");
		header.setField83("IS CORR");
		header.setField84("UV INSTRMNT CLASS");
		header.setField85("UV INDEX CLASS");
		header.setField86("PRIOR SRC TRD REF");
		header.setField87("SWAP RPRT PURPOSE");
		header.setField88("PAY REC IND");
		header.setField89("NOTN TWO AMNT");
		return header;
	}
}
