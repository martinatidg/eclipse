package com.citi.reghub.core.entities;

import com.citi.reghub.core.common.LocalDateToLongConverter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EntityView {

	private Entity entity;
	
	@JsonSerialize(using = LocalDateToLongConverter.class)
	private LocalDateTime receivedTs;    
    
    @JsonSerialize(using = LocalDateToLongConverter.class)
    private LocalDateTime publishedTs;   
    
    @JsonSerialize(using = LocalDateToLongConverter.class)
    private LocalDateTime executionTs;   
    
    @JsonSerialize(using = LocalDateToLongConverter.class)
    private LocalDateTime lastUpdatedTs; 
	
	
	public EntityView(Entity entity) {
		this.entity = entity;
		this.receivedTs = entity.receivedTs;
		this.publishedTs = entity.publishedTs;
		this.executionTs = entity.executionTs;
		this.lastUpdatedTs = entity.lastUpdatedTs;
	} 
		
	public String getRegHubId() {
		return entity.id;
	}
	public String getStatus() {
		return entity.status;
	}
	public List<String> getReasonCodes() {
		return entity.reasonCodes;
	}

	public String getStream() {
		return entity.stream;
	}
	public String getFlow() {
		return entity.flow;
	}

	public LocalDateTime getReceivedTs() {
		return receivedTs;
	}
	public LocalDateTime getPublishedTs() {
		return publishedTs;
	}
	public LocalDateTime getExecutionTs() {
		return executionTs;
	}
	public LocalDateTime getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public String getSourceSystem() {
		return entity.sourceSystem;
	}
	public String getSourceUId() {
		return entity.sourceUId;
	}
	public String getSourceId() {
		return entity.sourceId;
	}
	public String getSourceStatus() {
		return entity.sourceStatus;
	}
	public String getSourceVersion() {
		return entity.sourceVersion;
	}
	public String getRegReportingRef() {
		return entity.regReportingRef;
	}
	
	public boolean isRdsEligible() {
		return entity.isRdsEligible();
	}


	public Map<String, Object> getInfo() {
		return entity.info;
	}

	public List<String> getInstructions() {
		return entity.instructions;
	}

}
