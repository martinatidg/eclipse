package com.citi.reghub.core.entities;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.unwind;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.citi.reghub.core.common.AnyObjectRepository;
import com.citi.reghub.core.common.QueryCriteria;
import com.citi.reghub.core.metadata.client.MetadataClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;

@RestController
public class EntitiesGetController {

	public static final String ISO_DATE_TIME_REGEX = "^([\\+-]?\\d{4}(?!\\d{2}\\b))((-?)((0[1-9]|1[0-2])(\\3([12]\\d|0[1-9]|3[01]))?|W([0-4]\\d|5[0-2])(-?[1-7])?|(00[1-9]|0[1-9]\\d|[12]\\d{2}|3([0-5]\\d|6[1-6])))([T\\s]((([01]\\d|2[0-3])((:?)[0-5]\\d)?|24\\:?00)([\\.,]\\d+(?!:))?)?(\\17[0-5]\\d([\\.,]\\d+)?)?([zZ]|([\\+-])([01]\\d|2[0-3]):?([0-5]\\d)?)?)?)?$";

	private static final Logger LOGGER = LoggerFactory.getLogger(EntitiesGetController.class);

	public static final Integer DEFAULT_RECORD_LIMIT = 1000;

	@Autowired
	private EntitiesRepository repository;

	@Autowired
	private AnyObjectRepository anyObjectRepository;

	@Autowired
	private MetadataClient metadataClient;

	private Entity entityObj = new Entity();

	@GetMapping("/entities/{regHubId}")
	public EntityView getEntity(@PathVariable String regHubId, @RequestParam String stream, @RequestParam String flow) {

		LOGGER.debug("Processing getEntity request with regHubId='{}', stream='{}', flow='{}'", regHubId, stream, flow);
		Entity entity = repository.findByIdAndStreamAndFlow(regHubId, stream, flow).orElse(entityObj);

		return new EntityView(entity);
	}

	@GetMapping("/entities")
	public List<EntityView> getEntities(@RequestParam String stream, @RequestParam String flow,

			@RequestParam(required = false, defaultValue = "true") Boolean summaryView,

			@RequestParam(required = false) String status, @RequestParam(required = false) List<String> statuses,
			@RequestParam(required = false) List<String> reasonCodes, @RequestParam(required = false) String sourceId,
			@RequestParam(required = false) String regReportingRef,

			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String receivedSince,
			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String receivedUntil,

			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String executionSince,
			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String executionUntil,

			@RequestParam(required = false, defaultValue = "lastUpdatedTs") String sortBy,
			@RequestParam(required = false, defaultValue = "desc") String sortOrder,
			@RequestParam(required = false, defaultValue = "0") Integer offset,
			@RequestParam(required = false, defaultValue = "100") Integer limit) {

		LOGGER.debug(
				"Processing getAudits request with " + "stream='{}', flow='{}', summaryView='{}', "
						+ "status='{}', statuses='{}', reasonCodes='{}', " + "sourceId='{}', regReportingRef='{}', "
						+ "receivedSince='{}', receivedUntil='{}', executionSince='{}', executionUntil='{}', "
						+ "sortBy='{}', sortOrder='{}', offset='{}', limit='{}'",
				stream, flow, summaryView, status, statuses, reasonCodes, sourceId, regReportingRef, receivedSince,
				receivedUntil, executionSince, executionUntil, sortBy, sortOrder, offset, limit);

		QueryCriteria criteria = new QueryCriteria().addFilter("stream", stream).addFilter("flow", flow)
				.addFilter("status", status).addFilter("status", statuses).addFilter("sourceId", sourceId)
				.addFilter("regReportingRef", regReportingRef).addFilter("reasonCodes", reasonCodes)
				.between("receivedTs", receivedSince, receivedUntil)
				.between("executionTs", executionSince, executionUntil).sort(sortBy, sortOrder).page(offset, limit);

		if (summaryView)
			criteria.projection(Entity.TOP_LEVEL_FIELDS);

		return anyObjectRepository.find(criteria.build(), Entity.class).map(EntityView::new)
				.collect(Collectors.toList());

	}
												
	@GetMapping("/entities/generic")
	public List<EntityView> getEntityBySourceID(@RequestParam(required = false) String sourceId,
			@RequestParam(required = false) String status,
			@RequestParam(required = false, defaultValue = "true") Boolean summaryView,

			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String receivedSince,
			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String receivedUntil,

			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String executionSince,
			@Valid @Pattern(regexp = ISO_DATE_TIME_REGEX) @RequestParam(required = false) String executionUntil,

			@RequestParam(required = false, defaultValue = "lastUpdatedTs") String sortBy,
			@RequestParam(required = false, defaultValue = "desc") String sortOrder,
			@RequestParam(required = false, defaultValue = "0") Integer offset,
			@RequestParam(required = false, defaultValue = "100") Integer limit) {

		LOGGER.debug(
				"Processing getAudits request with "
						+ "status='{}', sourceId='{}', receivedSince='{}', receivedUntil='{}', executionSince='{}', executionUntil='{}', "
						+ "sortBy='{}', sortOrder='{}', offset='{}', limit='{}', summaryView='{}' ",
				status, sourceId, receivedSince, receivedUntil, executionSince, executionUntil, sortBy, sortOrder,
				offset, limit, summaryView);

		QueryCriteria criteria = new QueryCriteria().addFilter("status", status).addFilter("sourceId", sourceId)
				.between("receivedTs", receivedSince, receivedUntil)
				.between("executionTs", executionSince, executionUntil).sort(sortBy, sortOrder).page(offset, limit);

		if (summaryView)
			criteria.projection(Entity.TOP_LEVEL_FIELDS);

		return anyObjectRepository.find(criteria.build(), Entity.class).map(EntityView::new)
				.collect(Collectors.toList());
	}

	@GetMapping("/entities/relatedEntities/{regHubId}")
	public List<EntityView> relatedEntities(@PathVariable String regHubId, @RequestParam String stream,
			@RequestParam String flow, @RequestParam String sourceId) {

		LOGGER.debug("Processing getRelatedEntities request with " + "stream='{}', flow='{}'," + "sourceId='{}'",
				stream, flow, sourceId);

		List<Entity> entity = repository.findBySourceIdAndStreamAndFlow(sourceId, stream, flow);

		return entity.stream().map(EntityView::new).filter(e -> !e.getRegHubId().equals(regHubId))
				.collect(Collectors.toList());

	}

	@PostMapping("/entities/getSourceUIds")
	public List<EntityView> getEntities(@RequestBody String payloadAsString) throws IOException {
		LOGGER.debug("Processing getEntities request with payload='{}'", payloadAsString);
		HashMap payload = new ObjectMapper().readValue(payloadAsString, HashMap.class);
		QueryCriteria criteria = new QueryCriteria().addFilter("stream", payload.get("stream"))
				.addFilter("flow", payload.get("flow")).addFilter("id", payload.get("regHubIds"))
				.projection("id", "sourceUId");

		Query q = criteria.build();

		return anyObjectRepository.find(q, Entity.class).map(EntityView::new).collect(Collectors.toList());
	}

	@GetMapping("/entities/getExceptionSummaryView")
	public List<ExceptionSummaryView> getExceptionSummaryView(@RequestParam String stream, @RequestParam String flow,
			String recordlimit) throws JsonParseException, JsonMappingException, IOException {
		Criteria criteria = new Criteria().and("flow").is(flow).and("stream").is(stream);

		Aggregation aggregation = newAggregation(match(criteria), unwind("reasonCodes"),
				project("reasonCodes").andInclude("sourceSystem").andInclude("info")

		);

		List<ExceptionSummary> allEntitiesWithException = anyObjectRepository.aggregate(aggregation, "entities",
				ExceptionSummary.class);

		if (allEntitiesWithException.stream()
				.count() > (recordlimit == null ? DEFAULT_RECORD_LIMIT : Integer.parseInt(recordlimit)))
			throw new RuntimeException("Record size is too large");

		metadataClient.getMetadataClientConfig().put(MetadataClientConfig.STREAM_CODE, stream);
		metadataClient.getMetadataClientConfig().put(MetadataClientConfig.FLOW_CODE, flow);

		ObjectMapper mapper = new ObjectMapper();

		StringBuilder metadataname = new StringBuilder(stream).append("_").append(flow).append("_")
				.append("exception_definition");
		List<ExceptionCode> exceptionCodes = mapper.convertValue(metadataClient.get(metadataname.toString()),
				new TypeReference<List<ExceptionCode>>() {
				});

		Map<String, ExceptionCode> exceptionCodeMap = exceptionCodes.stream()
				.collect(Collectors.toMap(ExceptionCode::getExceptionCode, Function.identity()));

		Map<ExceptionSummaryView, Long> queryOutput = allEntitiesWithException.stream()
				.map(e -> e.setExceptioSummaryKey(exceptionCodeMap)).collect(Collectors.toList()).stream()
				.collect(Collectors.groupingBy(e -> e.getExceptionSummaryKey(), Collectors.counting()));

		return enrichedView(queryOutput, exceptionCodeMap);

	}

	@GetMapping("/entities/transactionSummary")
	public List<TransactionSummary> getTransactionSummaryView(
			@RequestParam(required = false) String startDate,
			@RequestParam(required = false) String stopDate)
			throws JsonParseException, JsonMappingException, IOException {
		Criteria criteria=new Criteria();
		
		if(startDate !=null && stopDate!=null){
			Long stDt = Long.parseLong(startDate);
			Long spDt = Long.parseLong(stopDate);
			criteria = 	Criteria.where("receivedTs").gte(stDt).lte(spDt);
		}
	  
		GroupOperation group = Aggregation.group("stream","flow","sourceSystem", "status").count().as("count");
		 SortOperation sort = Aggregation.sort(Sort.Direction.ASC, "stream","flow","sourceSystem");
		
		Aggregation aggregation = newAggregation(
				match(criteria),
				group,
				sort
			);

		List<TransactionSummary> transactionSummary = anyObjectRepository.aggregate(aggregation, "entities",
				TransactionSummary.class);
		return transactionSummary;
	}

	private List<ExceptionSummaryView> enrichedView(Map<ExceptionSummaryView, Long> queryOutput,
			Map<String, ExceptionCode> exceptionCodeMap) {
		List<ExceptionSummaryView> exceptionSummary = new ArrayList<ExceptionSummaryView>();

		if (queryOutput != null)
			for (ExceptionSummaryView key : queryOutput.keySet()) {

				if (exceptionCodeMap != null && exceptionCodeMap.get(key.getReasonCode()) != null) {
					key.setReasonCodeDesc(exceptionCodeMap.get(key.getReasonCode()).getLongDescription());
				}
				
				key.setCount(queryOutput.get(key));
				exceptionSummary.add(key);
			}

		return exceptionSummary;
	}

}
