package com.citi.reghub.core.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionSearchRequestDto {
	
	@JsonProperty("filter")
	private Map<String, List<String>> filter = new HashMap<>();
	
	@JsonProperty("filterDates")
	private Map<String, List<String>> filterDates = new HashMap<>();
	
	@JsonProperty("filterTimestamps")
	private Map<String, List<String>> filterTimestamps = new HashMap<>();
	
	@JsonProperty("projection")
	private List<String> projection = new ArrayList<>();
	
	@JsonProperty("sortBy")
	private String sortBy;
    
	@JsonProperty("sortOrder")
	private String sortOrder;
	
	@JsonProperty("offset")
	private Integer offset;
    
	@JsonProperty("limit")
	private Integer limit;

	public Map<String, List<String>> getFilter() {
		return filter;
	}

	public void setFilter(Map<String, List<String>> filter) {
		this.filter = filter;
	}

	public List<String> getProjection() {
		return projection;
	}

	public void setProjection(List<String> projection) {
		this.projection = projection;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public Integer getOffset() {
		return offset;
	}

	public void setOffset(Integer offset) {
		this.offset = offset;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public Map<String, List<String>> getFilterDates() {
		return filterDates;
	}

	public void setFilterDates(Map<String, List<String>> filterDates) {
		this.filterDates = filterDates;
	}

	public Map<String, List<String>> getFilterTimestamps() {
		return filterTimestamps;
	}

	public void setFilterTimestamps(Map<String, List<String>> filterTimestamps) {
		this.filterTimestamps = filterTimestamps;
	}

}
