package com.citi.reghub.core.entities;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ExceptionSummary {
	
	private String reasonCodes;
	private String status;
	private String stream;
	private String sourceSystem;
	private Map<String, Object> info;	
	private ExceptionSummaryView exceptionSummaryKey;
	

	
	
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getValue(String value) {
		return (String)getInfo().get(value);
	}
	public Map<String, Object> getInfo() {
		return info;
	}
	public void setInfo(Map<String, Object> info) {
		this.info = info;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReasonCode() {
		return reasonCodes;
	}
	public String getStream() {
		return stream;
	}
	
	public void setStream(String stream) {
		this.stream = stream;
	}
	public void setReasonCode(String reasonCodes) {
		this.reasonCodes = reasonCodes;
	}
	
	
	
	public ExceptionSummary setExceptioSummaryKey(Map<String,ExceptionCode> exceptionMap)
	{
		ExceptionSummaryView exceptionSummaryKey = new ExceptionSummaryView();
		
		if(exceptionMap.get(getReasonCode())!=null)
		{
		exceptionSummaryKey.setReasonCode(getReasonCode());
		exceptionSummaryKey.setSourceSystem(getSourceSystem());
		for (String key :exceptionMap.get(getReasonCode()).getOverrideFields())
		{
			exceptionSummaryKey.getOverriddenFields().put(key,getValue(key));			
				
		}
		
		}
		else
		{
			exceptionSummaryKey.setReasonCode(getReasonCode());
			exceptionSummaryKey.setSourceSystem(getSourceSystem());
		}
		
		
		
		this.exceptionSummaryKey=exceptionSummaryKey;
		
		return this;
	}
	public ExceptionSummaryView getExceptionSummaryKey() {
		return exceptionSummaryKey;
	}
	
}
