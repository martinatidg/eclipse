package com.citi.reghub.core.changerequest;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ChangeRequestRepository extends MongoRepository<ChangeRequest, ObjectId> {

    Optional<ChangeRequest> findById(ObjectId id);

}
