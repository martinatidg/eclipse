package com.citi.reghub.core.common;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.citi.reghub.core.event.EventEnvelope;

@Configuration
@EnableConfigurationProperties(XMPublisherProperties.class)
@ConditionalOnProperty("xm.producer.bootstrap.servers")
public class XMPublisher {
	
	XMPublisherProperties xmPublisherProperties;
	KafkaTemplate<String, EventEnvelope> kafkaTemplate;
	
	@Bean
	public XMPublisher xmPublisher(XMPublisherProperties xmPublisherProperties) {
		this.xmPublisherProperties = xmPublisherProperties;
		kafkaTemplate = xmPublisherProperties.createKafkaTemplate();
		return this;
	}
	
	public ListenableFuture<SendResult<String, EventEnvelope>> publish(String topicName, String key, EventEnvelope message){
		return xmPublisherProperties.sendMessage(kafkaTemplate, topicName, key, message);
	}

	public void publish(String topicName, String key, EventEnvelope message, ListenableFutureCallback<?> callback){
		xmPublisherProperties.sendMessage(kafkaTemplate, topicName, key, message, callback);
	}
	
}
