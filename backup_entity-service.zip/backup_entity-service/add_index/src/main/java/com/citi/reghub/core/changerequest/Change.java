package com.citi.reghub.core.changerequest;

import java.util.HashMap;
import java.util.Map;

public class Change {
	public String fieldName;
    public String oldValue;
    public String newValue;
    
    public Change() {
    }

    public Change(String fieldName, String oldValue, String newValue) {
        this.fieldName = fieldName;
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getOldValue() {
        return oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

   public Map<String,String> toMap(){
	   Map<String,String> map = new HashMap<String, String>();
	   map.put("fieldName", fieldName);
	   map.put("oldValue", oldValue);
	   map.put("newValue", newValue);
	   return map;
   }
}
