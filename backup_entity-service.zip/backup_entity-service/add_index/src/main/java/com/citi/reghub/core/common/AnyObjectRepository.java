package com.citi.reghub.core.common;

import com.mongodb.WriteResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Stream;

@Repository
public class AnyObjectRepository {

    @Autowired
    private MongoTemplate template;

    public <T> Stream<T> find(Query query, Class<T> klass){
        return template.find(query, klass).stream();
    }

    public <T> boolean upsert(String id, Update update, Class<T> klass) {
         QueryCriteria criteria = new QueryCriteria()
 		.addFilter("id",id);
         Query idQuery = criteria.build();
         WriteResult result = template.upsert(idQuery, update, klass);
         return result.getN() == 1;
     }
    
    public <T> boolean upsert(String id,String stream, String flow, Update update, Class<T> klass) {
       // Query idQuery = new Query().addCriteria(Criteria.where("id").is(id));
        QueryCriteria criteria = new QueryCriteria()
		.addFilter("id",id)
        .addFilter("stream", stream)
        .addFilter("flow", flow);
        Query idQuery = criteria.build();
        WriteResult result = template.upsert(idQuery, update, klass);
        return result.getN() == 1;
    }
    
    public <T> List<T> aggregate(Aggregation aggregation, String collectioName, Class<T> klass){
        return template.aggregate(aggregation, collectioName, klass).getMappedResults();
    }
    
    public <T> long getRecordCount(Query query, Class<T> klass) {
		return template.count(query, klass);
	}
}

