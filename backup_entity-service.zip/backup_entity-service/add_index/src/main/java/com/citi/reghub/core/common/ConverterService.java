package com.citi.reghub.core.common;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ConverterService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConverterService.class);
	
	public String dateStringToNano(String date) {
		
		LOGGER.debug("Converter Service called to convert date to long = ", date);
		LocalDateTime time = LocalDateTime.parse(date, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    	Long epochSec = time.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
    	Integer nanos = time.getNano();
    	Long dateToBeStoredInMongoDB = (epochSec * 1000000000) + nanos;
    	return String.valueOf(dateToBeStoredInMongoDB);
	}
}
