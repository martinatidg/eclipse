package com.citi.reghub.core.changerequest;

import java.time.LocalDateTime;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ChangeRequestView {

	private ChangeRequest request;
	
    public ChangeRequestView(ChangeRequest request) {
		this.request = request;
	}

	public String getId() {
		return request.id.toString();
	}

	public String getStatus() {
		return request.status;
	}

	public String getStream() {
		return request.stream;
	}

	public String getFlow() {
		return request.flow;
	}

	public String getMaker() {
		return request.maker;
	}

	public String getChecker() {
		return request.checker;
	}

	public String getMakerComments() {
		return request.makerComments;
	}

	public String getCheckerComments() {
		return request.checkerComments;
	}

	public LocalDateTime getMakerTs() {
		return request.createdTs;
	}

	public LocalDateTime getCheckerTs() {
		return (request.status != "OPEN") ? request.lastUpdatedTs : null;
	}

	public List<Change> getAttributes() {
		return request.attributes;
	}

	public String getexceptionId() {
		return request.exceptionId;
	}

	public String getregReportingRef() {
		return request.regReportingRef;
	}

	public String getReasonCode() {
		return request.reasonCode;
	}
	
	public String getDescription() {
		return request.description;
	}

	public String getRegHubId() {
		return request.regHubId;
	}

	public String getRequestAction() {
		return request.requestAction;
	}

	public String getType() {
		return request.type;
	}

	public String getSourceId() {
		return request.sourceId;
	}
	
}
