package com.citi.reghub.core.constants;

public final class RequestAction {
	public static final String REQUEST_ACTION_SUBMIT = "SUBMIT";
    public static final String REQUEST_ACTION_REPLAY = "REPLAY";
    public static final String REQUEST_ACTION_IGNORE = "IGNORE";
    public static final String REQUEST_ACTION_ACKNOWLEDGE = "ACKNOWLEDGE";
	
}
