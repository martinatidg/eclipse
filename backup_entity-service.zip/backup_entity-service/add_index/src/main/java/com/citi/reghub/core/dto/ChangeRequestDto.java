package com.citi.reghub.core.dto;

import java.util.ArrayList;
import java.util.List;

import com.citi.reghub.core.changerequest.Change;
import com.citi.reghub.core.changerequest.ChangeRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChangeRequestDto {
	
	@JsonProperty("exception")
	private List<ChangeRequest> exception = new ArrayList<ChangeRequest>();
	
	@JsonProperty("attributes")
	private List<Change> attributes = new ArrayList<Change>();
	
	@JsonProperty("stream")
	private String stream;
	
	@JsonProperty("maker")
	private String maker;
	
	@JsonProperty("makerComments")
	private String makerComments;
	
	@JsonProperty("type")
	private String type;
	
	@JsonProperty("reasonCode")
	private String reasonCode;
	
	@JsonProperty("description")
	private String description;
	
	@JsonProperty("requestAction")
	private String requestAction;
	
	public List<ChangeRequest> getException() {
		return exception;
	}

	public void setException(List<ChangeRequest> exception) {
		this.exception = exception;
	}
	
	public List<Change> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<Change> attributes) {
		this.attributes = attributes;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getMakerComments() {
		return makerComments;
	}

	public void setMakerComments(String makerComments) {
		this.makerComments = makerComments;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRequestAction() {
		return requestAction;
	}

	public void setRequestAction(String requestAction) {
		this.requestAction = requestAction;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
		
}
