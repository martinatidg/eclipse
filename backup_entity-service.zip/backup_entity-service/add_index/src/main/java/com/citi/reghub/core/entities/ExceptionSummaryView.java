package com.citi.reghub.core.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExceptionSummaryView {

	private String reasonCode;
	private String sourceSystem;
	private Map<String, Object> overriddenFields = new HashMap<String, Object>();
	private Long count;
	private String reasonCodeDesc;

	public List<ExceptionSummaryView> enrichedView(Map<ExceptionSummaryView, Long> queryOutput,
			Map<String, ExceptionCode> excepTionCodeMap) {

		List<ExceptionSummaryView> exceptionSummary = new ArrayList<ExceptionSummaryView>();

		for (ExceptionSummaryView key : queryOutput.keySet()) {

			if (excepTionCodeMap != null && excepTionCodeMap.get(key.getReasonCode()) != null) {
				key.setReasonCodeDesc(excepTionCodeMap.get(key.getReasonCode()).getLongDescription());
			}
			// else
			// {
			// key.setReasonCodeDesc("No description available in metadata");
			// }

			key.setCount(queryOutput.get(key));
			exceptionSummary.add(key);
		}

		return exceptionSummary;
	}

	public String getReasonCodeDesc() {
		return reasonCodeDesc;
	}

	public void setReasonCodeDesc(String reasonCodeDesc) {
		this.reasonCodeDesc = reasonCodeDesc;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public Map<String, Object> getOverriddenFields() {
		return overriddenFields;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@Override
	public boolean equals(Object o) {

		ExceptionSummaryView other = (ExceptionSummaryView) o;

		if (this.overriddenFields.size() == 0) {

			if (other.getReasonCode() != null && other.getSourceSystem() != null)
				if (other.getReasonCode().equals(reasonCode) && other.getSourceSystem().equals(sourceSystem))

					return true;
		} else {
			boolean isMapEqual = true;

			if (other.getOverriddenFields().size() != this.getOverriddenFields().size())
				isMapEqual = false;
			for (String key : other.getOverriddenFields().keySet()) {
				if (other.getOverriddenFields().get(key) != null && this.getOverriddenFields().get(key) != null)
					if (!other.getOverriddenFields().get(key).equals(this.getOverriddenFields().get(key)))
						isMapEqual = false;
			}

			if (other.getReasonCode() != null && other.getSourceSystem() != null)
				if (other.getReasonCode().equals(reasonCode) && other.getSourceSystem().equals(sourceSystem)
						&& isMapEqual)
					return true;
		}
		return false;
	}

	@Override
	public int hashCode() {

		int hashcode = 1;

		if (this.overriddenFields.size() == 0) {
			if (reasonCode != null && sourceSystem != null)
				hashcode = (int) (reasonCode.hashCode() * sourceSystem.hashCode());
		} else {

			for (String field : this.getOverriddenFields().keySet()) {

				if (this.getOverriddenFields().get(field) != null)
					hashcode = (int) (hashcode * this.getOverriddenFields().get(field).toString().hashCode());

			}

			if (reasonCode != null && sourceSystem != null)
				hashcode = (int) (hashcode * reasonCode.hashCode() * sourceSystem.hashCode());
		}

		return hashcode;
	}

}
