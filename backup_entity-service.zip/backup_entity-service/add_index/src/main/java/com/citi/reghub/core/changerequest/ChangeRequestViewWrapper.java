package com.citi.reghub.core.changerequest;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ChangeRequestViewWrapper {
	private List<ChangeRequestView> requestViewList = new ArrayList<>();
	
	private long totalRecords;
	
	public ChangeRequestViewWrapper(List<ChangeRequestView> requestViewList, long totalRecords) {
		super();
		this.requestViewList = requestViewList;
		this.totalRecords = totalRecords;
	}

	public List<ChangeRequestView> getRequestViewList() {
		return requestViewList;
	}

	public void setRequestViewList(List<ChangeRequestView> requestViewList) {
		this.requestViewList = requestViewList;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}
	
}
