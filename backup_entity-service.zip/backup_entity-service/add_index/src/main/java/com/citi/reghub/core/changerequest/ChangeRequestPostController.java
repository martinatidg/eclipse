package com.citi.reghub.core.changerequest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.AuditPublisher;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.common.AnyObjectRepository;
import com.citi.reghub.core.common.PatchObject;
import com.citi.reghub.core.common.QueryCriteria;
import com.citi.reghub.core.common.XMPublisher;
import com.citi.reghub.core.constants.RequestAction;
import com.citi.reghub.core.constants.RestStatus;
import com.citi.reghub.core.dto.ChangeRequestDto;
import com.citi.reghub.core.dto.TransactionSearchRequestDto;
import com.citi.reghub.core.entities.EntityOverride;
import com.citi.reghub.core.event.EventBuilder;
import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.event.EventName;
import com.citi.reghub.core.event.EventSource;
import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.citi.reghub.core.event.exception.ExceptionStatus;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
public class ChangeRequestPostController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChangeRequestPostController.class);

	@Autowired
	private ChangeRequestRepository repository;

	@Autowired
	private AnyObjectRepository anyObjectRepository;

	public Audit audit;

	@Autowired
	private AuditPublisher auditPublisher;

	@Value("${audit.topic.name}")
	private String auditTopicName;

	@Autowired
	private XMPublisher xmPublisher;

	@Value("${xm.topic.name}")
	private String xmTopicName;

	@Autowired
	public RestClient restClient;

	@Value("${replay.service.realtime.url}")
	private String replayServiceRealTimeUrl;
	
	@Value("${replay.service.batch.url}")
	private String replayServiceBatchUrl;
	
	@Value("${xm.kafka.exception.event.key}")
	private String xmEventKey;

	private static String createdTs = "createdTs";
	
	private static String replayServiceUrl;

	
	@PostMapping("/changerequests")
	public ChangeRequestViewWrapper getChangeRequest(@RequestBody TransactionSearchRequestDto searchRequestDto) {
		LOGGER.debug("Processing getChangeRequest with payload= ", searchRequestDto);

		Map<String, List<String>> payload = searchRequestDto.getFilter();

		QueryCriteria criteria = new QueryCriteria();

		if (null != payload) {
			List<String> createdTsList = new ArrayList<>();
			createdTsList = payload.get(createdTs);
			payload.remove(createdTs);

			String creationSince = createdTsList.get(0);
			String creationUntil = createdTsList.get(1);
			criteria.between(createdTs, creationSince, creationUntil);

			payload.forEach((key, value) -> {
				criteria.addFilter(key, payload.get(key));
			});
		}

		criteria.sort(searchRequestDto.getSortBy(), searchRequestDto.getSortOrder());
		Integer offSet = Integer.valueOf(searchRequestDto.getOffset());
		Integer getLimit = Integer.valueOf(searchRequestDto.getLimit());
		criteria.page(offSet * getLimit, getLimit);

		Query recordQuery = criteria.build();

		long totalRecords = anyObjectRepository.getRecordCount(criteria.build(), ChangeRequest.class);

		List<ChangeRequestView> requestList = anyObjectRepository.find(recordQuery, ChangeRequest.class)
				.map(ChangeRequestView::new).collect(Collectors.toList());

		ChangeRequestViewWrapper changeRequestViewWrapper = new ChangeRequestViewWrapper(requestList, totalRecords);

		return changeRequestViewWrapper;
	}

	@PostMapping("/changerequest/count")
	public ChangeRequestViewWrapper getChangeRequestCount(@RequestBody TransactionSearchRequestDto searchRequestDto) {
		LOGGER.debug("Processing getChangeRequestCount with payload= ", searchRequestDto);

		Map<String, List<String>> payload = searchRequestDto.getFilter();

		QueryCriteria criteria = new QueryCriteria();

		if (null != payload) {
			List<String> createdTsList = new ArrayList<>();
			createdTsList = payload.get(createdTs);
			payload.remove(createdTs);

			String creationSince = createdTsList.get(0);
			String creationUntil = createdTsList.get(1);
			criteria.between(createdTs, creationSince, creationUntil);

			payload.forEach((key, value) -> {
				criteria.addFilter(key, payload.get(key));
			});
		}

		long totalRecords = anyObjectRepository.getRecordCount(criteria.build(), ChangeRequest.class);

		ChangeRequestViewWrapper changeRequestViewWrapper = new ChangeRequestViewWrapper(null, totalRecords);

		return changeRequestViewWrapper;
	}
	
	@PostMapping("/acknowledge")
	public Map<String, String> exceptionAcknowledge(@RequestBody ChangeRequestDto changeRequestDTO) throws Exception {
		
		String responseMessage = "Successfully acknowledged the request";
		String responseStatus = RestStatus.SUCCESS;
		
		HashMap<String, String> response = new HashMap<String, String>();
		
		try {
			List<ChangeRequest> changeRequestList = createChangeRequestList(changeRequestDTO);
			
			List<String> exceptionIds = new ArrayList<String>();
			
			changeRequestList.stream().forEach(request -> {
				exceptionIds.add(request.exceptionId);
			
				Audit acknowledgeAuditEvent = request.toAudit("UserAction-ACKNOWLEDGE", "Acknowledge XM Response");
				acknowledgeAuditEvent.info.put("maker", request.maker);
				acknowledgeAuditEvent.info.put("makerComments", request.makerComments);
				acknowledgeAuditEvent.info.put("type", request.type.toString());
				acknowledgeAuditEvent.info.put("exceptionId", request.exceptionId);
				acknowledgeAuditEvent.info.put("Id", request.id);
				acknowledgeAuditEvent.info.put("action", "ACKNOWLEDGE");
				acknowledgeAuditEvent.tags.add("USER");
				
				publishAudit(acknowledgeAuditEvent);
				
			});
			
			updateExceptions(exceptionIds,ExceptionStatus.PENDING_REPLAY);
			
		} catch(Exception e) {
			return new HashMap<String, String>() {
				{
					put("status", RestStatus.FAILURE);
					put("message", e.getMessage());
				}
			};
		}
		
		response.put("status", responseStatus);
		response.put("message", responseMessage);
		return response;
	}
	
	@PostMapping("/changerequest")
	public Map<String, String> performUpdate(@RequestBody ChangeRequestDto changeRequestDTO) throws Exception {

		try {
			List<ChangeRequest> changeRequestList = createChangeRequestList(changeRequestDTO);

			switch (changeRequestDTO.getRequestAction()) {
				case RequestAction.REQUEST_ACTION_SUBMIT:
					return submitRequest(changeRequestList);
				case RequestAction.REQUEST_ACTION_IGNORE:
					return ignoreRequest(changeRequestList);
				case RequestAction.REQUEST_ACTION_REPLAY:
					return replayRequest(changeRequestList);
				default:
					return null;

			}
		} catch (Exception e) {
			return new HashMap<String, String>() {
				{
					put("status", RestStatus.FAILURE);
					put("message", e.getMessage());
				}
			};
		}

	}

	@PostMapping("/changerequest/reject")
	public Map<String, String> rejectChangeRequest(@RequestBody List<ChangeRequest> requestList) {

		String responseMessage = "Successfully rejected the change Requests";
		String responseStatus = RestStatus.SUCCESS;
		Map<String, String> response = new HashMap<String, String>();

		try {
			List<String> exceptionIds = new ArrayList<String>();

			requestList.stream().forEach(request -> {
				exceptionIds.add(request.exceptionId);
				Update update = request.reject(request.checker, request.checkerComments);
				anyObjectRepository.upsert(request.id.toString(), update, ChangeRequest.class);
				
				Audit rejectAuditEvent =  createAudit("UserAction-REJECT", "User rejected the exception replay/ignore request", request);
				rejectAuditEvent.info.put("checker", request.checker);
				rejectAuditEvent.info.put("checkerComments", request.checkerComments);
				
				publishAudit(rejectAuditEvent);
			});

			updateExceptions(exceptionIds, ExceptionStatus.OPEN);
		
		} catch (Exception e) {
			responseMessage = "Failed to Reject. Nested error: " + e.getMessage();
			responseStatus = RestStatus.FAILURE;
		}

		response.put("status", responseStatus);
		response.put("message", responseMessage);
		return response;
	}

	@PostMapping("/changerequest/approve")
	public Map<String, String> approveChangeRequest(@RequestBody List<ChangeRequest> requestList) {
		HashMap<String, String> resultObj = new HashMap<String, String>();
		String replyMessage = "Successfully Approved";
		
		List<String> exceptionIds = new ArrayList<String>();
		List<ChangeRequest> requestListToReplay = new ArrayList<ChangeRequest>();

		Set<String> regHubIdSet = new HashSet<String>();
		
		try {
		requestList.stream().forEach(request -> {
			exceptionIds.add(request.exceptionId);
			request.approve(request.checker, request.checkerComments);
			repository.save(request);
			Audit approveAuditEvent = null;

			if (regHubIdSet.add(request.regHubId)) {
				requestListToReplay.add(request);

			}

			if (request.getRequestAction().equalsIgnoreCase(RequestAction.REQUEST_ACTION_SUBMIT)) {
				approveAuditEvent = createAudit("UserAction-APPROVE", "User Approved the submitted changes",request);
				
				createEntityOverride(request);
			} else if (request.getRequestAction().equalsIgnoreCase(RequestAction.REQUEST_ACTION_IGNORE)) {
				approveAuditEvent = createAudit("UserAction-APPROVE", "User Approved to Ignore the Exception",request);
			}
			
			approveAuditEvent.info.put("checker", request.checker);
			approveAuditEvent.info.put("checkerComments", request.checkerComments);
			approveAuditEvent.info.put("maker", request.maker);
			approveAuditEvent.info.put("makerComments", request.makerComments);
			
			publishAudit(approveAuditEvent);
		});

		
			updateExceptions(exceptionIds,ExceptionStatus.PENDING_REPLAY);
			replayRequestListRecords(requestListToReplay);
		} catch (Exception e) {
			replyMessage = "Exception while approving request. " +
						e.getClass().getCanonicalName() + " | " + e.getMessage();
			resultObj.put("status", RestStatus.FAILURE);
			resultObj.put("message", replyMessage);
			e.printStackTrace();
			return resultObj;
		} 

		resultObj.put("status", RestStatus.SUCCESS);
		resultObj.put("message", replyMessage);
		return resultObj;
	}

	// WE will be pushing event into the exception-event topic

	private void updateExceptions(List<String> exceptionIdList, ExceptionStatus status) {

		exceptionIdList.forEach(exceptionId -> {
			EventBuilder eventBuilder = new EventBuilder();
			
			ExceptionMessage exceptionMessage = new ExceptionMessage();
			exceptionMessage.setId(exceptionId);
			exceptionMessage.setStatus(status);
			
			EventEnvelope eventEnvelope = eventBuilder.newEvent().ofTypeException()
					.withEventName(EventName.EXCEPTION_STATUS_UPDATED).withEventSource(EventSource.CORE_CHANGE_REQUEST)
					.withEventData(exceptionMessage).build();
			publishEventEnvelope(eventEnvelope);
		});

	}

	private void createEntityOverride(ChangeRequest request) {
		Update update = new PatchObject(request.updates()).getUpdateObject();
		anyObjectRepository.upsert(request.regHubId, request.stream, request.flow, update, EntityOverride.class);
	}

	public List<ChangeRequest> createChangeRequestList(ChangeRequestDto changeRequestDTO) {
		List<ChangeRequest> requestList = new ArrayList<ChangeRequest>();

		String stream = (changeRequestDTO.getStream() == null) ? "" : changeRequestDTO.getStream();
		String makerId = changeRequestDTO.getMaker() == null ? "" : changeRequestDTO.getMaker();
		String makerComments = changeRequestDTO.getMakerComments() == null ? "" : changeRequestDTO.getMakerComments();
		String reasonCode = changeRequestDTO.getReasonCode() == null ? "" : changeRequestDTO.getReasonCode();
		String description = changeRequestDTO.getDescription() == null ? "" : changeRequestDTO.getDescription();
		String type = changeRequestDTO.getType();
		

		List<Change> changeList = changeRequestDTO.getAttributes();

		changeRequestDTO.getException().stream().forEach(request -> {
			ChangeRequest requestObj = new ChangeRequest(request.exceptionId, request.regHubId, request.regReportingRef,
					reasonCode, changeList, makerId, makerComments, "", "", stream, request.flow, request.sourceId,
					changeRequestDTO.getRequestAction(), type, description);
			requestList.add(requestObj);
		});
		return requestList;
	}
	
	public Audit createAudit(String event, String result, ChangeRequest requestObject) {
		List<Map> attibuteList = new ArrayList<Map> ();
		
		requestObject.attributes.forEach(attribute -> {
			Map<String,String> attributeMap = new HashMap<String, String>();
			attributeMap.put("fieldName", attribute.fieldName);
			attributeMap.put("oldValue", attribute.oldValue);
			attributeMap.put("newValue", attribute.newValue);
			
			attibuteList.add(attributeMap);
		});
		
		Audit audit = requestObject.toAudit(event, result);
		
		audit.info.put("attributes", attibuteList);
		audit.info.put("type", requestObject.type.toString());
		audit.info.put("exceptionId", requestObject.exceptionId);
		audit.info.put("Id", requestObject.id);
		audit.info.put("action", requestObject.requestAction.toString());
		audit.tags.add("USER");
		
		return audit;
	}

	public Map<String, String> submitRequest(List<ChangeRequest> requests) throws Exception {
		HashMap<String, String> resultObj = new HashMap<String, String>();
		try {
			requests.stream().forEach(request -> {
				Audit submitAuditEvent = createAudit("UserAction-SUBMIT", "Request to change and modify txn for the Exception submitted", request);
				submitAuditEvent.info.put("maker", request.maker);
				submitAuditEvent.info.put("makerComments", request.makerComments);
				
				ChangeRequest saved = repository.insert(request);
				if (null != saved) {
					publishAudit(submitAuditEvent);
					updateExceptions(Arrays.asList(saved.exceptionId),ExceptionStatus.PENDING_APPROVAL);
				}
			});
			resultObj.put("status", RestStatus.SUCCESS);
			resultObj.put("message", "Successfully Created the changeRequest.");
			return resultObj;
		} catch (Exception e) {
			throw new Exception("Exception while creating change request" + e.getMessage());
		}
	}

	public Map<String, String> ignoreRequest(List<ChangeRequest> requests) throws Exception {
		HashMap<String, String> resultObj = new HashMap<String, String>();

		try {
			requests.stream().forEach(request -> {
				Audit ignoreAuditEvent = createAudit("UserAction-IGNORE", "Request to Ignore the Exception submitted", request);
				ignoreAuditEvent.info.put("maker", request.maker);
				ignoreAuditEvent.info.put("makerComments", request.makerComments);
				
				ChangeRequest saved = repository.insert(request);
				if (null != saved) {
					 publishAudit(ignoreAuditEvent);
					 updateExceptions(Arrays.asList(saved.exceptionId),ExceptionStatus.PENDING_APPROVAL);
				}
			});
			resultObj.put("status", RestStatus.SUCCESS);
			resultObj.put("message", "Successfully Created the changeRequest.");
			return resultObj;
		} catch (Exception e) {
			throw new Exception("Exception while creating change request" + e.getMessage());
		}

	}

	public Map<String, String> replayRequest(@RequestBody List<ChangeRequest> requestList) throws Exception {
		HashMap<String, String> resultObj = new HashMap<String, String>();

		try {
			replayRequestListRecords(requestList);
			resultObj.put("status", RestStatus.SUCCESS);
			resultObj.put("message", "Successfully Created the changeRequest.");
			return resultObj;
		} catch (Exception e) {
			throw new Exception("Exception while submitting for replay" + e.getMessage());
		}
	}

	public void publishAudit(Audit audit) {
		auditPublisher.publish(auditTopicName, audit.regHubId, audit);
	}

	public void publishEventEnvelope(EventEnvelope eventEnvelope) {
		xmPublisher.publish(xmTopicName, xmEventKey, eventEnvelope);
	}

	@SuppressWarnings("unchecked")
	public void replayRequestListRecords(List<ChangeRequest> replayRequestList) throws JsonProcessingException {
		Map<String, List<ChangeRequest>> changeRequestMap = replayRequestList.stream()
				.collect(Collectors.groupingBy(ChangeRequest::getFlow));
		String auditEvent = "UserAction-REPLAY";
		String auditResult = "Transaction replayed on the request of user";

		changeRequestMap.forEach((String flow, List<ChangeRequest> requestList) -> {
			List<String> regHubIdList = requestList.stream().map(e -> e.regHubId).collect(Collectors.toList());
			try {
				String responseMessage;
				Map<String, Object> payload = new HashMap<String, Object>();
				payload.put("regHubIds", regHubIdList);
				payload.put("flow", flow);
				payload.put("stream", requestList.get(0).stream);
				
				if(requestList.get(0).stream.equalsIgnoreCase("m2tr")) {
					replayServiceUrl = replayServiceBatchUrl;
				} else if(requestList.get(0).stream.equalsIgnoreCase("m2post")) {
					replayServiceUrl = replayServiceRealTimeUrl;
				}
				
				Map<String, String> response = restClient.doPost(payload, replayServiceUrl, Map.class, false);
				
				if (response != null && "SUCCESS".equalsIgnoreCase(response.get("message"))) {
					responseMessage = "Successfully sent to replay service";
				} else {
					responseMessage = "Error sending transaction to replay service.";
				}
				
				requestList.stream().forEach(request -> {
					Audit replayAuditEvent = createAudit(auditEvent, auditResult, request);
					replayAuditEvent.info.put("message", responseMessage);
					replayAuditEvent.info.put("maker", request.maker);
					replayAuditEvent.info.put("makerComments", request.makerComments);
					
					publishAudit(replayAuditEvent);
				});
			} catch (JsonProcessingException e) {
				// throw e;
			}
		});
	}
}