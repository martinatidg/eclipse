package com.citi.reghub.core.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.util.StringUtils;

public class QueryCriteria {

    private String timeField;

    private List<String> projection = new ArrayList<>();
    private Map<String, Object> filters = new HashMap<>();
    private String sortBy;
    private String sortOrder;
    private Integer offset;
    private Integer limit;
    private LocalDateTime since;
    private LocalDateTime until;

    private static final Logger LOGGER = LoggerFactory.getLogger(QueryCriteria.class);


    public QueryCriteria addFilter(String fieldName, Object value) {
    	LOGGER.trace("Processing addFilter with fieldName='{}', value='{}'", fieldName, value);
        if (value == null || (value instanceof Collection && ((Collection) value).isEmpty())) return this;
        filters.put(fieldName, value);
        return this;
    }

    public QueryCriteria projection(String... fields) {
        if (StringUtils.isEmpty(fields)) return this;
        projection.addAll(Arrays.asList(fields));
        return this;
    }

    public QueryCriteria sort(String sortBy, String sortOrder) {
    	LOGGER.trace("Processing sort request with sortBy='{}', sortOrder='{}'", sortBy, sortOrder);
        this.sortBy = sortBy;
        this.sortOrder = sortOrder;
        return this;
    }

    public QueryCriteria page(Integer offset, Integer limit) {
    	LOGGER.trace("Processing page request with offset='{}', limit='{}'", offset, limit);
        this.offset = offset;
        this.limit = limit;
        return this;
    }

    public QueryCriteria between(String timeField, String receivedSince, String receivedUntil) {
    	LOGGER.trace("Processing page request with timeField='{}', receivedSince='{}', receivedUntil='{}'", timeField, receivedSince, receivedUntil);
        if (StringUtils.isEmpty(timeField) || StringUtils.isEmpty(receivedSince) || StringUtils.isEmpty(receivedUntil)) return this;
        this.timeField = timeField;
        this.since = LocalDateTime.parse(receivedSince, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        this.until = LocalDateTime.parse(receivedUntil, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        return this;
    }

    public Query build(){
    	LOGGER.trace("Processing build query request");
        Query query = new Query();
        filters.forEach((key, value) -> {
            if (value instanceof List) {
                List<String> ids = (List<String>) value;
                query.addCriteria(Criteria.where(key).in(ids));
            }
            else {
                query.addCriteria(Criteria.where(key).is(value));
            }
        });
        if (this.since != null && this.until != null){
            query.addCriteria(Criteria.where(timeField).gte(since).lte(until));
        }
       
        projection.forEach(field -> query.fields().include(field));
        if (offset != null && limit != null) query.skip(offset).limit(limit);
        if (sortOrder != null && sortBy != null) query.with(new Sort(Sort.Direction.fromString(sortOrder), sortBy));
        return query;
    }

}
