package com.citi.reghub.core.entities;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EntityWrapper {
	
		private List<Entity> entityList = new ArrayList<>();
		
		private long totalRecords;
		
		public EntityWrapper() {
			
		}
		
		public EntityWrapper(List<Entity> entityList, long totalRecords) {
			super();
			this.entityList = entityList;
			this.totalRecords = totalRecords;
		} 

		public List<Entity> getEntityList() {
			return entityList;
		}

		public void setEntityList(List<Entity> entityList) {
			this.entityList = entityList;
		}

		public long getTotalRecords() {
			return totalRecords;
		}

		public void setTotalRecords(long totalRecords) {
			this.totalRecords = totalRecords;
		}

}
