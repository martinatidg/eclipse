package com.citi.reghub.core.overriderequest;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.EventTypes;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Document(collection = "overrideRequests")
@CompoundIndexes({
        @CompoundIndex(name = "streamFlow", def = "{'stream': 1, 'flow': 1}")
})
public class OverrideRequest {

    public static final String STATUS_REQUESTED = "REQUESTED";
    public static final String STATUS_APPROVED = "APPROVED";
    public static final String STATUS_REJECTED = "REJECTED";

    @Id
    ObjectId id;
    @Indexed
    public String status; // override status (REQUESTED, APPROVED, REJECTED)

    public Audit audit;
    @Indexed public List<String> regHubIds;
    public String stream;
    public String flow;

    public List<Change> changes;

    @Indexed public String makerComments;           // comments by maker providing details of reasoning
    @Indexed public String checkerComments;         // comments by approver providing details of reasoning

    @Indexed public String maker;                   // soeid of user making the override request for an entity
    @Indexed public String checker;                 // soeid of the user approving the overrides

    @Indexed public LocalDateTime createdTs;        // this can act as time request was made (maker timestamp)
    @Indexed public LocalDateTime lastUpdatedTs;    // this can act as time request was approved (checker timestamp)

   
    public OverrideRequest() {
    }

    public void approve(String checker, String checkerComments){
        this.checker = checker;
        this.checkerComments = checkerComments;
        this.status = STATUS_APPROVED;
        this.lastUpdatedTs = LocalDateTime.now(Clock.systemUTC());
        
    }

    public void reject(String checker, String checkerComments){
        this.checker = checker;
        this.checkerComments = checkerComments;
        this.status = STATUS_REJECTED;
        this.lastUpdatedTs = LocalDateTime.now(Clock.systemUTC());
    }

    public Map<String, Object> updates() {
        Map<String,Object> fields = new HashMap<>();
        changes.forEach(c -> fields.put(c.fieldName,c.newValue));
        return fields;
    }
    
    public Audit toAudit(String eventType){
    	Audit audit = new Audit();
		audit.stream = this.stream;
		audit.flow = this.flow;
		audit.event= eventType;
		if(eventType == EventTypes.MAKER_ENTITY_UPDATE)
			{audit.info.put(
				"changes",
				changes.stream().map(m -> m.toMap())
						.collect(Collectors.toList()));
			audit.info.put("overrideRequestId", id);
			}
		return audit;
		  	  	
    }
    
 }
