package com.citi.reghub.core.overriderequest;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OverrideRequestView {

	private OverrideRequest request;

	public OverrideRequestView(OverrideRequest request) {
		this.request = request;
	}

	public String getId() {
		return request.id.toString();
	}
	public String getStatus() {
		return request.status;
	}

	public List<String> getRegHubIds() {
		return request.regHubIds;
	}
	public String getStream() {
		return request.stream;
	}
	public String getFlow() {
		return request.flow;
	}

	public String getMakerComments() {
		return request.makerComments;
	}
	public String getCheckerComments() {
		return request.checkerComments;
	}
	public String getMaker() {
		return request.maker;
	}
	public String getChecker() {
		return request.checker;
	}


	public LocalDateTime getMakerTs() {
		return request.createdTs;
	}
	public LocalDateTime getCheckerTs() {
		return (request.status != "REQUESTED") ? request.lastUpdatedTs : null;
	}

	public List<Change> getChanges() {
		return request.changes;
	}
}
