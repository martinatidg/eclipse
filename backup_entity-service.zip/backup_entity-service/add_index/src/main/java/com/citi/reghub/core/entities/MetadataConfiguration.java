package com.citi.reghub.core.entities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.metadata.client.MetadataClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;

@Configuration
public class MetadataConfiguration {
	
	@Value("${metadata.service.url}")
    public String metaDataUrl;
    
    
    @Autowired
    public CacheClient cacheClient;
    
    @Autowired
    public RestClient restClient;
    
	
	
	@Bean
	public MetadataClient metadataClient() {
		MetadataClientConfig metaConfig = new MetadataClientConfig();
		metaConfig.put(MetadataClientConfig.METADATA_URL_KEY, metaDataUrl);
		metaConfig.put(MetadataClientConfig.REST_CLIENT, restClient);
		metaConfig.put(MetadataClientConfig.CACHE_CLIENT, cacheClient);
		//metaConfig.put(MetadataClientConfig.STREAM_CODE, "m2tr");
		//metaConfig.put(MetadataClientConfig.FLOW_CODE, "csheq");
		MetadataClient metadataClient = new MetadataClient(metaConfig);
		return metadataClient;
    }

}
