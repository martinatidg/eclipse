package com.citi.reghub.core.entities;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.stream.*;

import org.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.core.io.*;
import org.springframework.data.domain.*;
import org.springframework.data.domain.Sort.*;
import org.springframework.data.mongodb.core.*;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.citi.cmot.armada.report.generator.*;
import com.citi.reghub.core.common.*;
import com.citi.reghub.core.constants.*;
import com.citi.reghub.core.convertors.*;
import com.citi.reghub.core.dto.*;

@RestController
public class EntitiesPostController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EntitiesPostController.class);
	
    @Autowired
    private EntitiesRepository repository;
    
    @Autowired
    private MongoTemplate template;

    @Autowired
    private AnyObjectRepository anyObjectRepository;
    
    @Autowired
    private ConverterService converterService;

    @Autowired
    private EntityExportService entityExportService;
    
    
    @Value("${max.excel.export.record.limit}")
    private String MAX_EXCEl_EXPORT_RECORD_LIMIT;

    @Value("${max.csv.export.record.limit}")
    private String MAX_CSV_EXPORT_RECORD_LIMIT;
    
    @Value("${export.dir.path}")
    private String EXPORT_DIR_PATH;
    
    private static String executionTs = "executionTs";
    
    @PostMapping("/entities")
    public Map<String,String> saveEntity(@RequestBody Entity entity) {
        Entity savedEntity = repository.save(entity);
        //createAudit(entity.id, entity.stream, entity.flow, "addedfromservice", null);
        //createAudit(entity.id, entity.stream, entity.flow, "addedfromservice",  Map<String, String>());
    	LOGGER.debug("Processing saveEntity request with entity='{}'", entity);
        return new HashMap<String,String>(){{
            put("id",savedEntity.id);
            put("status", RestStatus.SUCCESS);
            put("message","Successfully saved entity.");
        }};
    }

    @PostMapping("/entities/{stream}/{flow}/{id}/patch")
    public Map<String,String> patchEntity(@PathVariable String id, @PathVariable String stream,@PathVariable String flow,  @RequestBody Map<String,Object> entity) throws IOException {
        boolean upserted = anyObjectRepository.upsert(id,stream,flow, new PatchObject(entity).getUpdateObject(), Entity.class);

        return new HashMap<String,String>(){{
            put("id",id);
            put("status", RestStatus.SUCCESS);
            put("message","Successfully patched entity.");
        }};
    }
    
	@PostMapping("/entities/transactions")
    public EntityViewWraper getTransactions(@RequestBody TransactionSearchRequestDto transactionSearchRequestDto) {
    	LOGGER.debug("Processing getTransactions with payload= ", transactionSearchRequestDto);
    	
    	Map<String, List<String>> payload = transactionSearchRequestDto.getFilter();
    	Map<String, List<String>> payloadDates = transactionSearchRequestDto.getFilterDates();
    	Map<String, List<String>> payloadTimestamps = transactionSearchRequestDto.getFilterTimestamps();

        QueryCriteria criteria = new QueryCriteria();
        
        if(null != payload) {
        	if(null != payload.get(executionTs)) {
        		List<String> executionTsList = new ArrayList<>();
        		executionTsList = payload.get(executionTs);
        		payload.remove(executionTs);
        		payload.forEach((key, value) -> {
             		criteria.addFilter(key, payload.get(key));
             	});
        		
        		String executionSince = executionTsList.get(0);
        		String executionUntil = executionTsList.get(1);
    	        criteria.between(executionTs, executionSince, executionUntil);
    	       
        	} else {
        		payload.forEach((key, value) -> {
            		criteria.addFilter(key, payload.get(key));
            	});
        	}
        }

        if(null != payloadDates) {
        	payloadDates.forEach((key, value) -> {
        		List<Instant> payloadDate = value.stream()
                        .map(v -> ZonedDateTime.parse(v, DateTimeFormatter.ISO_LOCAL_DATE_TIME.withZone(ZoneId.of("UTC"))).toInstant())
                        .collect(Collectors.toList());
        		criteria.addFilter(key, payloadDate);
        		
        	});
        }

        if(null != payloadTimestamps) {
            payloadTimestamps.forEach((key, value) -> {
                List<Long> payloadTimestamp = value.stream()
                        .map(v -> Long.valueOf(converterService.dateStringToNano(v)))
                        .collect(Collectors.toList());
                criteria.addFilter(key, payloadTimestamp);

            });
        }


        /*String PREFIX = "info.";
        List<String> list = new ArrayList<String>(payload.keySet());
        List<String> infoList = new ArrayList<>();
        
        for(String str : list) {
        	if(str.startsWith(PREFIX)) {
        		infoList.add(str);
        	}
        }
        
        for(String info : infoList){
        	if(payload.containsKey(info)){
        		criteria.addFilter(info, payload.get(info));
        	}
        }*/
        
        if(null != transactionSearchRequestDto.getProjection()) {
        	String[] projectedArray = transactionSearchRequestDto.getProjection().toArray(new String[transactionSearchRequestDto.getProjection().size()]);
        	criteria.projection(projectedArray);
        }
        
        
        Query q = criteria.build();
        
        /*long totalRecords = anyObjectRepository.find(q, Entity.class)
                .map(EntityView::new)
                .collect(Collectors.toList()).size();*/
        
        long totalRecords = template.count(q, Entity.class, "entities");
        
        if(null != transactionSearchRequestDto.getSortBy() && null != transactionSearchRequestDto.getSortOrder()) {
	        criteria.sort(transactionSearchRequestDto.getSortBy(), transactionSearchRequestDto.getSortOrder());
        }
        
        if(null != transactionSearchRequestDto.getOffset() && null != transactionSearchRequestDto.getLimit()) {
        	Integer offSet = Integer.valueOf(transactionSearchRequestDto.getOffset());
        	Integer getLimit = Integer.valueOf(transactionSearchRequestDto.getLimit());
        	criteria.page(offSet*getLimit, getLimit);
        }
        
        Query recordQuery = criteria.build(); 
        List<EntityView> entityViewList = anyObjectRepository.find(recordQuery, Entity.class)
									        .map(EntityView::new)
									        .collect(Collectors.toList());
        EntityViewWraper entityViewWraper = new EntityViewWraper(entityViewList, totalRecords);
        
        return  entityViewWraper;
    }
	
	@PostMapping("/entities/exceptions")
    public EntityWrapper getExceptionWithReasonCodes(@RequestBody TransactionSearchRequestDto transactionSearchRequestDto) {
    	
		LOGGER.debug("Processing getExceptionWithReasonCodes with payload = ", transactionSearchRequestDto);
    	
    	Map<String, List<String>> payload = transactionSearchRequestDto.getFilter();

    	String executionSince = null;
    	
		String executionUntil = null;
		
    	if(null != payload.get(executionTs)) {
	    	List<String> executionTsList = new ArrayList<>();
			executionTsList = payload.get(executionTs);
			executionSince = executionTsList.get(0);
			executionUntil = executionTsList.get(1);
    	}
    	
    	String executionSinceInNano = converterService.dateStringToNano(executionSince);
    	
    	String executionUntilInNano = converterService.dateStringToNano(executionUntil);
    	
    	MatchOperation matchStageWithExecutionTs =  Aggregation.match(new Criteria().and(executionTs).gte(Long.valueOf(executionSinceInNano)).lt(Long.valueOf(executionUntilInNano)));
    	
    	MatchOperation matchStage = null;
    	//Very bad - figure out other way to create criteria dynamically
    	if(null == payload.get("sourceSystem")) {
    		matchStage = Aggregation.match(new Criteria("stream").in(payload.get("stream")).and("status").in(payload.get("status"))
    			.and("flow").in(payload.get("flow")));
    	} else {
        	matchStage = Aggregation.match(new Criteria("stream").in(payload.get("stream")).and("status").in(payload.get("status"))
        		.and("flow").in(payload.get("flow")).and("sourceSystem").in(payload.get("sourceSystem")));
    	}
    	
    	UnwindOperation unwindStage = Aggregation.unwind("$reasonCodes");
    	
		SortOperation sortOperation = null;
		if("asc".equalsIgnoreCase(transactionSearchRequestDto.getSortOrder())){
			 sortOperation = sort(new Sort(Direction.ASC, transactionSearchRequestDto.getSortBy()));
		} else {
			 sortOperation = sort(new Sort(Direction.DESC, transactionSearchRequestDto.getSortBy()));
		}
		
		Aggregation aggregation = null;
    	
		ProjectionOperation projectStage = null;
    	
    	int projectionListSize = transactionSearchRequestDto.getProjection().size();

    	if(projectionListSize == 0) {
    		aggregation = Aggregation.newAggregation(matchStage, matchStageWithExecutionTs, unwindStage, new LimitOperation(transactionSearchRequestDto.getLimit()), sortOperation).withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());
    	} else {
			List<String> topLevelProjectionList = transactionSearchRequestDto.getProjection();
			List<String> infoProjectionList = new ArrayList<>();
			for (String string : topLevelProjectionList) {
				if(string.startsWith("info")) {
					infoProjectionList.add(string);
				}
			}
			topLevelProjectionList.removeIf(s -> s.contains("info"));
			String[] topLevelProjectionListToArray = topLevelProjectionList.toArray(new String[topLevelProjectionList.size()]);
			String[] infoProjectionListToArray = infoProjectionList.toArray(new String[infoProjectionList.size()]);
			Fields infoFields = Aggregation.fields(infoProjectionListToArray);
			projectStage = Aggregation.project(topLevelProjectionListToArray).and("info").nested(infoFields);
			aggregation = Aggregation.newAggregation(matchStage, matchStageWithExecutionTs, unwindStage, new LimitOperation(transactionSearchRequestDto.getLimit()), sortOperation, projectStage).withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());
    	}

    	List<Entity> allEntitiesWithReasonCodes = anyObjectRepository.aggregate(aggregation, "entities", Entity.class);

    	return new EntityWrapper(allEntitiesWithReasonCodes, allEntitiesWithReasonCodes.size());
    }
	

    @PostMapping("/entities/transactions/exportcsv")
    public ResponseEntity<ByteArrayResource> exportTransactionsAsCsv(
            @RequestBody TransactionSearchRequestDto transactionSearchRequestDto) throws IOException {
        LOGGER.debug("Processing exportTransactions as csv with payload= ", transactionSearchRequestDto);

        ResponseEntity<ByteArrayResource> result = null;
        
        QueryCriteria criteria = entityExportService.buildTransactionQueryCriteria(transactionSearchRequestDto);

        List<Entity> entityList = anyObjectRepository.find(criteria.build(), Entity.class).collect(Collectors.toList());
        
        if(entityList.size() <= Integer.parseInt(MAX_CSV_EXPORT_RECORD_LIMIT)) {
            LocalDate currentDate = LocalDate.now();
            String fileName = "RegHub_Transactions_" + currentDate + ".csv";

            File reportFile = generateReportAsCSV(entityList, fileName);

            Path path = Paths.get(reportFile.getAbsolutePath());
            ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));

            HttpHeaders headers = entityExportService.getFileHttpHeaders(fileName);
            headers.add("content-Type", "text/csv");
            
            result = ResponseEntity.ok().headers(headers)
                    .contentType(MediaType.parseMediaType("application/octet-stream")).body(resource);

            if (reportFile.exists()) {
                reportFile.delete();
            }
        }

        return result;
    }

    @PostMapping("/entities/transactions/exporttoexcel")
    public ResponseEntity<InputStreamResource> exportTransactionsAsExcel(
            @RequestBody TransactionSearchRequestDto transactionSearchRequestDto) throws IOException {

        LOGGER.debug("Processing exportTransactions with payload= ", transactionSearchRequestDto);

        NanoLongToLocalDateConvertor longToDateConvertor = new NanoLongToLocalDateConvertor();
        ResponseEntity<InputStreamResource> result = null;
        InputStream inputStream = null;

        QueryCriteria criteria = entityExportService.buildTransactionQueryCriteria(transactionSearchRequestDto);

        List<Entity> entityList = anyObjectRepository.find(criteria.build(), Entity.class).map(e -> {
            e.info.forEach((key, value) -> {
                if (key.endsWith("Ts") && value != null) {
                    LocalDateTime dateTime = longToDateConvertor.convert(Long.parseLong(value.toString()));
                    String formattedDateTime = entityExportService.formatDateTimeToNanoDateTime(dateTime);
                    e.info.put(key, formattedDateTime);
                }
            });
            return e;
        }).collect(Collectors.toList());

        if (entityList.size() <= Integer.parseInt(MAX_EXCEl_EXPORT_RECORD_LIMIT)) {

            LocalDate currentDate = LocalDate.now();
            String fileName = "RegHub_Transactions_" + currentDate + ".xlsx";

            Report excelReport = entityExportService.generateReportAsExcel(entityList, fileName);
            inputStream = excelReport.getReportInputStream();

            InputStreamResource resource = new InputStreamResource(inputStream);

            HttpHeaders headers = entityExportService.getFileHttpHeaders(fileName);
            headers.add("content-Type", "application/vnd.ms-excel");
            
            result = ResponseEntity.ok().headers(headers)
                    .contentType(MediaType.parseMediaType("application/octet-stream")).body(resource);
        } else {
            LOGGER.debug("CSV MAX LIMIT EXCEED");
        }

        return result;
    }
    
    public File generateReportAsCSV(List<Entity> entityList, String fileName) {
        Report report = null;
        File file = null;
        try {

            Map<String, Object> exportCSVEntityMap = new HashMap<String, Object>();
            Header header = entityExportService.getCSVHeader();

            exportCSVEntityMap.put(RGConstants.DELIMIT_HEADER_KEY, header);
            exportCSVEntityMap.put(RGConstants.DELIMIT_RECORDS_KEY, entityList);
            exportCSVEntityMap.put(RGConstants.DELIMIT_REPORT_NAME_KEY, fileName);
            exportCSVEntityMap.put(RGConstants.DELIMIT_REPORT_PATH_KEY, EXPORT_DIR_PATH);

            ReportGenerator reportGenerator = ReportGenerator.newInstance("export_transactions_csv");

            report = reportGenerator.generateReport(exportCSVEntityMap);
            report.getReportInputStream().close();

            file = report.getReportFile();

        } catch (ReportGenerationException e) {
            LOGGER.error("ReportGenerationException while generating CSV.", e);
        } catch (IOException e) {
            LOGGER.error("ReportGenerationException while generating CSV.", e);
        }

        return file;
    }
}