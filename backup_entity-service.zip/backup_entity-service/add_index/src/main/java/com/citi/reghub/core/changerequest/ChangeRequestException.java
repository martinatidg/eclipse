package com.citi.reghub.core.changerequest;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChangeRequestException {
	
	@JsonProperty("exceptionId")
	public String exceptionId;
	
	@JsonProperty("reghubId")
	public String reghubId;
	
	@JsonProperty("regReportingRef")
	public String regReportingRef;
	
	@JsonProperty("flow")
	public String flow;
	
	@JsonProperty("sourceId")
	public String sourceId;
	
	public ChangeRequestException() {}
	
	public ChangeRequestException (String exceptionId, String reghubId, String regReportingRef, String flow, String sourceId) {
		super();
		this.exceptionId = exceptionId;
		this.reghubId = reghubId;
		this.regReportingRef = regReportingRef;
		this.flow = flow;
		this.sourceId = sourceId;
	}
	
}
