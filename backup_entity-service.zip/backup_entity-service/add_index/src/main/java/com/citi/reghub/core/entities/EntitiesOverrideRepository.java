package com.citi.reghub.core.entities;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EntitiesOverrideRepository extends MongoRepository<EntityOverride, String> {

	Optional<Entity> findByIdAndStreamAndFlow(String regHubId, String stream,
			String flow);
	
	Optional<Entity> findById(String regHubId);

}
