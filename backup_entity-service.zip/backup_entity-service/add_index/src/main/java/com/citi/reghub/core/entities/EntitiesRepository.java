package com.citi.reghub.core.entities;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EntitiesRepository extends MongoRepository<Entity, String> {

    Optional<Entity> findByIdAndStreamAndFlow(String id, String stream, String flow);

    List<Entity> findBySourceIdAndStreamAndFlow(String sourceId, String stream, String flow);

}
