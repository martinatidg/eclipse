package com.citi.reghub.core.constants;

public final class ChangeRequestType {
	public static final String CHANGE_REQUEST_TYPE_EXCEPTION = "EXCEPTION";
    public static final String CHANGE_REQUEST_TYPE_NACK = "NACK";
}
