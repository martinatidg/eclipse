package com.citi.reghub.core.entities;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EntityViewWraper {
	
	private List<EntityView> entityViewList = new ArrayList<>();
	
	private long totalRecords;
	
	public EntityViewWraper(List<EntityView> entityViewList, long totalRecords) {
		super();
		this.entityViewList = entityViewList;
		this.totalRecords = totalRecords;
	}

	public List<EntityView> getEntityViewList() {
		return entityViewList;
	}

	public void setEntityViewList(List<EntityView> entityViewList) {
		this.entityViewList = entityViewList;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}
}
