package com.citi.reghub.core.entities;


import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.citi.reghub.core.common.AnyObjectRepository;
import com.citi.reghub.core.common.PatchObject;
import com.citi.reghub.core.constants.RestStatus;

@RestController
public class EntitiesOverrideController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EntitiesOverrideController.class);

    @Autowired
    private EntitiesOverrideRepository repository;

    @Autowired
    private AnyObjectRepository anyObjectRepository;
 
    private Entity entityObj = new Entity();
    
    @GetMapping("/entities/override/{regHubId}")
    public EntityView getEntity(@PathVariable String regHubId
    						, @RequestParam String stream, @RequestParam String flow) {
        Entity entity = repository.findByIdAndStreamAndFlow(regHubId, stream, flow)
                .orElse(entityObj);
        
        return new EntityView(entity);
    }


    @PostMapping("/entities/{stream}/{flow}/{id}/override/patch")
    public Map<String,String> patchEntity(@PathVariable String id,@PathVariable String stream,
    		@PathVariable String flow, @RequestBody Map<String,Object> fields) throws IOException {
        anyObjectRepository.upsert(id,stream, flow, new PatchObject(fields).getUpdateObject(), EntityOverride.class);

        return new HashMap<String,String>(){{
            put("id",id);
            put("message","Successfully patched entity override.");
            put("status", RestStatus.SUCCESS);
        }};
    }
    
    @GetMapping("/entities/{regHubId}/override")
    public EntityView getEntity(@PathVariable String regHubId) {
        Entity entity = repository.findById(regHubId)
                .orElse(entityObj);
        
        return new EntityView(entity);
    }
    
    
}
