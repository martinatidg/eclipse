package com.citi.reghub.core.common;

import org.springframework.boot.context.properties.ConfigurationProperties;

import com.citi.reghub.core.event.EventEnvelope;
import com.citi.reghub.core.kafka.KafkaProducerConfiguration;

@ConfigurationProperties(prefix = "xm")
public class XMPublisherProperties extends KafkaProducerConfiguration<String, EventEnvelope>{

}
