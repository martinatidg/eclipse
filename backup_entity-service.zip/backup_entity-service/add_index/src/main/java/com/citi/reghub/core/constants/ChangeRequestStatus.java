package com.citi.reghub.core.constants;

public final class ChangeRequestStatus {
	public static final String STATUS_OPEN = "OPEN";
    public static final String STATUS_APPROVED = "APPROVED";
    public static final String STATUS_REJECTED = "REJECTED";
}
