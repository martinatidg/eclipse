package com.citi.reghub.core.overriderequest;


import com.citi.reghub.core.Audit;
import com.citi.reghub.core.AuditPublisher;
import com.citi.reghub.core.common.AnyObjectRepository;
import com.citi.reghub.core.common.PatchObject;
import com.citi.reghub.core.common.QueryCriteria;
import com.citi.reghub.core.constants.RestStatus;
import com.citi.reghub.core.constants.EventTypes;
import com.citi.reghub.core.entities.Entity;
import com.citi.reghub.core.entities.EntityOverride;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import java.io.IOException;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.citi.reghub.core.entities.EntitiesGetController.ISO_DATE_TIME_REGEX;
import static com.citi.reghub.core.overriderequest.OverrideRequest.STATUS_REQUESTED;

@RestController
public class OverrideRequestController {

    @Autowired
    private OverrideRequestRepository repository;

    @Autowired
    private AnyObjectRepository anyObjectRepository;
    
    public Audit audit;
    
    @Autowired
    private AuditPublisher auditPublisher;
    
    @Value("${audit.topic.name}")
	private String auditTopicName;
    
    private String stream, flow;
    
     
    @GetMapping("/overrideRequests")
    public List<OverrideRequestView> find(@RequestParam String stream, @RequestParam String flow,

                                        @RequestParam(required = false) List<String> regHudIds,
                                        @RequestParam(required = false) String status,
                                        @RequestParam(required = false) String maker,

                                        @Valid @Pattern(regexp = ISO_DATE_TIME_REGEX)
                                        @RequestParam(required = false) String since,
                                        @Valid @Pattern(regexp = ISO_DATE_TIME_REGEX)
                                        @RequestParam(required = false) String until,

                                        @RequestParam(required = false, defaultValue = "lastUpdatedTs") String sortBy,
                                        @RequestParam(required = false, defaultValue = "desc") String sortOrder,
                                        @RequestParam(required = false, defaultValue = "0") Integer offset,
                                        @RequestParam(required = false, defaultValue = "100") Integer limit) {

        QueryCriteria criteria = new QueryCriteria()
                .addFilter("stream", stream)
                .addFilter("flow", flow)
                .addFilter("status", status)
                .addFilter("maker", maker)
                .addFilter("regHudIds", regHudIds)
                .between("lastUpdatedTs", since,until)
                .sort(sortBy, sortOrder)
                .page(offset, limit);

        return anyObjectRepository.find(criteria.build(),OverrideRequest.class).map(OverrideRequestView::new).collect(Collectors.toList());

    }


    @PostMapping("/overrideRequests")
    public Map<String,String> insert(@RequestBody OverrideRequest request) throws IOException {
        request.status = STATUS_REQUESTED;
        request.createdTs = LocalDateTime.now(Clock.systemUTC());
        request.lastUpdatedTs = request.createdTs;
        OverrideRequest saved = repository.insert(request);
            
        streamRequestAndCreatePublishAudit(request, EventTypes.MAKER_ENTITY_UPDATE, "REQUEST");
        

        return new HashMap<String,String>(){{
            put("id",saved.id.toString());
            put("status", RestStatus.SUCCESS);
            put("message","Successfully saved override request.");
        }};
    }

    @PostMapping("/overrideRequests/approve")
    public Map<String,Object> approve(@RequestBody Map<String,Object> request) throws IOException {
        List<String> ids = (List<String>) request.get("ids");
        String checker = (String) request.get("checker");
        String comments = (String) request.get("checkerComments");

        ids.stream().parallel()
                .map(id -> repository.findById(new ObjectId(id)))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .peek(o -> o.approve(checker, comments))
                .peek(o -> repository.save(o))
                .peek(o -> patchOverrideEntity(o))
                .peek(o -> markEntityAsOverridden(o))
                .forEach(o -> streamRequestAndCreatePublishAudit(o, EventTypes.CHECKER_ENTITY_UPDATE, "APPROVED"));

        return new HashMap<String,Object>(){{
            put("ids",ids);
            put("status", RestStatus.SUCCESS);
            put("message","Successfully approved override requests.");
        }};
    }

    @PostMapping("/overrideRequests/reject")
    public Map<String,Object> reject(@RequestBody Map<String,Object> request) throws IOException {
        List<String> ids = (List<String>) request.get("ids");
        String userId = (String) request.get("checker");
        String comments = (String) request.get("checkerComments");

        ids.stream().parallel()
                .map(id -> repository.findById(new ObjectId(id)))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .peek(o -> o.reject(userId, comments))
                .peek(o -> repository.save(o))
                .forEach(o -> streamRequestAndCreatePublishAudit(o, EventTypes.CHECKER_ENTITY_UPDATE, "REJECTED"));;

        return new HashMap<String,Object>(){{
            put("ids",ids);
            put("status", RestStatus.SUCCESS);
            put("message","Successfully rejected override requests.");
        }};
    }

    private void markEntityAsOverridden(OverrideRequest request) {
    	
    	stream = request.stream;
    	flow = request.flow;
        request.regHubIds.forEach(regHubId -> {
            Update update = new Update().addToSet("instructions", "OVERRIDDEN");
            anyObjectRepository.upsert(regHubId, stream, flow, update, Entity.class);
            });
        
        
    }

    private void patchOverrideEntity(OverrideRequest request) {
    	
    	stream = request.stream;
    	flow = request.flow;
        request.regHubIds.forEach(regHubId -> {
            Update update = new PatchObject(request.updates()).getUpdateObject();
            anyObjectRepository.upsert(regHubId,stream, flow, update, EntityOverride.class);
        });
    }
    
   
    private void streamRequestAndCreatePublishAudit(OverrideRequest request, String eventType, String result){
    	request.regHubIds.stream()
		.forEach(regHubId -> {
			createAndPublishAudit(regHubId,eventType, request.toAudit(eventType), result);
		});
    }
    
    public void createAndPublishAudit(String regHubId, String eventType, Audit audit, String result){
    	audit.regHubId =regHubId;
        audit.result= result;
        auditPublisher.publish(auditTopicName, audit.regHubId, audit);
       
    }
    
}
