package com.citi.reghub.core.changerequest;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Update;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.changerequest.Change;
import com.citi.reghub.core.constants.ChangeRequestStatus;

@Document(collection = "changeRequests")
@CompoundIndexes({
        @CompoundIndex(name = "streamFlow", def = "{'stream': 1, 'flow': 1}")
})
public class ChangeRequest {
	
	@Id 
    public ObjectId id;
    
    public String status; // override status (REQUESTED, APPROVED, REJECTED)
    
    public String exceptionId;

    public String regHubId;
    
    public String regReportingRef;
    
    @Indexed 
    public String reasonCode;
    
    public String description;
    
    public List<Change> attributes;
    
    @Indexed 
    public String maker;
    
    public String makerComments;
    
    public String checker;
    
    public String checkerComments;
    
    @Indexed 
    public String stream;
    
    @Indexed 
    public String flow;
    
    @Indexed 
    public String sourceId;
    
    public String requestAction;
    
    @Indexed 
    public LocalDateTime createdTs;
    
	public LocalDateTime lastUpdatedTs;
	
	public String type;
    
    public ChangeRequest() {
		super();
		this.createdTs = LocalDateTime.now(Clock.systemUTC());
	}
    
    public ChangeRequest(String exceptionId, String regHubId, String regReportingRef, String reasonCode,
			List<Change> attributes, String maker, String makerComments, String checker, String checkerComments,
			String stream, String flow, String sourceId, String requestAction, String type, String description) {

		this.id = new ObjectId();
		this.status = ChangeRequestStatus.STATUS_OPEN;
		this.exceptionId = exceptionId;
		this.regHubId = regHubId;
		this.regReportingRef = regReportingRef;
		this.reasonCode = reasonCode;
		this.attributes = attributes;
		this.maker = maker;
		this.makerComments = makerComments;
		this.checker = checker;
		this.checkerComments = checkerComments;
		this.stream = stream;
		this.flow = flow;
		this.sourceId = sourceId;
		this.requestAction = requestAction;
		this.createdTs = LocalDateTime.now(Clock.systemUTC());
		this.lastUpdatedTs = this.createdTs;
		this.type = type;
		this.description = description;
	}
    
    public Update approve(String checker, String checkerComments) {
		this.checker = checker;
		this.checkerComments = checkerComments;
		this.status = ChangeRequestStatus.STATUS_APPROVED;
		this.lastUpdatedTs = LocalDateTime.now(Clock.systemUTC());
		return generateUpdate();
	}

	public Update reject(String checker, String checkerComments) {
		this.checker = checker;
		this.checkerComments = checkerComments;
		this.status = ChangeRequestStatus.STATUS_REJECTED;
		this.lastUpdatedTs = LocalDateTime.now(Clock.systemUTC());
		return generateUpdate();
	}

	public Update generateUpdate() {
		Update update = new Update();
		update.set("checker", checker)
			.set("checkerComments", checkerComments)
			.set("status", status)
			.set("lastUpdatedTs", lastUpdatedTs);
		return update;
	}
	
	public Map<String, Object> updates() {
		Map<String, Object> fields = new HashMap<>();
		attributes.forEach(a -> fields.put(a.fieldName, a.newValue));
		return fields;
	}

    public Audit toAudit(String event, String result) {
		Audit audit = new Audit();
		audit.regHubId = this.regHubId;
		audit.stream = this.stream;
		audit.flow = this.flow;
		audit.event = event;
		audit.result = result;
		return audit;
	}

	public String getFlow() {
		return flow;
	}

	public String getRequestAction() {
		return requestAction;
	}

	public void setRequestAction(String requestAction) {
		this.requestAction = requestAction;
	}
}
