package com.citi.reghub.core.overriderequest;

import java.util.HashMap;
import java.util.Map;

public class Change {
	
    public String fieldName;
    public String oldValue;
    public String newValue;
    public String reasonCode;

    public Change() {
    }

    public Change(String fieldName, String oldValue, String newValue, String reasonCode) {
        this.fieldName = fieldName;
        this.oldValue = oldValue;
        this.newValue = newValue;
        this.reasonCode = reasonCode;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getOldValue() {
        return oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

    public String getReasonCode() {
        return reasonCode;
    }

    
   public Map<String,String> toMap(){
	   Map<String,String> map = new HashMap<String, String>();
	   map.put("fieldName", fieldName);
	   map.put("oldValue", oldValue);
	   map.put("newValue", newValue);
	   map.put("reasonCode", reasonCode);
	   return map;
   }
}
