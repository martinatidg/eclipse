package com.citi.reghub.core.event.exception;

public enum FunctionalOwner {
	
	BUS("BUS"),
	TECH("TECH"),
	SMC("SMC"),
	AMC("AMC"),
	ORC("ORC");

	final String value;

	FunctionalOwner(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static FunctionalOwner fromValue(String v) {
		for (FunctionalOwner c : FunctionalOwner.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
