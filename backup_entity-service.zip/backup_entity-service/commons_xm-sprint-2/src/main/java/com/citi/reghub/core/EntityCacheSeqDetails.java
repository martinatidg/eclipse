package com.citi.reghub.core;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.hazelcast.nio.serialization.Portable;
import com.hazelcast.nio.serialization.PortableReader;
import com.hazelcast.nio.serialization.PortableWriter;

public class EntityCacheSeqDetails implements Portable {
	
	public String sourceStatus;
	public LocalDateTime publishedTs;
	public String status;
	public String sourceId;
	private String regReportingRef;
	
	public EntityCacheSeqDetails(String sourceStatus, LocalDateTime publishedTs, String status, String sourceId) {
		super();
		this.sourceStatus = sourceStatus;
		this.publishedTs = publishedTs;
		this.status = status;
		this.sourceId = sourceId;
	}
	
	public EntityCacheSeqDetails(String sourceStatus, LocalDateTime publishedTs, String status, String sourceId, String regReportRef) {
		super();
		this.sourceStatus = sourceStatus;
		this.publishedTs = publishedTs;
		this.status = status;
		this.sourceId = sourceId;
		this.regReportingRef = regReportRef;
	}
	
	public EntityCacheSeqDetails(Entity message){
		sourceStatus=message.sourceStatus;
		publishedTs= message.publishedTs;
		status= message.status;
		sourceId = message.sourceId;
		regReportingRef = message.regReportingRef;
	}
	
	public EntityCacheSeqDetails(){
	}

	@Override
	public int getClassId() {
		return 1;
	}

	@Override
	public int getFactoryId() {
		return 1;
	}

	public String getSourceStatus() {
		return sourceStatus;
	}

	public void setSourceStatus(String sourceStatus) {
		this.sourceStatus = sourceStatus;
	}

	public LocalDateTime getPublishedTs() {
		return publishedTs;
	}

	public void setPublishedTs(LocalDateTime publishedTs) {
		this.publishedTs = publishedTs;
	}

	public void setRegReportingRef(String r) {
		this.regReportingRef = r;
	}
	
	public String getRegReportingRef() {
		return this.regReportingRef;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public void readPortable(PortableReader reader) throws IOException {
		sourceStatus =  reader.readUTF("sourceStatus");
		status = reader.readUTF("status");
		sourceId = reader.readUTF("sourceId");
		String publishedTsAsString = reader.readUTF("publishedTs");
        if(publishedTsAsString != null) {
        	publishedTs = LocalDateTime.parse(publishedTsAsString, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
        }	

        try {
        	regReportingRef = reader.readUTF("regReportingRef");
        } catch (Throwable t) {
        	// suppress for backward compatibility
        }

	}

	@Override
	public void writePortable(PortableWriter writer) throws IOException {
		if(sourceStatus != null)
			writer.writeUTF("sourceStatus", sourceStatus);
		if(publishedTs != null) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
            writer.writeUTF("publishedTs", publishedTs.format(formatter));
        }
		if(status != null)
			writer.writeUTF("status", status);
		if(sourceId != null)
			writer.writeUTF("sourceId", sourceId);
		if(regReportingRef != null)
			writer.writeUTF("regReportingRef", regReportingRef);
	}

}
