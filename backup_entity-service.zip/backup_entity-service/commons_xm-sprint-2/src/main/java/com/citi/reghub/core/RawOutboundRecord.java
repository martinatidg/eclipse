package com.citi.reghub.core;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.UUID;

// TODO; do we need to extends from InfoablePojo

public class RawOutboundRecord extends InfoablePojo {

	public static final String NO_FILE_NAME = "NULL";

	public class OutboundMessageType {
		public static final String FIX = "fix";
		public static final String CSV_FORMAT = "csv";
		public static final String XML_FORMAT = "xml";
	}

	public String _id;
	public String regHubId;
	public String correlationId; //to be used for storing the reporting ID
	public String stream; // reporting stream (always 4 char) e.g. M2TR, M2PR,
							// M2PO
	public String flow; // reporting asset class / product (always 3 char) e.g.
						// CEQ (cash equities), CFI (cash fixed income)

	public LocalDateTime sendTs;
	public String sendTo;
	public String reportedMessageType;
	public String reportedMessage;
	public String fileName;
	public String responseMessage;
	public String ackId;
	public LocalDateTime responseTs;
	public String intmdResponse;
	public LocalDateTime intmdResponseTs;
	public String message;
	public String messageType;
	public String sourceId;
	public String regReportingRef;

	public RawOutboundRecord() {
		_id = UUID.randomUUID().toString();
		this.fileName = NO_FILE_NAME;
	}

	public RawOutboundRecord(Entity entity) {
		_id = UUID.randomUUID().toString();
		this.sendTs = LocalDateTime.now(Clock.systemUTC());
		this.fileName = NO_FILE_NAME;
		this.flow = entity.flow;
		this.regHubId = entity.regHubId;
		this.stream = entity.stream;
	}

	@Override
	public String toString() {
		return "RawOutboundEntity [_id=" + _id + ", regHubId=" + regHubId + ", correlationId="+ correlationId + ", stream="
				+ stream + ", flow=" + flow + ", sendTs=" + sendTs + ", sendTo=" + sendTo + ", reportedMessageType="
				+ reportedMessageType + ", reportedMessage=" + reportedMessage + ", fileName=" + fileName + ", responseMessage=" + responseMessage
				+ ", ackId=" + ackId + ", responseTs=" + responseTs + ", intmdResponse=" + intmdResponse + ", intmdResponseTs=" + intmdResponseTs + "]";
	}
}
