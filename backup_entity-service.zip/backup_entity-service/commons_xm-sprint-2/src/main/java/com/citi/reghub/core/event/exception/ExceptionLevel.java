package com.citi.reghub.core.event.exception;

public enum ExceptionLevel {
	
	WARNS("warning"),
	EXCEPTION("exception"),
	REJECT("reject");

	final String value;

	ExceptionLevel(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ExceptionLevel fromValue(String v) {
		for (ExceptionLevel c : ExceptionLevel.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
