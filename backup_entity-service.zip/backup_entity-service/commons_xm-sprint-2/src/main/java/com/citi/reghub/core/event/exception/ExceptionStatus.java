package com.citi.reghub.core.event.exception;

public enum ExceptionStatus {
	
	OPEN("OPEN"),
	ACTED("ACTED"),
	PENDING("PENDING"),
	CLOSED("CLOSED");

	final String value;

	ExceptionStatus(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ExceptionStatus fromValue(String v) {
		for (ExceptionStatus c : ExceptionStatus.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
