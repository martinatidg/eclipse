package com.citi.reghub.core.entity.client;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.fasterxml.jackson.core.JsonProcessingException;


public class EntityClient {

	private EntityClientConfig entityClientConfig;
	public static Logger LOGGER = LoggerFactory.getLogger(EntityClient.class);

	public EntityClient(EntityClientConfig entityClientConfig) {

		if(entityClientConfig == null) LOGGER.warn("Entity client config passed is null, using default configuration");
		this.entityClientConfig = (entityClientConfig == null ? new EntityClientConfig() : entityClientConfig);
		if (!this.entityClientConfig.containsKey(MetadataClientConfig.METADATA_URL_KEY))
			this.entityClientConfig.setDefaultMetadataUrl();
		LOGGER.info("Instantiated Enrichment client instance with config='{}'", entityClientConfig);
	}

	private String prepareEntityUrl(String metadataName) {
		return String.format(entityClientConfig.getEntityUrl(), metadataName);
	}

	public Entity getOverriddenEntityFromService(String reghubId) {
		LOGGER.debug("Hitting Entity Service for reghubId='{}'", reghubId);
		Entity entity = (Entity) entityClientConfig.getRestClient().get(prepareEntityUrl(reghubId), Entity.class);
		/*if (entity == null) {
			RuntimeException ex = new RuntimeException("Entity Not found for the specified reghubId");
			LOGGER.error("Entity not found for the reghubId='{}'", reghubId, ex);
			throw ex;
		}*/
		return entity;
	}

	public List<Map> getEntitySourceUIdsByReghubIds(Map payload) throws JsonProcessingException {
		LOGGER.debug("Hitting Entity Service for payload='{}'", payload);
		List<Map> entity =  entityClientConfig.getRestClient().doPostReturnValues(payload , entityClientConfig.getEntityUrl(), Map.class);
		if (entity == null){
			RuntimeException ex = new RuntimeException("Entity Not found for the specified payload");
			LOGGER.error("Entity not found for the payload='{}'", payload, ex);
			throw ex;
		}
		return entity;
	}

	public Entity getLatestReportedEntityBySourceId(String sourceId , String stream , String flow) {
		LOGGER.debug("Hitting Entity Service for sourceId='{}', stream='{}', flow='{}'", sourceId, stream, flow);
		String restParam = "?stream="+stream+"&flow="+flow+"&sourceId="+sourceId+"&status="+EntityStatus.REPORTED+"&limit=1";
		List<Entity> entity = (List<Entity>) entityClientConfig.getRestClient().getValues(entityClientConfig.getEntityUrl()+restParam, Entity.class);
		return entity.get(0);
	}

	public Entity getLatestEntityBySourceId(String sourceId) {
		LOGGER.debug("Hitting Entity Service for sourceId='{}'", sourceId);
		String restParam = "?sourceId=" + sourceId + "&limit=1" + "&summaryView=" + false;
		List<Entity> entity = (List<Entity>) entityClientConfig.getRestClient().getValues(entityClientConfig.getEntityUrl()+restParam, Entity.class);

		return entity.get(0);
	}
}
