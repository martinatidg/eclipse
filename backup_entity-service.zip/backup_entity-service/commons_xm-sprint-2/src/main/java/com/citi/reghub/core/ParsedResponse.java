package com.citi.reghub.core;

import java.io.Serializable;

public class ParsedResponse implements Serializable {
	
	private static final long serialVersionUID = -4257290001467612407L;
	public String sourceId;
	public String ackId;
	public int trdRptStatus;
	public String stream;
	public String flow;
	public int rejectReason;
	public String msgType;
	public Long sendTs;
	public String regReportingRef;
	public String rejectionMessage;
	
	
	@Override
	public String toString() {
		return "ParsedResponse [sourceId=" + sourceId + ", ackId=" + ackId + ", trdRptStatus=" + trdRptStatus
				+ ", stream=" + stream + ", flow=" + flow + ", rejectReason=" + rejectReason + ", msgType=" + msgType
				+ ", sendTs=" + sendTs + ", regReportingRef=" + regReportingRef + ", rejectionMessage="
				+ rejectionMessage + "]";
	}
}
