package com.citi.reghub.core.refdata.client;

import java.util.ArrayList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.cache.util.MapName;
import com.citi.ocean.dataobject.account.OceanAccountSummary;
import com.citi.reghub.core.QueryBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gemstone.gemfire.cache.query.SelectResults;

public class RefdataAccountClient implements RefdataInterface {

	public static Logger LOGGER = LoggerFactory.getLogger(RefdataSecurityClient.class);

	private final ObjectMapper mapper;
	private final OceanGemfireCacheClient oceanGemfireCacheClient;

	public RefdataAccountClient(final OceanGemfireCacheClient oceanGemfireCacheClient) {
		this.oceanGemfireCacheClient = oceanGemfireCacheClient;
		mapper = new ObjectMapper();
	}

	@Override
	public Map<String, Object> getData(String identifier, Object value) {
		try {
			AccountIdentifier inputIdentifier = AccountIdentifier.valueOf(identifier.toUpperCase());
			QueryBuilder query = new QueryBuilder().column("*").from(MapName.MAP_REFERENCE_ACCOUNT_OCEAN_ACCOUNT)
					.where(String.format(inputIdentifier.getCriteria(), value));

			SelectResults<OceanAccountSummary> searchResult = oceanGemfireCacheClient
					.getDataByGemfireQuery(query.toString());
			ArrayList<OceanAccountSummary> list = (ArrayList<OceanAccountSummary>) searchResult.asList();
			// temporary logic: need to confirm with BA's in case multiple records are
			// received in account lookup
			return list != null && !list.isEmpty() ? mapper.convertValue(list.get(0), Map.class) : null;
		} catch (IllegalArgumentException e) {
			LOGGER.error("Invalid input Account Identifier: '{}'", identifier, e);
			throw new RuntimeException("Invalid input Account Identifier: " + identifier);
		}
	}

}
