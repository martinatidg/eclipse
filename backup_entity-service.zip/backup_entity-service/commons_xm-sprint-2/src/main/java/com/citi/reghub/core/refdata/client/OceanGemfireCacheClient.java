package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.cache.client.MapService;
import com.citi.ocean.cache.util.MapName;
import com.citi.ocean.dataobject.product.IsinOceanProductInfo;
import com.citi.ocean.dataobject.product.OceanProductInfo;
import com.citi.ocean.dataobject.product.OceanProductSummary;
import com.gemstone.gemfire.cache.query.FunctionDomainException;
import com.gemstone.gemfire.cache.query.NameResolutionException;
import com.gemstone.gemfire.cache.query.Query;
import com.gemstone.gemfire.cache.query.QueryInvocationTargetException;
import com.gemstone.gemfire.cache.query.QueryService;
import com.gemstone.gemfire.cache.query.SelectResults;
import com.gemstone.gemfire.cache.query.TypeMismatchException;

public class OceanGemfireCacheClient {

	public static final String ERROR_MSG = "Exception occurred while fetching response from Ocean Gemfire Region %s, Identifier %s, IdentifierValue %s, Error %s";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OceanGemfireCacheClient.class);

	private QueryService queryService;

	private Map<Long, OceanProductSummary> productMap;
	private Map<Long, OceanProductInfo> fiiMap;
	private Map<String, OceanProductInfo> cusipMap;
	private Map<String, OceanProductInfo> smcpMap;
	private Map<String, IsinOceanProductInfo> isinMap;

	private Map<String, String> config;

	public OceanGemfireCacheClient(final Map<String, String> config) {
		this.config = config;
		if (config != null && !config.containsKey("refdata.cache.xmlpath")) {
			setCacheConfig(RefdataClient.GEMFIRE_CACHE_XML_VALUE);
		} else {
			String refdataConfigXml = config.get("refdata.cache.xmlpath");
			setCacheConfig(refdataConfigXml);
		}

		try {
			initilizeGemfireCache();
		} catch (Exception e) {}
	}

	private void initilizeGemfireCache() throws Exception {
		try {
			queryService = MapService.getQueryService();

			productMap = MapService.get(MapName.MAP_REFERENCE_PRODUCT_OCEAN_PRODUCT);
			isinMap = MapService.get(MapName.MAP_REFERENCE_ISIN_PRODUCT);
			cusipMap = MapService.get(MapName.MAP_REFERENCE_PRODUCT_CUSIP);
			smcpMap = MapService.get(MapName.MAP_REFERENCE_PRODUCT_SMCP);
			fiiMap = MapService.get(MapName.MAP_REFERENCE_PRODUCT_FII);	
		} catch (Exception e) {
			LOGGER.error("Error connecting Ocean Gemfire cache.", e);
			throw e;
		}
		
	}

	private void setCacheConfig(String cacheXmlValue) {
		System.setProperty(RefdataClient.GEMFIRE_CACHE_XML_KEY, cacheXmlValue);
	}

	public boolean isCacheAvailable() throws Exception {
		if (!isAlive()) {
			return reconnectGemfireCache();
		}
		return true;
	}

	private boolean reconnectGemfireCache() throws Exception {
		try {
			if (config != null && !config.containsKey("refdata.cache.xmlpath")) {
				setCacheConfig(RefdataClient.GEMFIRE_CACHE_XML_VALUE);
			} else {
				String refdataConfigXml = config.get("refdata.cache.xmlpath");
				setCacheConfig(refdataConfigXml);
			}
			initilizeGemfireCache();
			return true;
		} catch (Exception e) {
			LOGGER.error("Error connecting Ocean Gemfire cache.", e);
			throw e;
		}
	}

	public boolean isAlive() {
		if (productMap == null || isinMap == null || cusipMap == null || smcpMap == null || fiiMap == null) {
			return false;
		} else {
			return true;	
		}		
	}

	public OceanProductSummary getByOceanProductId(Long oceanId) {
		try {
			isCacheAvailable();
			return productMap.get(oceanId);
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_OCEAN_PRODUCT, "OceanId", oceanId, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsByFII(Long fii) {
		try {
			isCacheAvailable();
			return getByOceanProductId(fiiMap.get(fii).getOceanProductId());
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_FII, "FII", fii, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsByCUSIP(String cusip) {
		try {
			isCacheAvailable();
			return getByOceanProductId(cusipMap.get(cusip).getOceanProductId());
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_CUSIP, "CUSIP", cusip, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsBySMCP(String smcp) {
		try {
			isCacheAvailable();
			return getByOceanProductId(smcpMap.get(smcp).getOceanProductId());
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_PRODUCT_SMCP, "SMCP", smcp, e.getMessage()));
		}
	}

	public OceanProductSummary getProductsByISIN(String isin) {
		try {
			isCacheAvailable();
			return getByOceanProductId(isinMap.get(isin).getOceanProductId());
		} catch (Exception e) {
			throw new RuntimeException(String.format(ERROR_MSG, MapName.MAP_REFERENCE_ISIN_PRODUCT, "ISIN", isin, e.getMessage()));
		}
	}

	public <T> SelectResults<T> getDataByGemfireQuery(String queryString) {
		Query gemfireQuery = queryService.newQuery(queryString);
		return (SelectResults<T>) executeGemfireQuery(gemfireQuery);
	}

	private Object executeGemfireQuery(Query gemfireQuery) {
		if (queryService == null)
			return null;
		try {
			return gemfireQuery.execute();
		} catch (FunctionDomainException | TypeMismatchException | NameResolutionException
				| QueryInvocationTargetException e) {
			LOGGER.error("Exception occurred while Ocean Gemfire query", e);
		}
		return null;
	}

}