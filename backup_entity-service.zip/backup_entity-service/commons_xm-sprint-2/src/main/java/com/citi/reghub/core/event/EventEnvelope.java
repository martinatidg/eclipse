package com.citi.reghub.core.event;

import java.io.Serializable;

@SuppressWarnings("serial")
public class EventEnvelope implements Serializable {

	private EventData eventData;
	private EventType eventType;
	private EventName eventName;
	private EventVersion eventVersion;
	private EventSource eventSource;
	private long eventTime;

	public EventData getEventData() {
		return eventData;
	}

	public void setEventData(EventData eventData) {
		this.eventData = eventData;
	}

	public EventName getEventName() {
		return eventName;
	}

	public void setEventName(EventName eventName) {
		this.eventName = eventName;
	}

	public EventVersion getEventVersion() {
		return eventVersion;
	}

	public void setEventVersion(EventVersion eventVersion) {
		this.eventVersion = eventVersion;
	}

	public EventSource getEventSource() {
		return eventSource;
	}

	public void setEventSource(EventSource eventSource) {
		this.eventSource = eventSource;
	}

	public long getEventTime() {
		return eventTime;
	}

	public void setEventTime(long eventTime) {
		this.eventTime = eventTime;
	}

	public void setEventTimeToNow() {
		this.eventTime = System.currentTimeMillis();
	}

	public EventType getEventType() {
		return eventType;
	}

	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}

	@Override
	public String toString() {
		return "EventEnvelope [eventData=" + eventData + ", eventName=" + eventName + ", eventVersion=" + eventVersion
				+ ", eventSource=" + eventSource + ", eventTime=" + eventTime + "]";
	}

}
