package com.citi.reghub.core.constants;

public interface Flow {
    String CSHEQ = "csheq";
    String CSHFI = "cshfi";
    String OTCCMD = "otccmd";
    String OTCEQD = "otceqd";
}
