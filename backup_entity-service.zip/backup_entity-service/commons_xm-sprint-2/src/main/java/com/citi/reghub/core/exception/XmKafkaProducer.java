package com.citi.reghub.core.exception;

import java.util.Properties;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.event.EventEnvelope;

@Component
public class XmKafkaProducer {
	private static final Logger LOGGER = LoggerFactory.getLogger(XmKafkaProducer.class); 

	
	
	@Value("${global.kafka.commons.bootstrap.servers}") 
	private String kafkaServer;
	
	@Value("${global.kafka.producer.acks}") 
	private String kafkaAcks;
	
	@Value("${global.kafka.producer.retries}") 
	private String kafkaRetries;
	
	@Value("${global.kafka.producer.batch.size}") 
	private String kafkaBatchSize;
	
	@Value("${global.kafka.producer.linger.ms}") 
	private String kafkaLingerMs;
	
	@Value("${global.kafka.producer.buffer.memory}") 
	private String kafkaBufferMemory;
	
	private Properties props = new Properties();
	
	private Producer<String, EventEnvelope> producer = null;
	
	
	
	@PostConstruct
	public void init() {
	     LOGGER.info("init kafkaServer = {}", kafkaServer);
		 props.put("bootstrap.servers", kafkaServer==null?"localhost:9092":kafkaServer);
		 props.put("acks", kafkaAcks==null?"all":kafkaAcks);
		 props.put("retries", kafkaRetries==null?0:Integer.parseInt(kafkaRetries));
		 props.put("batch.size", kafkaBatchSize==null?16384:Integer.parseInt(kafkaBatchSize));
		 props.put("linger.ms", kafkaLingerMs==null?1:Integer.parseInt(kafkaLingerMs));
		 props.put("buffer.memory", kafkaBufferMemory==null?33554432:Integer.parseInt(kafkaBufferMemory));
		 props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		 props.put("value.serializer", "com.citi.reghub.core.EventEnvelopeSerializer");
		 producer = new KafkaProducer<>(props);
		
	}
		 
	
	public Future<RecordMetadata> send(String topic, String key, EventEnvelope message) {
		 LOGGER.info("send topic = {} , key ={}", topic, key);
	     if(producer == null){
	    	 
	    	 init();
	     }
	     return producer.send(new ProducerRecord<String, EventEnvelope>(topic, key, message));

	}

}
