package com.citi.reghub.core.refdata.client;

public enum AccountIdentifier {
	OCEAN_ID("OCEAN_ID", "getOceanAccountId() = %d"),
	MNEMONIC("MNEMONIC", "getAcctMnemonic() = '%s'"),
	GFCID("GFCID", "getGfci() = '%s'"),
	ACTID("ACTID", "getActId() = %d");
	
	private String value;
	private String criteria;

	private AccountIdentifier(String value, String criteria) {
		this.value = value;
		this.criteria = criteria;
	}

	public String getValue() {
		return value;
	}
	
	public String getCriteria() {
		return criteria;
	}
}
