package com.citi.reghub.core;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class GenericToString {

    public String toString(){
        return ReflectionToStringBuilder.toString(this);
    }

}
