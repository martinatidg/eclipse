package com.citi.reghub.core.event.exception;

import java.io.Serializable;

public class Note implements Serializable {
	private static final long serialVersionUID = 1L;

	private String source;	// Who owns/updates the note: UI, X-STREAM
	private String exceptionNote;
	private long createdTS;
	private String createdBy;

	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getNote() {
		return exceptionNote;
	}
	public void setNote(String note) {
		this.exceptionNote = note;

	}
	public long getCreatedTS() {
		return createdTS;
	}
	public void setCreatedTS(long createdTS) {
		this.createdTS = createdTS;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((exceptionNote == null) ? 0 : exceptionNote.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Note other = (Note) obj;

		if (exceptionNote == null) {
			if (other.exceptionNote != null)
				return false;
		} else if (!exceptionNote.equals(other.exceptionNote))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Note [source=" + source + ", note=" + exceptionNote + ", createdTS=" + createdTS + ", createdBy=" + createdBy
				+ "]";
	}
}
