package com.citi.reghub.core.converter;

import com.citi.reghub.core.ParsedResponse;

public interface ConvertFixMsgToParsedResponse {

	public ParsedResponse convert(String fixMsg);
}
