package com.citi.reghub.core.exception;

public enum EventType {

	EXCEPTION_CREATED("exceptionCreated"),
	EXCEPTION_UPDATED("exceptionUpdated"),
	EXCEPTION_CLOSED("exceptionClosed"),
	EXCEPTION_REQUESTED("exceptionRequested"),
	EXCEPTION_STATUS_UDATED("exceptionStatusUpdated"),
	EXCEPTION_NOTE_ADDED("exceptionNoteAdded"),
	EXCEPTION_NOTE_DELETED("exceptionNoteDeleted");
	//

	private final String value;


	EventType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static EventType fromValue(String v) {
		for (EventType c : EventType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

}
