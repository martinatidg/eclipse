package com.citi.reghub.core.entity.client;

import org.apache.http.impl.client.HttpClients;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.client.RestClient;

public class EntityClientTest {

	// Disabled. The test case is useful only when the Entity service is available.

	@Test
	public void testGetLatestEntityBySourceId2() {

		//String ENTITY_URL_VALUE = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
		String ENTITY_URL_VALUE = "http://sd-adc0-1def.nam.nsroot.net:9088/reghub-api/entity-service/entities/generic";
		EntityClientConfig entityClientConfig = new EntityClientConfig();
		RestClient restClient = new RestClient(HttpClients.createDefault());
		entityClientConfig.set(EntityClientConfig.REST_CLIENT, restClient);
		entityClientConfig.set(EntityClientConfig.ENTITY_URL_KEY, ENTITY_URL_VALUE);

		EntityClient entityClient = new EntityClient(entityClientConfig);
		Entity entity = entityClient.getLatestEntityBySourceId("19885943");
		
		Assert.assertNotNull("The entity is null", entity);

	}
}
