package com.citi.reghub.core.refdata.client;
import java.util.HashMap;

import com.citi.reghub.core.refdata.client.SingletonRefdataClient;

public class TestRefData {

	public static void main(String args[]) {

		SingletonRefdataClient.setInstance(new HashMap<String, String>());

		long startTs = System.currentTimeMillis();
		
		//System.out.println(SingletonRefdataClient.getInstance().getRefdataAccountClient().getData("MNEMONIC", "EMU8"));
		

		System.out.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("SMCP", "351204"));
		
		//System.out.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("CUSIP", "08148P9L6"));
		
		System.out.println(System.currentTimeMillis() - startTs);
		
		//System.out.println(SingletonRefdataClient.getInstance().getRefdataAccountClient().getData("MNEMONIC", "Q7LINK"));
		
		/*System.out.println(SingletonRefdataClient.getInstance().getRefdataAccountClient().getData("ACTID", 833764));
		
		System.out.println(SingletonRefdataClient.getInstance().getRefdataAccountClient().getData("OCEAN_ID", 1106306548));
		
		System.out.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("SMCP", "404194678"));
		
		System.out.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("CUSIP", "08148P9L6"));
		
		System.out.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("ISIN", "GB00BYPBD519"));
		
		System.out.println(SingletonRefdataClient.getInstance().getRefdataProductClient().getData("OCEAN_ID", 14942600001L));*/
		
		
	}

}
