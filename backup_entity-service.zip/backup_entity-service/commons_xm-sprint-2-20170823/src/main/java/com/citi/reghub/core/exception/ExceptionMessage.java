package com.citi.reghub.core.exception;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ExceptionMessage implements Serializable {
	private static final long serialVersionUID = 1L;
	// values for level
	public static final String WARN = "warning";
	public static final String EXCEPTION = "exception";
	public static final String REJECT = "reject";

	// values for status
	public static final String OPEN = "OPEN";
	public static final String CLOSE = "CLOSED";
	public static final String ACTED = "ACTED";
	public static final String PENDING = "PENDING";

	private String id;
	private String sourceId;
	private String regReportingRef;	//from Entity record: used as reporting id for trade/quote/order/transaction e.g. stream + flow + sourceId
	private String status;
	private String reasonCode;
	private String description;
	private String functionOwner;	// BUS, TECH, SMC, AMC, ORC
	private boolean xstreamEligible;
	private List<Note> notes;
	private String type;
	private String level;
	private Map<String, Object> attributes;
	private long requestedTS;
	private long createdTS;
	private long updatedTS;
	private String updatedSource;	// UI, X-STREAM, ARM

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public String getRegReportingRef() {
		return regReportingRef;
	}
	public void setRegReportingRef(String regReportingRef) {
		this.regReportingRef = regReportingRef;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFunctionOwner() {
		return functionOwner;
	}
	public void setFunctionOwner(String functionOwner) {
		this.functionOwner = functionOwner;
	}
	public boolean isXstreamEligible() {
		return xstreamEligible;
	}
	public void setXstreamEligible(boolean xstreamEligible) {
		this.xstreamEligible = xstreamEligible;
	}
	public List<Note> getNotes() {
		return notes;
	}
	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public Map<String, Object> getAttributes() {
		return attributes;
	}
	public void setAttributes(Map<String, Object> attributes) {
		this.attributes = attributes;
	}
	public long getRequestedTS() {
		return requestedTS;
	}
	public void setRequestedTS(long requestedTS) {
		this.requestedTS = requestedTS;
	}
	public long getCreatedTS() {
		return createdTS;
	}
	public void setCreatedTS(long createdTS) {
		this.createdTS = createdTS;
	}
	public long getUpdatedTS() {
		return updatedTS;
	}
	public void setUpdatedTS(long updatedTS) {
		this.updatedTS = updatedTS;
	}
	public String getUpdatedSource() {
		return updatedSource;
	}
	public void setUpdatedSource(String updatedSource) {
		this.updatedSource = updatedSource;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExceptionMessage other = (ExceptionMessage) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ExceptionMessage [id=" + id + ", sourceId=" + sourceId + ", regReportingRef=" + regReportingRef
				+ ", status=" + status + ", reasonCode=" + reasonCode + ", description=" + description
				+ ", functionOwner=" + functionOwner + ", xstreamEligible=" + xstreamEligible + ", notes=" + notes
				+ ", type=" + type + ", level=" + level + ", attributes=" + attributes + ", requestedTS=" + requestedTS
				+ ", createdTS=" + createdTS + ", updatedTS=" + updatedTS + ", updatedSource=" + updatedSource + "]";
	}
}
