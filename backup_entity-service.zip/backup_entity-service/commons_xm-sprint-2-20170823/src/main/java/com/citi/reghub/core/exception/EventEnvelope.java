package com.citi.reghub.core.exception;

import java.io.Serializable;

public class EventEnvelope implements Serializable {
	public static final String EXCEPTION_REQUESTED	 = "exceptionRequested";
	public static final String EXCEPTION_CREATED	 = "exceptionCreated";
	public static final String EXCEPTION_UPDATED	 = "exceptionUpdated";
	public static final String EXCEPTION_CLOSED		 = "exceptionClosed";

	private static final long serialVersionUID = 1L;

	private int eventVersion;
	private String eventSource;
	private String eventName;
	private long eventTime;
	private ExceptionMessage eventData;

	public int getEventVersion() {
		return eventVersion;
	}
	public void setEventVersion(int eventVersion) {
		this.eventVersion = eventVersion;
	}
	public String getEventSource() {
		return eventSource;
	}
	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public long getEventTime() {
		return eventTime;
	}
	public void setEventTime(long eventTime) {
		this.eventTime = eventTime;
	}
	public ExceptionMessage getExceptionMessage() {
		return eventData;
	}
	public void setExceptionMessage(ExceptionMessage exceptionMessage) {
		this.eventData = exceptionMessage;
	}

	@Override
	public String toString() {
		return "EventMessage [eventVersion=" + eventVersion + ", eventSource=" + eventSource + ", eventName="
				+ eventName + ", eventTime=" + eventTime + ", exceptionMessage=" + eventData + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventName == null) ? 0 : eventName.hashCode());
		result = prime * result + ((eventSource == null) ? 0 : eventSource.hashCode());
		result = prime * result + ((eventData == null) ? 0 : eventData.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EventEnvelope other = (EventEnvelope) obj;
		if (eventName == null) {
			if (other.eventName != null)
				return false;
		} else if (!eventName.equals(other.eventName))
			return false;
		if (eventSource == null) {
			if (other.eventSource != null)
				return false;
		} else if (!eventSource.equals(other.eventSource))
			return false;
		if (eventData == null) {
			if (other.eventData != null)
				return false;
		} else if (!eventData.equals(other.eventData))
			return false;
		return true;
	}
}
