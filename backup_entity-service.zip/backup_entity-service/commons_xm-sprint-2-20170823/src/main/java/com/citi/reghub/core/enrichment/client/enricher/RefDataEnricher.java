package com.citi.reghub.core.enrichment.client.enricher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.enrichment.client.EnricherConfig;
import com.citi.reghub.core.enrichment.client.EnricherResult;
import com.citi.reghub.core.refdata.client.Refdata;
import com.citi.reghub.core.refdata.client.RefdataClient;
import com.citi.reghub.core.refdata.client.RefdataType;
import com.citi.reghub.core.refdata.client.SecurityIdentifier;
import com.citi.reghub.core.rules.client.DroolsEngine;
import com.citi.reghub.core.rules.client.Rule;
import com.citi.reghub.core.rules.client.RuleResult;

public class RefDataEnricher extends Enricher {

	public static final String LOOK_UP_TYPE = "lookupType";
	public static final String LOOK_UP_KEY_DEFINITION = "lookupKeyDefinition";

	private static final Logger LOGGER = LoggerFactory.getLogger(RefDataEnricher.class);

	@SuppressWarnings("unchecked")
	private Map<String, Object> getData(String lookupType, Map<String, Object> input) {
		LOGGER.debug("Processing getData, request with lookupType='{}', input='{}'", lookupType, input);
		RefdataClient refdataClient = clientConfig.getRefDataClient();
		Map<String, Object> result = new HashMap<>();

		RefdataType refdataType = RefdataType.valueOf(lookupType.toUpperCase());
		String lookupKeyType = (String) input.get("lookupKeyType");
		String lookupKeyValue = (String) input.get("lookupKeyValue");

		switch (refdataType) {
		case ACCOUNT:
			if ("MNEMONIC".equalsIgnoreCase(lookupKeyType)) {
				Refdata refdata = refdataClient.getAccountIdsByAccountMnemonic(lookupKeyValue);
				List<Map<String, String>> accountIdsList = (List<Map<String, String>>) refdata.data;
				List<Map<String, String>> nonRestrictedAccountsList = new ArrayList<Map<String, String>>();
				for (Iterator<Map<String, String>> iterator = accountIdsList.iterator(); iterator.hasNext();) {
					Map<String, String> accountIdMap = (Map<String, String>) iterator.next();
					if ("N".equals(accountIdMap.get("IS_RESTRICTED"))) {
						Refdata accountRefdata = refdataClient
								.getAccountDataByAccountId(accountIdMap.get("ACCOUNT_ID"));
						Map<String, String> account = (Map<String, String>) accountRefdata.data;
						nonRestrictedAccountsList.add(account);
					}
				}
				result.put("ACCOUNTIDLIST", accountIdsList);
				result.put("NON_RESTRICTED_ACCOUNTS_LIST", nonRestrictedAccountsList);
			} else if ("ACCOUNTID".equalsIgnoreCase(lookupKeyValue)) {
				Refdata accountRefdata = refdataClient.getAccountDataByAccountId(lookupKeyValue);
				result.put(RefdataType.ACCOUNT.name(), accountRefdata.data);
			}
			break;

		case SECURITY:
			Refdata refdata = clientConfig.getRefDataClient().getSecurityDetails(lookupKeyType, lookupKeyValue);
			result.put(RefdataType.SECURITY.name(), refdata.data);
			break;

		}

		return result;
	}

	@Override
	public EnricherResult enrich(EnricherConfig enricherConfig, Object root, boolean forceRefereshCache) {
		LOGGER.debug("processing enrich, request with enricherConfig='{}', root='{}', forceRefreshCache='{}' initiated",
				enricherConfig, root, forceRefereshCache);
		Rule lookupKeyRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName + "lookup",
				(String) enricherConfig.configuration.get(LOOK_UP_KEY_DEFINITION), null, new ArrayList<>());
		Map<String, Object> metadata = new HashMap<String, Object>();
		RuleResult keyLookUpRuleResult = DroolsEngine.getEngine().execute(lookupKeyRule, root, metadata,
				forceRefereshCache);

		Map<String, Object> refdata = getData((String) enricherConfig.configuration.get(LOOK_UP_TYPE),
				(HashMap<String, Object>) keyLookUpRuleResult.value);
		Rule enrichmentRule = new Rule(enricherConfig.enricherId, enricherConfig.enricherName,
				(String) enricherConfig.configuration.get(UPDATE_DEFINITION), null, new ArrayList<>());
		RuleResult enrichmentRuleResult = DroolsEngine.getEngine().execute(enrichmentRule, root, refdata,
				forceRefereshCache);

		return new EnricherResult(enrichmentRuleResult.ruleName, enrichmentRuleResult.comments,
				enrichmentRuleResult.value);
	}

}
