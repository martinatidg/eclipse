package com.citi.reghub.core;

import java.time.LocalDateTime;

import com.citi.reghub.core.converter.LongToLocalDateTimeDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;

public class CustomConversionsModule extends SimpleModule {

	private static final long serialVersionUID = 1L;

	public CustomConversionsModule() {
		addDeserializer(LocalDateTime.class, new LongToLocalDateTimeDeserializer(LocalDateTime.class));
	}
}
