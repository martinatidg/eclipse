package com.citi.reghub.core.cache.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.FieldSerializer;
import com.hazelcast.nio.ObjectDataInput;
import com.hazelcast.nio.ObjectDataOutput;
import com.hazelcast.nio.serialization.StreamSerializer;

public class GlobalKryoSerializerDeserializer implements StreamSerializer<Object>{
	
	private static final ThreadLocal<Kryo> kryoThreadLocal = new ThreadLocal<Kryo>() {
		@Override
		protected Kryo initialValue() {
			Kryo kryo = new Kryo();
			kryo.register(Object.class,new FieldSerializer<>(kryo, Object.class));
			return kryo;
		}
	};

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getTypeId() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public Object read(ObjectDataInput objectDataInput) throws IOException {
		// TODO Auto-generated method stub
		InputStream in = (InputStream) objectDataInput;
		Input input = new Input(in);
		Kryo kryo = kryoThreadLocal.get();
		Object trade = kryo.readClassAndObject(input);
		input.close();
		return trade;
	}

	@Override
	public void write(ObjectDataOutput objectDataOutput, Object obj) throws IOException {
		// TODO Auto-generated method stub
		Kryo kryo = kryoThreadLocal.get();
		Output output = new Output((OutputStream) objectDataOutput);
		kryo.writeClassAndObject(output, obj);
		output.flush();
	}

}
