package com.citi.reghub.core.rules.client;

import com.citi.reghub.core.constants.EntityStatus;

public class Result {

	public String status = EntityStatus.REPORTABLE;
    public Boolean result = true;
    private boolean isImplementationLatest =false;
	
    public String getStatus() {
        return status;
    }

    public boolean is(String status){
        return status.equals(this.status);
    }
    
    public void mark(String status) {
        this.status = status;
        this.result = status != EntityStatus.REPORTABLE ? false: true;
    }
    
    public boolean isReportable() {
        return is(EntityStatus.REPORTABLE);
    }
    
    public boolean isNonReportable() {
        return is(EntityStatus.NON_REPORTABLE);
    }
    
    public boolean isBizException() {
        return is(EntityStatus.BIZ_EXCEPTION);
    }
    
    public boolean isTechException() {
        return is(EntityStatus.TECH_EXCEPTION);
    }
    
    public boolean isAppException(){
    	return is(EntityStatus.APP_EXCEPTION);
    }
    
    public void markReportable() {
    	mark(EntityStatus.REPORTABLE);
    }
    
    public void markNonReportable() {
    	mark(EntityStatus.NON_REPORTABLE);
    }
    
    public void markTechException() {
        mark(EntityStatus.TECH_EXCEPTION);
    }
    
    public void markBizException() {
        mark(EntityStatus.BIZ_EXCEPTION);
    }
    
    public void markAppException() {
    	mark(EntityStatus.APP_EXCEPTION);
    }
    
	public boolean isException() {
		return isAppException() || isTechException() || isBizException();
	}

	public void markRuleFail() {
		result = false;
		isImplementationLatest = true;
	}
	
	public void markRulePass() {
		result = true;
		isImplementationLatest = true;
	}
	
	public boolean hasFailed() {
		return !result;
	}

	public boolean isImplementationLatest() {
		return isImplementationLatest;
	}
	
}
