package com.citi.reghub.core.hrmstrader.client;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;

import java.util.HashMap;

public class HrmsTraderClientConfig extends HashMap<String,Object> {

	private static final long serialVersionUID = 1L;
	
	public static final String REST_CLIENT = "restClient";
    public static final String HRMSTRADER_URL_KEY = "hrmsTraderUrl";
    public static final String CACHE_CLIENT = "cacheClient";
    public static final String HRMSTRADER_URL_VALUE = "http://localhost:9090/reghub-api/hrms-trader-service/%s/%s";
    public static final String CACHE_COLLECTION_NAME = "cacheCollectionName";
    public static final String TRADER_INFO_SERVICE_URI = "traderServiceURI";
    public static final String TRADER_INFO_SERVICE_URI_VALUE = "trader";

    
    public RestClient getRestClient() {
        return (RestClient) get(REST_CLIENT);
    }

    public String getHrmsTraderUrl() {
        return (String) get(HRMSTRADER_URL_KEY);
    }

    public HrmsTraderClientConfig setDefaultHrmsTraderUrl() {
        return set(HRMSTRADER_URL_KEY, HRMSTRADER_URL_VALUE)
        		.set(TRADER_INFO_SERVICE_URI,TRADER_INFO_SERVICE_URI_VALUE);
    }

    public CacheClient getCacheClient(){
    	return (CacheClient)get(CACHE_CLIENT);
    }

    public String getCacheCollectionName() {
        return (String) get(CACHE_COLLECTION_NAME);
    }

    public String getTraderInfoServiceURI() {
        return (String) get(TRADER_INFO_SERVICE_URI);
    }

    public HrmsTraderClientConfig set(String key, Object value){
        put(key,value);
        return this;
    }

}
