package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.dataobject.account.OceanAccountInfo;
import com.citi.ocean.dataobject.account.OceanAccountSummary;
import com.citi.ocean.dataobject.account.OceanGFCDetail;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RefdataAccountClient implements RefdataInterface {

	public static Logger LOGGER = LoggerFactory.getLogger(RefdataAccountClient.class);

	private final ObjectMapper mapper;
	private final OceanGemfireCacheClient oceanGemfireCacheClient;

	public RefdataAccountClient(final OceanGemfireCacheClient oceanGemfireCacheClient) {
		this.oceanGemfireCacheClient = oceanGemfireCacheClient;
		mapper = new ObjectMapper();
	}

/*	@Override
	public Map<String, Object> getData(String identifier, Object value) {
		try {
			AccountIdentifier inputIdentifier = AccountIdentifier.valueOf(identifier.toUpperCase());
			QueryBuilder query = new QueryBuilder().column("*").from(MapName.MAP_REFERENCE_ACCOUNT_OCEAN_ACCOUNT)
					.where(String.format(inputIdentifier.getCriteria(), value));

			SelectResults<OceanAccountSummary> searchResult = oceanGemfireCacheClient
					.getDataByGemfireQuery(query.toString());
			ArrayList<OceanAccountSummary> list = (ArrayList<OceanAccountSummary>) searchResult.asList();
			// temporary logic: need to confirm with BA's in case multiple records are
			// received in account lookup
			return list != null && !list.isEmpty() ? mapper.convertValue(list.get(0), Map.class) : null;
		} catch (IllegalArgumentException e) {
			LOGGER.error("Invalid input Account Identifier: '{}'", identifier, e);
			throw new RuntimeException("Invalid input Account Identifier: " + identifier);
		}
	}*/


	@Override
	public Map<String, Object> getData(String identifier, Object value) {
		try {
			AccountIdentifier inputIdentifier = AccountIdentifier.valueOf(identifier.toUpperCase());
			
			switch (inputIdentifier) {
			case GFCID:
				return getAccountDetailsByGFCID(value);
			case MNEMONIC:
				return getAccountDetailsByMnemonic(value);
			case ACTID:
				return getAccountDetailsByActi(value);
			case SLANG:
				return getAccountDetailsBySlang(value);
			case ACCOUNTMNEMONIC:
				return getAccountDetailsByMnemonic(value);	
			
			}
			return null;
		} catch (IllegalArgumentException e) {
			LOGGER.error("Invalid input Account Identifier: '{}'", identifier, e);
			throw new RuntimeException("Invalid input Account Identifier: " + identifier + " supported Account Identifier are " + AccountIdentifier.values().toString());
		}
	}
	
	private Map<String, Object> getAccountDetailsByGFCID(Object gfcid) {
		OceanGFCDetail accSummary = oceanGemfireCacheClient.getAccountByGFCID(gfcid.toString());
		OceanGFCDetailLocal oceanAccSummaryLocal = getGFCIDLocalMap(accSummary);
		return mapper.convertValue(oceanAccSummaryLocal, Map.class);
	}

	private Map<String, Object> getAccountDetailsByMnemonic(Object mnemonic) {
		OceanAccountInfo accSummary = oceanGemfireCacheClient.getAccountByMnemonic(mnemonic.toString());
		OceanAccountInfoLocal oceanAccSummaryLocal = getLocalAccInfoMap(accSummary);
		return mapper.convertValue(oceanAccSummaryLocal, Map.class);
	}
	
	private Map<String, Object> getAccountDetailsByActi(Object acti) {
		OceanAccountInfo accSummary = oceanGemfireCacheClient.getAccountByActi(Integer.parseInt(acti.toString()));
		OceanAccountInfoLocal oceanAccSummaryLocal = getLocalAccInfoMap(accSummary);
		return mapper.convertValue(oceanAccSummaryLocal, Map.class);
	}
	
	private Map<String, Object> getAccountDetailsBySlang(Object slang) {
		OceanAccountInfo accSummary = oceanGemfireCacheClient.getAccountBySlang(slang.toString());
		OceanAccountInfoLocal oceanAccSummaryLocal = getLocalAccInfoMap(accSummary);
		return mapper.convertValue(oceanAccSummaryLocal, Map.class);
	}
	
	
	private OceanAccountInfoLocal getLocalAccInfoMap(OceanAccountInfo accSummary) {
		
		OceanAccountInfoLocal accountInfoLocal = new OceanAccountInfoLocal();
		
		if(accountInfoLocal != null){
			
			accountInfoLocal.setAccountDescription(accSummary.getAccountDescription());
			accountInfoLocal.setAccountImsNumber(accSummary.getAccountImsNumber());
			accountInfoLocal.setAcctDetail(accSummary.getAcctDetail());
			accountInfoLocal.setAcctMnemonic(accSummary.getAcctMnemonic());
			accountInfoLocal.setActi(accSummary.getActi());
			accountInfoLocal.setCodeDesc(accSummary.getCodeDesc());
			accountInfoLocal.setCpii(accSummary.getCpii());
			accountInfoLocal.setCreatedBy(accSummary.getCreatedBy());
		//	accountInfoLocal.setDirty(accSummary.getdirty);
			accountInfoLocal.setFigp(accSummary.getFigp());
			accountInfoLocal.setGfci(accSummary.getGfci());
			accountInfoLocal.setGrandParentId(accSummary.getGrandParentId());
			accountInfoLocal.setGrandParentLongName(accSummary.getGrandParentLongName());
			accountInfoLocal.setGrandParentLongNameFromGrandParentBasedOnFigp(accSummary.getGrandParentLongNameFromGrandParentBasedOnFigp());
			accountInfoLocal.setGrandParentLongNameFromGrandParentBasedOnGrandParentId(accSummary.getGrandParentLongNameFromGrandParentBasedOnGrandParentId());
			accountInfoLocal.setGrandParentLongNameFromRefAcctBasedOnFigp(accSummary.getGrandParentLongNameFromRefAcctBasedOnFigp());
			accountInfoLocal.setLegalEntityCode(accSummary.getLegalEntityCode());
			accountInfoLocal.setManagementMnemonic(accSummary.getManagementMnemonic());
			//accountInfoLocal.setOceanAccountDetail(acctDetail);
			accountInfoLocal.setOceanAcctId(accSummary.getOceanAcctId());
			accountInfoLocal.setRaceMicroControlCode(accSummary.getRaceMicroControlCode());
			accountInfoLocal.setStrategy(accSummary.getStrategy());
			accountInfoLocal.setStrategyName(accSummary.getStrategyName());
			accountInfoLocal.setSubstrategy(accSummary.getSubstrategy());
			accountInfoLocal.setSubstrategyName(accSummary.getSubstrategyName());
			
			if(accSummary.getAcctDetail() != null){
			accountInfoLocal.setEeaFlag(accSummary.getAcctDetail().getEeaEntityFlag());
			accountInfoLocal.setLei(accSummary.getAcctDetail().getLei());
			}else{
				OceanGFCDetail  oceanDetail = oceanGemfireCacheClient.getAccountByGFCID(accSummary.getGfci());
				accountInfoLocal.setLei(oceanDetail.getLei());
				accountInfoLocal.setEeaFlag(oceanDetail.getEeaEntityFlag());
			}
		}
		return accountInfoLocal;
	}

	private OceanGFCDetailLocal getGFCIDLocalMap(OceanGFCDetail accSummary) {
		OceanGFCDetailLocal gfcDetailLocal = new OceanGFCDetailLocal();
		
		if (accSummary != null){
			gfcDetailLocal.setDomicileAddressCity(accSummary.getDomicileAddressCity());
			gfcDetailLocal.setDomicileAddressCountry(accSummary.getDomicileAddressCountry());
			gfcDetailLocal.setCagid(accSummary.getCagid());
			gfcDetailLocal.setCgmlLargeTrader(accSummary.getCgmlLargeTrader());
			gfcDetailLocal.setDomicileAddressPostcode(accSummary.getDomicileAddressPostcode());
			gfcDetailLocal.setDomicileAddressState(accSummary.getDomicileAddressState());
			gfcDetailLocal.setDomicileAddressStreet(accSummary.getDomicileAddressStreet());
			gfcDetailLocal.setEeaEntityFlag(accSummary.getEeaEntityFlag());
			gfcDetailLocal.setGfci(accSummary.getGfci());
			gfcDetailLocal.setGfcLongname(accSummary.getGfcLongname());
			gfcDetailLocal.setIncorporatedAddressCity(accSummary.getIncorporatedAddressCity());
			gfcDetailLocal.setIncorporatedAddressCountry(accSummary.getIncorporatedAddressCountry());
			gfcDetailLocal.setIncorporatedAddressPostcode(accSummary.getIncorporatedAddressPostcode());
			gfcDetailLocal.setIncorporatedAddressState(accSummary.getIncorporatedAddressState());
			gfcDetailLocal.setIncorporatedAddressStreet(accSummary.getIncorporatedAddressStreet());
			gfcDetailLocal.setLei(accSummary.getLei());
			gfcDetailLocal.setParentGfpid(accSummary.getParentGfpid());
			gfcDetailLocal.setTaxId(accSummary.getTaxId());

		}
		
		return gfcDetailLocal;
	}
	
	private OceanAccountSummaryLocal getLocalMap(OceanAccountSummary accSummary ){
		OceanAccountSummaryLocal oceanAccountSummaryLocal = new OceanAccountSummaryLocal();
		if (accSummary != null){
			
			oceanAccountSummaryLocal.setAcctDesc(accSummary.getAcctDesc());
			oceanAccountSummaryLocal.setAcctImsNum(accSummary.getAcctImsNum());
			oceanAccountSummaryLocal.setAcctLastTrdDate(accSummary.getAcctLastTrdDate());
			oceanAccountSummaryLocal.setAcctLastUpdDate(accSummary.getAcctLastUpdDate());
			oceanAccountSummaryLocal.setAcctMnemonic(accSummary.getAcctMnemonic());
			oceanAccountSummaryLocal.setAcctMsgType(accSummary.getAcctMsgType());
			oceanAccountSummaryLocal.setAcctOpenDate(accSummary.getAcctOpenDate());
			oceanAccountSummaryLocal.setAcctStat(accSummary.getAcctStat());
			oceanAccountSummaryLocal.setAcctSubtypeCd(accSummary.getAcctSubtypeCd());
			oceanAccountSummaryLocal.setAcctTypeCd(accSummary.getAcctTypeCd());
			oceanAccountSummaryLocal.setAcctTypeId(accSummary.getAcctTypeId());
			oceanAccountSummaryLocal.setActi(accSummary.getActi());
			oceanAccountSummaryLocal.setAssetOneFg(accSummary.getAssetOneFg());
			oceanAccountSummaryLocal.setBrchId(accSummary.getBrchId());
			oceanAccountSummaryLocal.setBtsiAcctType(accSummary.getBtsiAcctType());
			oceanAccountSummaryLocal.setBusUnitId(accSummary.getBusUnitId());
			oceanAccountSummaryLocal.setCagid(accSummary.getCagid());
			oceanAccountSummaryLocal.setCgmlLargeTrader(accSummary.getCgmlLargeTrader());
			oceanAccountSummaryLocal.setCpii(accSummary.getCpii());
			oceanAccountSummaryLocal.setCrgid(accSummary.getCrgid());
			oceanAccountSummaryLocal.setDomicileAddressCity(accSummary.getDomicileAddressCity());
			oceanAccountSummaryLocal.setDomicileAddressCountry(accSummary.getDomicileAddressCountry());
			oceanAccountSummaryLocal.setDomicileAddressPostcode(accSummary.getDomicileAddressPostcode());
			oceanAccountSummaryLocal.setDomicileAddressState(accSummary.getDomicileAddressState());
			oceanAccountSummaryLocal.setDomicileAddressStreet(accSummary.getDomicileAddressStreet());
			oceanAccountSummaryLocal.setEeaEntityFlag(accSummary.getEeaEntityFlag());
			oceanAccountSummaryLocal.setForexBaseNumber(accSummary.getForexBaseNumber());
			oceanAccountSummaryLocal.setFreezePositionFlag(accSummary.getFreezePositionFlag());
			oceanAccountSummaryLocal.setGfci(accSummary.getGfci());
			oceanAccountSummaryLocal.setGfciNm(accSummary.getGfciNm());
			oceanAccountSummaryLocal.setGfcLongname(accSummary.getGfcLongname());
			oceanAccountSummaryLocal.setIncorporatedAddressCity(accSummary.getIncorporatedAddressCity());
			oceanAccountSummaryLocal.setIncorporatedAddressCountry(accSummary.getIncorporatedAddressCountry());
			oceanAccountSummaryLocal.setIncorporatedAddressPostcode(accSummary.getIncorporatedAddressPostcode());
			oceanAccountSummaryLocal.setIncorporatedAddressState(accSummary.getIncorporatedAddressState());
			oceanAccountSummaryLocal.setIncorporatedAddressStreet(accSummary.getIncorporatedAddressStreet());
			oceanAccountSummaryLocal.setInstId(accSummary.getInstId());
			oceanAccountSummaryLocal.setIsAgencyBroker(accSummary.getIsAgencyBroker());
			oceanAccountSummaryLocal.setLargeTraderIdentification1(accSummary.getLargeTraderIdentification1());
			oceanAccountSummaryLocal.setLargeTraderIdentification2(accSummary.getLargeTraderIdentification2());
			oceanAccountSummaryLocal.setLargeTraderIdentification3(accSummary.getLargeTraderIdentification3());
			oceanAccountSummaryLocal.setLei(accSummary.getLei());
			oceanAccountSummaryLocal.setLglEntyCd(accSummary.getLglEntyCd());
			oceanAccountSummaryLocal.setLglEntyId(accSummary.getLglEntyId());
			oceanAccountSummaryLocal.setMarkedForPurgeFlag(accSummary.getMarkedForPurgeFlag());
			oceanAccountSummaryLocal.setMcle(accSummary.getMcle());
			oceanAccountSummaryLocal.setMifidClassification(accSummary.getMifidClassification());
			oceanAccountSummaryLocal.setMpid(accSummary.getMpid());
			oceanAccountSummaryLocal.setMpidDesc(accSummary.getMpidDesc());
			oceanAccountSummaryLocal.setOceanAcctId(accSummary.getOceanAcctId());
			oceanAccountSummaryLocal.setParentGfpid(accSummary.getParentGfpid());
			oceanAccountSummaryLocal.setRestrictTradeFlag(accSummary.getRestrictTradeFlag());
			oceanAccountSummaryLocal.setRestrictViewFlag(accSummary.getRestrictViewFlag());
			oceanAccountSummaryLocal.setTaxId(accSummary.getTaxId());
			
		}
		return oceanAccountSummaryLocal;
	}
	
	
}
