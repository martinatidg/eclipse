package com.citi.reghub.core.rules.client;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public class RulesClient {

    private RulesClientConfig rulesClientConfig;

    private CacheClient cacheClient;

    private static final String CACHE_RULES_COLLECTION = "rule_graph";

    private static final String CACHE_RULES_COLLECTION_TYPE = "Map";

    public static Logger LOGGER = LoggerFactory.getLogger(RulesClient.class);

    public RulesClient(RulesClientConfig rulesClientConfig){
    	this.rulesClientConfig = (rulesClientConfig == null ? new RulesClientConfig() :  rulesClientConfig);
        if (!this.rulesClientConfig.containsKey(RulesClientConfig.RULE_GRAPH_URL_KEY)) this.rulesClientConfig.setDefaultRuleGraphUrl();
        this.cacheClient = rulesClientConfig.getCacheClient();
        LOGGER.info("Instantialised Rules Client with configuration='{}'", rulesClientConfig);
    }

    public RuleGraph load(String ruleGraphName) {
    	return getFromService(ruleGraphName);

    }

    private RuleGraph getFromService(String ruleGraphName) {
    	LOGGER.debug("Hitting Rules Service for Rule Graph with name='{}'", ruleGraphName);
    	if (rulesClientConfig.getRestClient() == null) throw new RuntimeException("RulesClientConfig should have HTTP_CLIENT set.");
        RuleGraph ruleGraph = (RuleGraph) rulesClientConfig.getRestClient().get(prepareRuleGraphUrl(ruleGraphName),RuleGraph.class);
        if(ruleGraph == null)
        	throw new RuntimeException("Rule Graph Not found for rule graph name "+ruleGraphName);
        putInCache(ruleGraphName);
        return ruleGraph;
	}

	public long getLastLoadTime(String ruleGraphName) {
		LOGGER.info("Hitting cache to get last load time for RuleGraph='{}'", ruleGraphName);
		Object obj = cacheClient.get(ruleGraphName,prepareCacheClientConfig());
		long lastLoadTime = 0;
		if(obj != null)
			lastLoadTime = (long) obj;
		return lastLoadTime;
	}

	private void putInCache(String ruleGraphName) {
		cacheClient.put(ruleGraphName, System.currentTimeMillis(),prepareCacheClientConfig());
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map prepareCacheClientConfig(){
		Map props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, CACHE_RULES_COLLECTION);
		props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_RULES_COLLECTION_TYPE);
		props.put(CacheClient.PUT_IF_ABSENT, "true");
		return props;
	}

	private String prepareRuleGraphUrl(String ruleGraphName) {
        return String.format(rulesClientConfig.getRuleGraphUrl(),ruleGraphName);
    }

}