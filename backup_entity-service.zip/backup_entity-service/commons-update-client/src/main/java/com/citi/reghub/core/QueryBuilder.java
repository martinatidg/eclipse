package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.List;

public class QueryBuilder {

	private List<String> columns = new ArrayList<String>();

	private List<String> tables = new ArrayList<String>();

	private List<String> wheres = new ArrayList<String>();

	public QueryBuilder() {}

	public QueryBuilder(String table) {
		tables.add(table);
	}

	private void appendList(StringBuffer sql, List<String> list, String init, String sep) {
		boolean first = true;
		for (String s : list) {
			if (first) {
				sql.append(init);
			} else {
				sql.append(sep);
			}
			sql.append(s);
			first = false;
		}
	}

	public QueryBuilder column(String name) {
		columns.add(name);
		return this;
	}

	public QueryBuilder from(String table) {
		tables.add(table);
		return this;
	}

	@Override
	public String toString() {

		StringBuffer sql = new StringBuffer("select ");

		if (columns.size() == 0) {
			sql.append("*");
		} else {
			appendList(sql, columns, "", ", ");
		}

		appendList(sql, tables, " from ", ", ");
		appendList(sql, wheres, " where ", " and ");

		return sql.toString();
	}

	public QueryBuilder where(String expr) {
		wheres.add(expr);
		return this;
	}
}
