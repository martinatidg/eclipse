package com.citi.reghub.core.client;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonRestClient {

    private static RestClient instance;
    private static final Logger LOGGER = LoggerFactory.getLogger(SingletonRestClient.class);

    public static RestClient getInstance(){
        if(instance == null) {
            instance= new RestClient(createDefault());
        }return instance;
    }

    private static HttpClient createDefault() {
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.disableAutomaticRetries();
		CloseableHttpClient client = builder.build();
		return client;
	}

}
