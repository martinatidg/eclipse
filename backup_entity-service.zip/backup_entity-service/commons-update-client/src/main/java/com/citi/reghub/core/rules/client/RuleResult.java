package com.citi.reghub.core.rules.client;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.citi.reghub.core.ConvertToMongoMap;

public class RuleResult extends Result implements ConvertToMongoMap {

	public String ruleName;
    public String comments;
    public Object value;
    public String code;
    
    public RuleResult(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleName() {
        return ruleName;
    }
    
    public void setRuleDescription(String comment){
    	this.comments = comment;
    }
    
    public void setCode(String code){
    	this.code = code;
    }
    
    public void setAffectedFields(String field, Object oldVal, Object newVal) {
    	if(value == null) {
    		value = new LinkedList<>();
    	}
    	Map<String, Object> affectedFieldMap = new HashMap<>();
    	affectedFieldMap.put("affectedField", field);
    	affectedFieldMap.put("oldValue", oldVal);
    	affectedFieldMap.put("newValue", newVal);
    	((List) value).add(affectedFieldMap);
    }

	@Override
	public Map toMap(Object object) {
		Map<String, Object> ruleResultMap = new HashMap<String, Object>();
		ruleResultMap.put("ruleName", this.ruleName);
		ruleResultMap.put("comments", this.comments);
		ruleResultMap.put("value", this.value);
		ruleResultMap.put("code", this.code);
		ruleResultMap.put("result", this.result);
		ruleResultMap.values().removeIf(Objects::isNull);
		return ruleResultMap;
	}

}
