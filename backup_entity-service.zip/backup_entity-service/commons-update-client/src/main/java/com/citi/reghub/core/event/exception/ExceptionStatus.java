package com.citi.reghub.core.event.exception;

public enum ExceptionStatus {
	
	OPEN("OPEN"),
	ACTED("ACTED"),
	PENDING_APPROVAL("PENDING_APPROVAL"),
	PENDING_REPLAY("PENDING_REPLAY"),
	CLOSED("CLOSED"),
	CLOSED_IGNORED("CLOSED_IGNORED");

	final String value;

	ExceptionStatus(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static ExceptionStatus fromValue(String v) {
		for (ExceptionStatus c : ExceptionStatus.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
