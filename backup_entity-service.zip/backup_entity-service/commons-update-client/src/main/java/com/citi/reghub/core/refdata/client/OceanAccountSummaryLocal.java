package com.citi.reghub.core.refdata.client;

import java.util.Date;

import com.citi.ocean.dataobject.Detail;

public class OceanAccountSummaryLocal extends Detail
{
    private static final long serialVersionUID = 1L;

    private Long oceanAcctId;
    private String acctTypeCd;
    private String acctSubtypeCd;
    private Long lglEntyId;
    private Integer acti;
    private String acctMsgType;
    private String acctStat;
    private String acctMnemonic;
    private String acctDesc;
    private String acctImsNum;
    private String cpii;
    private String gfci;
    private String gfciNm;
    private String mpid;
    private String mpidDesc;
    private String lglEntyCd;
    private Date acctOpenDate;
    private Date acctLastTrdDate;
    private Date acctLastUpdDate;
    private String gfcLongname;
    private String cagid;
    private String mcle;
    private String forexBaseNumber;
    private String cgmlLargeTrader;
    private String largeTraderIdentification1;
    private String largeTraderIdentification2;
    private String largeTraderIdentification3;
    private String taxId;
    private String parentGfpid;
    private String restrictTradeFlag;
    private String freezePositionFlag;
    private String lei;
    private String crgid;
    private String domicileAddressStreet;
    private String domicileAddressState;
    private String domicileAddressCountry;
    private String domicileAddressPostcode;
    private String incorporatedAddressStreet;
    private String incorporatedAddressCity;
    private String incorporatedAddressState;
    private String domicileAddressCity;
    private String incorporatedAddressCountry;
    private String incorporatedAddressPostcode;
    private String mifidClassification;
    private String eeaEntityFlag;
    private String isAgencyBroker;
    private String btsiAcctType;
    private Integer acctTypeId;
    private String assetOneFg;
    private Long instId;
    private String busUnitId;
    private String acctBoType;
    private String brchId;
    private String restrictViewFlag;
    private String markedForPurgeFlag;

    /**
     * @return the oceanAcctId
     */
    public Long getOceanAcctId()
    {
        return oceanAcctId;
    }

    /**
     * @param oceanAcctId the oceanAcctId to set
     */
    public void setOceanAcctId(final Long oceanAcctId)
    {
        this.oceanAcctId = oceanAcctId;
    }

    /**
     * @return the acctIdType
     */

    /**
     * @return the acctTypeCd
     */
    public String getAcctTypeCd()
    {
        return acctTypeCd;
    }

    /**
     * @param acctTypeCd the acctTypeCd to set
     */
    public void setAcctTypeCd(final String acctTypeCd)
    {
        this.acctTypeCd = acctTypeCd;
    }

    /**
     * @return the acctNm
     */

    /**
     * @return the acctSubtypeCd
     */
    public String getAcctSubtypeCd()
    {
        return acctSubtypeCd;
    }

    /**
     * @param acctSubtypeCd the acctSubtypeCd to set
     */
    public void setAcctSubtypeCd(final String acctSubtypeCd)
    {
        this.acctSubtypeCd = acctSubtypeCd;
    }

    /**
     * @return the lglEntyId
     */
    public Long getLglEntyId()
    {
        return lglEntyId;
    }

    /**
     * @param lglEntyId the lglEntyId to set
     */
    public void setLglEntyId(final Long lglEntyId)
    {
        this.lglEntyId = lglEntyId;
    }

    /**
     * @return the acti
     */
    public Integer getActi()
    {
        return acti;
    }

    /**
     * @param acti the acti to set
     */
    public void setActi(final Integer acti)
    {
        this.acti = acti;
    }

    /**
     * @return the acctMsgType
     */
    public String getAcctMsgType()
    {
        return acctMsgType;
    }

    /**
     * @param acctMsgType the acctMsgType to set
     */
    public void setAcctMsgType(final String acctMsgType)
    {
        this.acctMsgType = acctMsgType;
    }

    /**
     * @return the acctStat
     */
    public String getAcctStat()
    {
        return acctStat;
    }

    /**
     * @param acctStat the acctStat to set
     */
    public void setAcctStat(final String acctStat)
    {
        this.acctStat = acctStat;
    }

    /**
     * @return the acctMnemonic
     */
    public String getAcctMnemonic()
    {
        return acctMnemonic;
    }

    /**
     * @param acctMnemonic the acctMnemonic to set
     */
    public void setAcctMnemonic(final String acctMnemonic)
    {
        this.acctMnemonic = acctMnemonic;
    }

    /**
     * @return the acctDesc
     */
    public String getAcctDesc()
    {
        return acctDesc;
    }

    /**
     * @param acctDesc the acctDesc to set
     */
    public void setAcctDesc(final String acctDesc)
    {
        this.acctDesc = acctDesc;
    }

    /**
     * @return the acctImsNum
     */
    public String getAcctImsNum()
    {
        return acctImsNum;
    }

    /**
     * @param acctImsNum the acctImsNum to set
     */
    public void setAcctImsNum(final String acctImsNum)
    {
        this.acctImsNum = acctImsNum;
    }

    /**
     * @return the cpii
     */
    public String getCpii()
    {
        return cpii;
    }

    /**
     * @param cpii the cpii to set
     */
    public void setCpii(final String cpii)
    {
        this.cpii = cpii;
    }

    /**
     * @return the gfci
     */
    public String getGfci()
    {
        return gfci;
    }

    /**
     * @param gfci the gfci to set
     */
    public void setGfci(final String gfci)
    {
        this.gfci = gfci;
    }

    /**
     * @return the gfciNm
     */
    public String getGfciNm()
    {
        return gfciNm;
    }

    /**
     * @param gfciNm the gfciNm to set
     */
    public void setGfciNm(final String gfciNm)
    {
        this.gfciNm = gfciNm;
    }

    /**
     * @return the mpid
     */
    public String getMpid()
    {
        return mpid;
    }

    /**
     * @param mpid the mpid to set
     */
    public void setMpid(final String mpid)
    {
        this.mpid = mpid;
    }

    /**
     * @return the mpidDesc
     */
    public String getMpidDesc()
    {
        return mpidDesc;
    }

    /**
     * @param mpidDesc the mpidDesc to set
     */
    public void setMpidDesc(final String mpidDesc)
    {
        this.mpidDesc = mpidDesc;
    }

    /**
     * @return the lglEntyCd
     */
    public String getLglEntyCd()
    {
        return lglEntyCd;
    }

    /**
     * @param lglEntyCd the lglEntyCd to set
     */
    public void setLglEntyCd(final String lglEntyCd)
    {
        this.lglEntyCd = lglEntyCd;
    }

    /**
     * @return the acctOpenDate
     */
    public Date getAcctOpenDate()
    {
        return acctOpenDate;
    }

    /**
     * @param acctOpenDate the acctOpenDate to set
     */
    public void setAcctOpenDate(final Date acctOpenDate)
    {
        this.acctOpenDate = acctOpenDate;
    }

    /**
     * @return the acctLastTrdDate
     */
    public Date getAcctLastTrdDate()
    {
        return acctLastTrdDate;
    }

    /**
     * @param acctLastTrdDate the acctLastTrdDate to set
     */
    public void setAcctLastTrdDate(final Date acctLastTrdDate)
    {
        this.acctLastTrdDate = acctLastTrdDate;
    }

    /**
     * @return the acctLastUpdDate
     */
    public Date getAcctLastUpdDate()
    {
        return acctLastUpdDate;
    }

    /**
     * @param acctLastUpdDate the acctLastUpdDate to set
     */
    public void setAcctLastUpdDate(final Date acctLastUpdDate)
    {
        this.acctLastUpdDate = acctLastUpdDate;
    }

    /**
     * @return the gfcLongname
     */
    public String getGfcLongname()
    {
        return gfcLongname;
    }

    /**
     * @param gfcLongname the gfcLongname to set
     */
    public void setGfcLongname(final String gfcLongname)
    {
        this.gfcLongname = gfcLongname;
    }

    /**
     * @return the cagid
     */
    public String getCagid()
    {
        return cagid;
    }

    /**
     * @param cagid the cagid to set
     */
    public void setCagid(final String cagid)
    {
        this.cagid = cagid;
    }

    /**
     * @return the mcle
     */
    public String getMcle()
    {
        return mcle;
    }

    /**
     * @param mcle the mcle to set
     */
    public void setMcle(final String mcle)
    {
        this.mcle = mcle;
    }

    /**
     * @return the forexBaseNumber
     */
    public String getForexBaseNumber()
    {
        return forexBaseNumber;
    }

    /**
     * @param forexBaseNumber the forexBaseNumber to set
     */
    public void setForexBaseNumber(final String forexBaseNumber)
    {
        this.forexBaseNumber = forexBaseNumber;
    }

    /**
     * @return the cgmlLargeTrader
     */
    public String getCgmlLargeTrader()
    {
        return cgmlLargeTrader;
    }

    /**
     * @param cgmlLargeTrader the cgmlLargeTrader to set
     */
    public void setCgmlLargeTrader(final String cgmlLargeTrader)
    {
        this.cgmlLargeTrader = cgmlLargeTrader;
    }

    /**
     * @return the taxId
     */
    public String getTaxId()
    {
        return taxId;
    }

    /**
     * @param taxId the taxId to set
     */
    public void setTaxId(final String taxId)
    {
        this.taxId = taxId;
    }

    /**
     * @return the restrictTradeFlag
     */
    public String getRestrictTradeFlag()
    {
        return restrictTradeFlag;
    }

    /**
     * @param restrictTradeFlag the restrictTradeFlag to set
     */
    public void setRestrictTradeFlag(final String restrictTradeFlag)
    {
        this.restrictTradeFlag = restrictTradeFlag;
    }

    /**
     * @return the freezePositionFlag
     */
    public String getFreezePositionFlag()
    {
        return freezePositionFlag;
    }

    /**
     * @param freezePositionFlag the freezePositionFlag to set
     */
    public void setFreezePositionFlag(final String freezePositionFlag)
    {
        this.freezePositionFlag = freezePositionFlag;
    }

    /**
     * @return the domicileCountryCode
     */

    /**
     * @return the lei
     */
    public String getLei()
    {
        return lei;
    }

    /**
     * @param lei the lei to set
     */
    public void setLei(final String lei)
    {
        this.lei = lei;
    }

    /**
     * @return the crgid
     */
    public String getCrgid()
    {
        return crgid;
    }

    /**
     * @param crgid the crgid to set
     */
    public void setCrgid(final String crgid)
    {
        this.crgid = crgid;
    }

    /**
     * @return the domicileAddressStreet
     */
    public String getDomicileAddressStreet()
    {
        return domicileAddressStreet;
    }

    /**
     * @param domicileAddressStreet the domicileAddressStreet to set
     */
    public void setDomicileAddressStreet(final String domicileAddressStreet)
    {
        this.domicileAddressStreet = domicileAddressStreet;
    }

    /**
     * @return the domicileAddressCity
     */
    public String getDomicileAddressCity()
    {
        return domicileAddressCity;
    }

    /**
     * @param domicileAddressCity the domicileAddressCity to set
     */
    public void setDomicileAddressCity(final String domicileAddressCity)
    {
        this.domicileAddressCity = domicileAddressCity;
    }

    /**
     * @return the domicileAddressState
     */
    public String getDomicileAddressState()
    {
        return domicileAddressState;
    }

    /**
     * @param domicileAddressState the domicileAddressState to set
     */
    public void setDomicileAddressState(final String domicileAddressState)
    {
        this.domicileAddressState = domicileAddressState;
    }

    /**
     * @return the domicileAddressCountry
     */
    public String getDomicileAddressCountry()
    {
        return domicileAddressCountry;
    }

    /**
     * @param domicileAddressCountry the domicileAddressCountry to set
     */
    public void setDomicileAddressCountry(final String domicileAddressCountry)
    {
        this.domicileAddressCountry = domicileAddressCountry;
    }

    /**
     * @return the domicileAddressPostcode
     */
    public String getDomicileAddressPostcode()
    {
        return domicileAddressPostcode;
    }

    /**
     * @param domicileAddressPostcode the domicileAddressPostcode to set
     */
    public void setDomicileAddressPostcode(final String domicileAddressPostcode)
    {
        this.domicileAddressPostcode = domicileAddressPostcode;
    }

    /**
     * @return the incorporatedAddressStreet
     */
    public String getIncorporatedAddressStreet()
    {
        return incorporatedAddressStreet;
    }

    /**
     * @param incorporatedAddressStreet the incorporatedAddressStreet to set
     */
    public void setIncorporatedAddressStreet(final String incorporatedAddressStreet)
    {
        this.incorporatedAddressStreet = incorporatedAddressStreet;
    }

    /**
     * @return the incorporatedAddressCity
     */
    public String getIncorporatedAddressCity()
    {
        return incorporatedAddressCity;
    }

    /**
     * @param incorporatedAddressCity the incorporatedAddressCity to set
     */
    public void setIncorporatedAddressCity(final String incorporatedAddressCity)
    {
        this.incorporatedAddressCity = incorporatedAddressCity;
    }

    /**
     * @return the incorporatedAddressState
     */
    public String getIncorporatedAddressState()
    {
        return incorporatedAddressState;
    }

    /**
     * @param incorporatedAddressState the incorporatedAddressState to set
     */
    public void setIncorporatedAddressState(final String incorporatedAddressState)
    {
        this.incorporatedAddressState = incorporatedAddressState;
    }

    /**
     * @return the incorporatedAddressCountry
     */
    public String getIncorporatedAddressCountry()
    {
        return incorporatedAddressCountry;
    }

    /**
     * @param incorporatedAddressCountry the incorporatedAddressCountry to set
     */
    public void setIncorporatedAddressCountry(final String incorporatedAddressCountry)
    {
        this.incorporatedAddressCountry = incorporatedAddressCountry;
    }

    /**
     * @return the incorporatedAddressPostcode
     */
    public String getIncorporatedAddressPostcode()
    {
        return incorporatedAddressPostcode;
    }

    /**
     * @param incorporatedAddressPostcode the incorporatedAddressPostcode to set
     */
    public void setIncorporatedAddressPostcode(final String incorporatedAddressPostcode)
    {
        this.incorporatedAddressPostcode = incorporatedAddressPostcode;
    }

    /**
     * @return the gfcName
     */

    /**
     * @return the mifidClassification
     */
    public String getMifidClassification()
    {
        return mifidClassification;
    }

    /**
     * @param mifidClassification the mifidClassification to set
     */
    public void setMifidClassification(final String mifidClassification)
    {
        this.mifidClassification = mifidClassification;
    }

    /**
     * @return the eeaEntityFlag
     */
    public String getEeaEntityFlag()
    {
        return eeaEntityFlag;
    }

    /**
     * @param eeaEntityFlag the eeaEntityFlag to set
     */
    public void setEeaEntityFlag(final String eeaEntityFlag)
    {
        this.eeaEntityFlag = eeaEntityFlag;
    }

    /**
     * @return the isAgencyBroker
     */
    public String getIsAgencyBroker()
    {
        return isAgencyBroker;
    }

    /**
     * @param isAgencyBroker the isAgencyBroker to set
     */
    public void setIsAgencyBroker(final String isAgencyBroker)
    {
        this.isAgencyBroker = isAgencyBroker;
    }

    /**
     * @return the largeTraderIdentification1
     */
    public String getLargeTraderIdentification1()
    {
        return largeTraderIdentification1;
    }

    /**
     * @param largeTraderIdentification1 the largeTraderIdentification1 to set
     */
    public void setLargeTraderIdentification1(final String largeTraderIdentification1)
    {
        this.largeTraderIdentification1 = largeTraderIdentification1;
    }

    /**
     * @return the largeTraderIdentification2
     */
    public String getLargeTraderIdentification2()
    {
        return largeTraderIdentification2;
    }

    /**
     * @param largeTraderIdentification2 the largeTraderIdentification2 to set
     */
    public void setLargeTraderIdentification2(final String largeTraderIdentification2)
    {
        this.largeTraderIdentification2 = largeTraderIdentification2;
    }

    /**
     * @return the largeTraderIdentification3
     */
    public String getLargeTraderIdentification3()
    {
        return largeTraderIdentification3;
    }

    /**
     * @param largeTraderIdentification3 the largeTraderIdentification3 to set
     */
    public void setLargeTraderIdentification3(final String largeTraderIdentification3)
    {
        this.largeTraderIdentification3 = largeTraderIdentification3;
    }

    /**
     * @return the parentGfpid
     */
    public String getParentGfpid()
    {
        return parentGfpid;
    }

    /**
     * @param parentGfpid the parentGfpid to set
     */
    public void setParentGfpid(final String parentGfpid)
    {
        this.parentGfpid = parentGfpid;
    }

    /**
     * @return the btsiAcctType
     */
    public String getBtsiAcctType()
    {
        return btsiAcctType;
    }

    /**
     * @param btsiAcctType the btsiAcctType to set
     */
    public void setBtsiAcctType(final String btsiAcctType)
    {
        this.btsiAcctType = btsiAcctType;
    }

    /**
     * @return the acctTypeId
     */
    public Integer getAcctTypeId()
    {
        return acctTypeId;
    }

    /**
     * @param acctTypeId the acctTypeId to set
     */
    public void setAcctTypeId(final Integer acctTypeId)
    {
        this.acctTypeId = acctTypeId;
    }

    /**
     * @return the assetOneFg
     */
    public String getAssetOneFg()
    {
        return assetOneFg;
    }

    /**
     * @param assetOneFg the assetOneFg to set
     */
    public void setAssetOneFg(final String assetOneFg)
    {
        this.assetOneFg = assetOneFg;
    }

    /**
     * @return the instId
     */
    public Long getInstId()
    {
        return instId;
    }

    /**
     * @param instId the instId to set
     */
    public void setInstId(final Long instId)
    {
        this.instId = instId;
    }

    /**
     * @return the busUnitId
     */
    public String getBusUnitId()
    {
        return busUnitId;
    }

    /**
     * @param busUnitId the busUnitId to set
     */
    public void setBusUnitId(final String busUnitId)
    {
        this.busUnitId = busUnitId;
    }

    /**
     * @return the acctBoType
     */
    public String getAcctBoType()
    {
        return acctBoType;
    }

    /**
     * @param acctBoType the acctBoType to set
     */
    public void setAcctBoType(final String acctBoType)
    {
        this.acctBoType = acctBoType;
    }

    /**
     * @return the brchId
     */
    public String getBrchId()
    {
        return brchId;
    }

    /**
     * @param brchId the brchId to set
     */
    public void setBrchId(final String brchId)
    {
        this.brchId = brchId;
    }

    /**
     * @return the restrictViewFlag
     */
    public String getRestrictViewFlag()
    {
        return restrictViewFlag;
    }

    /**
     * @param restrictViewFlag the restrictViewFlag to set
     */
    public void setRestrictViewFlag(final String restrictViewFlag)
    {
        this.restrictViewFlag = restrictViewFlag;
    }

    /**
     * @return the markedForPurgeFlag
     */
    public String getMarkedForPurgeFlag()
    {
        return markedForPurgeFlag;
    }

    /**
     * @param markedForPurgeFlag the markedForPurgeFlag to set
     */
    public void setMarkedForPurgeFlag(final String markedForPurgeFlag)
    {
        this.markedForPurgeFlag = markedForPurgeFlag;
    }

}