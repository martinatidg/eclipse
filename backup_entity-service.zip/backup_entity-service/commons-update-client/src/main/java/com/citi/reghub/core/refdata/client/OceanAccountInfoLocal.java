package com.citi.reghub.core.refdata.client;

import com.citi.ocean.dataobject.Entity;
import com.citi.ocean.dataobject.account.OceanAccountDetail;

/**
 * <code>OceanAccountInfoLocal</code> encapsulates the data of an OCEAN Account.
 * 
 * @author Geetha Konduru (gk11597)
 * @since 23/10/2010 19:11:52
 */

public class OceanAccountInfoLocal extends Entity
{

    private static final long serialVersionUID = 1L;

    private Long oceanAcctId;
    private String acctMnemonic;
    private String cpii;
    private Integer acti;
    private String createdBy;
    private OceanAccountDetail acctDetail;

    // additional columns for tps
    private String accountDescription;
    private String accountImsNumber;
    private String legalEntityCode;
    private String gfci;
    private String codeDesc;
    private String figp;
    private String grandParentId;
    private String grandParentLongName;
    private String managementMnemonic;
    private String raceMicroControlCode;
    private String strategy;
    private String strategyName;
    private String substrategy;
    private String substrategyName;
    private String grandParentLongNameFromRefAcctBasedOnFigp;
    private String grandParentLongNameFromRefAcctBasedOnGrandParentId;
    private String grandParentLongNameFromGrandParentBasedOnFigp;
    private String grandParentLongNameFromGrandParentBasedOnGrandParentId;
    private String eeaFlag;
    private String lei;


    public OceanAccountInfoLocal()
    {
    }

    public OceanAccountInfoLocal(final long oceanAcctId, final String createdBy)
    {
        this.oceanAcctId = oceanAcctId;
        this.createdBy = createdBy;

        setOceanAccountDetail(new OceanAccountDetail());
    }

    public OceanAccountInfoLocal(final long oceanAcctId, final String createdBy,
        final OceanAccountDetail acctDetail)
    {
        this.oceanAcctId = oceanAcctId;
        this.createdBy = createdBy;

        // For Synchronization
        setOceanAccountDetail(acctDetail);
    }

    public Long getOceanAcctId()
    {
        return oceanAcctId;
    }

    public void setOceanAcctId(final Long oceanAcctId)
    {
        this.oceanAcctId = oceanAcctId;
    }

    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(final String createdBy)
    {
        this.createdBy = createdBy;
    }

    public OceanAccountDetail getOceanAccountDetail()
    {
        return acctDetail;
    }

    public void setOceanAccountDetail(final OceanAccountDetail acctDetail)
    {
        this.acctDetail = acctDetail;

        // For Synchronization
        if (acctDetail != null)
        {
            this.oceanAcctId = acctDetail.getOceanAcctId();
            this.acctMnemonic = acctDetail.getAcctMnemonic();
            this.acti = acctDetail.getActi();
            this.cpii = acctDetail.getCpii();
        }
    }

    public String getAcctMnemonic()
    {
        return acctMnemonic;
    }

    public void setAcctMnemonic(final String acctMnemonic)
    {
        this.acctMnemonic = acctMnemonic;
    }

    public String getCpii()
    {
        return cpii;
    }

    public void setCpii(final String cpii)
    {
        this.cpii = cpii;
    }

    public Integer getActi()
    {
        return acti;
    }

    public void setActi(final Integer acti)
    {
        this.acti = acti;
    }

    /**
     * @return the acctDetail
     */
    public OceanAccountDetail getAcctDetail()
    {
        return acctDetail;
    }

    /**
     * @param acctDetail the acctDetail to set
     */
    public void setAcctDetail(final OceanAccountDetail acctDetail)
    {
        this.acctDetail = acctDetail;
    }

    /**
     * @return the accountDescription
     */
    public String getAccountDescription()
    {
        return accountDescription;
    }

    /**
     * @param accountDescription the accountDescription to set
     */
    public void setAccountDescription(final String accountDescription)
    {
        this.accountDescription = accountDescription;
    }

    /**
     * @return the accountImsNumber
     */
    public String getAccountImsNumber()
    {
        return accountImsNumber;
    }

    /**
     * @param accountImsNumber the accountImsNumber to set
     */
    public void setAccountImsNumber(final String accountImsNumber)
    {
        this.accountImsNumber = accountImsNumber;
    }

    /**
     * @return the legalEntityCode
     */
    public String getLegalEntityCode()
    {
        return legalEntityCode;
    }

    /**
     * @param legalEntityCode the legalEntityCode to set
     */
    public void setLegalEntityCode(final String legalEntityCode)
    {
        this.legalEntityCode = legalEntityCode;
    }

    /**
     * @return the gfci
     */
    public String getGfci()
    {
        return gfci;
    }

    /**
     * @param gfci the gfci to set
     */
    public void setGfci(final String gfci)
    {
        this.gfci = gfci;
    }

    /**
     * @return the codeDesc
     */
    public String getCodeDesc()
    {
        return codeDesc;
    }

    /**
     * @param codeDesc the codeDesc to set
     */
    public void setCodeDesc(final String codeDesc)
    {
        this.codeDesc = codeDesc;
    }

    /**
     * @return the figp
     */
    public String getFigp()
    {
        return figp;
    }

    /**
     * @param figp the figp to set
     */
    public void setFigp(final String figp)
    {
        this.figp = figp;
    }

    /**
     * @return the grandParentLongName
     */
    public String getGrandParentLongName()
    {
        return grandParentLongName;
    }

    /**
     * @param grandParentLongName the grandParentLongName to set
     */
    public void setGrandParentLongName(final String grandParentLongName)
    {
        this.grandParentLongName = grandParentLongName;
    }

    /**
     * @return the grandParentId
     */
    public String getGrandParentId()
    {
        return grandParentId;
    }

    /**
     * @param grandParentId the grandParentId to set
     */
    public void setGrandParentId(final String grandParentId)
    {
        this.grandParentId = grandParentId;
    }

    /**
     * @return the managementMnemonic
     */
    public String getManagementMnemonic()
    {
        return managementMnemonic;
    }

    /**
     * @param managementMnemonic the managementMnemonic to set
     */
    public void setManagementMnemonic(final String managementMnemonic)
    {
        this.managementMnemonic = managementMnemonic;
    }

    /**
     * @return the raceMicroControlCode
     */
    public String getRaceMicroControlCode()
    {
        return raceMicroControlCode;
    }

    /**
     * @param raceMicroControlCode the raceMicroControlCode to set
     */
    public void setRaceMicroControlCode(final String raceMicroControlCode)
    {
        this.raceMicroControlCode = raceMicroControlCode;
    }

    /**
     * @return the strategy
     */
    public String getStrategy()
    {
        return strategy;
    }

    /**
     * @param strategy the strategy to set
     */
    public void setStrategy(final String strategy)
    {
        this.strategy = strategy;
    }

    /**
     * @return the strategyName
     */
    public String getStrategyName()
    {
        return strategyName;
    }

    /**
     * @param strategyName the strategyName to set
     */
    public void setStrategyName(final String strategyName)
    {
        this.strategyName = strategyName;
    }

    /**
     * @return the substrategy
     */
    public String getSubstrategy()
    {
        return substrategy;
    }

    /**
     * @param substrategy the substrategy to set
     */
    public void setSubstrategy(final String substrategy)
    {
        this.substrategy = substrategy;
    }

    /**
     * @return the substrategyName
     */
    public String getSubstrategyName()
    {
        return substrategyName;
    }

    /**
     * @param substrategyName the substrategyName to set
     */
    public void setSubstrategyName(final String substrategyName)
    {
        this.substrategyName = substrategyName;
    }

    /**
     * @return the grandParentLongNameFromRefAcctBasedOnFigp
     */
    public String getGrandParentLongNameFromRefAcctBasedOnFigp()
    {
        return grandParentLongNameFromRefAcctBasedOnFigp;
    }

    /**
     * @param grandParentLongNameFromRefAcctBasedOnFigp the grandParentLongNameFromRefAcctBasedOnFigp to
     *            set
     */
    public void setGrandParentLongNameFromRefAcctBasedOnFigp(
        final String grandParentLongNameFromRefAcctBasedOnFigp)
    {
        this.grandParentLongNameFromRefAcctBasedOnFigp = grandParentLongNameFromRefAcctBasedOnFigp;
    }

    /**
     * @return the grandParentLongNameFromRefAcctBasedOnGrandParentId
     */
    public String getGrandParentLongNameFromRefAcctBasedOnGrandParentId()
    {
        return grandParentLongNameFromRefAcctBasedOnGrandParentId;
    }

    /**
     * @param grandParentLongNameFromRefAcctBasedOnGrandParentId the
     *            grandParentLongNameFromRefAcctBasedOnGrandParentId to set
     */
    public void setGrandParentLongNameFromRefAcctBasedOnGrandParentId(
        final String grandParentLongNameFromRefAcctBasedOnGrandParentId)
    {
        this.grandParentLongNameFromRefAcctBasedOnGrandParentId =
            grandParentLongNameFromRefAcctBasedOnGrandParentId;
    }

    /**
     * @return the grandParentLongNameFromGrandParentBasedOnFigp
     */
    public String getGrandParentLongNameFromGrandParentBasedOnFigp()
    {
        return grandParentLongNameFromGrandParentBasedOnFigp;
    }

    /**
     * @param grandParentLongNameFromGrandParentBasedOnFigp the
     *            grandParentLongNameFromGrandParentBasedOnFigp to set
     */
    public void setGrandParentLongNameFromGrandParentBasedOnFigp(
        final String grandParentLongNameFromGrandParentBasedOnFigp)
    {
        this.grandParentLongNameFromGrandParentBasedOnFigp = grandParentLongNameFromGrandParentBasedOnFigp;
    }

    /**
     * @return the grandParentLongNameFromGrandParentBasedOnGrandParentId
     */
    public String getGrandParentLongNameFromGrandParentBasedOnGrandParentId()
    {
        return grandParentLongNameFromGrandParentBasedOnGrandParentId;
    }

    /**
     * @param grandParentLongNameFromGrandParentBasedOnGrandParentId the
     *            grandParentLongNameFromGrandParentBasedOnGrandParentId to set
     */
    public void setGrandParentLongNameFromGrandParentBasedOnGrandParentId(
        final String grandParentLongNameFromGrandParentBasedOnGrandParentId)
    {
        this.grandParentLongNameFromGrandParentBasedOnGrandParentId =
            grandParentLongNameFromGrandParentBasedOnGrandParentId;
    }
    
	public String getEeaFlag() {
		return eeaFlag;
	}

	public void setEeaFlag(String eeaFlag) {
		this.eeaFlag = eeaFlag;
	}

    @Override
    public String toString()
    {
        StringBuilder buf = new StringBuilder(getOceanAccountDetail() != null ? 4096 : 256);
        buf.append(getClass().getSimpleName()).append("@").append(Integer.toHexString(hashCode()));
        buf.append(": [");

        buf.append(" oceanAcctId= '").append(oceanAcctId);
        buf.append("', createdBy= '").append(createdBy);
        buf.append("', acctMnemonic= '").append(acctMnemonic);
        buf.append("', cpii= '").append(cpii);
        buf.append("', acti= '").append(acti);

        if (getOceanAccountDetail() != null)
        {
            buf.append("', oceanAccountDetail= '").append(getOceanAccountDetail());
        }

        return buf.append("' ]").toString();
    }

	public String getLei() {
		return lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

}

// EOF