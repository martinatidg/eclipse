package com.citi.reghub.core.event;

public enum EventName {
	//XM related events
	EXCEPTION_CREATED("exceptionCreated"),
	EXCEPTION_UPDATED("exceptionUpdated"),
	EXCEPTION_CLOSED("exceptionClosed"),
	EXCEPTION_REQUESTED("exceptionRequested"),
	EXCEPTION_STATUS_UPDATED("exceptionStatusUpdated"),
	EXCEPTION_NOTE_ADDED("exceptionNoteAdded"),
	EXCEPTION_NOTE_DELETED("exceptionNoteDeleted"),
	EXCEPTION_ALL_CLOSED("exceptionAllClosed"),
	EXCEPTION_ALL_CLOSED_IGNORED("exceptionAllClosedIgnored");
	//

	final String value;


	EventName(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static EventName fromValue(String v) {
		for (EventName c : EventName.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

}
