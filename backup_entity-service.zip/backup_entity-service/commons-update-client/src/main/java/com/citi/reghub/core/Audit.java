package com.citi.reghub.core;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Audit extends InfoablePojo {
	
	public String regHubId;
	public String stream;
	public String flow;

	public String event;
	public String result;
	public List<String> tags = new ArrayList<String>();

	public LocalDateTime auditTs;
	
	public Audit() {
		this.auditTs = LocalDateTime.now(Clock.systemUTC());
	}
	
	public Audit(Entity e) {
		this.auditTs = LocalDateTime.now(Clock.systemUTC());
		this.regHubId = e.regHubId;
		this.stream = e.stream;
		this.flow = e.flow;
	}
	
}
