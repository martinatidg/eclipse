package com.citi.reghub.core.refdata.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.ocean.dataobject.product.OceanProductSummary;
import com.citi.reghub.core.CommonUtils;

public class RefdataSecurityClient implements RefdataInterface {

	public static Logger LOGGER = LoggerFactory.getLogger(RefdataSecurityClient.class);
	
	private final OceanGemfireCacheClient oceanGemfireCacheClient;

	public RefdataSecurityClient(final OceanGemfireCacheClient oceanGemfireCacheClient) {
		this.oceanGemfireCacheClient = oceanGemfireCacheClient;
	}

	private Map<String, Object> getSecurityDetailsByOceanId(Object oceanId) {
		Long identifierValue = Long.parseLong(oceanId.toString());
		OceanProductSummary resp = oceanGemfireCacheClient.getByOceanProductId(identifierValue);
		OceanProductSummaryLocal oceanProductSummaryLocal = getLocalMap(resp);
		return CommonUtils.objectToMap(oceanProductSummaryLocal);
	}

	private Map<String, Object> getSecurityDetailsByFII(Object fii) {
		Long identifierValue = Long.parseLong(fii.toString());
		OceanProductSummary fiiInfo = oceanGemfireCacheClient.getProductsByFII(identifierValue);
		OceanProductSummaryLocal oceanProductSummaryLocal = getLocalMap(fiiInfo);
		return CommonUtils.objectToMap(oceanProductSummaryLocal);
	}

	private Map<String, Object> getSecurityDetailsByISIN(Object isin) {
		OceanProductSummary isinInfo = oceanGemfireCacheClient.getProductsByISIN(isin.toString());
		OceanProductSummaryLocal oceanProductSummaryLocal = getLocalMap(isinInfo);
		return CommonUtils.objectToMap(oceanProductSummaryLocal);
	}

	private Map<String, Object> getSecurityDetailsByCUSIP(Object cusip) {
		OceanProductSummary cusipInfo = oceanGemfireCacheClient.getProductsByCUSIP(cusip.toString());
		OceanProductSummaryLocal oceanProductSummaryLocal = getLocalMap(cusipInfo);
		return CommonUtils.objectToMap(oceanProductSummaryLocal);
	}

	private Map<String, Object> getSecurityDetailsBySMCP(Object smcp) {
		OceanProductSummary smcpSummary = oceanGemfireCacheClient.getProductsBySMCP(smcp.toString());
		OceanProductSummaryLocal oceanProductSummaryLocal = getLocalMap(smcpSummary);
		return CommonUtils.objectToMap(oceanProductSummaryLocal);
	}

	@Override
	public Map<String, Object> getData(String identifier, Object value) {
		try {
			SecurityIdentifier inputIdentifier = SecurityIdentifier.valueOf(identifier.toUpperCase());
			
			switch (inputIdentifier) {
			case SMCP:
				return getSecurityDetailsBySMCP(value);
			case ISIN:
				return getSecurityDetailsByISIN(value);
			case FII:
				return getSecurityDetailsByFII(value);
			case CUSIP:
				return getSecurityDetailsByCUSIP(value);
			case OCEAN_ID:
				return getSecurityDetailsByOceanId(value);
			}
			return null;
		} catch (IllegalArgumentException e) {
			LOGGER.error("Invalid input Security Identifier: '{}'", identifier, e);
			throw new RuntimeException("Invalid input Security Identifier: " + identifier + " supported Security Identifier are " + SecurityIdentifier.values().toString());
		}	
		
	}
	
	
	private OceanProductSummaryLocal getLocalMap(OceanProductSummary smcpSummary ){
		OceanProductSummaryLocal oceanProductSummaryLocal = new OceanProductSummaryLocal();
		if (smcpSummary != null){
			oceanProductSummaryLocal.setOceanProductId(smcpSummary.getOceanProductId());
			oceanProductSummaryLocal.setCust1Txt(smcpSummary.getCust1Txt());
			oceanProductSummaryLocal.setSectorCd(smcpSummary.getSectorCd());
			oceanProductSummaryLocal.setCusip(smcpSummary.getCusip());
			oceanProductSummaryLocal.setIsin(smcpSummary.getIsin());
			oceanProductSummaryLocal.setSedol(smcpSummary.getSedol());
			oceanProductSummaryLocal.setFii(smcpSummary.getFii());
			oceanProductSummaryLocal.setEts(smcpSummary.getEts());
			oceanProductSummaryLocal.setTckr(smcpSummary.getTckr());
			oceanProductSummaryLocal.setProductType(smcpSummary.getProductType());
			oceanProductSummaryLocal.setSecurityTypeLevel2(smcpSummary.getSecurityTypeLevel2());
			oceanProductSummaryLocal.setSecurityTypeLevel3(smcpSummary.getSecurityTypeLevel3());
			oceanProductSummaryLocal.setContractSize(smcpSummary.getContractSize());
			oceanProductSummaryLocal.setTickSize(smcpSummary.getTickSize());
			oceanProductSummaryLocal.setQuotelotSize(smcpSummary.getQuotelotSize());
			oceanProductSummaryLocal.setRoundLotSize(smcpSummary.getRoundLotSize());
			oceanProductSummaryLocal.setTradeLotSize(smcpSummary.getTradeLotSize());
			oceanProductSummaryLocal.setUnitOfTrade(smcpSummary.getUnitOfTrade());
			oceanProductSummaryLocal.setPointvalue(smcpSummary.getPointvalue());
			oceanProductSummaryLocal.setCfiCode(smcpSummary.getCfiCode());
			oceanProductSummaryLocal.setContractType(smcpSummary.getContractType());
			oceanProductSummaryLocal.setStrikePrice(smcpSummary.getStrikePrice());
			oceanProductSummaryLocal.setExerciseType(smcpSummary.getExerciseType());
			oceanProductSummaryLocal.setExpirationDate(smcpSummary.getExpirationDate());
			oceanProductSummaryLocal.setCurrentMaturityDate(smcpSummary.getCurrentMaturityDate());
			oceanProductSummaryLocal.setIsphysical(smcpSummary.getIsphysical());
			oceanProductSummaryLocal.setIscallable(smcpSummary.getIscallable());
			oceanProductSummaryLocal.setIscash(smcpSummary.getIscash());
			oceanProductSummaryLocal.setIsputable(smcpSummary.getIsputable());
			oceanProductSummaryLocal.setUnderlyingIsin(smcpSummary.getUnderlyingIsin());
			oceanProductSummaryLocal.setIssueCurrCd(smcpSummary.getIssueCurrCd());
			oceanProductSummaryLocal.setPrimaryExng(smcpSummary.getPrimaryExng());
			oceanProductSummaryLocal.setIssueCntryCd(smcpSummary.getIssueCntryCd());
			oceanProductSummaryLocal.setIssuerCntry(smcpSummary.getIssuerCntry());
			oceanProductSummaryLocal.setSmcp(smcpSummary.getSmcp());
			oceanProductSummaryLocal.setDestinationCurrency(smcpSummary.getDestinationCurrency());
			oceanProductSummaryLocal.setLastTradeDate(smcpSummary.getLastTradeDate());
			oceanProductSummaryLocal.setBaseCurrency(smcpSummary.getBaseCurrency());
			oceanProductSummaryLocal.setOtherAdditionalSubProduct(smcpSummary.getOtherAdditionalSubProduct());
			oceanProductSummaryLocal.setOtherBaseProduct(smcpSummary.getOtherBaseProduct());
			oceanProductSummaryLocal.setOtherSubProduct(smcpSummary.getOtherSubProduct());
			oceanProductSummaryLocal.setFinalPriceType(smcpSummary.getFinalPriceType());
			oceanProductSummaryLocal.setFirstLegTermValue(smcpSummary.getFirstLegTermValue());
		//	oceanProductSummaryLocal.setIsoFirstLeg(smcpSummary.getisoFirstLeg());
		//	oceanProductSummaryLocal.setIsoOtherLeg(smcpSummary.getisoOtherLeg());
			oceanProductSummaryLocal.setOtherLegTermValue(smcpSummary.getOtherLegTermValue());
			oceanProductSummaryLocal.setUnderlyingCreditIndexSeries(smcpSummary.getUnderlyingCreditIndexSeries());
			oceanProductSummaryLocal.setUnderlyingCreditIndexVersion(smcpSummary.getUnderlyingCreditIndexVersion());
			oceanProductSummaryLocal.setUnderlyingIssuerType(smcpSummary.getUnderlyingIssuerType());
			oceanProductSummaryLocal.setSettlementType(smcpSummary.getSettlementType());
			oceanProductSummaryLocal.setIsoUnderlying(smcpSummary.getIsoUnderlying());
			oceanProductSummaryLocal.setUnderlyingTermUnit(smcpSummary.getUnderlyingTermUnit());
			oceanProductSummaryLocal.setUnderlyingTermValue(smcpSummary.getUnderlyingTermValue());
			oceanProductSummaryLocal.setIssuerType(smcpSummary.getIssuerType());
			oceanProductSummaryLocal.setOptMaturityDate(smcpSummary.getOptMaturityDate());
			oceanProductSummaryLocal.setProductSubType(smcpSummary.getProductSubType());
			oceanProductSummaryLocal.setProductNm(smcpSummary.getProductNm());
			oceanProductSummaryLocal.setIsEeaTrade(smcpSummary.getIsEeaTrade());
			oceanProductSummaryLocal.setIsLiquiditySubclass(smcpSummary.getIsLiquiditySubclass());
			oceanProductSummaryLocal.setPreTradeSstiThresholdFloor(smcpSummary.getPreTradeSstiThresholdFloor());
			oceanProductSummaryLocal.setPostTradeSstiThresholdFloor(smcpSummary.getPostTradeSstiThresholdFloor());
			oceanProductSummaryLocal.setPostTradeSstiThresholdValue(smcpSummary.getPostTradeSstiThresholdValue());
			oceanProductSummaryLocal.setPreTradeSstiThresholdValue(smcpSummary.getPreTradeSstiThresholdValue());
			oceanProductSummaryLocal.setPreTradeLisThresholdFloor(smcpSummary.getPreTradeLisThresholdFloor());
			oceanProductSummaryLocal.setPostTradeLisThresholdFloor(smcpSummary.getPostTradeLisThresholdFloor());
			oceanProductSummaryLocal.setPreTradeLisThresholdValue(smcpSummary.getPreTradeLisThresholdValue());
			oceanProductSummaryLocal.setPostTradeLisThresholdValue(smcpSummary.getPostTradeLisThresholdValue());
			oceanProductSummaryLocal.setMifidCountrycode(smcpSummary.getMifidCountrycode());
			oceanProductSummaryLocal.setCitiSystematicInternalizer(smcpSummary.getCitiSystematicInternalizer());
			oceanProductSummaryLocal.setIsRequestAdmissionTrading(smcpSummary.getIsRequestAdmissionTrading());
			oceanProductSummaryLocal.setApprovalAdmissionTradingDate(smcpSummary.getApprovalAdmissionTradingDate());
			oceanProductSummaryLocal.setRequestAdmissionTradingDate(smcpSummary.getRequestAdmissionTradingDate());
			oceanProductSummaryLocal.setRequestAdmissionFirstTradeDate(smcpSummary.getRequestAdmissionFirstTradeDate());
			oceanProductSummaryLocal.setPrincipalAmountIssued(smcpSummary.getPrincipalAmountIssued());
			oceanProductSummaryLocal.setMinimumPrincipalDenomination(smcpSummary.getMinimumPrincipalDenomination());
			oceanProductSummaryLocal.setCouponDividendRate(smcpSummary.getCouponDividendRate());
			oceanProductSummaryLocal.setCurrentPeriodSpread(smcpSummary.getCurrentPeriodSpread());
			oceanProductSummaryLocal.setSeniority(smcpSummary.getSeniority());
			oceanProductSummaryLocal.setProductDefinitionName(smcpSummary.getProductDefinitionName());
			oceanProductSummaryLocal.setAdditionalSubProduct(smcpSummary.getAdditionalSubProduct());
			oceanProductSummaryLocal.setBaseProduct(smcpSummary.getBaseProduct());
			oceanProductSummaryLocal.setOtherLegReferenceRate(smcpSummary.getOtherLegReferenceRate());
			oceanProductSummaryLocal.setOtherLegReferenceRateTermUnit(smcpSummary.getOtherLegReferenceRateTermUnit());
			oceanProductSummaryLocal.setFirstLegReferenceRate(smcpSummary.getFirstLegReferenceRate());
			oceanProductSummaryLocal.setFirstLegReferenceRateTermUnit(smcpSummary.getFirstLegReferenceRateTermUnit());
			oceanProductSummaryLocal.setReturnPayoutTrigger(smcpSummary.getReturnPayoutTrigger());
			oceanProductSummaryLocal.setSubProduct(smcpSummary.getSubProduct());
			oceanProductSummaryLocal.setTransactionType(smcpSummary.getTransactionType());
			oceanProductSummaryLocal.setDeliveryMethod(smcpSummary.getDeliveryMethod());
			oceanProductSummaryLocal.setSettlementDate(smcpSummary.getSettlementDate());
			oceanProductSummaryLocal.setPriceUnits(smcpSummary.getPriceUnits());
			oceanProductSummaryLocal.setTerminationDate(smcpSummary.getTerminationDate());
			oceanProductSummaryLocal.setNotionalSchedule(smcpSummary.getNotionalSchedule());
			oceanProductSummaryLocal.setUnderlyingLei(smcpSummary.getUnderlyingLei());
			oceanProductSummaryLocal.setValuationMethodTrigger(smcpSummary.getValuationMethodTrigger());
			oceanProductSummaryLocal.setNotionalCurrencyCode(smcpSummary.getNotionalCurrencyCode());
			oceanProductSummaryLocal.setOtherNotionalCurrencyCode(smcpSummary.getOtherNotionalCurrencyCode());
		}
		return oceanProductSummaryLocal;
		
	}
}
