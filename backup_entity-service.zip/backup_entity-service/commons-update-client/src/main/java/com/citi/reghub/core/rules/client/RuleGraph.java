package com.citi.reghub.core.rules.client;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.AuditTags;
import com.citi.reghub.core.constants.EventTypes;

public class RuleGraph implements Serializable {

    private static final long serialVersionUID = -3480981365171954276L;
	public String id;
    public String name;
    public String type;
    public String description;
    public String group;
    
    
    public List<Rule> rules = new ArrayList<>();
    
    public RuleGraph() {
    }

    public RuleGraph(String id, String name, String type, List<Rule> rules) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.rules = rules;
    }

	public RuleGraphResult execute(Object root, Map<String, Object> data, boolean forceRefreshCache) {

		List<RuleResult> ruleResults = rules.stream().map(r -> r.execute(root, data, forceRefreshCache))
				.collect(Collectors.toList());

		return new RuleGraphResult(ruleResults);
	}

	public Audit toAudit(Audit audit) {
		String event = EventTypes.RULE_GRAPH_EXECUTION + " : " + this.name;
		audit.event = event;
		audit.tags.add(AuditTags.RULE);
		return audit;
	}

    
}
