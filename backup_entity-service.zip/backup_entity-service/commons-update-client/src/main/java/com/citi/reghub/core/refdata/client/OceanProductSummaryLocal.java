package com.citi.reghub.core.refdata.client;

import java.util.Date;

import com.citi.ocean.dataobject.Detail;

public class OceanProductSummaryLocal extends Detail {
	private static final long serialVersionUID = 1L;
	private Long oceanProductId;
	private String cust1Txt;
	private String sectorCd;
	private String cusip;
	private String isin;
	private String sedol;
	private Long fii;
	private String ets;
	private String tckr;
	private String productType;
	private String securityTypeLevel2;
	private String securityTypeLevel3;
	private String contractSize;
	private String tickSize;
	private String quotelotSize;
	private String roundLotSize;
	private String tradeLotSize;
	private Double unitOfTrade;
	private String pointvalue;
	private String cfiCode;
	private String contractType;
	private Double strikePrice;
	private String exerciseType;
	private Date expirationDate;
	private Date currentMaturityDate;
	private String isphysical;
	private String iscallable;
	private String iscash;
	private String isputable;
	private String underlyingIsin;
	private String issueCurrCd;
	private String primaryExng;
	private String issueCntryCd;
	private String issuerCntry;
	private String smcp;
	private String destinationCurrency;
	private Date lastTradeDate;
	private String baseCurrency;
	private String otherAdditionalSubProduct;
	private String otherBaseProduct;
	private String otherSubProduct;
	private String finalPriceType;
	private String firstLegTermValue;
	private String isoFirstLeg;
	private String isoOtherLeg;
	private String otherLegTermValue;
	private String underlyingCreditIndexSeries;
	private String underlyingCreditIndexVersion;
	private String underlyingIssuerType;
	private String settlementType;
	private String isoUnderlying;
	private String underlyingTermUnit;
	private String underlyingTermValue;
	private String issuerType;
	private Date optMaturityDate;
	private String productSubType;
	private String productNm;
	private String isEeaTrade;
	private String isLiquiditySubclass;
	private String preTradeSstiThresholdFloor;
	private String postTradeSstiThresholdFloor;
	private String postTradeSstiThresholdValue;
	private String preTradeSstiThresholdValue;
	private String preTradeLisThresholdFloor;
	private String postTradeLisThresholdFloor;
	private String preTradeLisThresholdValue;
	private String postTradeLisThresholdValue;
	private String mifidCountrycode;
	private String citiSystematicInternalizer;
	private String isRequestAdmissionTrading;
	private Date approvalAdmissionTradingDate;
	private Date requestAdmissionTradingDate;
	private Date requestAdmissionFirstTradeDate;
	private String principalAmountIssued;
	private String minimumPrincipalDenomination;
	private String couponDividendRate;
	private String currentPeriodSpread;
	private String seniority;
	private String productDefinitionName;
	private String additionalSubProduct;
	private String baseProduct;
	private String otherLegReferenceRate;
	private String otherLegReferenceRateTermUnit;
	private String firstLegReferenceRate;
	private String firstLegReferenceRateTermUnit;
	private String returnPayoutTrigger;
	private String subProduct;
	private String transactionType;
	private String deliveryMethod;
	private Date settlementDate;
	private String priceUnits;
	private Date terminationDate;
	private String notionalSchedule;
	private String underlyingLei;
	private String valuationMethodTrigger;
	private String notionalCurrencyCode;
	private String otherNotionalCurrencyCode;

	public String getCust1Txt() {
		return this.cust1Txt;
	}

	public void setCust1Txt(String cust1Txt) {
		this.cust1Txt = cust1Txt;
	}

	public static long getSerialversionuid() {
		return 1L;
	}

	public void setStrikePriceCurrency(Double strikePriceCurrency) {
		this.strikePrice = strikePriceCurrency;
	}

	public Double getStrikePriceCurrency() {
		return this.strikePrice;
	}

	public Double getStrikePrice() {
		return this.strikePrice;
	}

	public void setStrikePrice(Double strikePrice) {
		this.strikePrice = strikePrice;
	}

	public String getIssueCurrCd() {
		return this.issueCurrCd;
	}

	public void setIssueCurrCd(String issueCurrCd) {
		this.issueCurrCd = issueCurrCd;
	}

	public String getSectorCd() {
		return this.sectorCd;
	}

	public void setSectorCd(String sectorCd) {
		this.sectorCd = sectorCd;
	}

	public String getCusip() {
		return this.cusip;
	}

	public void setCusip(String cusip) {
		this.cusip = cusip;
	}

	public String getIsin() {
		return this.isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}

	public String getSedol() {
		return this.sedol;
	}

	public void setSedol(String sedol) {
		this.sedol = sedol;
	}

	public Long getFii() {
		return this.fii;
	}

	public void setFii(Long fii) {
		this.fii = fii;
	}

	public String getEts() {
		return this.ets;
	}

	public void setEts(String ets) {
		this.ets = ets;
	}

	public String getTckr() {
		return this.tckr;
	}

	public void setTckr(String tckr) {
		this.tckr = tckr;
	}

	public String getProductType() {
		return this.productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getSecurityTypeLevel2() {
		return this.securityTypeLevel2;
	}

	public void setSecurityTypeLevel2(String securityTypeLevel2) {
		this.securityTypeLevel2 = securityTypeLevel2;
	}

	public String getSecurityTypeLevel3() {
		return this.securityTypeLevel3;
	}

	public void setSecurityTypeLevel3(String securityTypeLevel3) {
		this.securityTypeLevel3 = securityTypeLevel3;
	}

	public String getContractSize() {
		return this.contractSize;
	}

	public void setContractSize(String contractSize) {
		this.contractSize = contractSize;
	}

	public String getTickSize() {
		return this.tickSize;
	}

	public void setTickSize(String tickSize) {
		this.tickSize = tickSize;
	}

	public String getQuotelotSize() {
		return this.quotelotSize;
	}

	public void setQuotelotSize(String quotelotSize) {
		this.quotelotSize = quotelotSize;
	}

	public String getRoundLotSize() {
		return this.roundLotSize;
	}

	public void setRoundLotSize(String roundLotSize) {
		this.roundLotSize = roundLotSize;
	}

	public String getTradeLotSize() {
		return this.tradeLotSize;
	}

	public void setTradeLotSize(String tradeLotSize) {
		this.tradeLotSize = tradeLotSize;
	}

	public Double getUnitOfTrade() {
		return this.unitOfTrade;
	}

	public void setUnitOfTrade(Double unitOfTrade) {
		this.unitOfTrade = unitOfTrade;
	}

	public String getPointvalue() {
		return this.pointvalue;
	}

	public void setPointvalue(String pointvalue) {
		this.pointvalue = pointvalue;
	}

	public String getCfiCode() {
		return this.cfiCode;
	}

	public void setCfiCode(String cfiCode) {
		this.cfiCode = cfiCode;
	}

	public String getContractType() {
		return this.contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getExerciseType() {
		return this.exerciseType;
	}

	public void setExerciseType(String exerciseType) {
		this.exerciseType = exerciseType;
	}

	public Date getExpirationDate() {
		return this.expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getCurrentMaturityDate() {
		return this.currentMaturityDate;
	}

	public void setCurrentMaturityDate(Date currentMaturityDate) {
		this.currentMaturityDate = currentMaturityDate;
	}

	public String getIsphysical() {
		return this.isphysical;
	}

	public void setIsphysical(String isphysical) {
		this.isphysical = isphysical;
	}

	public String getIscallable() {
		return this.iscallable;
	}

	public void setIscallable(String iscallable) {
		this.iscallable = iscallable;
	}

	public String getIscash() {
		return this.iscash;
	}

	public void setIscash(String iscash) {
		this.iscash = iscash;
	}

	public String getIsputable() {
		return this.isputable;
	}

	public void setIsputable(String isputable) {
		this.isputable = isputable;
	}

	public String getUnderlyingIsin() {
		return this.underlyingIsin;
	}

	public void setUnderlyingIsin(String underlyingIsin) {
		this.underlyingIsin = underlyingIsin;
	}

	public String getPrimaryExng() {
		return this.primaryExng;
	}

	public void setPrimaryExng(String primaryExng) {
		this.primaryExng = primaryExng;
	}

	public String getIssueCntryCd() {
		return this.issueCntryCd;
	}

	public void setIssueCntryCd(String issueCntryCd) {
		this.issueCntryCd = issueCntryCd;
	}

	public String getIssuerCntry() {
		return this.issuerCntry;
	}

	public void setIssuerCntry(String issuerCntry) {
		this.issuerCntry = issuerCntry;
	}

	public Long getOceanProductId() {
		return this.oceanProductId;
	}

	public void setOceanProductId(Long oceanProductId) {
		this.oceanProductId = oceanProductId;
	}

	public String getDestinationCurrency() {
		return this.destinationCurrency;
	}

	public void setDestinationCurrency(String destinationCurrency) {
		this.destinationCurrency = destinationCurrency;
	}

	public Date getLastTradeDate() {
		return this.lastTradeDate;
	}

	public void setLastTradeDate(Date lastTradeDate) {
		this.lastTradeDate = lastTradeDate;
	}

	public String getBaseCurrency() {
		return this.baseCurrency;
	}

	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}

	public String getOtherAdditionalSubProduct() {
		return this.otherAdditionalSubProduct;
	}

	public void setOtherAdditionalSubProduct(String otherAdditionalSubProduct) {
		this.otherAdditionalSubProduct = otherAdditionalSubProduct;
	}

	public String getOtherBaseProduct() {
		return this.otherBaseProduct;
	}

	public void setOtherBaseProduct(String otherBaseProduct) {
		this.otherBaseProduct = otherBaseProduct;
	}

	public String getOtherSubProduct() {
		return this.otherSubProduct;
	}

	public void setOtherSubProduct(String otherSubProduct) {
		this.otherSubProduct = otherSubProduct;
	}

	public String getFinalPriceType() {
		return this.finalPriceType;
	}

	public void setFinalPriceType(String finalPriceType) {
		this.finalPriceType = finalPriceType;
	}

	public String getFirstLegTermValue() {
		return this.firstLegTermValue;
	}

	public void setFirstLegTermValue(String firstLegTermValue) {
		this.firstLegTermValue = firstLegTermValue;
	}

	public String getOtherLegTermValue() {
		return this.otherLegTermValue;
	}

	public void setOtherLegTermValue(String otherLegTermValue) {
		this.otherLegTermValue = otherLegTermValue;
	}

	public String getUnderlyingCreditIndexSeries() {
		return this.underlyingCreditIndexSeries;
	}

	public void setUnderlyingCreditIndexSeries(
			String underlyingCreditIndexSeries) {
		this.underlyingCreditIndexSeries = underlyingCreditIndexSeries;
	}

	public String getUnderlyingCreditIndexVersion() {
		return this.underlyingCreditIndexVersion;
	}

	public void setUnderlyingCreditIndexVersion(
			String underlyingCreditIndexVersion) {
		this.underlyingCreditIndexVersion = underlyingCreditIndexVersion;
	}

	public String getUnderlyingIssuerType() {
		return this.underlyingIssuerType;
	}

	public void setUnderlyingIssuerType(String underlyingIssuerType) {
		this.underlyingIssuerType = underlyingIssuerType;
	}

	public String getSettlementType() {
		return this.settlementType;
	}

	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType;
	}

	public String getUnderlyingTermUnit() {
		return this.underlyingTermUnit;
	}

	public void setUnderlyingTermUnit(String underlyingTermUnit) {
		this.underlyingTermUnit = underlyingTermUnit;
	}

	public String getUnderlyingTermValue() {
		return this.underlyingTermValue;
	}

	public void setUnderlyingTermValue(String underlyingTermValue) {
		this.underlyingTermValue = underlyingTermValue;
	}

	public String getIssuerType() {
		return this.issuerType;
	}

	public void setIssuerType(String issuerType) {
		this.issuerType = issuerType;
	}

	public String getSmcp() {
		return this.smcp;
	}

	public void setSmcp(String smcp) {
		this.smcp = smcp;
	}

	public Date getOptMaturityDate() {
		return this.optMaturityDate;
	}

	public void setOptMaturityDate(Date optMaturityDate) {
		this.optMaturityDate = optMaturityDate;
	}

	public String getProductSubType() {
		return this.productSubType;
	}

	public void setProductSubType(String productSubType) {
		this.productSubType = productSubType;
	}

	public String getIsoFirstLeg() {
		return this.isoFirstLeg;
	}

	public void setIsoFirstLeg(String isoFirstLeg) {
		this.isoFirstLeg = isoFirstLeg;
	}

	public String getIsoOtherLeg() {
		return this.isoOtherLeg;
	}

	public void setIsoOtherLeg(String isoOtherLeg) {
		this.isoOtherLeg = isoOtherLeg;
	}

	public String getIsoUnderlying() {
		return this.isoUnderlying;
	}

	public void setIsoUnderlying(String isoUnderlying) {
		this.isoUnderlying = isoUnderlying;
	}

	public String getProductNm() {
		return this.productNm;
	}

	public void setProductNm(String productNm) {
		this.productNm = productNm;
	}

	public String getIsEeaTrade() {
		return this.isEeaTrade;
	}

	public void setIsEeaTrade(String isEeaTrade) {
		this.isEeaTrade = isEeaTrade;
	}

	public String getIsLiquiditySubclass() {
		return this.isLiquiditySubclass;
	}

	public void setIsLiquiditySubclass(String isLiquiditySubclass) {
		this.isLiquiditySubclass = isLiquiditySubclass;
	}

	public String getPreTradeSstiThresholdFloor() {
		return this.preTradeSstiThresholdFloor;
	}

	public void setPreTradeSstiThresholdFloor(String preTradeSstiThresholdFloor) {
		this.preTradeSstiThresholdFloor = preTradeSstiThresholdFloor;
	}

	public String getPostTradeSstiThresholdFloor() {
		return this.postTradeSstiThresholdFloor;
	}

	public void setPostTradeSstiThresholdFloor(
			String postTradeSstiThresholdFloor) {
		this.postTradeSstiThresholdFloor = postTradeSstiThresholdFloor;
	}

	public String getPostTradeSstiThresholdValue() {
		return this.postTradeSstiThresholdValue;
	}

	public void setPostTradeSstiThresholdValue(
			String postTradeSstiThresholdValue) {
		this.postTradeSstiThresholdValue = postTradeSstiThresholdValue;
	}

	public String getPreTradeSstiThresholdValue() {
		return this.preTradeSstiThresholdValue;
	}

	public void setPreTradeSstiThresholdValue(String preTradeSstiThresholdValue) {
		this.preTradeSstiThresholdValue = preTradeSstiThresholdValue;
	}

	public String getPreTradeLisThresholdFloor() {
		return this.preTradeLisThresholdFloor;
	}

	public void setPreTradeLisThresholdFloor(String preTradeLisThresholdFloor) {
		this.preTradeLisThresholdFloor = preTradeLisThresholdFloor;
	}

	public String getPostTradeLisThresholdFloor() {
		return this.postTradeLisThresholdFloor;
	}

	public void setPostTradeLisThresholdFloor(String postTradeLisThresholdFloor) {
		this.postTradeLisThresholdFloor = postTradeLisThresholdFloor;
	}

	public String getPreTradeLisThresholdValue() {
		return this.preTradeLisThresholdValue;
	}

	public void setPreTradeLisThresholdValue(String preTradeLisThresholdValue) {
		this.preTradeLisThresholdValue = preTradeLisThresholdValue;
	}

	public String getPostTradeLisThresholdValue() {
		return this.postTradeLisThresholdValue;
	}

	public void setPostTradeLisThresholdValue(String postTradeLisThresholdValue) {
		this.postTradeLisThresholdValue = postTradeLisThresholdValue;
	}

	public String getMifidCountrycode() {
		return this.mifidCountrycode;
	}

	public void setMifidCountrycode(String mifidCountrycode) {
		this.mifidCountrycode = mifidCountrycode;
	}

	public String getCitiSystematicInternalizer() {
		return this.citiSystematicInternalizer;
	}

	public void setCitiSystematicInternalizer(String citiSystematicInternalizer) {
		this.citiSystematicInternalizer = citiSystematicInternalizer;
	}

	public String getIsRequestAdmissionTrading() {
		return this.isRequestAdmissionTrading;
	}

	public void setIsRequestAdmissionTrading(String isRequestAdmissionTrading) {
		this.isRequestAdmissionTrading = isRequestAdmissionTrading;
	}

	public Date getApprovalAdmissionTradingDate() {
		return this.approvalAdmissionTradingDate;
	}

	public void setApprovalAdmissionTradingDate(
			Date approvalAdmissionTradingDate) {
		this.approvalAdmissionTradingDate = approvalAdmissionTradingDate;
	}

	public Date getRequestAdmissionTradingDate() {
		return this.requestAdmissionTradingDate;
	}

	public void setRequestAdmissionTradingDate(Date requestAdmissionTradingDate) {
		this.requestAdmissionTradingDate = requestAdmissionTradingDate;
	}

	public Date getRequestAdmissionFirstTradeDate() {
		return this.requestAdmissionFirstTradeDate;
	}

	public void setRequestAdmissionFirstTradeDate(
			Date requestAdmissionFirstTradeDate) {
		this.requestAdmissionFirstTradeDate = requestAdmissionFirstTradeDate;
	}

	public String getPrincipalAmountIssued() {
		return this.principalAmountIssued;
	}

	public void setPrincipalAmountIssued(String principalAmountIssued) {
		this.principalAmountIssued = principalAmountIssued;
	}

	public String getMinimumPrincipalDenomination() {
		return this.minimumPrincipalDenomination;
	}

	public void setMinimumPrincipalDenomination(
			String minimumPrincipalDenomination) {
		this.minimumPrincipalDenomination = minimumPrincipalDenomination;
	}

	public String getCouponDividendRate() {
		return this.couponDividendRate;
	}

	public void setCouponDividendRate(String couponDividendRate) {
		this.couponDividendRate = couponDividendRate;
	}

	public String getCurrentPeriodSpread() {
		return this.currentPeriodSpread;
	}

	public void setCurrentPeriodSpread(String currentPeriodSpread) {
		this.currentPeriodSpread = currentPeriodSpread;
	}

	public String getSeniority() {
		return this.seniority;
	}

	public void setSeniority(String seniority) {
		this.seniority = seniority;
	}

	public String getProductDefinitionName() {
		return this.productDefinitionName;
	}

	public void setProductDefinitionName(String productDefinitionName) {
		this.productDefinitionName = productDefinitionName;
	}

	public String getAdditionalSubProduct() {
		return this.additionalSubProduct;
	}

	public void setAdditionalSubProduct(String additionalSubProduct) {
		this.additionalSubProduct = additionalSubProduct;
	}

	public String getBaseProduct() {
		return this.baseProduct;
	}

	public void setBaseProduct(String baseProduct) {
		this.baseProduct = baseProduct;
	}

	public String getOtherLegReferenceRate() {
		return this.otherLegReferenceRate;
	}

	public void setOtherLegReferenceRate(String otherLegReferenceRate) {
		this.otherLegReferenceRate = otherLegReferenceRate;
	}

	public String getOtherLegReferenceRateTermUnit() {
		return this.otherLegReferenceRateTermUnit;
	}

	public void setOtherLegReferenceRateTermUnit(
			String otherLegReferenceRateTermUnit) {
		this.otherLegReferenceRateTermUnit = otherLegReferenceRateTermUnit;
	}

	public String getFirstLegReferenceRate() {
		return this.firstLegReferenceRate;
	}

	public void setFirstLegReferenceRate(String firstLegReferenceRate) {
		this.firstLegReferenceRate = firstLegReferenceRate;
	}

	public String getFirstLegReferenceRateTermUnit() {
		return this.firstLegReferenceRateTermUnit;
	}

	public void setFirstLegReferenceRateTermUnit(
			String firstLegReferenceRateTermUnit) {
		this.firstLegReferenceRateTermUnit = firstLegReferenceRateTermUnit;
	}

	public String getReturnPayoutTrigger() {
		return this.returnPayoutTrigger;
	}

	public void setReturnPayoutTrigger(String returnPayoutTrigger) {
		this.returnPayoutTrigger = returnPayoutTrigger;
	}

	public String getSubProduct() {
		return this.subProduct;
	}

	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getDeliveryMethod() {
		return this.deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public Date getSettlementDate() {
		return this.settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getPriceUnits() {
		return this.priceUnits;
	}

	public void setPriceUnits(String priceUnits) {
		this.priceUnits = priceUnits;
	}

	public Date getTerminationDate() {
		return this.terminationDate;
	}

	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	public String getNotionalSchedule() {
		return this.notionalSchedule;
	}

	public void setNotionalSchedule(String notionalSchedule) {
		this.notionalSchedule = notionalSchedule;
	}

	public String getUnderlyingLei() {
		return this.underlyingLei;
	}

	public void setUnderlyingLei(String underlyingLei) {
		this.underlyingLei = underlyingLei;
	}

	public String getValuationMethodTrigger() {
		return this.valuationMethodTrigger;
	}

	public void setValuationMethodTrigger(String valuationMethodTrigger) {
		this.valuationMethodTrigger = valuationMethodTrigger;
	}

	public String getNotionalCurrencyCode() {
		return this.notionalCurrencyCode;
	}

	public void setNotionalCurrencyCode(String notionalCurrencyCode) {
		this.notionalCurrencyCode = notionalCurrencyCode;
	}

	public String getOtherNotionalCurrencyCode() {
		return this.otherNotionalCurrencyCode;
	}

	public void setOtherNotionalCurrencyCode(String otherNotionalCurrencyCode) {
		this.otherNotionalCurrencyCode = otherNotionalCurrencyCode;
	}

}
