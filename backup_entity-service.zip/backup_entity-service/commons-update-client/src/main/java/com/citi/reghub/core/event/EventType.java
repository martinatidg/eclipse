package com.citi.reghub.core.event;

public enum EventType {

	EXCEPTION("exception");
	//

	final String value;


	EventType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static EventType fromValue(String v) {
		for (EventType c : EventType.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

}
