package com.citi.reghub.core.converter;

public class DoubleConverter implements TypeConverter<String, Double> {

	public Double convert(String obj,String format) {
		// TODO Auto-generated method stub
		return new Double(obj);
	}

}
