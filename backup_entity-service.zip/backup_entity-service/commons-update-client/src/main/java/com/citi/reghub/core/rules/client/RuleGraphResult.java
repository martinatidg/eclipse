package com.citi.reghub.core.rules.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.constants.EntityStatus;

import com.citi.reghub.core.Audit;

public class RuleGraphResult extends Result {
    
	private List<RuleResult> ruleResults = new ArrayList<>();
	public List<String> resultCodes = new ArrayList<>();
	private List<String> definedExceptionOrder = Arrays.asList(EntityStatus.APP_EXCEPTION, EntityStatus.NON_REPORTABLE,
			EntityStatus.TECH_EXCEPTION, EntityStatus.BIZ_EXCEPTION, EntityStatus.REPORTABLE);

	public RuleGraphResult() {
		super();
	}

	public RuleGraphResult(List<RuleResult> ruleResults) {
		super();
		setRuleResults(ruleResults);
	}

	
    public List<RuleResult> getRuleResults() {
        return ruleResults;
    }

	public void setRuleResults(List<RuleResult> ruleResults) {
		this.ruleResults = ruleResults;

		Optional<RuleResult> mostValuedResult = ruleResults.stream()
				.sorted(Comparator.comparing(c -> definedExceptionOrder.indexOf(c.status))).findFirst();
		if (mostValuedResult.isPresent())
			this.mark(mostValuedResult.get().status);

		ruleResults.stream().filter(item -> item.code != null).forEach(item -> this.resultCodes.add(item.code));

	}


	public Audit toAudit(Audit audit) {
		String result = this.status;
		audit.result = result;
		if(!ruleResults.isEmpty())
			ruleResults.forEach(r -> audit.info.put(r.ruleName, r.toMap(r)));
		return audit;
	}

}
