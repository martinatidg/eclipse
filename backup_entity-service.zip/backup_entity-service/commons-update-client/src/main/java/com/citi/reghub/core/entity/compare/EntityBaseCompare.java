package com.citi.reghub.core.entity.compare;

import java.util.Comparator;

import org.apache.commons.lang3.StringUtils;

import com.citi.reghub.core.Entity;

public class EntityBaseCompare implements Comparator<Entity> {

	public int compare(Entity a, Entity b) {
		int c = StringUtils.compare(a.sourceId, b.sourceId);
		if (c != 0) {
			return c;
		}
		
		c = StringUtils.compare(a.sourceSystem, b.sourceSystem);
		if (c != 0) {
			return c;
		}
		
		c = StringUtils.compare(a.sourceVersion, b.sourceVersion);
		if (c != 0) {
			return c;
		}

		return 0;
	}
}
