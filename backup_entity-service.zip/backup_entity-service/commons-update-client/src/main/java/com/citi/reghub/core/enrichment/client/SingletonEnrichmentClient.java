package com.citi.reghub.core.enrichment.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonEnrichmentClient {

	private static EnrichmentClient instance;
	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonEnrichmentClient.class);

	public static EnrichmentClient getInstance() {
		if (instance == null) {
			LOGGER.error("EnrichmentClient instance='{}'", instance,
					new RuntimeException("Instance of Enrichment client is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonEnrichmentClient");
		}
		return instance;
	}

	public static void setInstance(EnrichmentClientConfig config) {
		instance = new EnrichmentClient(config);
	}
}
