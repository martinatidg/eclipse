package com.citi.reghub.core.metadata.client;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public class MetadataClient {

    private MetadataClientConfig metadataClientConfig;
    private CacheClient cacheClient;

    private static final String CACHE_METADATA_COLLECTION = "metadata";
    private static final String CACHE_METADATA_COLLECTION_TYPE = "Map";
	private static final String UNDEFINED = "undefined";

    public static Logger LOGGER = LoggerFactory.getLogger(MetadataClient.class);

    public MetadataClient(MetadataClientConfig metadataClientConfig) {
        if(metadataClientConfig == null) LOGGER.warn("Provided metadata client config is null, using default configuration");
        this.metadataClientConfig = (metadataClientConfig == null ? new MetadataClientConfig() :  metadataClientConfig);
        if (!this.metadataClientConfig.containsKey(MetadataClientConfig.METADATA_URL_KEY)) this.metadataClientConfig.setDefaultMetadataUrl();
        this.cacheClient = this.metadataClientConfig.getCacheClient();
        LOGGER.info("Instantialised Metadata Client with configuration='{}'", metadataClientConfig);
    }


    public Object get(String metadataName) {
    	LOGGER.debug("Processing get for metadata with metadataName='{}'", metadataName);
        Object metadata = getFromCache(metadataName);
        if(metadata == null){
            metadata = getFromService(metadataName);
        }
        return metadata;
    }

    private String prepareMetadataUrl(String metadataName) {
        return String.format(metadataClientConfig.getMetadataUrl(),metadataName);
    }

    private Object getFromCache(String metadataName){
        LOGGER.debug("Processing getFromCache for metadata with metadataName='{}'", metadataName);
        return cacheClient.get( metadataName,prepareCacheClientConfig());
    }

    private void putInCache(String metadataName,Object metadata){
        cacheClient.put(metadataName, metadata,prepareCacheClientConfig());
        LOGGER.trace("Processed put for metadataName='{}', metadata='{}'", metadataName, metadata);
    }

    private Object getFromService(String metadataName){
        LOGGER.debug("Processing getFromService for metadata with name", metadataName);
        if (metadataClientConfig.getRestClient() == null) {
        	RuntimeException ex = new RuntimeException("Invalid Rest client for metadata");
        	LOGGER.error("HTTP_CLIENT has not be set with metadataName='{}'", metadataName, ex);
        	throw ex;
        }
        Map meta = metadataClientConfig.getRestClient().get(prepareMetadataUrl(metadataName),Map.class);
        if(meta == null) {
            RuntimeException ex = new RuntimeException("Invalid metadata name has been provided");
            LOGGER.error("Get request with metadataName='{}'", metadataName, ex);
            throw ex;
        }Metadata metadata = new Metadata(meta);
        putInCache(metadataName, metadata.value);
        return metadata.value;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private Map prepareCacheClientConfig(){
        Map props = new HashMap<>();
        String stream = metadataClientConfig.getStreamCode()== null? UNDEFINED : metadataClientConfig.getStreamCode().toLowerCase();
		String flow = metadataClientConfig.getFlowCode()== null? UNDEFINED : metadataClientConfig.getFlowCode().toLowerCase();
		String metadataName = stream+"_"+flow+"_"+CACHE_METADATA_COLLECTION;
        props.put(CacheClient.CACHE_COLLECTION_NAME, metadataName);
        props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_METADATA_COLLECTION_TYPE);
        return props;
    }
    
    public MetadataClientConfig getMetadataClientConfig()
    {
    	return metadataClientConfig;
    }

}