package com.citi.reghub.core.metadata.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonMetadataClient {

	private static MetadataClient instance;
	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonMetadataClient.class);

	public static MetadataClient getInstance() {
		if (instance == null) {
			LOGGER.error("MetadataClient instance='{}'", instance,
					new RuntimeException("Instance of Metadata client is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonMetadataClient");
		}
		return instance;
	}

	public static void setInstance(MetadataClientConfig config) {
		instance = new MetadataClient(config);
	}

}
