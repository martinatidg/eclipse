package com.citi.reghub.core.enrichment.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.citi.reghub.core.ConvertToMongoMap;

public class EnricherResult implements ConvertToMongoMap {
	
	public String enricherId;
    public String comments;
    public Object value;
    
	public EnricherResult(String enricherId, String comments, Object value) {
		this.enricherId = enricherId;
		this.comments = comments;
		this.value = value;
	}

	public String getEnricherId() {
		return enricherId;
	}

	public void setEnricherId(String enricherId) {
		this.enricherId = enricherId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	@Override
	public Map toMap(Object object) {
		Map<String, Object> enricherResultMap = new HashMap<String, Object>();
		enricherResultMap.put("enricherId", this.enricherId);
		enricherResultMap.put("comments", this.comments);
		enricherResultMap.put("value", this.value);
		enricherResultMap.values().removeIf(Objects::isNull);
		return enricherResultMap;
	}   
    
}
