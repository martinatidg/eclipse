package com.citi.reghub.core.response.handler;

public class NoDefinedProcessorException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NoDefinedProcessorException(String msgType) {
		super(msgType);
	}
	
}
