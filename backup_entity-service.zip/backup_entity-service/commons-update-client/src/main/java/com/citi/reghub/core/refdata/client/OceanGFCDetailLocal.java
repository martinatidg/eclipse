package com.citi.reghub.core.refdata.client;



import java.util.LinkedHashMap;
import java.util.Map;

import com.citi.ocean.dataobject.Detail;

public class OceanGFCDetailLocal extends Detail
{

    private static final long serialVersionUID = 1L;
    private String gfci;
    private String gfcLongname;
    private String cagid;
    private String cgmlLargeTrader;
    private String taxId;
    private String parentGfpid;
    private String lei;
    private String domicileAddressStreet;
    private String domicileAddressCity;
    private String domicileAddressState;
    private String domicileAddressCountry;
    private String domicileAddressPostcode;
    private String incorporatedAddressStreet;
    private String incorporatedAddressCity;
    private String incorporatedAddressState;
    private String incorporatedAddressCountry;
    private String incorporatedAddressPostcode;
    private String eeaEntityFlag;

    public OceanGFCDetailLocal(final String gfci, final String gfcLongname, final String cagid,
        final String cgmlLargeTrader, final String taxId, final String parentGfpid, final String lei,
        final String domicileAddressStreet, final String domicileAddressCity,
        final String domicileAddressState, final String domicileAddressCountry,
        final String domicileAddressPostcode, final String incorporatedAddressStreet,
        final String incorporatedAddressCity, final String incorporatedAddressState,
        final String incorporatedAddressCountry, final String incorporatedAddressPostcode,
        final String eeaEntityFlag)
    {
        this.gfci = gfci;
        this.gfcLongname = gfcLongname;
        this.cagid = cagid;
        this.cgmlLargeTrader = cgmlLargeTrader;
        this.taxId = taxId;
        this.parentGfpid = parentGfpid;
        this.lei = lei;
        this.domicileAddressStreet = domicileAddressStreet;
        this.domicileAddressCity = domicileAddressCity;
        this.domicileAddressState = domicileAddressState;
        this.domicileAddressCountry = domicileAddressCountry;
        this.domicileAddressPostcode = domicileAddressPostcode;
        this.incorporatedAddressStreet = incorporatedAddressStreet;
        this.incorporatedAddressCity = incorporatedAddressCity;
        this.incorporatedAddressState = incorporatedAddressState;
        this.incorporatedAddressCountry = incorporatedAddressCountry;
        this.incorporatedAddressPostcode = incorporatedAddressPostcode;
        this.eeaEntityFlag = eeaEntityFlag;
    }

    /**
     *
     */

    /**
     *
     */
    public OceanGFCDetailLocal()
    {
    }

    @Override
    public String toString()
    {
        StringBuilder buf = new StringBuilder(3076);

        Map<String, Object> map = new LinkedHashMap<String, Object>();

        map.put("gfci", gfci);
        map.put("gfcLongname", gfcLongname);
        map.put("cagid", cagid);
        map.put("cgmlLargeTrader", cgmlLargeTrader);
        map.put("taxId", taxId);
        map.put("parentGfpid", parentGfpid);
        map.put("lei", lei);
        map.put("domicileAddressStreet", domicileAddressStreet);
        map.put("domicileAddressCity", domicileAddressCity);
        map.put("domicileAddressState", domicileAddressState);
        map.put("domicileAddressCountry", domicileAddressCountry);
        map.put("domicileAddressPostcode", domicileAddressPostcode);
        map.put("incorporatedAddressStreet", incorporatedAddressStreet);
        map.put("incorporatedAddressCity", incorporatedAddressCity);
        map.put("incorporatedAddressState", incorporatedAddressState);
        map.put("incorporatedAddressCountry", incorporatedAddressCountry);
        map.put("incorporatedAddressPostcode", incorporatedAddressPostcode);
        map.put("eeaEntityFlag", eeaEntityFlag);

        toString(buf, map);

        return buf.toString();
    }

    /**
     * @return the gfci
     */
    public String getGfci()
    {
        return gfci;
    }

    /**
     * @param gfci the gfci to set
     */
    public void setGfci(final String gfci)
    {
        this.gfci = gfci;
    }

    /**
     * @return the gfcLongname
     */
    public String getGfcLongname()
    {
        return gfcLongname;
    }

    /**
     * @param gfcLongname the gfcLongname to set
     */
    public void setGfcLongname(final String gfcLongname)
    {
        this.gfcLongname = gfcLongname;
    }

    /**
     * @return the cagid
     */
    public String getCagid()
    {
        return cagid;
    }

    /**
     * @param cagid the cagid to set
     */
    public void setCagid(final String cagid)
    {
        this.cagid = cagid;
    }

    /**
     * @return the cgmlLargeTrader
     */
    public String getCgmlLargeTrader()
    {
        return cgmlLargeTrader;
    }

    /**
     * @param cgmlLargeTrader the cgmlLargeTrader to set
     */
    public void setCgmlLargeTrader(final String cgmlLargeTrader)
    {
        this.cgmlLargeTrader = cgmlLargeTrader;
    }

    /**
     * @return the taxId
     */
    public String getTaxId()
    {
        return taxId;
    }

    /**
     * @param taxId the taxId to set
     */
    public void setTaxId(final String taxId)
    {
        this.taxId = taxId;
    }

    /**
     * @return the parentGfpid
     */
    public String getParentGfpid()
    {
        return parentGfpid;
    }

    /**
     * @param parentGfpid the parentGfpid to set
     */
    public void setParentGfpid(final String parentGfpid)
    {
        this.parentGfpid = parentGfpid;
    }

    /**
     * @return the lei
     */
    public String getLei()
    {
        return lei;
    }

    /**
     * @param lei the lei to set
     */
    public void setLei(final String lei)
    {
        this.lei = lei;
    }

    /**
     * @return the domicileAddressStreet
     */
    public String getDomicileAddressStreet()
    {
        return domicileAddressStreet;
    }

    /**
     * @param domicileAddressStreet the domicileAddressStreet to set
     */
    public void setDomicileAddressStreet(final String domicileAddressStreet)
    {
        this.domicileAddressStreet = domicileAddressStreet;
    }

    /**
     * @return the domicileAddressCity
     */
    public String getDomicileAddressCity()
    {
        return domicileAddressCity;
    }

    /**
     * @param domicileAddressCity the domicileAddressCity to set
     */
    public void setDomicileAddressCity(final String domicileAddressCity)
    {
        this.domicileAddressCity = domicileAddressCity;
    }

    /**
     * @return the domicileAddressState
     */
    public String getDomicileAddressState()
    {
        return domicileAddressState;
    }

    /**
     * @param domicileAddressState the domicileAddressState to set
     */
    public void setDomicileAddressState(final String domicileAddressState)
    {
        this.domicileAddressState = domicileAddressState;
    }

    /**
     * @return the domicileAddressCountry
     */
    public String getDomicileAddressCountry()
    {
        return domicileAddressCountry;
    }

    /**
     * @param domicileAddressCountry the domicileAddressCountry to set
     */
    public void setDomicileAddressCountry(final String domicileAddressCountry)
    {
        this.domicileAddressCountry = domicileAddressCountry;
    }

    /**
     * @return the domicileAddressPostcode
     */
    public String getDomicileAddressPostcode()
    {
        return domicileAddressPostcode;
    }

    /**
     * @param domicileAddressPostcode the domicileAddressPostcode to set
     */
    public void setDomicileAddressPostcode(final String domicileAddressPostcode)
    {
        this.domicileAddressPostcode = domicileAddressPostcode;
    }

    /**
     * @return the incorporatedAddressStreet
     */
    public String getIncorporatedAddressStreet()
    {
        return incorporatedAddressStreet;
    }

    /**
     * @param incorporatedAddressStreet the incorporatedAddressStreet to set
     */
    public void setIncorporatedAddressStreet(final String incorporatedAddressStreet)
    {
        this.incorporatedAddressStreet = incorporatedAddressStreet;
    }

    /**
     * @return the incorporatedAddressCity
     */
    public String getIncorporatedAddressCity()
    {
        return incorporatedAddressCity;
    }

    /**
     * @param incorporatedAddressCity the incorporatedAddressCity to set
     */
    public void setIncorporatedAddressCity(final String incorporatedAddressCity)
    {
        this.incorporatedAddressCity = incorporatedAddressCity;
    }

    /**
     * @return the incorporatedAddressState
     */
    public String getIncorporatedAddressState()
    {
        return incorporatedAddressState;
    }

    /**
     * @param incorporatedAddressState the incorporatedAddressState to set
     */
    public void setIncorporatedAddressState(final String incorporatedAddressState)
    {
        this.incorporatedAddressState = incorporatedAddressState;
    }

    /**
     * @return the incorporatedAddressCountry
     */
    public String getIncorporatedAddressCountry()
    {
        return incorporatedAddressCountry;
    }

    /**
     * @param incorporatedAddressCountry the incorporatedAddressCountry to set
     */
    public void setIncorporatedAddressCountry(final String incorporatedAddressCountry)
    {
        this.incorporatedAddressCountry = incorporatedAddressCountry;
    }

    /**
     * @return the incorporatedAddressPostcode
     */
    public String getIncorporatedAddressPostcode()
    {
        return incorporatedAddressPostcode;
    }

    /**
     * @param incorporatedAddressPostcode the incorporatedAddressPostcode to set
     */
    public void setIncorporatedAddressPostcode(final String incorporatedAddressPostcode)
    {
        this.incorporatedAddressPostcode = incorporatedAddressPostcode;
    }

    /**
     * @return the eeaEntityFlag
     */
    public String getEeaEntityFlag()
    {
        return eeaEntityFlag;
    }

    /**
     * @param eeaEntityFlag the eeaEntityFlag to set
     */
    public void setEeaEntityFlag(final String eeaEntityFlag)
    {
        this.eeaEntityFlag = eeaEntityFlag;
    }

    /**
     * @return the serialversionuid
     */
    public static long getSerialversionuid()
    {
        return serialVersionUID;
    }

}

// EOF