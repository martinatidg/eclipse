package com.citi.reghub.core.rules.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DroolsEngine {

    private static DroolsEngine engine;
    private Lock obj = new ReentrantLock();
    private Map<String, KieBase> knwBuilderWithRuleSetCodeKey = new ConcurrentHashMap<String, KieBase>();
    private static final Logger LOGGER = LoggerFactory.getLogger(DroolsEngine.class);

    public static DroolsEngine getEngine() {
        if (engine == null) engine = new DroolsEngine();
        return engine;
    }

    public RuleResult execute(Rule rule, Object root, Map<String,Object> data, boolean forceRefreshCache) {
    	LOGGER.debug("Processing excute, request with rule='{}', root='{}', data='{}', cacheRefresh='{}'", rule, root, data, forceRefreshCache);
        RuleResult result = new RuleResult(rule.name);
        KieBase kbase = null;
        String ruleText = rule.getBase64DecodedDefinition();
        String ruleSetCode = rule.name;
        if (forceRefreshCache || knwBuilderWithRuleSetCodeKey.get(ruleSetCode) == null) {
            try {
                obj.lock();
                KieServices kieServices = KieServices.Factory.get();
                KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
                kieFileSystem.write("src/main/resources/com/citi/reghub/" + ruleSetCode + ".drl", ruleText.toString());
                KieBuilder kbuilder = kieServices.newKieBuilder(kieFileSystem);
                kbuilder.buildAll();
                if (kbuilder.getResults().hasMessages(Message.Level.ERROR)) {
                    throw new RuntimeException("Error building drools rule: " + kbuilder.getResults().toString());
                }
                KieContainer kContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
                kbase = kContainer.getKieBase();
                knwBuilderWithRuleSetCodeKey.put(ruleSetCode, kbase);
            } finally {
                obj.unlock();
            }
        } else {
        	kbase = knwBuilderWithRuleSetCodeKey.get(ruleSetCode);
        }
        List<Object> values = new ArrayList<>();
        values.add(data);
        values.add(root);
        values.add(result);
        kbase.newStatelessKieSession().execute(values);
        return result;
    }
}
