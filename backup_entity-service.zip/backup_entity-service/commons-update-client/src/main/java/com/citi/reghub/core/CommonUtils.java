package com.citi.reghub.core;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonUtils {
	public static Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);
			
	public static Map<String, Object> objectToMap(Object inputPojo) {
		Map<String, Object> objectAsMap = new HashMap<String, Object>();
		try {
			BeanInfo info = Introspector.getBeanInfo(inputPojo.getClass());
			for (PropertyDescriptor pd : info.getPropertyDescriptors()) {
				Method reader = pd.getReadMethod();
				if (reader != null) {
					objectAsMap.put(pd.getName(), reader.invoke(inputPojo));
				}					
			}
		} catch (IntrospectionException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			LOGGER.error("Error converting given object to Map", e);
			throw new RuntimeException("Error converting given object to Map", e);
		}
		return objectAsMap;
	}
}
