package com.citi.reghub.core.constants;

public interface EntityFlags {
	
	String CANCEL_FOR_AMEND = "CANCEL_FOR_AMEND";
}
