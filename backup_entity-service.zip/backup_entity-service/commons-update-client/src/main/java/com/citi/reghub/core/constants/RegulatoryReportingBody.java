package com.citi.reghub.core.constants;

public interface RegulatoryReportingBody {
	
	String ARM = "ARM";
	String APA = "APA";
	String ECMA = "ECMA";
}
