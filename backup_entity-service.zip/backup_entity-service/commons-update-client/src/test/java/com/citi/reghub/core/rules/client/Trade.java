package com.citi.reghub.core.rules.client;

import java.util.HashMap;
import java.util.Map;

public class Trade {
    public String tradeId;
    public String securityId;
    public String exchangeCode;
    public Map<String,Object> info = new HashMap<>();

}
