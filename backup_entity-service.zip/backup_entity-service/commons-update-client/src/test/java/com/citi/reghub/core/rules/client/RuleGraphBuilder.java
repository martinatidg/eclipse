package com.citi.reghub.core.rules.client;

import java.util.ArrayList;
import java.util.List;

public class RuleGraphBuilder {
    private String id = "55d4527b795633d28e3dfce9";
    private String name;
    private String type = "Sequential";
    private List<Rule> rules = new ArrayList<Rule>();

    public RuleGraphBuilder name(String name) {
        this.name = name;
        return this;
    }

    public RuleGraphBuilder rule(String name, String fileName, String resultCode) {
        Rule rule = new RuleBuilder().build("ruleId" + fileName, name, fileName, resultCode);
        rules.add(rule);
        return this;
    }
    
    public RuleGraphBuilder rule(String name, String fileName, String resultCode, String owner,String type, String level ,String xstream) {
        Rule rule = new RuleBuilder().build("ruleId" + fileName, name, fileName, resultCode);
        rule.setOwner(owner);
        rule.setType(type);
        rule.setLevel(level);
        rule.setXstream(xstream);
        rules.add(rule);
        return this;
    }

    public RuleGraphBuilder rule(String name, String fileName, String metadataName, String metadataKey, String resultCode) {
        Rule rule = new RuleBuilder().metadata(metadataName,metadataKey).build("ruleId" + fileName, name, fileName, resultCode);
        rules.add(rule);
        return this;
    }

    public RuleGraph build() {
        return new RuleGraph(id,name,type,rules);
    }
}
