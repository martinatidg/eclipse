package com.citi.reghub.core.entity.client;

import org.apache.http.impl.client.HttpClients;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.client.RestClient;

public class EntityClientTest {

	// Disabled on repository. uncomment when developing on local repository.

	@Test
	public void testGetLatestEntityBySourceId2() {
//		// SIT
//		String stream = "m2tr";
//		String flow = "csheq";
//		String sourceID = "489580745";		// SIT
//		String host = "sd-c3af-37ba";	// SIT

//		// QAT
//		String stream = "m2tr";
//		String flow = "otceqd";
//		String sourceID = "PFS-9890134-39344541-1-UITID";		// QAT
//		String host = "sd-3b5d-e5fb";		// QAT

//		// UAT
//		String stream = "m2tr";
//		String flow = "cshfx";
//		String sourceID = "139809602";
//		String host = "sd-87b5-53ae";

		//String ENTITY_URL_VALUE = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
//		String ENTITY_URL_VALUE = "http://sd-3b5d-e5fb.nam.nsroot.net:9088/reghub-api/entity-service/entities/generic";
//		String ENTITY_URL_VALUE = "http://" + host + ".nam.nsroot.net:9088/reghub-api/entity-service/entities";		// SIT
//		EntityClientConfig entityClientConfig = new EntityClientConfig();
//		RestClient restClient = new RestClient(HttpClients.createDefault());
//		entityClientConfig.set(EntityClientConfig.REST_CLIENT, restClient);
//		entityClientConfig.set(EntityClientConfig.ENTITY_URL_KEY, ENTITY_URL_VALUE);
//
//		EntityClient entityClient = new EntityClient(entityClientConfig);
//		//Entity entity = entityClient.getLatestEntityBySourceId("perf5eq1100613");
//		Entity entity = entityClient.getLatestEntityBySourceId(stream, flow, sourceID);
//
//		System.out.println("entity:\n" + entity);
//		Assert.assertNotNull("The entity is null", entity);
	}
}
