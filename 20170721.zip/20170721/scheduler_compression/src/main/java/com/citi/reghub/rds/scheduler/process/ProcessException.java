package com.citi.reghub.rds.scheduler.process;

/**
 * Used by {@link RuntimeProcessor}
 * 
 * @author Michael Rootman
 *
 */
@SuppressWarnings("serial")
public class ProcessException extends Exception {

}
