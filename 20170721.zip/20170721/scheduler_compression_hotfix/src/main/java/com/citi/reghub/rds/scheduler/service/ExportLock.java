package com.citi.reghub.rds.scheduler.service;

public class ExportLock {

	private String db;
	private String collection;
	private long lastExportTimestamp;
	private long newExportTimestamp;
	private long lockObtainedTimestamp;

	public long getLastExportTimestamp() {
		return lastExportTimestamp;
	}

	public void setLastExportTimestamp(long lastExportTimestamp) {
		this.lastExportTimestamp = lastExportTimestamp;
	}

	public long getNewExportTimestamp() {
		return newExportTimestamp;
	}

	public void setNewExportTimestamp(long newExportTimestamp) {
		this.newExportTimestamp = newExportTimestamp;
	}

	public long getLockObtainedTimestamp() {
		return lockObtainedTimestamp;
	}

	public void setLockObtainedTimestamp(long lockObtainedTimestamp) {
		this.lockObtainedTimestamp = lockObtainedTimestamp;
	}

	public String getDb() {
		return db;
	}

	public void setDb(String db) {
		this.db = db;
	}

	public String getCollection() {
		return collection;
	}

	public void setCollection(String collection) {
		this.collection = collection;
	}

	@Override
	public String toString() {
		return "ExportLock [db=" + db + ", collection=" + collection + ", lastExportTimestamp=" + lastExportTimestamp
				+ ", newExportTimestamp=" + newExportTimestamp + ", lockObtainedTimestamp=" + lockObtainedTimestamp
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((collection == null) ? 0 : collection.hashCode());
		result = prime * result + ((db == null) ? 0 : db.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExportLock other = (ExportLock) obj;
		if (collection == null) {
			if (other.collection != null)
				return false;
		} else if (!collection.equals(other.collection))
			return false;
		if (db == null) {
			if (other.db != null)
				return false;
		} else if (!db.equals(other.db))
			return false;
		return true;
	}

}