package com.java8.optional;

import java.util.*;

public class Person {

    private Optional<Car> car;

    public Optional<Car> getCar() {
        return car;
    }
}
