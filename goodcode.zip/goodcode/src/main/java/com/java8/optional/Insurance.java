package com.java8.optional;

public class Insurance {

    private String name;

    public String getName() {
        return name;
    }
}
