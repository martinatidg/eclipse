package com.java8.stream;

public class StreamTest {

}
