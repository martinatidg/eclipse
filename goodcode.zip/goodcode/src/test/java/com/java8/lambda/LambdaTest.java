package com.java8.lambda;

public class LambdaTest {

}
