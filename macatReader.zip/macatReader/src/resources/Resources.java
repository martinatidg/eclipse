package resources;

//java -classpath .;"C:\Program Files\Java\jdk1.7.0_17\jre\lib\jfxrt.jar com.idgmi.sempostmark.Resources
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Resources {

    private static ResourceBundle messages;
    private static ResourceBundle imagePaths;
    private static String stylesheet;
    private static final Map<String, Image> imageMap = new ConcurrentHashMap<>();
    private static final Map<String, ImageView> imageViewMap = new ConcurrentHashMap<>();

    private Resources() throws Exception {
        throw new Exception("This class does not allow to create an instance");
    }

    public static String getMessage(String key) {
        if (messages == null) {
            try {
                messages = ResourceBundle.getBundle("resources.Messages", Locale.US);
            } catch (MissingResourceException e) {
                System.err.printf("Resources.getMessage() MissingResourceException:\n%s", e.getMessage());
            }
        }
        return messages.getString(key);
    }

    public static String getImagePath(String key) {
        if (imagePaths == null) {
            try {
                imagePaths = ResourceBundle.getBundle("resources.ImagePath", Locale.US);
            } catch (MissingResourceException e) {
                System.err.printf("Resources.getImagePath() MissingResourceException:\n%s", e.getMessage());
            }
        }
        return imagePaths.getString(key);
    }

    static public String getStylesheet() {
        if (stylesheet == null || stylesheet.trim().isEmpty()) {
            stylesheet = Resources.class.getResource("/resources/macatStyle.css").toExternalForm();
        }

        return stylesheet;
        //return Resources.class.getResource("/MessagesScene.css").toExternalForm();
    }

    public static Image getImage(String name) {
        Image localImg = null;
        if (imageMap.containsKey(name)) {
            localImg = imageMap.get(name);
        } else {
            localImg = new Image(Resources.class.getResource(getImagePath(name)).toExternalForm());
            imageMap.put(name, localImg);
        }
        return localImg;
    }

    public static ImageView getNewImageView(String name) {
        return new ImageView(getImage(name));
    }

    public static ImageView getImageView(String name) {
        ImageView localImgView;

        if (imageViewMap.containsKey(name)) {
            localImgView = imageViewMap.get(name);
        } else {
            localImgView = new ImageView(getImage(name));
            imageViewMap.put(name, localImgView);
        }

        return localImgView;
    }
}