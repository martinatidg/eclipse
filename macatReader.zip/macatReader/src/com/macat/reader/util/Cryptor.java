package com.macat.reader.util;

import java.io.*;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.*;
import org.apache.commons.codec.binary.Base64;

public final class Cryptor {

    //private static int keySizeAES = 256;
    //private static String saltAES = "SempostmarkSalt"; // OFRna73m*aze01xY

    private final static String INITIALIZATION_VECTOR = "OFRna73m*aze01xY";
    private final static String PASSWORD = "$emP0sTM@rkT0P$3cu!ty12345678912";
    private final static String UTF8_ENCODING = "UTF-8";
    private final static String ASCII_ENCODING = "ASCII";
    private final static String CIPHER_TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private final static String AES_ENCRYPTION = "AES";

    static Logger logger = IdgLog.getLogger();

    public static void decryptFile(String myTextFile, String cipherTextFile, String key) throws CryptorException {
            //throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IOException {
        //byte[] keyBytes = convertPasswordToBytes(key);
        //byte[] ivBytes = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);

        //Cipher myCipher = null; //getCipher(Cipher.DECRYPT_MODE, keyBytes, ivBytes);

        FileInputStream inputFile = null;
        FileOutputStream outputFile = null;
        CipherOutputStream cipherOutputStream = null;

        try {
            byte[] keyBytes = convertPasswordToBytes(key);
            byte[] ivBytes = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);
            Cipher myCipher = getCipher(Cipher.DECRYPT_MODE, keyBytes, ivBytes);
            inputFile = new FileInputStream(myTextFile);
            outputFile = new FileOutputStream(cipherTextFile);
            cipherOutputStream = new CipherOutputStream(outputFile, myCipher);
            int i = 0;

            while ((i = inputFile.read()) != -1) {
                cipherOutputStream.write(i);
            }
        }
        catch (Exception e) {
            throw new CryptorException(e);
        }
        finally {
            try {
            if (cipherOutputStream != null) {
                cipherOutputStream.close();
            }

            if (outputFile != null) {
                outputFile.close();
            }

            if (inputFile != null) {
                inputFile.close();
            }
            }
            catch (Exception ex) {
                throw new CryptorException(ex);
            }
        }
    }

    public static void encryptFile(String myTextFile, String cipherTextFile, String key) throws CryptorException {
//            throws GeneralSecurityException, IOException {
        //byte[] keyBytes = convertPasswordToBytes(key);
        //byte[] ivBytes = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);

        //Cipher myCipher = getCipher(Cipher.ENCRYPT_MODE, keyBytes, ivBytes);

        FileInputStream inputFile = null;
        FileOutputStream outputFile = null;
        CipherOutputStream cipherOutputStream = null;

        try {
            byte[] keyBytes = convertPasswordToBytes(key);
            byte[] ivBytes = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);
            Cipher myCipher = getCipher(Cipher.ENCRYPT_MODE, keyBytes, ivBytes);
            inputFile = new FileInputStream(myTextFile);
            outputFile = new FileOutputStream(cipherTextFile);
            cipherOutputStream = new CipherOutputStream(outputFile, myCipher);
            int i = 0;

            while ((i = inputFile.read()) != -1) {
                cipherOutputStream.write(i);
            }
        }
        catch (Exception ex) {
            throw new CryptorException(ex);
        }
        finally {
            try {
            if (cipherOutputStream != null) {
                cipherOutputStream.close();
            }

            if (outputFile != null) {
                outputFile.close();
            }

            if (inputFile != null) {
                inputFile.close();
            }
            }
            catch (Exception ex) {
                throw new CryptorException(ex);
            }
        }
    }

    // / <summary>
    // / Return the cipher
    // / </summary>
    // / <param name="key">Secret Key</param>
    // / <param name="initialVector">Initial Vector</param>
    private static Cipher getCipher(int mode, byte[] key, byte[] initialVector)
            throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, InvalidAlgorithmParameterException {
        Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, AES_ENCRYPTION);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
        cipher.init(mode, secretKeySpec, ivParameterSpec);
        return cipher;
    }

    public static byte[] decrypt(byte[] cipheredBytes, String key) throws CryptorException {
        try {
            ///throws NoSuchAlgorithmException,
            //NoSuchPaddingException, InvalidKeyException,
            ///InvalidAlgorithmParameterException, IllegalBlockSizeException,
            //BadPaddingException, UnsupportedEncodingException {
            
            //byte[] cipheredBytes = Base64.decodeBase64(encryptedText);
            byte[] keyBytes = convertPasswordToBytes(key);
            byte[] initialVector = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);
            
            Cipher cipher = getCipher(Cipher.DECRYPT_MODE, keyBytes, initialVector);
            cipheredBytes = cipher.doFinal(cipheredBytes);
            return cipheredBytes;
        } catch (Exception ex) {
            throw new CryptorException(ex);
        }

    }

    public static byte[] encrypt(String plainText, String keyStr) throws CryptorException {
        try {
            ////throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
            //InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
            
            byte[] plainTextbytes = plainText.getBytes(UTF8_ENCODING);
            byte[] keyBytes = convertPasswordToBytes(keyStr);
            byte[] initialVector = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);
            
            Cipher cipher = getCipher(Cipher.ENCRYPT_MODE, keyBytes, initialVector);
            plainTextbytes = cipher.doFinal(plainTextbytes);
            
            return plainTextbytes;
        } catch (Exception ex) {
            throw new CryptorException(ex);
        }
    }

    // / <summary>
    // / Decrypts a base64 encoded string using the given key
    // / </summary>
    // / <param name="encryptedText">Base64 Encoded String</param>
    // / <param name="key">Secret Key</param>
    // / <returns>Decrypted String</returns>
    public static String decodeAndDecrypt(String encryptedText, String key) throws CryptorException {
        try {
            //throws KeyException, GeneralSecurityException,
            //GeneralSecurityException, InvalidAlgorithmParameterException,
            //IllegalBlockSizeException, BadPaddingException, IOException {

            byte[] cipheredBytes = Base64.decodeBase64(encryptedText);
            //byte[] keyBytes = convertPasswordToBytes(key);
            //byte[] ivBytes = INITIALIZATION_VECTOR.getBytes(UTF8_ENCODING);

            String str = new String(decrypt(cipheredBytes, key), UTF8_ENCODING);
            return str;
        } catch (Exception ex) {
            throw new CryptorException(ex);
        }
    }

    // / <summary>
    // / Encrypts plaintext using AES 128bit key and a Chain Block Cipher and
    // returns a base64 encoded string
    // / </summary>
    // / <param name="plainText">Plain text to encrypt</param>
    // / <param name="key">Secret key</param>
    // / <returns>Base64 encoded string</returns>
    public static String encryptAndEncode(String plainText, String key) throws CryptorException {
        try {
            return Base64.encodeBase64String(encrypt(plainText, key));
        } catch (Exception ex) {
            throw new CryptorException(ex);
        }
    }

    public static void saveString(String text, String outputfilename)
            throws FileNotFoundException, IOException {
        OutputStream out = null;

        try {
            out = new FileOutputStream(outputfilename);
            out.write(text.getBytes());

        } finally {
            if (out != null) {
                out.close();
            }
        }
    }

    private static byte[] convertPasswordToBytes(String key) throws CryptorException { //throws UnsupportedEncodingException {
        String updatedKey = key.trim();
        byte[] keyBytes = null;

        // the length of key must be exactly 32
        if (updatedKey.length() >= 32) {
            updatedKey = updatedKey.substring(0, 32);
        } else {
            updatedKey += PASSWORD.substring(updatedKey.length());
        }

        try {
            keyBytes = updatedKey.getBytes(UTF8_ENCODING);
        } catch (UnsupportedEncodingException ex) {
            throw new CryptorException(ex);
        }
        return keyBytes;
    }

    public static String convertPasswordToString(String key) { //throws UnsupportedEncodingException {
        String updatedKey = key.trim();
        byte[] keyBytes;

        // the length of key must be exactly 32
        if (updatedKey.length() >= 32) {
            updatedKey = updatedKey.substring(0, 32);
        } else {
            updatedKey += PASSWORD.substring(updatedKey.length());
        }

        return updatedKey;
    }
}
