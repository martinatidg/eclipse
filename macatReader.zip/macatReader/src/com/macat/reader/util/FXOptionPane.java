package com.macat.reader.util;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class FXOptionPane {

    public enum Response {

        NO, YES, CANCEL
    };
    private static Response buttonSelected = Response.CANCEL;
    private static String returnedStr = "";

    public static void main(String[] args) {
        Application.launch(args);

    }
    // private static ImageView icon = new ImageView();
    static class Dialog extends Stage {

        public Dialog(String title, Stage owner, Scene scene, String iconFile) {
            setTitle(title);
            initStyle(StageStyle.UTILITY);
            initModality(Modality.APPLICATION_MODAL);
            initOwner(owner);
            setResizable(true);
            setScene(scene);
            // icon.setImage( new Image( getClass().getResourceAsStream(
            // iconFile ) ) );
        }

        public void showDialog() {
            sizeToScene();
            centerOnScreen();
            showAndWait();
        }
    }

    static class Message extends Text {

        public Message(String msg) {
            super(msg);
            setWrappingWidth(250);
        }
    }

    public static Response showConfirmDialog(Stage owner, String message, String title, String yesButtonStr, String noButtonStr) {
        Button yesButton = null;
        Button noButton = null;
        VBox vb = new VBox();
        Scene scene = new Scene(vb);
        final Dialog dial = new Dialog(title, owner, scene, "images/Confirm.png");
        vb.setPadding(new Insets(80, 50, 80, 50)); // Layout.PADDING );
        vb.setSpacing(10); // Layout.SPACING );

        yesButton = new Button(yesButtonStr);
        yesButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                dial.close();
                buttonSelected = Response.YES;
            }
        });
        noButton = new Button(noButtonStr);
        noButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                dial.close();
                buttonSelected = Response.NO;
            }
        });

        BorderPane bp = new BorderPane();
        HBox buttons = new HBox();
        buttons.setAlignment(Pos.CENTER);
        buttons.setSpacing(10); // Layout.SPACING );
        buttons.getChildren().addAll(yesButton, noButton);
        bp.setCenter(buttons);
        HBox msg = new HBox();
        msg.setSpacing(5); // Layout.SPACING_SMALL );
        //if (title.contains("Logout")) {
        msg.getChildren().addAll(new Message(message));
        //}
        vb.getChildren().addAll(msg, bp);
        dial.showDialog();
        return buttonSelected;
    }

    public static void showMessageDialog(Stage owner, String message, String title) {
        showMessageDialog(owner, new Message(message), title);
    }

    private static void showMessageDialog(Stage owner, Node message, String title) {
        VBox vb = new VBox();
        Scene scene = new Scene(vb);
        final Dialog dial = new Dialog(title, owner, scene, "images/Info.png");
        vb.setPadding(new Insets(10, 10, 10, 10)); // Layout.PADDING );
        vb.setSpacing(10); // Layout.SPACING );
        Button okButton = new Button("OK");
        okButton.setAlignment(Pos.CENTER);
        okButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                dial.close();
            }
        });

        BorderPane bp = new BorderPane();
        bp.setCenter(okButton);
        HBox msg = new HBox();
        msg.setSpacing(5);// Layout.SPACING_SMALL );
        msg.getChildren().addAll(message);
        // msgBox.getChildren().addAll(icon, message);
        vb.getChildren().addAll(msg, bp);
        dial.showDialog();
    }

    public static String requestMessageDialog(Stage owner, String message, String description, String title, boolean isPassword) {
        VBox vb = new VBox();
        Scene scene = new Scene(vb, 300, 100);

        final Dialog dial = new Dialog(title, owner, scene, "images/Info.png");
        vb.setPadding(new Insets(10, 10, 10, 10)); // Layout.PADDING );
        vb.setSpacing(10); // Layout.SPACING );

        final TextField msgField;
        if (isPassword) {
            msgField = new PasswordField();
        } else {
            msgField = new TextField("message");
        }

        Label promptLabel = new Label(description);

        Button okButton = new Button("OK");
        okButton.setAlignment(Pos.CENTER);
        okButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                returnedStr = msgField.getText();
                dial.close();
            }
        });

        Message promptmsg = new Message(message);

        HBox bp = new HBox(10);
        bp.getChildren().addAll(promptLabel, msgField, okButton);

        HBox msgBox = new HBox();
        msgBox.setSpacing(5);// Layout.SPACING_SMALL );
        msgBox.getChildren().addAll(promptmsg);

        vb.getChildren().addAll(msgBox, bp);
        dial.showDialog();

        return returnedStr;
    }

}
