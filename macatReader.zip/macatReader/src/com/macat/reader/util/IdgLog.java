/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.macat.reader.util;

/**
 *
 * @author cc.martin.tan
 */
/*
import ch.qos.logback.access.joran.JoranConfigurator;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.util.StatusPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

*/



import com.macat.reader.constants.Dir;
import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 *
 * This class can be used to check the result of a configuration file.
 *
 * @author S&eacute;bastien Pennec
 */
public class IdgLog {
    //public static final String DOCUMENTS_DIRECTORY = System.getProperty("user.home") + File.separator + "Documents" + File.separator;
    private static Logger logger = Logger.getLogger("com.idgmi.sempostmark");
    private static Handler handler;
    private String logpath; // = Dir.OS.getMacatLogDir() + File.separator + "log%g.txt";
    private int pageSize = 500000;
    private int logRotateNumber = 5;

    static private IdgLog log; // = new IdgLog();

    private IdgLog() {
        this("Info");
    }

    private IdgLog(String level) {
        this("", level, -1, -1);
    }

    private IdgLog(String path, String level, int psize, int logNo) {
        logpath = Dir.MACATELOG.dir() + File.separator + "log%g.txt";
        if (!path.trim().isEmpty()) {
            logpath = path;
        }

        if (psize > 0) {
            pageSize = psize;
        }

        if (logNo > 0) {
            logRotateNumber = logNo;
        }
        try {
            logger = Logger.getLogger("com.idgmi.sempostmark");
            switch(level) {
                case "Debug":
                    logger.setLevel(Level.FINE);
                    break;
                case "Error":
                    logger.setLevel(Level.SEVERE);
                    break;
                case "Off":
                    logger.setLevel(Level.OFF);
                case "All":
                    logger.setLevel(Level.ALL);
                    break;
                default:
                    logger.setLevel(Level.INFO);
            }

            logger.removeHandler(handler);
            handler = new FileHandler(logpath, pageSize, logRotateNumber);
            handler.setFormatter(new SimpleFormatter());
            handler.setLevel(Level.ALL);
            logger.addHandler(handler);

        } catch (IOException ex) {
            Logger.getLogger(IdgLog.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(IdgLog.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static public Logger getLogger() {
        return logger;
    }

    public void debug(String msg) {
        logger.fine(msg);
    }
    
    static public IdgLog instance() {
        //if (log == null) {
        //    log = new IdgLog("Error");
        //}
        return log;
    }
    
    static public Handler getHandler() {
        return handler;
    }
    
    static public void initialize() {
        if (log == null) {
            log = new IdgLog();
        }
    }

    static public void initialize(String level) {
        log = new IdgLog(level);
    }
    
   static public void initialize(String path, String level, int psize, int logNo) {
        log = new IdgLog(path, level, psize, logNo);
    }
}
