package com.macat.reader.util;

import java.awt.AlphaComposite;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.scene.web.HTMLEditor;
import javafx.stage.Screen;
import org.apache.commons.validator.routines.EmailValidator;

public class Util {
    static Logger logger = IdgLog.getLogger();

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

    public static String encodeString(String in) {
        try {
            return URLEncoder.encode(in, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            logger.log(Level.SEVERE, "", ex);
            return "";
        }
    }

    public static String decodeString(String in) {
        try {
            return URLDecoder.decode(in, "US-ASCII");
        } catch (UnsupportedEncodingException ex) {
            logger.log(Level.SEVERE, "", ex);
            return "";
        }
    }

    public static String removeExtension(String in) {
        int p = in.lastIndexOf(".");
        if (p < 0) {
            return in;
        }

        int d = in.lastIndexOf(File.separator);

        if (d < 0 && p == 0) {
            return in;
        }

        if (d >= 0 && d > p) {
            return in;
        }

        return in.substring(0, p);
    }

    public static HTMLEditor getHtmlDisplayer() {
        HTMLEditor htmlEditor = new HTMLEditor();
        for (Node toolBar = htmlEditor.lookup(".tool-bar"); toolBar != null; toolBar = htmlEditor.lookup(".tool-bar")) {
            ((Pane) toolBar.getParent()).getChildren().remove(toolBar);
        }
        //htmlEditor.setDisable(true);

        return htmlEditor;
    }

    public static HTMLEditor getHtmlEditor(boolean enabled) {
        HTMLEditor htmlEditor = new HTMLEditor();
        for (Node toolBar = htmlEditor.lookup(".tool-bar"); toolBar != null; toolBar = htmlEditor.lookup(".tool-bar")) {
            ((Pane) toolBar.getParent()).getChildren().remove(toolBar);
        }
        htmlEditor.setDisable(enabled);

        return htmlEditor;
    }

    public static boolean validateEmail(String email) {
        return EmailValidator.getInstance().isValid(email);
    }

    public static void writeFile(String filename, String text) throws IOException {
        FileOutputStream outputFile = null;

        try {
            outputFile = new FileOutputStream(filename);
            outputFile.write(text.getBytes());
        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
        } finally {
            if (outputFile != null) {
                outputFile.close();
            }
        }
    }

    public static Rectangle2D getScreenBound() {
        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getBounds();

        return bounds;
    }


    public static BufferedImage resizeImage(BufferedImage originalImage, int newWidth, int newHeight, int type){
	BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, type);
	Graphics2D g = resizedImage.createGraphics();
	g.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
	g.dispose();
 
	return resizedImage;
    }
 
    public static BufferedImage resizeImageWithHint(BufferedImage originalImage, int newWidth, int newHeight, int type){
 
	BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, type);
	Graphics2D g = resizedImage.createGraphics();
	g.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
	g.dispose();	
	g.setComposite(AlphaComposite.Src);
 
	g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
	RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	g.setRenderingHint(RenderingHints.KEY_RENDERING,
	RenderingHints.VALUE_RENDER_QUALITY);
	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	RenderingHints.VALUE_ANTIALIAS_ON);
 
	return resizedImage;
    }

    public static Dimension getAdjustedHeightByWidth(double oldW, double oldH, double newW, double newH) {
        double hRatio = newH / oldH;
        double wRatio = newW / oldW;
        double r = hRatio < wRatio ? hRatio : wRatio;
        System.out.println("in getAdjustedHeightByWidth old width = " + oldW + ", old height  = " + oldH + ", new width = " + newW + ", new height = " + newH + ", rate = " + r);
        Dimension newD = new Dimension((int)(oldW * r), (int)(oldH * r));
        System.out.println("in newD.getWidth = " + newD.getWidth() + ",  newD.getHeight = " + newD.getHeight());

        return newD;
    }
}
