package com.macat.reader.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DateUtil {
    static Logger logger = IdgLog.getLogger();
    public static final String DATE_PATTERN1 = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_PATTERN2 = "EEE MMM dd HH:mm:ss z yyyy";


    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }


    public static String formatDateStr1(String date) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date pdate;
        String formattedDate = "";
        try {
            pdate = formatter.parse(date);
            formattedDate = formatter.format(pdate);
        } catch (ParseException ex) {
            Logger.getLogger(DateUtil.class.getName()).log(Level.SEVERE, null, ex);
        }

        //System.out.println("Util.formatDateStr(" + date + ") = " + formatDate);
        return formattedDate;
    }

    public static String formatDateStr(String date) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_PATTERN2);
        Date pdate;
        String formattedDate = "";
        try {
            pdate = formatter.parse(date);
            //formattedDate = formatter.format(pdate);
            formattedDate = formatDate(pdate);  // convert to DATE_PATTERN
        } catch (ParseException e) {
            logger.log(Level.SEVERE, "{0} cannot be parsed with Pattern : " + DATE_PATTERN2 + ".", date);
            try {
                formatter = new SimpleDateFormat(DATE_PATTERN1);
                pdate = formatter.parse(date);
                formattedDate = formatter.format(pdate);
            } catch (ParseException ex) {
                logger.log(Level.SEVERE, "{0} cannot be parsed with Pattern : " + DATE_PATTERN1 + ".\n {1}", new Object[]{date, ex});
            }
        }

        //System.out.println("Util.formatDateStr(" + date + ") = " + formatDate);
        return formattedDate;
    }

    public static String formatDate(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_PATTERN1);
        String formattedDate = formatter.format(date);
        return formattedDate;
    }

    /**
     *
     * @param days
     * @return Date - the date that is days ago from today. If days is less than
     * 1, it is set to a default value.
     */
    public static Date getDateFromToday(int days) {
        //logger.log(Level.FINE, "retrieveDays = {0}", days);

        if (days <= 0) {
            days = 0;
        }

        days = -days;

        //logger.log(Level.FINE, "final retrieveDays = {0}", days);

        Calendar now = Calendar.getInstance();
        now.add(Calendar.DAY_OF_MONTH, days);
        now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        Date dateToDownload = now.getTime();

        //logger.log(Level.FINE, "Emails downloaded since {0}", dateToDownload);

        return dateToDownload;
    }

    public static Date parseDate(String date) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date pdate;
        pdate = formatter.parse(date);

        return pdate;
    }

    public static Date getDate(int fromToday) {
        DateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN1);
        Calendar cal = Calendar.getInstance();
        Calendar calReturn = Calendar.getInstance();
        dateFormat.format(cal.getTime());
        calReturn.add(Calendar.DATE, fromToday);
        dateFormat.format(calReturn.getTime());
        Date date = calReturn.getTime();

        return date;
    }
}
