package com.macat.reader.domain;

import com.macat.reader.constants.FileType;
import java.io.Serializable;
import java.nio.file.Path;
import java.util.Objects;
import javafx.scene.control.Label;

public class FileInfo implements Serializable, Comparable {
    private Path path;
    private Label name;
    private Boolean crypted;
    private String createTime;
    private String updateTime;
    private String accessTime;
    private String size;
    private FileType type;

    public FileInfo() {
    }

    public Path getPath() { return path; }
    public void setPath(Path path) { this.path = path;}

    public Label getName() { return name; }
    public void setName(Label name) { this.name = name;}

    public boolean isCrypted() { return crypted; }
    public void setCrypted(boolean crypted) { this.crypted = crypted;}

    public String getCreateTime() { return createTime;}
    public void setCreateTime(String createTime) { this.createTime = createTime;}

    public String getUpdateTime() { return this.updateTime; }
    public void setUpdateTime(String updateTime) { this.updateTime = updateTime; }

    public String getAccessTime() { return this.accessTime; }
    public void setAccessTime(String accessTime) { this.accessTime = accessTime; }

    public String getSize() { return this.size; }
    public void setSize(String size) { this.size = size; }

    public FileType getType() { return this.type; }
    public void setType(FileType type) { this.type = type; }

    @Override
    public int compareTo(Object o) {
        if (o == null) {
            return -1;
        }

        return this.path.toAbsolutePath().toString().compareTo(((FileInfo) o).path.toAbsolutePath().toString());
    }

    @Override
    public String toString() {
        return "FileInfo{" + "path=" + path + ", name=" + name + ", crypted=" + crypted + ", createTime=" + createTime + ", updateTime=" + updateTime + ", accessTime=" + accessTime + ", size=" + size + ", type=" + type + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + Objects.hashCode(this.path.toAbsolutePath().toString());
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FileInfo other = (FileInfo) obj;
        if (!Objects.equals(this.path.toAbsolutePath().toString(), other.path.toAbsolutePath().toString())) {
            return false;
        }
        return true;
    }
}
