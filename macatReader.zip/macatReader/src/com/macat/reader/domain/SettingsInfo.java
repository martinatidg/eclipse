package com.macat.reader.domain;

import java.io.Serializable;
import java.util.Objects;
import javafx.scene.control.PasswordField;

public class SettingsInfo implements Serializable, Comparable {
    private String email;
    private PasswordField password;
    //private ChoiceBox<String> types;
    private String emailType;

    public String getEmailType() {
        return emailType;
    }

    public void setEmailType(String emailType) {
        this.emailType = emailType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public PasswordField getPassword() {
        return password;
    }

    public void setPassword(PasswordField password) {
        this.password = password;
    }

    public SettingsInfo() {
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + Objects.hashCode(this.getEmail());
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SettingsInfo other = (SettingsInfo) obj;
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Object o) {
        if (o == null) {
            return -1;
        }

        return this.getEmail().compareTo(((SettingsInfo) o).getEmail());
    }
}
