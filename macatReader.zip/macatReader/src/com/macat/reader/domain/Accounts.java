package com.macat.reader.domain;

import java.util.Objects;

public class Accounts {
    public static final String TABLENAME = "ACCOUNTS";
    public static final int DEFAULT_LOCKTIME = 10; // seconds
    public static final int DEFAULT_WARNTIME = 10; // seconds

    public static final String ID = "ID";
    public static final String ADDRESS = "ADDRESS";
    public static final String ISLOGIN = "ISLOGIN";
    public static final String NAME = "NAME";
    public static final String PASSWORD = "PASSWORD";
    public static final String PROVIDER = "PROVIDER";
    public static final String REMEMBER_ME = "REMEMBERME";
    public static final String CONTACT_URL = "contactUrl";
    public static final String SERVER_TS = "serverTimestamp";
    public static final String LOCAL_TS = "localTimestamp";
    public static final String LOCKTIME = "LOCKTIME";
    public static final String WARNTIME = "WARNTIME";

    private Integer id;
    private String address;
    private String islogin;
    private String name;
    private String password;
    private String provider;
    private String rememberMe;
    private String contactUrl;
    private String serverTimestamp;
    private String localTimestamp;
    private int lockTime = DEFAULT_LOCKTIME;
    private int warnTime = DEFAULT_WARNTIME;

    private boolean addressSet = false;
    private boolean idSet = false;
    private boolean isloginSet = false;
    private boolean nameSet = false;
    private boolean passwordSet = false;
    private boolean providerSet = false;
    private boolean rememberMeSet = false;
    private boolean lockTimeSet = false;
    private boolean warnTimeSet = false;
    private boolean contactUrlSet = false;
    private boolean serverTimestampSet = false;
    private boolean localTimestampSet = false;

    public Integer getId() {
        return this.id;
    }
    public void setId(Integer id) {
        this.id = id;
        idSet = true;
    }
    public boolean isIdSet() {
        return this.idSet;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
        addressSet = true;
    }

    public boolean isAddressSet() {
        return this.addressSet;
    }

    public String getIslogin() {
        return this.islogin;
    }

    public void setIslogin(String islogin) {
        this.islogin = islogin;
        isloginSet = true;
    }

    public boolean isIsloginSet() {
        return this.isloginSet;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
        nameSet = true;
    }

    public boolean isNameSet() {
        return this.nameSet;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
        passwordSet = true;
    }
    public boolean isPasswordSet() {
        return this.passwordSet;
    }

    public String getProvider() {
        return this.provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
        providerSet = true;
    }

    public boolean isProviderSet() {
        return this.providerSet;
    }

    public String getRememberMe() {
        return this.rememberMe;
    }
    public void setRememberMe(String rememberMe) {
        this.rememberMe = rememberMe;
        rememberMeSet = true;
    }
    public boolean isRememberMeSet() {
        return this.rememberMeSet;
    }

    public String getContactUrl() {
        return this.contactUrl;
    }
    public void setContactUrl(String contactUrl) {
        this.contactUrl = contactUrl;
        contactUrlSet = true;
    }
    public boolean isContactUrlSet() {
        return this.contactUrlSet;
    }

    public String getServerTimestamp() {
        return this.serverTimestamp;
    }
    public void setServerTimestamp(String serverTs) {
        this.serverTimestamp = serverTs;
        serverTimestampSet = true;
    }
    public boolean isServerTimestampSet() {
        return this.serverTimestampSet;
    }

    public String getLocalTimestamp() {
        return this.localTimestamp;
    }
    public void setLocalTimestamp(String localTs) {
        this.localTimestamp = localTs;
        localTimestampSet = true;
    }
    public boolean isLocalTimestampSet() {
        return this.localTimestampSet;
    }

    public int getLockTime() {
        return this.lockTime;
    }
    public void setLockTime(int lockTime) {
        this.lockTime = lockTime;
        lockTimeSet = true;
    }
    public boolean isLockTimeSet() {
        return this.lockTimeSet;
    }

    public int getWarnTime() {
        return this.warnTime;
    }
    public void setWarnTime(int warnTime) {
        this.warnTime = warnTime;
        warnTimeSet = true;
    }
    public boolean isWarnTimeSet() {
        return this.warnTimeSet;
    }

    @Override
    public String toString() {
        return "Accounts: Id = " + this.getId() + ", Address = " + this.getAddress() + ", Name = " + this.getName();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Accounts other = (Accounts) obj;
        if (!Objects.equals(this.getAddress(), other.getAddress())) {
            return false;
        }
        if (!Objects.equals(this.getName(), other.getName())) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 41 * hash + Objects.hashCode(this.getAddress());
        hash = 41 * hash + Objects.hashCode(this.getName());

        return hash;    }


}
