package com.macat.reader.domain;

import com.macat.reader.constants.EmailType;
import java.util.Objects;

public class EmailAccounts implements Comparable<EmailAccounts> {
    private int id;
    private String username;
    private String password;
    private String accountName;
    private String email;
    private String domain;
    private boolean ssl;

    private EmailType mailType;
    private String mailHost;
    private String protocol;
    private String mailPort;
    private String socketPort;
    private String socketClass;
    private boolean partialfetch; //"; //, "false");
    private boolean fallback; //"; //, "false");

    private String smtpHost;
    private String smtpPort;
    private boolean smtpStarttls;
    private boolean smtpAuth;

    private String signature;
    private byte[] photo;
    private String photoName;

    public EmailAccounts() {
    }

    public int getId() {return this.id;}
    public void setId(int id) {this.id = id;}

    public String getUsername() {return this.username == null ? "" : username;}
    public void setUsername(String uname) {this.username = uname;}

    public String getPassword() {return this.password == null ? "" : password;}
    public void setPassword(String pwd) {this.password = pwd;}

    public String getAccountName() {return this.accountName == null ? "" : accountName;}
    public void setAccountName(String accname) {this.accountName = accname;}

    public String getDomain() {return domain == null ? "" : domain;}
    public void setDomain(String domain) {this.domain = domain;}

    public String getEmail() {return this.email == null ? "" : email;}
    public void setEmail(String email) {this.email = email;}

    public boolean getSsl() {return this.ssl;}
    public void setSsl(boolean ssl) {this.ssl = ssl;}

    // Mail
    public EmailType getMailType() {return mailType;}
    public void setMailType(String typeStr) {this.mailType = EmailType.getType(typeStr);}
    public void setMailType(EmailType mailtype) {this.mailType = mailtype;}

    public String getMailHost() {return this.mailHost == null ? "" : mailHost;}
    public void setMailHost(String mailServer) {this.mailHost = mailServer;}

    public String getProtocol() {return this.protocol == null ? "" : protocol;}
    public void setProtocol(String protocol) {this.protocol = protocol;}

    public String getMailPort() {return this.mailPort == null ? "" : mailPort;}
    public void setMailPort(String mailPort) {this.mailPort = mailPort;}

    public String getSocketPort() {return this.socketPort == null ? "" : socketPort;}
    public void setSocketPort(String socketPort) {this.socketPort = socketPort;}

    public String getSocketClass() {return this.socketClass == null ? "" : socketClass;}
    public void setSocketClass(String socketClass) {this.socketClass = socketClass;}

    public boolean getPartialfetch() {return this.partialfetch;}
    public void setPartialfetch(boolean partialfetch) {this.partialfetch = partialfetch;}

    public boolean getFallback() {return this.fallback;}
    public void setFallback(boolean fallback) {this.fallback = fallback;}

    // SMTP
    public String getSmtpHost() {return this.smtpHost == null ? "" : smtpHost;}
    public void setSmtpHost(String smtpServer) {this.smtpHost = smtpServer;}

    public String getSmtpPort() {return this.smtpPort == null ? "" : smtpPort;}
    public void setSmtpPort(String smtpPort) {this.smtpPort = smtpPort;}

    public boolean getSmtpStarttls() {return this.smtpStarttls;}
    public void setSmtpStarttls(boolean smtpStarttls) {this.smtpStarttls = smtpStarttls;}

    public boolean getSmtpAuth() {return this.smtpAuth;}
    public void setSmtpAuth(boolean smtpAuth) {this.smtpAuth = smtpAuth;}

    // General
    public String getSignature() {return this.signature == null ? "" : signature;}
    public void setSignature(String signature) {this.signature = signature;}

    public byte[] getPhoto() {return this.photo;}
    public void setphoto(byte[] uphoto) {this.photo = uphoto;}

    public String getPhotoName() {return this.photoName;}
    public void setPhotoName(String pname) {this.photoName = pname;}

    @Override
    public int hashCode() {
        int hash = 3;
        if (this.email != null) {
            this.email = this.email.toLowerCase();
        }
        hash = 17 * hash + Objects.hashCode(this.email);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        if (this.email == null) {
            return false;
        }
        this.email = this.email.toLowerCase();

        final EmailAccounts other = (EmailAccounts) obj;

        if (other.email == null) {
            return false;
        }
        other.email = other.email.toLowerCase();

        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(EmailAccounts o) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static enum ServerType {
        IMAP, POP3;

        static public ServerType getType(String typeStr) {
            if (typeStr == null || typeStr.trim().isEmpty()) {
                return null;
            }
            typeStr = typeStr.trim();

            return Enum.valueOf(ServerType.class, typeStr.toUpperCase());
        }
    };
}
