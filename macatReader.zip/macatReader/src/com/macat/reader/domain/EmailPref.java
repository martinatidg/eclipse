/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.macat.reader.domain;

import com.google.gdata.client.contacts.ContactsService;
import com.macat.reader.Context;
import com.macat.reader.ReaderMain;
import com.macat.reader.constants.EmailType;
import com.macat.reader.util.FXOptionPane;
import com.macat.reader.util.IdgLog;
import com.macat.reader.util.Util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.prefs.BackingStoreException;
import java.util.prefs.InvalidPreferencesFormatException;
import java.util.prefs.Preferences;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.mail.MessagingException;
import resources.Resources;

/**
 *
 * @author martin.tan
 */
public class EmailPref {
    static final Logger logger = IdgLog.getLogger();

    private enum Node {
        ACCOUNTS("accounts"), EMAIL("email"), PASSWORD("password"), EMAIL_TYPE("emailType");
        
        private String node;

        private Node(String nodename) {
            node = nodename;
        }

        public String node() {
            return node;
        }

        @Override
        public String toString() {
            return node;
        }
    }
//    private static final String ACCOUNTS = "accounts";
//    private static final String EMAIL = "email";
//    private static final String PASSWORD = "password";
//    private static final String EMAIL_TYPE = "emailType";

    private final Preferences root;

    public EmailPref() {
        root = Preferences.userRoot().node(Node.ACCOUNTS.node());
    }

    public void removeNode() {
        try {
            root.removeNode();
            root.flush();
        } catch (BackingStoreException ex) {
            Logger.getLogger(EmailPref.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void addAccount(String email, String password, String type) {
        String users = root.get(Node.ACCOUNTS.node(), "");

        if (users == null || users.trim().isEmpty()) {
            users = email;
        } else {
            users += ";" + email;
        }

        root.put(Node.ACCOUNTS.node, users);

        Preferences accNode = root.node(email);
        accNode.put(Node.EMAIL.node(), email);
        accNode.put(Node.PASSWORD.node(), password);
        accNode.put(Node.EMAIL_TYPE.node(), type);
    }

    public void deleteUser(String email) throws BackingStoreException {
        String users = root.get(Node.ACCOUNTS.node(), "");
        System.out.println("delete user: users = " + users + ", email = " + email);
        if (users == null || users.trim().isEmpty()) {
            return;
        }

        String[] userLst = users.split(";");

        String newUsers = "";

        for (String str : userLst) {
            System.out.println("delete user: str = " + str);
            if (str.trim().equalsIgnoreCase(email.trim())) {
                Preferences accNode = root.node(str);
                accNode.removeNode();
            } else {
                if (newUsers.isEmpty()) {
                    newUsers = str;
                } else {
                    newUsers += ";" + str;
                }
            }
        }
        root.put(Node.ACCOUNTS.name(), newUsers);
    }

    public void updateAccount(SettingsInfo emailinfo) throws BackingStoreException {
        String email = emailinfo.getEmail();
        String password = emailinfo.getPassword().getText();
        String emailtype = emailinfo.getEmailType();

        Preferences accNode = root.node(email);
        //accNode.put(EMAIL, email);
        accNode.put(Node.PASSWORD.name(), password);
        accNode.put(Node.EMAIL_TYPE.node(), emailtype);
    }

    public List<EmailAccounts> getEmailAccountList(String email) {
        List<EmailAccounts> tmplist = new ArrayList<EmailAccounts>();
        String users = root.get(Node.ACCOUNTS.node(), "");
        if (users == null || users.trim().isEmpty()) {
            return null;
        }

        EmailAccounts acc = null;
        String[] userLst = users.split(";");

        for (String str : userLst) {
            Preferences accNode = root.node(str);
            if (accNode == null) {
                return null;
            }

            String temail = str;
            String password = accNode.get(Node.PASSWORD.node(), "");
            String typestr = accNode.get(Node.EMAIL_TYPE.node(), "");
            EmailType type = EmailType.getType(typestr);

            System.out.println("email = " + str);
            System.out.println("EMAIL = " + temail);
            System.out.println("email + PASSWORD_PIX = " + password);
            System.out.println("email + EMAIL_TYPE_PIX = " + type);

            acc = new EmailAccounts();
            getEmailAccount(temail, password, type);

        }

        return tmplist;
    }

    public EmailAccounts getEmailAccount(String email) {
        String users = root.get(Node.ACCOUNTS.node(), "");
        if (users == null || users.trim().isEmpty()) {
            return null;
        }

        EmailAccounts acc = null;
        String[] userLst = users.split(";");

        for (String str : userLst) {
            if (str.trim().equalsIgnoreCase(email.trim())) {
                Preferences accNode = root.node(str);
                if (accNode == null) {
                    return null;
                }

                String temail = str;
                String password = accNode.get(Node.PASSWORD.node(), "");
                String typestr = accNode.get(Node.EMAIL_TYPE.node(), "");
                EmailType type = EmailType.getType(typestr);

                System.out.println("email = " + str);
                System.out.println("EMAIL = " + temail);
                System.out.println("email + PASSWORD_PIX = " + password);
                System.out.println("email + EMAIL_TYPE_PIX = " + type);

                acc = getEmailAccount(temail, password, type);

                break;
            }
        }

        return acc;
    }

    public ObservableList<String> getusers() {
        String users = root.get(Node.ACCOUNTS.node(), "");
        System.out.println("users = " + users);
        if (users == null || users.trim().isEmpty()) {
            return null;
        }

        ObservableList<String> emails = FXCollections.observableArrayList();
        String[] userLst = users.split(";");

        for (String str : userLst) {
            emails.add(str);
            Preferences accNode = root.node(str);
            System.out.println("email = " + str);
            System.out.println("email + EMAIL_PIX = " + accNode.get(Node.EMAIL.node(), ""));
            System.out.println("email + PASSWORD_PIX = " + accNode.get(Node.PASSWORD.node(), ""));
            System.out.println("email + EMAIL_TYPE_PIX = " + accNode.get(Node.EMAIL_TYPE.node(), ""));

        }

        return emails;
    }

    public String[] getEmails() {
        String users = root.get(Node.ACCOUNTS.node(), "");
        System.out.println("users = " + users);
        if (users == null || users.trim().isEmpty()) {
            return null;
        }

        String[] userLst = users.split(";");

        return userLst;
    }

    public void exportxml(String filename) throws FileNotFoundException, IOException, BackingStoreException {
        try (OutputStream file = new FileOutputStream(filename)) {
            root.exportSubtree(file);
        }
    }

    public void importxml(String filename) throws IOException, InvalidPreferencesFormatException {
        try (InputStream file = new FileInputStream(filename)) {
            Preferences.importPreferences(file);
        }
    }

    public EmailAccounts getEmailAccount(String email, String password, EmailType type) {
        String[] usersplit = email.split("@");
        String username = usersplit[0];
        String domain = usersplit[1];

        // pop3/imap
        String mailhost = type.mailServer(); //Constants.GMAIL_HOST;
        String mailPort = type.port();
        String protocol = type.protocol();
        boolean socketfallback = false;
        String socketClass = "";
        String socketPort = "110";
        boolean partialfetch = false;

        // smtp
        String smtphost = type.smtpServer();
        String smtpPort = "";
        boolean starttls = false;
        boolean auth = true;
        boolean ssl = false;

        switch (type) {
            case EXCHANGE:
            case VOISCMAIL:
                mailhost = type.mailServer();
                domain = type.domain();
                socketfallback = false;
                socketClass = "javax.net.SocketFactory";
                socketPort = "110";
                break;

            case GMAIL:
                partialfetch = false;
            // note: no break;
            case HOTMAIL:
                starttls = true;
                break;

            case YAHOO:
                ssl = true;
                break;

            default:
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        "The email type you selected is not supported yet.",
                        "Settings");
                return null;
        }

        if (!Util.validateEmail(email)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    "Email: (" + email + ") format is invalid.",
                    "Email Wizard");
            return null;
        }

        EmailAccounts useraccount = new EmailAccounts();
        useraccount.setProtocol(protocol);
        useraccount.setMailHost(mailhost);
        useraccount.setMailPort(mailPort);
        useraccount.setFallback(socketfallback);
        useraccount.setSocketClass(socketClass);
        useraccount.setSocketPort(socketPort);
        useraccount.setPartialfetch(partialfetch);
        
        useraccount.setUsername(username);
        useraccount.setEmail(email);

        useraccount.setPassword(password);
        useraccount.setMailType(type);
        useraccount.setAccountName(email);
        useraccount.setDomain(domain);

        // outgoing SMTP
        useraccount.setSmtpHost(smtphost);
        useraccount.setSmtpPort(smtpPort);
        useraccount.setSmtpStarttls(starttls);
        useraccount.setSmtpAuth(auth);
        useraccount.setSsl(ssl);
/*
        if (!validateServer(useraccount)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    "Cannot connect to the server.",
                    "Email Wizard");
            return null;
        }
*/
        //Context.setCurrentUser(useraccount);

        return useraccount;
    }

    private boolean validateServer(EmailAccounts user) {
        ContactsService contactService = null;
        EmailType type = user.getMailType();

        if (EmailType.EXCHANGE == type) {

            boolean exchangeValid = true;
            try {
                Context.setCurrentUser(user);
                Context.setServer();
                //GmailUtils.currentAccount.setEmail(Context.exchangeUtils.getEmail());
            } catch (Exception e2) {
                exchangeValid = false;
                //logger.log(Level.SEVERE, null, e2);
            }

            if (!exchangeValid) {
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("usernamePasswordNotCorrect"),
                        Resources.getMessage("validateServer"));
                return false;
            }
        } else if (EmailType.GMAIL == type) {
            try {
                contactService = AddUsersValidations.gmailValidations(
                        getSplittedUsername(user.getUsername()),
                        user.getPassword());
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Authentication exception: \n{0}", e.getStackTrace());
                contactService = null;
            }
            if (contactService == null) {
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("usernamePasswordNotCorrect"),
                        Resources.getMessage("validateServer"));
                return false;
            }
        } else if (EmailType.YAHOO == type) {
            boolean yahooValid = AddUsersValidations.yahooValidations(user.getUsername(), user.getPassword());

            if (!yahooValid) {
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("usernamePasswordNotCorrect"),
                        Resources.getMessage("validateServer"));
                return false;
            }
        } else if (EmailType.HOTMAIL == type) {
            boolean valid = true;
            String cause = "";
            try {
                valid = AddUsersValidations.hotmailValidations(user);
            } catch (MessagingException ex) {
                valid = false;
                cause = ex.getMessage();
            }

            if (!valid) {
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        cause,
                        Resources.getMessage("validateServer"));
                return false;
            }

        }

        return true;
    }

    private String getSplittedUsername(String username) {
        String[] usersplit = null;
        String emailText = null;
        if (!username.contains(EmailType.VOISCMAIL.toString())) {
            usersplit = username.split("@");
            username = usersplit[0];
            emailText = username;
        } else if (username.contains(EmailType.VOISCMAIL.toString())) {
            emailText = username;
        }
        return emailText;
    }

}
