package com.macat.reader.domain;

import com.google.gdata.client.contacts.ContactsService;
import com.google.gdata.data.PlainTextConstruct;
import com.google.gdata.data.contacts.ContactEntry;
import com.google.gdata.data.contacts.ContactFeed;
import com.google.gdata.data.contacts.ContactGroupEntry;
import com.google.gdata.data.contacts.ContactGroupFeed;
import com.google.gdata.data.contacts.GroupMembershipInfo;
import com.google.gdata.data.contacts.Nickname;
import com.google.gdata.data.extensions.Email;
import com.google.gdata.data.extensions.FamilyName;
import com.google.gdata.data.extensions.FullName;
import com.google.gdata.data.extensions.GivenName;
import com.google.gdata.data.extensions.Name;
import com.google.gdata.util.AuthenticationException;
import com.google.gdata.util.ServiceException;
import com.macat.reader.Context;
import com.macat.reader.constants.Constants;
import com.macat.reader.util.IdgLog;
import java.io.IOException;
import java.net.ConnectException;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

//import com.google.gdata.data.appsforyourdomain.Nickname;
public class ContactsUtil {
    static Logger logger = IdgLog.getLogger();

    // make this class as a utility class
    private ContactsUtil() {
        throw new UnsupportedOperationException("Utility class. Cannot be instantiated"); 
    }

    /*
     * This method will authenticate the user credentials passed to it and
     * returns an instance of ContactService class.
     */
    public static ContactsService authenticateId(String userid, String password) {
        ContactsService contactService = null;
        try {
            contactService = new ContactsService("RupalMindfire-AddressApp");
            contactService.setUserCredentials(userid, password);
            // this.userId = userid;
        } catch (AuthenticationException ex) {
            logger.log(Level.SEVERE, null, ex);
        }
        return contactService;

    }

    public static void deleteContact(String emailAddress)
            throws ServiceException, IOException {

        ContactsService myService = Context.getContactService();
        // Request the feed
        URL feedUrl = new URL(Constants.GMAIL_CONTACT_URL);
        ContactFeed resultFeed = myService.getFeed(feedUrl, ContactFeed.class);
        // Print the results
        // logger.info(resultFeed.getTitle().getPlainText());
        for (int i = 0; i < resultFeed.getEntries().size(); i++) {
            ContactEntry entry = resultFeed.getEntries().get(i);
            logger.log(Level.INFO, "________EDIT URL______________{0}", entry.getEditLink().getHref());

            for (Email email : entry.getEmailAddresses()) {

                if (email.getAddress().equals(emailAddress)) {
                    entry.delete();
                    logger.info("Deleted from server");
                }

            }
            // logger.info("Contact's ETag: " + entry.getEtag());
        }
    }


   private static Set<String> getContactsOnServer(ContactsService myService) throws ServiceException, IOException {
        Set<String> emails = new HashSet<>();

        URL feedUrl = new URL(Constants.GMAIL_CONTACT_URL);

        ContactFeed resultFeed = myService.getFeed(feedUrl, ContactFeed.class);
        List<ContactEntry> cconentry = resultFeed.getEntries();

        for (ContactEntry entry : resultFeed.getEntries()) {
            for (Email email : entry.getEmailAddresses()) {
                emails.add(email.getAddress().toLowerCase());
            }
        }

        return emails;
    }


    public static void main(String ar[]) {
        try {
            ContactsUtil googleContactsAccess = new ContactsUtil();
            ContactsService contactSrv = googleContactsAccess.authenticateId("patelcrpintu", "jayambec");
            /*
            createContactWithGroupName("System Group: My Contacts", 
                    "fullname", "givenname", "familyname",
                    "tomtombaba@gmail.com", "nn");
            */
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
        }
    }
}