package com.macat.reader.domain;

import com.google.gdata.client.contacts.ContactsService;
import com.macat.reader.constants.EmailType;
import com.macat.reader.domain.EmailAccounts;
import com.macat.reader.util.IdgLog;
import java.net.URI;
import java.util.Properties;
import java.util.logging.Logger;
import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;
import microsoft.exchange.webservices.data.ExchangeService;
import microsoft.exchange.webservices.data.ExchangeVersion;
import microsoft.exchange.webservices.data.WebCredentials;

//import com.moonrug.exchange.IMapiSession;
public class AddUsersValidations {

    static Logger logger = IdgLog.getLogger();

    public static ContactsService gmailValidations(String userid,
            String password) throws Exception {

        ContactsService contactService = null;
        // try{
        contactService = new ContactsService("RupalMindfire-AddressApp");
        contactService.setUserCredentials(userid, password);
        // this.userId = userid;
        // }catch(Exception e){
        // logger.info(e);
        // }
        return contactService;

    }

    public static boolean yahooValidations(String userid, String password) { // throws
        // Exception{
        boolean ok = true;

        try {
            Store store = null;
            Properties props = System.getProperties();
            props.setProperty("mail.store.protocol", "imaps");
            Session session = Session.getDefaultInstance(props, null);
            store = session.getStore("imaps");
            store.connect("imap.mail.yahoo.com", userid, password);
        } catch (Exception e) {
            ok = false;
            logger.severe("" + e);
        }

        return ok;
    }

    public static boolean hotmailValidations(EmailAccounts user) throws AuthenticationFailedException, NoSuchProviderException, MessagingException { // throws
        // Exception{
        boolean ok = true;

        Store store = null;
        Properties props = System.getProperties();
        props.setProperty("mail.store.protocol", "pop3s");
        Session session = Session.getDefaultInstance(props, null);
        store = session.getStore("pop3s");
        store.connect("pop3.live.com", user.getEmail(), user.getPassword());

        return ok;
    }

    public static void voiscmailValidations(String userid, String password)
            throws Exception {
        Store store = null;

        try {
            Properties props = System.getProperties();

            props.setProperty("mail.store.protocol", "pop3");
            props.setProperty("mail.pop3.host", EmailType.VOISCMAIL.domain());
            props.setProperty("mail.pop3.port", "110");
            props.setProperty("mail.pop3.socketFactory.port", "110");
            props.setProperty("mail.pop3.socketFactory.class",
                    "javax.net.SocketFactory");
            props.setProperty("mail.pop3.socketFactory.fallback", "false");

            URLName url = new URLName("pop3", "javax.net.SocketFactory", 110, "INBOX", userid, password);

            // props.setProperty("mail.store.protocol", "smtp");
            Session session = Session.getDefaultInstance(props, null);
            store = session.getStore(url);
            // store.connect("imap.gmail.com", "bangalore.pune.india", "malay123");
            store.connect(EmailType.VOISCMAIL.domain(), userid, password);
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.severe("" + ex);
        }
    }

    public static void Validations(String userid, String password)
            throws Exception {
        Store store = null;
        String uri = "https://mail.isaacdaniel.com/EWS/Exchange.asmx";
        ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
        WebCredentials credentials = new WebCredentials("username", "password", "domain");
        service.setTraceEnabled(true);
        service.setCredentials(credentials);
        service.setUrl(new URI(uri));
    }
}
