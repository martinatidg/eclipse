/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.macat.reader.ui;

import com.macat.reader.ReaderMain;
import com.macat.reader.util.IdgLog;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author cc.martin.tan
 */
public class GuiUtil {

    private static Logger logger = IdgLog.getLogger();

    private static final Map<String, Stage> stageMap = new HashMap<>();
    private static final Map<String, Object> controllerMap = new HashMap<>();
    private static final Map<String, Parent> parentMap = new HashMap<>();

    public static <T> T getController(Class<T> cls, String key, boolean dialog) throws IOException {
        T ctrler = cls.cast(controllerMap.get(key));

        if (ctrler == null) {
            initialize(cls, key, dialog);
        }

        ctrler = cls.cast(controllerMap.get(key));
        return ctrler;
    }

    public static <T> T getController(Class<T> cls, String key) throws IOException {
        T ctrler = cls.cast(controllerMap.get(key));

        if (ctrler == null) {
            initialize(cls, key, false);
        }

        ctrler = cls.cast(controllerMap.get(key));
        return ctrler;
    }

    public static Stage getStage(Class cls, String key, boolean dialog) throws IOException {
        logger.info("entering ...");
        Stage stage = stageMap.get(key);
        if (stage == null) {
            initialize(cls, key, dialog);
        }

        return stageMap.get(key);
    }

    public static Parent getParent(Class cls, String key) throws IOException {
        logger.info("entering ...");
        Parent parent = parentMap.get(key);
        if (parent == null) {
            initialize(cls, key, false);
        }

        return parentMap.get(key);
    }

    public static Stage getStage(Class cls, String key) throws IOException {
        logger.info("entering ...");
        Stage stage = stageMap.get(key);
        if (stage == null) {
            initialize(cls, key, false);
        }

        return stageMap.get(key);
    }

    private static <T> void initialize(Class<T> cls, String xml, boolean dialog) throws IOException {
        logger.info("entering ...");

        logger.info("constructing new stage ...");
        FXMLLoader fxmlLoader = new FXMLLoader(GuiUtil.class.getResource(xml));
        Parent root = fxmlLoader.load();
        parentMap.put(xml, root);

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        if (dialog) {
            stage.setResizable(false);
            stage.initStyle(StageStyle.UTILITY);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(ReaderMain.getStage());
        }
        stageMap.put(xml, stage);

        T controller = cls.cast(fxmlLoader.getController());
        controllerMap.put(xml, controller);
    }
}
