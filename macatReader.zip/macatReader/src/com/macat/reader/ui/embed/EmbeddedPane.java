/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.macat.reader.ui.embed;

import com.aspose.cells.ImageFormat;
import com.aspose.cells.ImageOrPrintOptions;
import com.aspose.cells.SheetRender;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.words.Document;
import com.macat.reader.ReaderMain;
import com.macat.reader.constants.Constants;
import com.macat.reader.constants.Extension;
import com.macat.reader.constants.Dir;
import com.macat.reader.ui.*;
import com.macat.reader.ui.controller.MainUIController;
//import static com.macat.reader.ui.controller.MainUIController.currentPath;
import com.macat.reader.util.FXOptionPane;
import com.macat.reader.util.IdgLog;
import com.macat.reader.util.IoUtil;
import com.macat.reader.util.MZip;
import static com.macat.reader.util.Util.getAdjustedHeightByWidth;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.text.Text;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.poi.hslf.model.Slide;
import org.apache.poi.hslf.usermodel.SlideShow;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import resources.Resources;

public class EmbeddedPane extends BorderPane {
    private final Logger logger = IdgLog.getLogger();

    private final int resolution = 150;
    private String currentFile = null;
    private int currentPage = 0;
    private int totalPages = 1000;
    private final Label pageTxt = new Label("0 / 0");

    private HBox topLeftHBox;
    HBox topMidHBox;
    HBox topRightHBox;
    private Button nextBtn;
    private Button previousBtn;
    private Button previousSheetBtn;
    private Button nextSheetBtn;
    private int currentSheet = 0;    // for XLS, XLSX only
    private int sheetCount = 0;
    //private final int totalSheets = 1000;
    private final Label sheetTxt = new Label("0 / 0");

    private final Label space1 = new Label("     ");
    //private static final Label space2 = new Label("     ");

    private final RadioButton originalRadio;
    private final RadioButton fitInRadio;

    private final HBox innerTopBox;

    private final Map<String, Object> docMap = new ConcurrentHashMap<>(); // cache the loaded file for reusing
    private ScrollPane scrollpane;
    //private static Pane mpane;
    private ImageView docIV;

    //private VBox mediaBox;
    private MediaView mediaMV;

    private static EmbeddedPane awtembed = null;
    private int LINE_PER_PAGE = 45;
    private boolean textOpened = false;

    public static EmbeddedPane istance() {
        if (awtembed == null) {
            awtembed = new EmbeddedPane();
        }

        return awtembed;
    }

    public double[] getMediaMVSize() {
        return new double[]{mediaMV.getFitWidth(), mediaMV.getFitHeight()};
    }

    public void setMediaSize() {
        try {
            MainUIController controller = GuiUtil.getController(MainUIController.class, MainUIController.FXML);
            double[] leftAnchorSize = controller.getLeftAnchorSize();

            double w = ReaderMain.getStage().widthProperty().getValue() - leftAnchorSize[0] - Constants.STAGE_PADDING;;
            double h = ReaderMain.getStage().heightProperty().getValue() - Constants.MENUBAR_HEIGHT - Constants.TITLEBAR_HEIGHT;

            double width = w - this.getPadding().getLeft() - this.getPadding().getRight();
            double height = h - this.getPadding().getTop() - this.getPadding().getBottom();
            System.out.println("EmbeddedPane.setMediaMVSize, final width = " + width + ", final height = " + height);

            this.setWidth(width);
            this.setHeight(height);
            mediaMV.setFitWidth(width);
            mediaMV.setFitHeight(height - innerTopBox.getHeight());
            innerTopBox.setPrefWidth(width);

        } catch (IOException ex) {
            Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public double[] getInnerTopBoxSize() {
        return new double[]{innerTopBox.getWidth(), innerTopBox.getHeight()};
    }

    public HBox getInnerTopBox() {
        return innerTopBox;
    }

    public MediaView getMediaView() {
        return mediaMV;
    }

    public ScrollPane getScrollPane() {
        return scrollpane;
    }

    private EmbeddedPane() {
        this.getStylesheets().add(Resources.getStylesheet());

        mediaMV = new MediaView();
        mediaMV.setPreserveRatio(true);

        scrollpane = new ScrollPane();
        scrollpane.setFitToHeight(true);
        scrollpane.setFitToWidth(true);
        docIV = new ImageView();
        scrollpane.setContent(docIV);

        long start = System.currentTimeMillis();

//        ChangeListener<Number> changelistener;
//        changelistener = (ObservableValue<? extends Number> observableValue, Number oldSceneWidth, Number newSceneWidth) -> {
//            logger.log(Level.INFO, "Width: {0}", newSceneWidth);
//            //updateShow();
//        };

        previousBtn = new Button("Previous");
        previousBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                logger.info("previous button clicked...");
                if (currentPage <= 0) {
                    currentPage = 0;
                } else {
                    currentPage--;
                }
                renderDoc();
            }
        });

        nextBtn = new Button("Next");
        nextBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                logger.info("next button clicked... currentPage = " + currentPage);
                if (currentPage >= (totalPages - 1)) {
                    currentPage = (totalPages <= 0) ? 0 : (totalPages - 1);
                } else {
                    currentPage++;
                }
                logger.log(Level.INFO, "after test currentPage = {0}", currentPage);

                renderDoc();
            }
        });

        nextSheetBtn = new Button("Next Sheet");
        nextSheetBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                logger.log(Level.INFO, "next button clicked... currentSheet = {0}", currentSheet);
                if (currentSheet >= (sheetCount - 1)) {
                    currentSheet = (sheetCount <= 0) ? 0 : (sheetCount - 1);
                } else {
                    currentSheet++;
                    currentPage = 0;
                }

                logger.log(Level.INFO, "after test currentSheet = {0}", currentSheet);

                renderDoc();
            }
        });

        previousSheetBtn = new Button("Previous Sheet");
        previousSheetBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                logger.log(Level.INFO, "next button clicked... currentSheet = {0}", currentSheet);
                if (currentSheet <= 0) {
                    currentSheet = 0;
                } else {
                    currentSheet--;
                    currentPage = 0;
                }

                logger.log(Level.INFO, "after test currentSheet = {0}", currentSheet);

                renderDoc();
            }
        });

        Button browseBtn = new Button("Browse");
        browseBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                logger.info("browse button clicked...");
                try {
                    Path path = IoUtil.browseFile(IoUtil.ALL, true, "Open File");
                    if (path == null || path.toString().trim().length() == 0) {
                        return;
                    }

                    currentFile = path.toString();
                    currentPage = 0;
                    renderDoc();
                } catch (IOException ex) {
                    Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        ToggleGroup fileGroup = new ToggleGroup();

        EventHandler<MouseEvent> sizingHandler = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                renderDoc();
            }
        };

        originalRadio = new RadioButton(Resources.getMessage("original"));
        originalRadio.setToggleGroup(fileGroup);
        originalRadio.setOnMouseClicked(sizingHandler);
        originalRadio.setTextFill(Constants.TEXT_COLOR);

        fitInRadio = new RadioButton(Resources.getMessage("fitIn"));
        fitInRadio.setToggleGroup(fileGroup);
        fitInRadio.setOnMouseClicked(sizingHandler);
        fitInRadio.setTextFill(Constants.TEXT_COLOR);
        fitInRadio.setSelected(true);

        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    logger.info("close button clicked...");
                    closeFile();
                } catch (IOException ex) {
                    Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        pageTxt.setAlignment(Pos.CENTER);
        sheetTxt.setAlignment(Pos.CENTER);

        topLeftHBox = new HBox(20);
        //topLeftHBox.setPadding(new Insets(10, 10, 10, 10));
        topLeftHBox.getChildren().addAll(previousBtn, pageTxt, nextBtn, space1, previousSheetBtn, sheetTxt, nextSheetBtn);
        topLeftHBox.setAlignment(Pos.CENTER_LEFT);

        topMidHBox = new HBox(10);
        //topRightHBox.setPadding(new Insets(10, 10, 10, 10));
        ///topRightHBox.getChildren().addAll(browseBtn, space2, closeBtn);
        topMidHBox.getChildren().addAll(originalRadio, fitInRadio);
        topMidHBox.setAlignment(Pos.CENTER);
        topMidHBox.setPrefWidth(200);

        topRightHBox = new HBox(30);
        //topRightHBox.setPadding(new Insets(10, 10, 10, 10));
        ///topRightHBox.getChildren().addAll(browseBtn, space2, closeBtn);
        topRightHBox.getChildren().addAll(closeBtn);
        topRightHBox.setAlignment(Pos.CENTER_RIGHT);
        topRightHBox.setPrefWidth(200);

        innerTopBox = new HBox(20);
        innerTopBox.setPadding(new Insets(5, 10, 5, 10));
        //innerTopBox.getChildren().addAll(topLeftHBox, topMidHBox, topRightHBox);
        //innerTopBox.prefWidthProperty().bind(this.widthProperty());
        innerTopBox.setMinWidth(1.1);

        //this.getChildren().addAll(innerTopBox);
        this.setTop(innerTopBox);
        //this.setCenter(scrollpane);

        setSheetVisible(false);
        long end = System.currentTimeMillis();
        logger.log(Level.INFO, "it took {0} miliseconds to display", (end - start));

    }

    public void renderDoc() {
        try {
            renderDoc(currentFile, currentPage);
        } catch (Exception ex) {
            Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void renderDoc(String filename, int pageNum) throws FileNotFoundException, IOException, Exception {
        //docMap.clear();
        logger.info("repainting ...");
        if (filename == null || filename.trim().isEmpty()) {
            return;
        }

        String extStr = IoUtil.getFileExtension(filename);
        Extension ext = Extension.type(extStr);
        //if (ext == null) {
        //    return;
        //}
        setSheetVisible(false);

        switch (ext) {
            case DOC:
            case DOCX:
            case ODT:
            case RTF:
            case DOCM:
            case DOT:
            case DOTX:
            case DOTM:
                paintWord(filename, pageNum);
                break;

            case XLS:
            case XLSX:
            case XLW:
            case XLT:
            case XLSM:
            case XLTX:
            case XLTM:
                setSheetVisible(true);
                paintXls(filename, currentSheet, pageNum);
                break;

            case PDF:
                //setSheetNoVisible(false);
                //paintPdfBufferedImage(g2,currentFile, currentPage, resolution);
                paintPdf(filename, pageNum, resolution);
                break;

            case PPT:
                //setSheetNoVisible(false);
                paintSlidesHslf(filename, pageNum);
                break;

            case PPTX:
                //setSheetNoVisible(false);
                paintSlidesXslf(filename, pageNum);
                break;

            case JPG:
            case JPEG:
            case PNG:
            case GIF:
            case BMP:
            case VBMP:
                //setSheetNoVisible(false);
                nextBtn.setVisible(false);
                previousBtn.setVisible(false);
                pageTxt.setVisible(false);
                innerTopBox.getChildren().remove(topLeftHBox);
                paintImage(filename);
                break;

            // Media audio
            case AIF:
            case AIFF:
            case M3U8:
            case MP3:
            case M4A:
            case MAV:
            case FXM:
            case FLV:
            case MP4:
            case M4V:
                nextBtn.setVisible(false);
                previousBtn.setVisible(false);
                pageTxt.setVisible(false);
                innerTopBox.getChildren().remove(topLeftHBox);
                innerTopBox.getChildren().remove(topMidHBox);

                 playMedia(filename);
                setMediaSize();
                break;

            case JAR: case ZIP: case GZIP: case TAR_GZIP: case SEVEN_Z: case AR: case ARJ: case BZIP2: case CPIO: case DEFLATE: case DUMP: case Z: case XZ: case TAR: case SNAPPY: case PACK200: case LZMA:
                viewZipped(filename);

            default: // case TXT: case TEXT: case HTML: case XML:case CSV:
                //setSheetNoVisible(false);
                paintText(filename, pageNum);

                break;
        }
    }

    public void updateFile() {
        renderDoc();
    }

    private void viewZipped(String filename) {
        logger.info("entering ...");
        Path path = Paths.get(filename);
        if (path == null) {
            return;
        }

        String ext = IoUtil.getFileExtension(path.toString());

        if (!Extension.isZipFile(ext)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.notZipFile"),
                    Resources.getMessage("unzip"));
            return;
        }

        //String unzipDirTitle = Resources.getMessage("title.browseUnzipDir");
        String zipname = Dir.MACATEZIP.dir();
        Path zipfile = Paths.get(zipname);

        if (zipfile == null) {
            return;
        }

        String msg = Resources.getMessage("msg.unzipSucceed");
        try {
            MZip.unzip(path, zipfile, "");
        } catch (IOException ex) {
            ex.printStackTrace();
            msg = Resources.getMessage("msg.unzipFailed");
        }

        //currentPath = zipfile.getAbsolutePath();

        FXOptionPane.showMessageDialog(
                ReaderMain.getStage(),
                msg,
                Resources.getMessage("unzip"));
    }

    public void openFile(String filename) throws Exception {
        logger.info("browse button clicked...");
        if (filename == null || filename.trim().length() == 0) {
            return;
        }
        currentFile = filename;
        currentPage = 0;
        fitInRadio.setSelected(true);
        renderDoc(currentFile, currentPage);
    }

    public void closeFile() throws IOException {
        MainUIController controller = GuiUtil.getController(MainUIController.class, MainUIController.FXML, false);
        controller.showEmbeddedDoc(MainUIController.ViewMode.FILESYSTEM, "");
        docMap.entrySet().stream().map((me) -> me.getValue()).forEach(new Consumer<Object>() {

            @Override
            public void accept(Object oj) {
                if (oj instanceof Closeable) {
                    Closeable clsoj = ((Closeable) oj);
                    try {
                        clsoj.close();
                    } catch (IOException ex) {
                        Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                oj = null;
            }
        });

        docMap.clear();

        Image im = docIV.getImage();
        im = null;
        docIV.setImage(null);

        mediaMV.setMediaPlayer(null);

        textOpened = false;
    }

    private void setSheetVisible(boolean visible) {
        //Platform.runLater(() -> {
        setTopBox();

        nextBtn.setVisible(true);
        previousBtn.setVisible(true);
        pageTxt.setVisible(true);
        previousSheetBtn.setVisible(visible);
        sheetTxt.setVisible(visible);
        nextSheetBtn.setVisible(visible);
        //});
    }

    private void setTopBox() {
        innerTopBox.getChildren().removeAll(innerTopBox.getChildren());
        innerTopBox.getChildren().addAll(topLeftHBox, topMidHBox, topRightHBox);
    }

    public void paintText(String fname, int pageNo) {
        long start = System.currentTimeMillis();
        int lineNum = LINE_PER_PAGE * pageNo;
        logger.log(Level.INFO, "LineNum = {0}", lineNum);
        if (!textOpened) {
            try {
                totalPages = getTextLineNumber(fname);
            } catch (IOException ex) {
                Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
            }
            logger.log(Level.INFO, "Total pages of this Document = {0}", totalPages);
        }

        try (LineNumberReader br = new LineNumberReader(new FileReader(fname));) {
            for (int i = 0; i < lineNum; i++) {
                br.readLine();
            }

            String pageContent = "";
            for (int i = 0; i < LINE_PER_PAGE; i++) {
                String str = br.readLine();
                if (str == null) {
                    break;
                }
                pageContent += "\n" + str;
            }

            //logger.log(Level.INFO, "paintText(),pageContent:\n{0}", new Object[]{pageContent});
            Text ta = new Text(pageContent);
            ta.setId("embeddedText");
            ta.setWrappingWidth(520);
            //ta.setX(50);
            //ta.setY(50);
            // WritableImage snapshot = ta.snapshot(new SnapshotParameters(), null);

            VBox vb = new VBox();
            vb.setPadding(new Insets(20, 40, 40, 40));
            vb.getChildren().add(ta);
            SnapshotParameters spp = getSnapshotParameters();
            WritableImage snapshot = vb.snapshot(spp, null);

            setImageView(snapshot);

            String sheetPrompt = (pageNo + 1) + " / " + totalPages;
            pageTxt.setText(sheetPrompt);

            long end = System.currentTimeMillis();
            logger.log(Level.INFO, "it took {0} miliseconds to make page {1} of the Word document.", new Object[]{end - start, pageNo});

        } catch (Exception ex) {
            Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void paintWord(String fname, int pageNo) {
        try {
            long start = System.currentTimeMillis();
            Document doc = (Document) docMap.get(fname);
            if (doc == null) {
                long start1 = System.currentTimeMillis();
                doc = new Document(fname);
                long end1 = System.currentTimeMillis();
                totalPages = doc.getBuiltInDocumentProperties().getPages();
                logger.log(Level.INFO, "it took {0} miliseconds to construct {1} pages of Word Document", new Object[]{end1 - start1, totalPages});
                docMap.put(fname, doc);
            }

            doc.getPageInfo(pageNo).getPaperSize();
            Dimension sizes = doc.getPageInfo(pageNo).getSizeInPixels(1.0f, 100.0f);
            int w = (int) sizes.getWidth();
            int h = (int) sizes.getHeight();
            logger.log(Level.INFO, "paintWord(), w = {0}, h = {1}", new Object[]{w, h});
            BufferedImage bufferedImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = bufferedImage.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            doc.renderToScale(pageNo, g, 0, 0, 1.0f);
            g.dispose();

            setImageView(bufferedImage);

            String sheetPrompt = (pageNo + 1) + " / " + totalPages;
            pageTxt.setText(sheetPrompt);

            long end = System.currentTimeMillis();
            logger.log(Level.INFO, "it took {0} miliseconds to make page {1} of the Word document.", new Object[]{end - start, pageNo});

        } catch (Exception ex) {
            Logger.getLogger(EmbeddedPane.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    private void paintPdf(String fname, int pageNo, int resolution) throws IOException {
        long start = System.currentTimeMillis();
        PDDocument doc = (PDDocument) docMap.get(fname);
        if (doc == null) {
            doc = PDDocument.load(fname);
            totalPages = doc.getDocumentCatalog().getAllPages().size();
            docMap.put(fname, doc);
        }

        long end = System.currentTimeMillis();
        logger.log(Level.INFO, "it took {0} miliseconds to render {1} pages of PDF to PDFImages", new Object[]{end - start, totalPages});

        PDPage page = (PDPage) doc.getDocumentCatalog().getAllPages().get(pageNo);
        //BufferedImage image = page.convertToImage();
        BufferedImage bufferedImage = page.convertToImage();
        setImageView(bufferedImage);

        String sheetPrompt = (pageNo + 1) + " / " + totalPages;

        pageTxt.setText(sheetPrompt);

    }

    private void paintXls(String fname, int sheetNo, int pageNo) throws Exception {
        long start = System.currentTimeMillis();
        Workbook book = (Workbook) docMap.get(fname);
        if (book == null) {
            book = new Workbook(fname);
            docMap.put(fname, book);
        }

        WorksheetCollection sheets = book.getWorksheets();
        sheetCount = sheets.getCount();
        Worksheet sheet = sheets.get(sheetNo);

        String sheetPrompt = (sheetNo + 1) + " / " + sheetCount;
        sheetTxt.setText(sheetPrompt);

        sheet.setShowFormulas(true);
        ImageOrPrintOptions imgOptions = new ImageOrPrintOptions();
        imgOptions.setAllColumnsInOnePagePerSheet(true);
        imgOptions.setCellAutoFit(true);
        totalPages = sheet.getPrintingPageBreaks(imgOptions).length;
        String pagePrompt = (pageNo + 1) + " / " + totalPages;
        pageTxt.setText(pagePrompt);

        imgOptions.setImageFormat(ImageFormat.getPng());

        SheetRender sr = new SheetRender(sheet, imgOptions);
        int h = (int) sr.getPageSize(pageNo)[0];
        int w = (int) sr.getPageSize(pageNo)[1];
        logger.log(Level.INFO, "sr.length = {0}, w = {1}, h = {2}", new Object[]{sr.getPageSize(pageNo).length, w, h});
        BufferedImage bufferedImage = new BufferedImage(h, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = bufferedImage.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        sr.toImage(pageNo, g);
        g.dispose();

        setImageView(bufferedImage);
        long end = System.currentTimeMillis();
        logger.log(Level.INFO, "it took {0} miliseconds to make page {1} of the Word document.", new Object[]{end - start, pageNo});

    }

    private void paintSlidesXslf(String fname, int pageNo) throws FileNotFoundException, IOException {
        long start = System.currentTimeMillis();
        XMLSlideShow xss = (XMLSlideShow) docMap.get(fname);
        if (xss == null) {
            InputStream ifs = new FileInputStream(fname);
            xss = new XMLSlideShow(ifs);
            docMap.put(fname, xss);
        }

        Dimension pageSize = xss.getPageSize();
        XSLFSlide[] slides = xss.getSlides();
        totalPages = slides.length;

        long end = System.currentTimeMillis();
        logger.info("it took " + (end - start) + " miliseconds to load " + totalPages + " pages of PDF to PDFImages");

        BufferedImage bufferedImage = new BufferedImage((int) pageSize.getWidth(), (int) pageSize.getHeight(), BufferedImage.TYPE_INT_ARGB);
        XSLFSlide sld = slides[pageNo];
        Graphics2D g = bufferedImage.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        sld.draw(g);

        setImageView(bufferedImage);

        String pagePrompt = (pageNo + 1) + " / " + totalPages;
        pageTxt.setText(pagePrompt);

    }

    private void paintSlidesHslf(String fname, int pageNo) throws FileNotFoundException, IOException {
        long start = System.currentTimeMillis();
        SlideShow xss = (SlideShow) docMap.get(fname);
        if (xss == null) {
            InputStream ifs = new FileInputStream(fname);
            xss = new SlideShow(ifs);
            docMap.put(fname, xss);
        }

        Dimension pageSize = xss.getPageSize();
        Slide[] slides = xss.getSlides();
        totalPages = slides.length;

        long end = System.currentTimeMillis();
        //totalPages = pres.getSlides().size();
        logger.info("it took " + (end - start) + " miliseconds to load " + totalPages + " pages of PDF to PDFImages");

        //ISlide sld = pres.getSlides().get_Item(pageNo);
        BufferedImage bufferedImage = new BufferedImage((int) pageSize.getWidth(), (int) pageSize.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Slide sld = slides[pageNo];
        Graphics2D g = bufferedImage.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        sld.draw(g);

        setImageView(bufferedImage);

        //g2.drawImage(image, 0, 0, null);
        String pagePrompt = (pageNo + 1) + " / " + totalPages;
        //Platform.runLater(() -> {
        pageTxt.setText(pagePrompt);
        //});
    }

    private void playMedia(String filename) {
        MediaPlayer player = (MediaPlayer) docMap.get(filename);
        if (player == null) {
            Path path = Paths.get(filename);
            URI uri = path.toUri();
            logger.info("uri.toString() = " + uri.toString());
            Media media = new Media(uri.toString());
            player = new MediaPlayer(media);
            player.setAutoPlay(true);
            docMap.put(filename, player);
            mediaMV.setMediaPlayer(player);
            //this.getChildren().add(mediaMV);
            this.setCenter(mediaMV);
        }

        logger.info("mediaMV play size, width = " + mediaMV.getFitWidth() + ", heoght = " + mediaMV.getFitHeight());

    }

    private void paintImage(String fname) throws FileNotFoundException {
        InputStream in = new FileInputStream(fname);
        Image image = new Image(in);

        setImageView(image);
    }

    private void setImageView(BufferedImage bufferedImage) {
        Image image = SwingFXUtils.toFXImage(bufferedImage, null);
        setImageView(image);
    }

    private void setImageView(Image image) {
        double viewHeight = image.getHeight();
        if (fitInRadio.isSelected()) {
            Dimension newD = getAdjustedHeightByWidth(image.getWidth(), image.getHeight(), scrollpane.getWidth(), scrollpane.getHeight());
            viewHeight = newD.getHeight();
        }
        docIV.setImage(image);
        docIV.setFitHeight(viewHeight);
        docIV.setPreserveRatio(true);
        docIV.setSmooth(true);
        docIV.setCache(false);

        this.setCenter(scrollpane);
    }

    private int getTextLineNumber(String fname) throws IOException {
        int lines = 0;

        try (LineNumberReader br = new LineNumberReader(new FileReader(fname));) {
            br.skip(Long.MAX_VALUE);
            lines = br.getLineNumber();
            //lineNumberReader.close();
            int pnum = lines / LINE_PER_PAGE;
            int rnum = lines % LINE_PER_PAGE;

            if (rnum > 0) {
                pnum++;
            }

            return pnum;
        }
    }

    private SnapshotParameters getSnapshotParameters() {
        SnapshotParameters sp = new SnapshotParameters();

        sp.setViewport(new Rectangle2D(0.0, 0.0, 600, 800));
        return sp;
    }

}
