package com.macat.reader.ui;

/**
 *
 * @author martin.tan
 */
public interface DocView {
    void updateFile();
    void openFile(String filename);
}
