/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.macat.reader.ui.controller;

import com.macat.reader.Context;
import com.macat.reader.ReaderMain;
import com.macat.reader.domain.EmailAccounts;
import com.macat.reader.util.IdgLog;
import java.net.URL;
import java.nio.file.Path;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import resources.Resources;

/**
 * FXML Controller class
 *
 * @author martin.tan
 */
public class EmailEntryController implements Initializable {
    public static final String FXML = "/com/macat/reader/ui/fxml/EmailEntry.fxml";
    private static final Logger logger = IdgLog.getLogger();

    @FXML
    private ChoiceBox emailChoice;
    @FXML
    private TextField emailFld;
    @FXML
    private TextField subjectFld;
    @FXML
    private TextArea noteArea;
    @FXML
    private Button cancelBtn;
    @FXML
    private Button sendBtn;
    @FXML
    private AnchorPane emailAnchorPane;
    
    private ObservableList<String> emails;
    private Stage dialogStage;
    String lastSelected = "";
    Path attachPath;

    public Stage getDialogStage() {
        return dialogStage;
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initialEmails();
        updateEmails();
    }

    @FXML
    public void sendAction() {
        String emailTo = emailFld.getText().trim();
        String subject = subjectFld.getText();
        String note = noteArea.getText();

        try {
            //MainUIController controller = GuiUtil.getController(MainUIController.class, MainUIController.FXML, false);
            //Path path = controller.getSelectedPath();
            Context.sendEmail(emailTo, subject, note, attachPath.toFile());
            dialogStage.close();
        } catch (Exception ex) {
            Logger.getLogger(EmailEntryController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void cancelAction() {
        dialogStage.close();
    }

    public void initialEmails() {
        emails = FXCollections.observableArrayList();
        emailChoice.setItems(emails);
        emailChoice.getSelectionModel().selectedItemProperty().addListener(getEmailListener());
    }

    public ChangeListener<String> getEmailListener() {
        ChangeListener<String> emailTypeListener = (ObservableValue<? extends String> observable, String old_value, String new_val) -> {
            logger.log(Level.FINE, "In ChangeListener, New value: {0}, Old value: {1}, OV value: {2}", new Object[]{new_val, old_value, observable.getValue()});

            if (lastSelected.equalsIgnoreCase(new_val) || new_val == null || new_val.isEmpty()) {
                return;
            }

            EmailAccounts acc = Context.emailPref.getEmailAccount(new_val);
            if (acc == null) {
                return;
            }

            Context.setCurrentUser(acc);
            try {
                Context.setServer();
            } catch (Exception ex) {
                Logger.getLogger(EmailEntryController.class.getName()).log(Level.SEVERE, null, ex);
                return;
            }

            String lastSelected = new_val;
        };

        return emailTypeListener;
    }

    public void updateEmails() {
        emails.clear();
        ObservableList<String> emaillist = Context.emailPref.getusers();

        if (emaillist == null) {
            return;
        }

        emails.addAll(emaillist);
        emailChoice.getSelectionModel().selectFirst();
    }

    public Path getAttachPath() {
        return attachPath;
    }

    public void setAttachPath(Path attachPath) {
        this.attachPath = attachPath;
        subjectFld.setText(attachPath.getFileName().toString());
        noteArea.setText(Resources.getMessage("attachNote"));
    }

    public void show() {
        //Window win = dialogStage.getOwner();
        Stage win = ReaderMain.getStage();
        Scene scene = win.getScene();
        //Point2D popupPoint = this.localToScene(0.0, 0.0);
        double w = win.getWidth();
        double h = win.getHeight();
        double w1 = emailAnchorPane.getPrefWidth();
        double h1 = emailAnchorPane.getPrefHeight();
        double x = scene.getWindow().getX() + scene.getX() + w / 2 - w1 / 2;
        double y = scene.getWindow().getY() + scene.getY() + h / 2 - h1 / 2;

        dialogStage.setX(x);
        dialogStage.setY(y);
        dialogStage.showAndWait();
    }

}
