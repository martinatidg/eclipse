/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.macat.reader.ui.controller;

import com.macat.reader.ReaderMain;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import resources.Resources;


/**
 *
 * @author michaelholland
 */
public class PasswordDialogController implements Initializable {
    public static final String FXML = "/com/macat/reader/ui/fxml/PasswordDialog.fxml";

    @FXML
    private TextField passwordTextField;
    @FXML
    private Button okButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Label errorLabel;
    @FXML
    private AnchorPane passwordAnchorPane;
    
    private Stage dialogStage;
    private String passwordString = "";
    private boolean cancelstatus = false;

    /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    @FXML 
    private void passwordKeyEvent(ActionEvent event) {
        event.consume();
        System.out.println("This was pressed.");
    }
    
    @FXML 
    private void passwordKeyPressed(KeyEvent key) {
        if (key.getCode().equals(KeyCode.ENTER)) {
            passwordString = passwordFromDialogBox();
        } else {
            errorLabel.setVisible(false);
        }
    }

    @FXML
    private void okButtonClicked() {
        //errorLabel.setVisible(false);
        passwordString = passwordFromDialogBox();
        if (!passwordString.isEmpty()) {
            cancelstatus = false;
            dialogStage.close();
        }
    }
    
    @FXML
    private void cancelButtonClicked() {
        //reset();
        cancelstatus = true;
        dialogStage.close();
    }
    
    //public void setCanceled(boolean canceled) {
    //    cancelstatus = canceled;
    //}

    public void reset() {
        cancelstatus = false;
        passwordString = "";
        passwordTextField.setText("");
        errorLabel.setVisible(false);
        //errorLabel.setText("");

    }

    private String passwordFromDialogBox() {
        passwordString = "";
        
        if (isPasswordValid()) {
            passwordString = passwordTextField.getText().trim();
            dialogStage.close();
        } else {
            errorLabel.setVisible(true);
            errorLabel.setText(Resources.getMessage("invalidPassword"));
        }
        
        return passwordString;
    }
    
    private boolean isPasswordValid() {
        String tempPassword = passwordTextField.getText().trim();
        
        return tempPassword != null && !tempPassword.isEmpty();
    }
    
    public void setCanceled(boolean canceled) {
        cancelstatus = canceled;
    }

    public boolean isCanceled() {
        return cancelstatus;
    }
    
    public String getPassword() {
        return passwordString == null ? "" : passwordString;
    }

    public void show() {
        //Window win = dialogStage.getOwner();
        Stage win = ReaderMain.getStage();
        Scene scene = win.getScene();
        //Point2D popupPoint = this.localToScene(0.0, 0.0);
        double w = win.getWidth();
        double h = win.getHeight();
        double w1 = passwordAnchorPane.getPrefWidth();
        double h1 = passwordAnchorPane.getPrefHeight();
        double x = scene.getWindow().getX() + scene.getX() + w / 2 - w1 / 2;
        double y = scene.getWindow().getY() + scene.getY() + h / 2 - h1 / 2;

        dialogStage.setX(x);
        dialogStage.setY(y);
        dialogStage.showAndWait();
    }

    public void close() {
        dialogStage.close();
    }

    public void setText(String text) {
        passwordTextField.setText(text);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
}
