package com.macat.reader.ui.controller;

import com.macat.reader.Context;
import com.macat.reader.ReaderMain;
import com.macat.reader.constants.ActOption;
import com.macat.reader.constants.Constants;
import com.macat.reader.constants.Dir;
import com.macat.reader.constants.Extension;
import com.macat.reader.constants.FileType;
import com.macat.reader.constants.OperatingSystem;
import com.macat.reader.constants.ViewOption;
import com.macat.reader.domain.FileInfo;
import com.macat.reader.handler.ToolbarLabel;
import com.macat.reader.pdf.PdfViewPane;
import com.macat.reader.ui.GuiUtil;
import com.macat.reader.ui.embed.EmbeddedPane;
import com.macat.reader.util.FXOptionPane;
import com.macat.reader.util.IdgLog;
import com.macat.reader.util.IoUtil;
import com.macat.reader.util.MZip;
import com.macat.security.Crypto;
import java.io.IOException;
import java.net.URL;
import java.nio.file.AccessDeniedException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.HostServices;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import resources.Resources;

/**
 * FXML Controller class
 *
 * @author martin.tan
 */
public class MainUIController implements Initializable {

    public static final String FXML = "/com/macat/reader/ui/fxml/MainUI.fxml";
    static Logger logger = IdgLog.getLogger();

    public static ViewOption currentView; // = ViewOption.MY_FOLDER;
    public static Path currentPath;
    public static Path previousPath;
    public static Path selectedPath; // = Paths.get(currentPath);
    final public static String ENC_EXT = "ids";
    public static ViewMode currentViewMode; // = ViewMode.FILESYSTEM;

    private DirectoryStream.Filter<Path> docFilter;
    private DirectoryStream.Filter<Path> folderFilter;
    private DirectoryStream.Filter<Path> encryptedFilter;
    private DirectoryStream.Filter<Path> allFilter;
    private DirectoryStream.Filter<Path> currentFilter;

    @FXML
    private BorderPane outerBorderPane;

    @FXML
    private VBox outerTopBox;

    @FXML
    private AnchorPane topAnchor;
    //@FXML
    //private AnchorPane lowerAnchor;
    @FXML
    private AnchorPane innerTopAnchor;
    @FXML
    private AnchorPane innerLowerAnchor;
    @FXML
    private AnchorPane leftAnchor;
    @FXML
    private TableView<FileInfo> fileSysTV;
    @FXML
    private BorderPane innerBorderPane;
    @FXML
    private VBox innerHeaderVBox;

    private Label myFolderBtnl;
    private Label docViewBtnl;

    private Label printBtnl;
    private Label emailBtnl;
    private Label encryptBtnl;
    private Label saveToBtnl;
    private Label settingsBtnl;

    //private Label deleteFolderBtnl;
    private Label newFolderBtnl;
    //private Label docLabel;
    private Label myFolderLabel;
    private Label customFolderLabel;
    private RadioButton allRadio;
    private RadioButton normalRadio;
    private RadioButton encryptedRadio;
    private RadioButton folderRadio;
    private ToggleGroup fileGroup = new ToggleGroup();

    private RadioButton embededRadio;
    private RadioButton localRadio;
    private ToggleGroup openGroup = new ToggleGroup();

    private Label goBackBtnl;
    private Label listViewBtnl;
    private Label folderViewBtnl;
    @FXML
    private TextField searchFld;

    private ObservableList<FileInfo> fileinfoData = FXCollections.observableArrayList();
    private TableColumn<FileInfo, Label> nameCol;
    private TableColumn<FileInfo, Boolean> cryptCol;
    private TableColumn<FileInfo, String> createTimeCol;
    private TableColumn<FileInfo, String> updateTimeCol;
    private TableColumn<FileInfo, String> accessTimeCol;
    private TableColumn<FileInfo, String> sizeCol;
    private TableColumn<FileInfo, String> typeCol;

    private Label innerEncryptBtnlb;
    private Label innerDecryptBtnlb;
    private Label innerZipBtnlb;
    private Label innerUnzipBtnlb;
    private Label innerEmailBtnlb;
    private Button moveToBtn;
    private Button duplicateBtn;
    private Button renameBtn;
    private Button deleteBtn;

    // view zip folder
    private HBox closeZipBox;
    private Label zipViewLb;
    private Button goupBtn;
    private Path currentTmpPath;

    private static MainUIController controller = null;
    private static Stage stage = null;

    static {
        currentPath = Dir.DOCUMENT.path();
        previousPath = currentPath;
        selectedPath = currentPath;
        currentViewMode = ViewMode.FILESYSTEM;
    }
    /*
     * Initializes the controller class.
     */

    static public MainUIController controller() throws IOException {
        if (controller == null) {
            controller = GuiUtil.getController(MainUIController.class, MainUIController.FXML);
        }

        return controller;
    }

    static public Stage stage() throws IOException {
        if (stage == null) {
            stage = GuiUtil.getStage(MainUIController.class, MainUIController.FXML);
        }

        return stage;
    }

    public double[] getOuterBorderPaneSize() {
        return new double[]{outerBorderPane.getWidth(), outerBorderPane.getHeight()};
    }

    public double[] getOuterTopBoxSize() {
        return new double[]{outerTopBox.getWidth(), outerTopBox.getHeight()};
    }

    public void setOuterBoxSize() {
        currentView = ViewOption.MY_FOLDER;
        outerTopBox.setPrefWidth(stage.getWidth());
        outerBorderPane.setPrefWidth(stage.getWidth());
        outerBorderPane.setPrefHeight(stage.getHeight());
    }

    public double[] getInnerBorderPaneSize() {
        return new double[]{innerBorderPane.getWidth(), innerBorderPane.getHeight()};
    }

    public double[] getLeftAnchorSize() {
        return new double[]{leftAnchor.getWidth(), leftAnchor.getHeight()};
    }

    public BorderPane getOuterPane() {
        return outerBorderPane;
    }

    public void bind() {
        outerBorderPane.prefWidthProperty().bind(stage.widthProperty());
        outerBorderPane.prefHeightProperty().bind(stage.heightProperty());
        innerBorderPane.prefWidthProperty().bind(outerBorderPane.widthProperty());
        innerBorderPane.prefHeightProperty().bind(outerBorderPane.heightProperty());
        innerBorderPane.maxWidthProperty().bind(outerBorderPane.widthProperty());
        innerBorderPane.maxHeightProperty().bind(outerBorderPane.heightProperty());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeFilters();
        initializeButtonLabel();
    }

    private void initializeButtonLabel() {
        double bottom = 3.0;
        currentTmpPath = null;

        printBtnl = new ToolbarLabel("print", "lbtn.top.print.up", "lbtn.top.print.dwn", new ToolbarHandler(ActOption.PRINT), Color.WHITE, ContentDisplay.LEFT);
        AnchorPane.setLeftAnchor(printBtnl, 50.0);
        AnchorPane.setTopAnchor(printBtnl, bottom);
        AnchorPane.setBottomAnchor(printBtnl, bottom);
        printBtnl.setDisable(true);

        emailBtnl = new ToolbarLabel("email", "lbtn.top.email.up", "lbtn.top.email.dwn", new ToolbarHandler(ActOption.EMAIL), Color.WHITE, ContentDisplay.LEFT);
        AnchorPane.setLeftAnchor(emailBtnl, 150.0);
        AnchorPane.setTopAnchor(emailBtnl, bottom);
        AnchorPane.setBottomAnchor(emailBtnl, bottom);

        encryptBtnl = new ToolbarLabel("encrypt", "lbtn.top.encrypt.up", "lbtn.top.encrypt.dwn", new ToolbarHandler(ActOption.ENCRYPT), Color.WHITE, ContentDisplay.LEFT);
        AnchorPane.setLeftAnchor(encryptBtnl, 250.0);
        AnchorPane.setTopAnchor(encryptBtnl, bottom);
        AnchorPane.setBottomAnchor(encryptBtnl, bottom);

        saveToBtnl = new ToolbarLabel("saveTo", "lbtn.top.saveTo.up", "lbtn.top.saveTo.dwn", new ToolbarHandler(ActOption.SAVE_TO), Color.WHITE, ContentDisplay.LEFT);
        AnchorPane.setLeftAnchor(saveToBtnl, 350.0);
        AnchorPane.setTopAnchor(saveToBtnl, bottom);
        AnchorPane.setBottomAnchor(saveToBtnl, bottom);

        settingsBtnl = new ToolbarLabel("settings", "lbtn.top.settings.up", "lbtn.top.settings.dwn", new ToolbarHandler(ActOption.SETTINGS), Color.WHITE, ContentDisplay.LEFT);
        AnchorPane.setLeftAnchor(settingsBtnl, 450.0);
        AnchorPane.setTopAnchor(settingsBtnl, bottom);
        AnchorPane.setBottomAnchor(settingsBtnl, bottom);

        topAnchor.getChildren().removeAll(topAnchor.getChildren());
        topAnchor.getChildren().addAll(printBtnl, emailBtnl, encryptBtnl, saveToBtnl, settingsBtnl);

        double left = 10.0;

        openGroup = new ToggleGroup();
        //ToolbarHandler filterHandler = new ToolbarHandler(ActOption.FILE_FILTER);
        embededRadio = new RadioButton(Resources.getMessage("embedded"));
        embededRadio.setToggleGroup(openGroup);
        embededRadio.setTextFill(Color.SKYBLUE);
        embededRadio.setId("radioButton");

        localRadio = new RadioButton(Resources.getMessage("localProgram"));
        localRadio.setToggleGroup(openGroup);
        localRadio.setTextFill(Color.SKYBLUE);
        localRadio.setId("radioButton");

        Label openLabel = new Label(Resources.getMessage("openAs"));
        openLabel.setTextFill(Color.SKYBLUE);

        leftAnchor.getChildren().removeAll(leftAnchor.getChildren());

        ToolbarHandler docviewHandler = new ToolbarHandler(ActOption.DOC_VIEW);
        docViewBtnl = new ToolbarLabel("docView", "lbtn.left.docView.up", "lbtn.left.docView.dwn", docviewHandler, Color.SKYBLUE, ContentDisplay.TOP);
        AnchorPane.setTopAnchor(docViewBtnl, 50.0);
        AnchorPane.setLeftAnchor(docViewBtnl, left);
        AnchorPane.setRightAnchor(docViewBtnl, left);

        ToolbarHandler myfoldersHandler = new ToolbarHandler(ActOption.MY_FOLDERS);
        myFolderBtnl = new ToolbarLabel("myFolders", "lbtn.left.myFolders.up", "lbtn.left.myFolders.dwn", myfoldersHandler, Color.SKYBLUE, ContentDisplay.TOP);
        AnchorPane.setTopAnchor(myFolderBtnl, 150.0);
        AnchorPane.setLeftAnchor(myFolderBtnl, left);
        AnchorPane.setRightAnchor(myFolderBtnl, left);

        AnchorPane.setTopAnchor(openLabel, 270.0);
        AnchorPane.setLeftAnchor(openLabel, left);
        AnchorPane.setRightAnchor(openLabel, left);

        AnchorPane.setTopAnchor(embededRadio, 300.0);
        AnchorPane.setLeftAnchor(embededRadio, left);
        AnchorPane.setRightAnchor(embededRadio, left);
        embededRadio.setSelected(true);

        AnchorPane.setTopAnchor(localRadio, 330.0);
        AnchorPane.setLeftAnchor(localRadio, left);
        AnchorPane.setRightAnchor(localRadio, left);

        leftAnchor.getChildren().addAll(docViewBtnl, myFolderBtnl, openLabel, embededRadio, localRadio);

        ToolbarHandler gobackHandler = new ToolbarHandler(ActOption.GO_BACK);
        goBackBtnl = new ToolbarLabel("goBack", "lbtn.goBack.up", "lbtn.goBack.dwn", gobackHandler, ContentDisplay.LEFT);

        ToolbarHandler listviewHandler = new ToolbarHandler(ActOption.LIST_VIEW);
        listViewBtnl = new ToolbarLabel("listView", "lbtn.listView.up", "lbtn.listView.dwn", listviewHandler, ContentDisplay.LEFT);
        listViewBtnl.setDisable(true);

        ToolbarHandler folderviewHandler = new ToolbarHandler(ActOption.FOLDER_VIEW);
        folderViewBtnl = new ToolbarLabel("folderView", "lbtn.folderView.up", "lbtn.folderView.dwn", folderviewHandler, ContentDisplay.LEFT);
        folderViewBtnl.setDisable(true);

        ToolbarHandler encHandler = new ToolbarHandler(ActOption.ENCRYPT);
        innerEncryptBtnlb = new ToolbarLabel("encrypt", "lbtn.tv.encrypt.up", "lbtn.tv.encrypt.dwn", encHandler, ContentDisplay.LEFT);

        ToolbarHandler decHandler = new ToolbarHandler(ActOption.DECRYPT);
        innerDecryptBtnlb = new ToolbarLabel("decrypt", "lbtn.tv.decrypt.up", "lbtn.tv.decrypt.dwn", decHandler, ContentDisplay.LEFT);

        ToolbarHandler zipHandler = new ToolbarHandler(ActOption.ZIP);
        innerZipBtnlb = new ToolbarLabel("Zip", "lbtn.tv.encrypt.up", "lbtn.tv.encrypt.dwn", zipHandler, ContentDisplay.LEFT);

        ToolbarHandler unzipHandler = new ToolbarHandler(ActOption.UNZIP);
        innerUnzipBtnlb = new ToolbarLabel("Unzip", "lbtn.tv.decrypt.up", "lbtn.tv.decrypt.dwn", unzipHandler, ContentDisplay.LEFT);

        ToolbarHandler emailHandler = new ToolbarHandler(ActOption.EMAIL);
        innerEmailBtnlb = new ToolbarLabel("email", "lbtn.tv.email.up", "lbtn.tv.email.dwn", emailHandler, ContentDisplay.LEFT);

        moveToBtn = new Button(Resources.getMessage("moveTo"));
        moveToBtn.setOnMouseClicked(new ToolbarHandler(ActOption.MOVE_TO));
        duplicateBtn = new Button(Resources.getMessage("duplicate"));
        duplicateBtn.setOnMouseClicked(new ToolbarHandler(ActOption.DUPLICATE));
        renameBtn = new Button(Resources.getMessage("rename"));
        renameBtn.setTextFill(Constants.TEXT_COLOR);
        renameBtn.setOnMouseClicked(new ToolbarHandler(ActOption.RENAME));
        deleteBtn = new Button(Resources.getMessage("delete"));
        deleteBtn.setOnMouseClicked(new ToolbarHandler(ActOption.DELETE));

        left = 30.0;
        bottom = 3.0;
        innerLowerAnchor.getChildren().removeAll(innerLowerAnchor.getChildren());
        AnchorPane.setLeftAnchor(goBackBtnl, left);
        AnchorPane.setLeftAnchor(listViewBtnl, left + 100);
        AnchorPane.setLeftAnchor(folderViewBtnl, left + 200);

        left += 330;
        AnchorPane.setLeftAnchor(innerEncryptBtnlb, left);
        AnchorPane.setLeftAnchor(innerDecryptBtnlb, left + 95);
        AnchorPane.setLeftAnchor(innerZipBtnlb, left + 190);
        AnchorPane.setLeftAnchor(innerUnzipBtnlb, left + 260);
        AnchorPane.setLeftAnchor(innerEmailBtnlb, left + 340);

        left += 450;
        AnchorPane.setLeftAnchor(moveToBtn, left);
        AnchorPane.setLeftAnchor(duplicateBtn, left + 80);
        AnchorPane.setLeftAnchor(renameBtn, left + 160);
        AnchorPane.setLeftAnchor(deleteBtn, left + 240);

        innerLowerAnchor.getChildren().addAll(goBackBtnl, listViewBtnl, folderViewBtnl,
                innerEncryptBtnlb, innerDecryptBtnlb, innerZipBtnlb, innerUnzipBtnlb, innerEmailBtnlb, moveToBtn, duplicateBtn, renameBtn, deleteBtn); //, searchFld);

        myFolderLabel = new ToolbarLabel("myFolders", "icon.docFolder.dwn", "icon.docFolder.dwn", null, ContentDisplay.LEFT);
        customFolderLabel = new ToolbarLabel("customFolder", "icon.customFolder", "icon.customFolder", null, ContentDisplay.LEFT);
        newFolderBtnl = new ToolbarLabel("newfolder", "lbtn.newfolder.up", "lbtn.newfolder.dwn", new ToolbarHandler(ActOption.NEW_FOLDER), ContentDisplay.LEFT);

        fileGroup = new ToggleGroup();
        ToolbarHandler filterHandler = new ToolbarHandler(ActOption.FILE_FILTER);
        allRadio = new RadioButton(Resources.getMessage("all"));
        allRadio.setToggleGroup(fileGroup);
        allRadio.setOnMouseClicked(filterHandler);
        allRadio.setTextFill(Constants.TEXT_COLOR);

        normalRadio = new RadioButton(Resources.getMessage("file"));
        normalRadio.setToggleGroup(fileGroup);
        normalRadio.setOnMouseClicked(filterHandler);
        normalRadio.setTextFill(Constants.TEXT_COLOR);

        folderRadio = new RadioButton(Resources.getMessage("folder"));
        folderRadio.setToggleGroup(fileGroup);
        folderRadio.setOnMouseClicked(filterHandler);
        folderRadio.setTextFill(Constants.TEXT_COLOR);

        encryptedRadio = new RadioButton(Resources.getMessage("encrypted"));
        encryptedRadio.setToggleGroup(fileGroup);
        encryptedRadio.setOnMouseClicked(filterHandler);
        encryptedRadio.setTextFill(Constants.TEXT_COLOR);

        left = 30.0;
        bottom = 3.0;
        innerTopAnchor.getChildren().removeAll(innerTopAnchor.getChildren());
        AnchorPane.setLeftAnchor(myFolderLabel, left);
        AnchorPane.setBottomAnchor(myFolderLabel, bottom);
        AnchorPane.setLeftAnchor(customFolderLabel, left);
        AnchorPane.setBottomAnchor(customFolderLabel, bottom);

        left += 300;
        AnchorPane.setLeftAnchor(allRadio, left);
        AnchorPane.setBottomAnchor(allRadio, bottom);
        allRadio.setSelected(true);
        AnchorPane.setLeftAnchor(normalRadio, left + 50);
        AnchorPane.setBottomAnchor(normalRadio, bottom);
        AnchorPane.setLeftAnchor(folderRadio, left + 100);
        AnchorPane.setBottomAnchor(folderRadio, bottom);
        AnchorPane.setLeftAnchor(encryptedRadio, left + 170);
        AnchorPane.setBottomAnchor(encryptedRadio, bottom);

        left = 30.0;
        AnchorPane.setRightAnchor(searchFld, left + 200);
        AnchorPane.setBottomAnchor(searchFld, bottom);
        AnchorPane.setRightAnchor(newFolderBtnl, left);
        AnchorPane.setBottomAnchor(newFolderBtnl, bottom);
        innerTopAnchor.getChildren().addAll(myFolderLabel, customFolderLabel,
                allRadio, normalRadio, folderRadio, encryptedRadio,
                searchFld, newFolderBtnl);

        setDocIcons(ViewOption.MY_FOLDER);

        //fileSysTV = 
        createTable();
        updateTableData(currentPath);
        nameCol.setPrefWidth(80 * 4 + 260);
        innerBorderPane.setCenter(fileSysTV);
        showEmbeddedDoc(ViewMode.FILESYSTEM, "");

        outerTopBox.setMinWidth(1.0);
        outerBorderPane.setMinWidth(1.0);
        outerBorderPane.setMinHeight(1.0);

        closeZipBox = new HBox(300);
        closeZipBox.setPadding(new Insets(5, 0, 5, 0));
        closeZipBox.setAlignment(Pos.CENTER);
        goupBtn = new Button(Resources.getMessage("goup"));
        goupBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                logger.info("go up button clicked...");
                //innerBorderPane.setTop(innerHeaderVBox);
                Path path = currentPath.getParent();
                currentPath = path;
                if (path.equals(currentTmpPath)) {
                    goupBtn.setDisable(true);
                }

                //currentViewMode = ViewMode.FILESYSTEM;
                updateTableView();
            }
        });

        Button closeZipBtn = new Button(Resources.getMessage("close"));
        closeZipBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                logger.info("close zip button clicked...");
                innerBorderPane.setTop(innerHeaderVBox);
                currentPath = previousPath;
                currentViewMode = ViewMode.FILESYSTEM;
                logger.info("in close zip handle, currentPath = " + currentPath.toString());
                updateTableView();
            }
        });

        zipViewLb = new Label("");
        closeZipBox.getChildren().addAll(goupBtn, zipViewLb, closeZipBtn);
//        lowerAnchor.getChildren().removeAll(lowerAnchor.getChildren());
//        lowerAnchor.setMinHeight(20);
    }

    public void updateFile() {
        EmbeddedPane pane = EmbeddedPane.istance();
        pane.maxWidthProperty().bind(stage.widthProperty());
        pane.maxHeightProperty().bind(stage.heightProperty());
        pane.updateFile();
    }

    public void closeFile() {
        EmbeddedPane pane = EmbeddedPane.istance();
        try {
            pane.closeFile();
        } catch (IOException ex) {
            Logger.getLogger(MainUIController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public double[] getInnerBoxBorderPaneSize() {
        return new double[]{innerBorderPane.getWidth(), innerBorderPane.getHeight()};
    }

    private void setDocIcons(ViewOption option) {
        switch (option) {
            case MY_FOLDER:
                customFolderLabel.setVisible(false);
                myFolderLabel.setVisible(true);
                break;
            case CUSTOM_FOLDER:
                customFolderLabel.setVisible(true);
                myFolderLabel.setVisible(false);
                break;
            case FOLDER_VIEW:
                newFolderBtnl.setVisible(true);
                break;
            case DOCUMENT_VIEW:
                newFolderBtnl.setVisible(false);
                break;
            default:
        }
    }

    private TableView<FileInfo> createTable() {
        //TableView<FileInfo> fileSysTV = new TableView<>();
        fileSysTV.getColumns().clear();
        fileSysTV.getStylesheets().add(Resources.getStylesheet());

        //fTable.setId("my-table");
        double colwidth = 80;

        nameCol = new TableColumn<>(Resources.getMessage("name"));
        nameCol.setCellValueFactory(new PropertyValueFactory<FileInfo, Label>("name"));
        nameCol.setMinWidth(colwidth * 8);
//        nameCol.setCellFactory(new Callback<TableColumn<FileInfo, Label>, TableCell<FileInfo, Label>>() {
//            @Override
//            public TableCell<FileInfo, Label> call(TableColumn<FileInfo, Label> param) {
//                TableCell<FileInfo, Label> cell = new TableCell<FileInfo, Label>() {
//                    @Override
//                    public void updateItem(Label item, boolean empty) {
//                        // Don't omit this:
//                        super.updateItem(item, empty);
//                        if (item != null) {
//                            setItem(item);
//                        }
//                    }
//                };
//                //cell.setAlignment(Pos.CENTER);
//                return cell;
//            }
//        });

        cryptCol = new TableColumn<FileInfo, Boolean>("");
        cryptCol.setCellValueFactory(new PropertyValueFactory<FileInfo, Boolean>("crypto"));
        cryptCol.setMinWidth(130);

        createTimeCol = new TableColumn<>(Resources.getMessage("dateCreated"));
        createTimeCol.setCellValueFactory(new PropertyValueFactory<FileInfo, String>("createTime"));
        createTimeCol.setMinWidth(220);

        updateTimeCol = new TableColumn<>(Resources.getMessage("dateModified"));
        updateTimeCol.setCellValueFactory(new PropertyValueFactory<FileInfo, String>("updateTime"));
        updateTimeCol.setMinWidth(220);

        accessTimeCol = new TableColumn<>(Resources.getMessage("dateAccessed"));
        accessTimeCol.setCellValueFactory(new PropertyValueFactory<FileInfo, String>("accessTime"));
        accessTimeCol.setMinWidth(220);

        sizeCol = new TableColumn<>(Resources.getMessage("size"));
        sizeCol.setCellValueFactory(new PropertyValueFactory<FileInfo, String>("size"));
        sizeCol.setMinWidth(colwidth);

        typeCol = new TableColumn<>(Resources.getMessage("type"));
        typeCol.setCellValueFactory(new PropertyValueFactory<FileInfo, String>("type"));
        typeCol.setMinWidth(120);

        //updateTableData(path);
        fileSysTV.setItems(fileinfoData);
        //contactTable.getColumns().addAll(nameCol, cryptCol, createTimeCol, updateTimeCol, sizeCol, typeCol);
        fileSysTV.getColumns().addAll(nameCol, createTimeCol, sizeCol);

        fileSysTV.setPrefHeight(800);
        fileSysTV.setTableMenuButtonVisible(true);
        fileSysTV.setEditable(true);

//        fileSysTV.setOnMouseClicked(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent t) {
//                int selectedIndex = ((TableView) t.getSource()).getSelectionModel().getFocusedIndex();
//                FileInfo finfo = (FileInfo) ((TableView) t.getSource()).getSelectionModel().getSelectedItem();
//                if (finfo == null || FileType.FOLDER != finfo.getType()) {
//                    return;
//                }
//
//                logger.info("mouse click on tableview = " + t.getClickCount() + " times, selectedIndex = " + selectedIndex + ",\nfinfo " + finfo);
//                ObservableList<FileInfo> fid = fileSysTV.getItems();
//                int i = 0;
//                for (FileInfo fi : fid) {
//                    logger.info("fid " + i++ + ": " + fi.toString());
//                }
//
//                if (t.getClickCount() > 1) {
//                    logger.info("in ToolbarHandler, case OPEN_FOLDER, event double clicked.");
//                    logger.info("Open folder.");
//                    openFolderAction();
//                    currentViewMode = ViewMode.FILESYSTEM;
//                    updateTableView();
//                }
//            }
//        });

        return fileSysTV;
    }
    private void cleanColumns() {
        fileSysTV.getColumns().clear();

        fileSysTV.getColumns().addAll(nameCol, createTimeCol, sizeCol);
        //fileSysTV.setItems(fileinfoData);
    }

    public void updateTableData(Path pathname) {
        logger.info("updateTableData： entering ..., pathname = " + pathname);
        cleanColumns();
        ObservableList<FileInfo> fileInfos = FXCollections.<FileInfo>observableArrayList();
        ObservableList<FileInfo> dirInfos = FXCollections.<FileInfo>observableArrayList();
        fileInfos.clear();
        dirInfos.clear();
        FileInfo fileinfo;
        String errMsg = "";
        boolean openFailed = false;
      
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(pathname, currentFilter)) {
            int j = 0;
            for (Path path : directoryStream) {
                System.out.print("loop " + j++ + ": ");
                fileinfo = new FileInfo();
                fileinfo.setPath(path);

                BasicFileAttributes attr = Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
                fileinfo.setCreateTime(attr.creationTime().toString());
                fileinfo.setUpdateTime(attr.lastModifiedTime().toString());
                fileinfo.setAccessTime(attr.lastAccessTime().toString());
                fileinfo.setSize(attr.size() + "");

                Label nameLbl;
                if (Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
                    nameLbl = new ToolbarLabel(path.getFileName().toString(), "icon.docFolder.up", "icon.docFolder.up", new ToolbarHandler(ActOption.OPEN_FOLDER), ContentDisplay.LEFT);
                    logger.fine("ToolbarHandler(ActOption.OPEN_FOLDER) is added to " + path.getFileName().toString());
                    fileinfo.setType(FileType.FOLDER);
                    fileinfo.setName(nameLbl);
                    dirInfos.add(fileinfo);
                } else {
                    String extStr = IoUtil.getFileExtension(path.toString());
                    Extension ext = Extension.type(extStr);

                    if (ext == Crypto.ENC_EXT) {
                        fileinfo.setCrypted(Boolean.TRUE);
                        fileinfo.setType(FileType.ENCRYPTED);
                        nameLbl = new ToolbarLabel(path.getFileName().toString(), "icon.doc.encrypted", "icon.doc.encrypted", new ToolbarHandler(ActOption.OPEN_DOC), ContentDisplay.LEFT);
                        logger.fine("ToolbarHandler(ActOption.OPEN_DOC) for encrypted file is added to " + path.getFileName().toString());
                    } //                    else if (Extension.isZipFile(ext)) {
                    //                        fileinfo.setCrypted(Boolean.FALSE);
                    //                        fileinfo.setType(FileType.ZIP);
                    //                        nameLbl = new ToolbarLabel(path.getFileName().toString(), "icon.doc", "icon.doc", new ToolbarHandler(ActOption.OPEN_ZIP), ContentDisplay.LEFT);
                    //                    }
                    else {
                        fileinfo.setCrypted(Boolean.FALSE);
                        fileinfo.setType(FileType.REGULAR);
                        nameLbl = new ToolbarLabel(path.getFileName().toString(), "icon.doc", "icon.doc", new ToolbarHandler(ActOption.OPEN_DOC), ContentDisplay.LEFT);
                        logger.fine("ToolbarHandler(ActOption.OPEN_DOC) is added to " + path.getFileName().toString());
                    }
                    fileinfo.setName(nameLbl);

                    fileInfos.add(fileinfo);
                }
            }

            fileinfoData.clear();
            if (currentFilter == docFilter) {
                fileinfoData.addAll(fileInfos);

                setButtonsDisable(false);
            } else if (currentFilter == folderFilter) {
                fileinfoData.addAll(dirInfos);

                setButtonsDisable(true);
                renameBtn.setDisable(false);
                deleteBtn.setDisable(false);
                myFolderBtnl.setDisable(false);
            } else if (currentFilter == encryptedFilter) {
                fileinfoData.addAll(fileInfos);

                setButtonsDisable(false);
                encryptBtnl.setDisable(true);
                innerEncryptBtnlb.setDisable(true);
            } else if (currentFilter == allFilter) {
                fileinfoData.addAll(dirInfos);
                fileinfoData.addAll(fileInfos);

                setButtonsDisable(false);
            }

            fileSysTV.setItems(fileinfoData);
            ObservableList<FileInfo> fid = fileSysTV.getItems();
            logger.fine("updated table data size = " + fid.size());

//            int i = 0;
//            for (FileInfo fi : fid) {
//                logger.info("table data[" + i++ + "]: " + fi.toString());
//            }

//            logger.info("Dir.DOCUMENT.dir() = " + Dir.DOCUMENT.dir() + ", pathname.toString() = " + pathname.toString());
            if (Dir.DOCUMENT.equals(pathname.toString())) { // note the equals(String str) overloads equals(Object obj), not overriding.
                setDocIcons(ViewOption.MY_FOLDER);
                goBackBtnl.setDisable(true);
            } else {
                setDocIcons(ViewOption.CUSTOM_FOLDER);
                Path cpath = pathname;
                //Path fpath = FileSystems.getDefault().getPath(currentPath);

                if (cpath.getParent() == null) {
                    this.customFolderLabel.setText(cpath.toString());
                } else {
                    Path fpath = cpath.getFileName();
                    this.customFolderLabel.setText(fpath.toString());
                }
                goBackBtnl.setDisable(false);
            }
        } catch (AccessDeniedException e) {
            e.printStackTrace();
            errMsg = Resources.getMessage("msg.accessDeniedTo") + e.getMessage();
            openFailed = true;
        } catch (IOException e) {
            e.printStackTrace();
            errMsg = e.getMessage();
            openFailed = true;
        }

        if (openFailed) {
            String errPrompt = Resources.getMessage("title.openFailed");
            Path cpath = pathname;
            String msg = errPrompt + ":\n" + errMsg;
            logger.log(Level.SEVERE, msg);
            FXOptionPane.showMessageDialog(ReaderMain.getStage(), msg, errPrompt);

            currentPath = cpath.getParent();
        }

    }

    private void setButtonsDisable(boolean disable) {
        //printBtnl.setDisable(disable);
        emailBtnl.setDisable(disable);
        encryptBtnl.setDisable(disable);
        saveToBtnl.setDisable(disable);

        innerEncryptBtnlb.setDisable(disable);
        innerDecryptBtnlb.setDisable(disable);
        innerEmailBtnlb.setDisable(disable);

        moveToBtn.setDisable(disable);
        duplicateBtn.setDisable(disable);
        renameBtn.setDisable(disable);
        deleteBtn.setDisable(disable);

        myFolderBtnl.setDisable(disable);
        docViewBtnl.setDisable(disable);

    }

    public class ToolbarHandler implements EventHandler<MouseEvent> {

        ActOption toolbarItem = null;
        Path path = null;

        public ToolbarHandler(ActOption toolbaritem) {
            this.toolbarItem = toolbaritem;
        }

        @Override
        public void handle(MouseEvent event) {
            int doubleClick = event.getClickCount();
            logger.info("in ToolbarHandler, " + toolbarItem + " is selected, currentPath = " + currentPath.toString() + ", click times = " + doubleClick);
            switch (toolbarItem) {
                case PRINT:
                    break;

                case EMAIL:
                    emailAction();
                    break;

                case ENCRYPT:
                    encryptAction();
                    updateTableView();
                    break;

                case DECRYPT:
                    decryptAction();
                    updateTableView();
                    break;

                case ZIP:
                    zipAction();
                    updateTableView();
                    break;

                case UNZIP:
                    unzipAction();
                    updateTableView();
                    break;

                case SAVE_TO:
                    saveToAction();
                    break;

                case SETTINGS:
                    settingsAction();
                    break;

                case DOC_VIEW:
                    openDocAction();
                    break;

                case OPEN_DOC:
                    if (event.getClickCount() > 1) {
                        openDocAction();
                    }
                    break;

                case OPEN_FOLDER:
                    if (event.getClickCount() > 1) {
                        logger.info("in ToolbarHandler, case OPEN_FOLDER, event double clicked.");
                        logger.info("Open folder.");
                        openFolderAction();
                        updateTableView();
                    }
                    logger.info("in ToolbarHandler, case OPEN_FOLDER, before break ");

                    break;

                case NEW_FOLDER:
                    createNewFolder(currentPath);
                    updateTableView();
                    break;

                case MY_FOLDERS:
                    closeFile();
                    currentPath = Dir.DOCUMENT.path();
                    updateTableView();
                    break;

                case GO_BACK:
                    logger.info("Go upper folder");
                    showEmbeddedDoc(ViewMode.FILESYSTEM, "");
                    if (currentViewMode == ViewMode.DOCVIEW) {
                        currentViewMode = ViewMode.FILESYSTEM;
                        return;
                    }

                    goBackAction();
                    updateTableView();
                    break;

                case LIST_VIEW:
                    break;

                case FOLDER_VIEW:
                    break;

                case MOVE_TO:
                    moveToAction();
                    updateTableView();
                    break;

                case DUPLICATE:
                    duplicateAction();
                    updateTableView();
                    break;

                case RENAME:
                    renameAction();
                    updateTableView();
                    break;

                case DELETE:
                    deleteAction();
                    updateTableView();
                    break;

                case FILE_FILTER:
                    if (normalRadio.isSelected()) {
                        currentFilter = docFilter;
                        setDocIcons(ViewOption.DOCUMENT_VIEW);
                    } else if (folderRadio.isSelected()) {
                        currentFilter = folderFilter;
                        setDocIcons(ViewOption.FOLDER_VIEW);
                    } else if (encryptedRadio.isSelected()) {
                        currentFilter = encryptedFilter;
                        setDocIcons(ViewOption.DOCUMENT_VIEW);
                    } else {
                        currentFilter = allFilter;
                        setDocIcons(ViewOption.FOLDER_VIEW);
                    }

                    updateTableView();
                    break;

                default:
                    break;
            }
            //updateTableView();
        }
    }

    private void updateTableView() {
        updateTableData(currentPath);
        //fileTv.setItems(fileinfoData);
    }

    public Path getSelectedPath() {
        FileInfo fileInfo1 = fileSysTV.getSelectionModel().getSelectedItem();
        if (fileInfo1 == null) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.noFileSelected"),
                    Resources.getMessage("title.selectfile"));
            return null;
        }

        return fileInfo1.getPath();
    }

    private void createNewFolder(Path baseDir) {
    //private void createNewFolder(String suggested) {

        //String pathStr = getNewFilename("New Folder", baseDir + File.separator + "New Folder");
        String pathStr = getNewFilename(Resources.getMessage("newfolder"), Resources.getMessage("newfolder"));
        if (pathStr.trim().isEmpty()) {
            return;
        }

        Path path = baseDir.resolve(pathStr);
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            try {
                Files.createDirectory(path);
            } catch (IOException ex) {
                logger.info("Failed to create the Macat home directory.");
            }
        }
    }

    private void encryptAction() {
        logger.info("encryptAction() entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        String filename = path.toString();
        String ext = IoUtil.getFileExtension(filename);
        if (Crypto.ENC_EXT.equals(ext)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.fileAlreadyEncrypted"),
                    Resources.getMessage("encrypt"));
            return;
        }

        String encname = IoUtil.replaceExtension(filename, Crypto.ENC_EXT.ext());
        String password = getPassword();
        if (password == null) {
            return;
        }

        Crypto.doEncryptFile(filename, encname, password);
        try {
            Files.deleteIfExists(path);
        } catch (IOException ex) {
            Logger.getLogger(MainUIController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void decryptAction() {
        logger.info("decryptAction() entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        String filename = path.toString();
        String ext = IoUtil.getFileExtension(filename);

        if (Crypto.ENC_EXT.equals(ext)) {
            String password = getPassword();
            if (password == null) {
                return;
            }

            String decryptedfile = Crypto.doDecryptFile(filename, password);
            if (decryptedfile == null) {
                return;
            }

            try {
                Files.deleteIfExists(path);
            } catch (IOException ex) {
                logger.info("IOException:\n" + ex.getMessage());
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("msg.cannotDeleteOriginalFile"),
                        Resources.getMessage("saveTo"));
            }
        }
    }

    private void zipAction() {
        logger.info("encryptAction() entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        String filename = path.toString();
        String ext = IoUtil.getFileExtension(filename);
        if (Extension.isZipFile(ext)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.fileAlreadyZipped"),
                    Resources.getMessage("zip"));
            return;
        }

        String zipname = IoUtil.replaceExtension(filename, Extension.ZIP.ext());

        String msg = Resources.getMessage("msg.zipSucceed");
        try {
            MZip.compress(filename, Extension.ZIP);
        } catch (IOException ex) {
            ex.printStackTrace();
            msg = Resources.getMessage("msg.zipFailed");
        }

        FXOptionPane.showMessageDialog(
                ReaderMain.getStage(),
                msg,
                Resources.getMessage("zip"));
    }

    private void unzipAction() {
        logger.info("entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        String ext = IoUtil.getFileExtension(path.toString());

        if (!Extension.isZipFile(ext)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.notZipFile"),
                    Resources.getMessage("unzip"));
            return;
        }

        String unzipDirTitle = Resources.getMessage("title.browseUnzipDir");
        String unzipDir = IoUtil.getFilenameWithoutExtension(path.getFileName().toString());
        Path unzippath = currentPath.resolve(unzipDir);

//        File zipfile = unzippath.toFile();
//        // Let users select a folder to unzip
//        try {
//            zipfile = IoUtil.browseDirFile(unzipDirTitle);
//        } catch (IOException ex) {
//            String err = ex.getMessage();
//            FXOptionPane.showMessageDialog(
//                    ReaderMain.getStage(),
//                    err,
//                    Resources.getMessage("unzip"));
//            zipfile = null;
//        }
//        if (zipfile == null) {
//            return;
//        }
        String msg = Resources.getMessage("msg.unzipSucceed");
        try {
            MZip.unzip(path, unzippath, "");
        } catch (IOException ex) {
            ex.printStackTrace();
            msg = Resources.getMessage("msg.unzipFailed");
        }

        if (unzippath != null) {
            currentPath = unzippath;
        }

        FXOptionPane.showMessageDialog(
                ReaderMain.getStage(),
                msg,
                Resources.getMessage("unzip"));
    }

    private void openFolderAction() {
        logger.info("openFolderAction() entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        currentPath = path;
        goupBtn.setDisable(false);
    }

    private void goBackAction() {
        logger.info("goBackAction() entering ...");
        Path path = currentPath;
        if (path == null) {
            return;
        }

        Path sp = path.getParent();
        if (sp != null) {
            currentPath = sp;
        }
    }

    private void openDocAction() {
        logger.info("openDocAction() entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        String filename = path.toAbsolutePath().toString();
        String ext = IoUtil.getFileExtension(filename);

        if (Crypto.ENC_EXT.equals(ext)) {
            String password = getPassword();
            if (password == null) {
                return;
            }

            Path tmp = Context.getTempPath();
            tmp = tmp.resolve("decrypted");
            filename = Crypto.doDecryptFile(filename, tmp.toString(), password);
            if (filename == null) {
                return;
            }
        }

        ext = IoUtil.getFileExtension(filename);

        if (Extension.isZipFile(ext)) {
            Path unzipfile;
            try {
                unzipfile = unzip(path);
            } catch (IOException ex) {
                Logger.getLogger(MainUIController.class.getName()).log(Level.SEVERE, null, ex);
                return;
            }

            if (unzipfile == null) {
                return;
            }

            if (Files.isDirectory(unzipfile, LinkOption.NOFOLLOW_LINKS)) {  // if the unzipped file is directory
                previousPath = currentPath;
                currentTmpPath = unzipfile;
                goupBtn.setDisable(true);
                currentPath = unzipfile;
                zipViewLb.setText(path.getFileName().toString());
                innerBorderPane.setTop(closeZipBox);
                currentViewMode = ViewMode.FILESYSTEM;
                updateTableView();

                return;
            } else {
                filename = unzipfile.toAbsolutePath().toString();
            }
        }

        if (embededRadio.isSelected()) {
            currentViewMode = ViewMode.DOCVIEW;
            showEmbeddedDoc(ViewMode.DOCVIEW, filename);
            //openDocEmbeddedAction();
        } else {
            currentViewMode = ViewMode.FILESYSTEM;
            HostServices hostServices = ReaderMain.instance().getHostServices();
            hostServices.showDocument(filename);
            //        openDocAction(false);
            updateTableView();
        }

//        if (embedded) {
//            showEmbeddedDoc(ViewMode.DOCVIEW, filename);
//        } else {
//            HostServices hostServices = ReaderMain.instance().getHostServices();
//            hostServices.showDocument(filename);
//        }
    }

    private Path unzip(String filename) throws IOException {
        logger.info("entering ...");
        Path path = Paths.get(filename);
        return unzip(path);
    }

    private Path unzip(Path path) throws IOException {
        if (path == null) {
            return null;
        }
        //String unzipDirTitle = Resources.getMessage("title.browseUnzipDir");
        Path tmpzippath = Context.getTempPath(); //Dir.MACATEZIP.dir();
        tmpzippath = tmpzippath.resolve(path.getFileName());
        //Path tmpzippath = Paths.get(tmpzipname, path.getFileName().toString());

        try {
            IoUtil.deleteDir(tmpzippath);
        } catch (NoSuchFileException e) {
            logger.info(e.getMessage());
        }

//        File tmpzipfile = tmpzippath.toFile(); //new File(tmpzipname);
//        if (tmpzipfile == null) {
//            return null;
//        }
        Path unzipfile = null;
        //String msg = Resources.getMessage("msg.unzipSucceed");
        try {
            unzipfile = MZip.unzip(path, tmpzippath, "");

        } catch (IOException ex) {
            ex.printStackTrace();
            //msg = Resources.getMessage("msg.unzipFailed");
        }

        //currentPath = tmpzipfile.getAbsolutePath();
        return unzipfile;
    }

    private String getPassword() {
        PasswordDialogController controller = getPasswordController();
        if (controller == null) {
            return null;
        }
        controller.reset();
        controller.show();
        if (controller.isCanceled()) {
            return null;
        }

        String password = controller.getPassword();

        while (password.length() < 8 || password.length() > 15) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.passwordConstraint"),
                    Resources.getMessage("password"));
            controller.show();
            if (controller.isCanceled()) {
                return null;
            }
            password = controller.getPassword();
        }

        return password;
    }

    private void saveToAction() {
        logger.info("saveToAction() entering ...");
        Path path = getSelectedPath();
        if (path == null) {
            return;
        }

        try {
            logger.info("saveToAction() entering ...");
            //label.setText("Hello World!");
            Path file = IoUtil.browseFile(IoUtil.ALL, false, Resources.getMessage("saveTo"));

            if (file == null) {
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("msg.noDestDir"),
                        Resources.getMessage("saveTo"));

                return;
            }

            Files.copy(path, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.COPY_ATTRIBUTES);
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Move file failed:\n{0}", ex.getMessage());
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.failedSaveFile"),
                    Resources.getMessage("title.saveFailed"));
        }
    }

    private void moveToAction() {
        logger.info("moveToAction() entering ...");
        Path oldFile = getSelectedPath();
        if (oldFile == null) {
            return;
        }

        Path tmpFile = null;
        try {
            tmpFile = IoUtil.browseDirPath(Resources.getMessage("moveTo"));
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Move file failed:\n{0}", ex.getMessage());
            tmpFile = null;
        }

        if (tmpFile == null) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.noDestDir"),
                    Resources.getMessage("moveTo"));

            return;
        }
        Path opath = oldFile.getFileName();
        Path newFile = tmpFile.resolve(opath);

        try {
            Files.move(oldFile, newFile, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Move file failed:\n{0}", ex.getMessage());
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.cannotAccessUsedFile"),
                    Resources.getMessage("title.moveFailed"));
        }
    }

    private void duplicateAction() {
        logger.info("duplicateAction() entering ...");
        Path oldFile = getSelectedPath();
        if (oldFile == null) {
            return;
        }

        String newStr = oldFile.toString();
        String ext = IoUtil.getFileExtension(newStr);
        newStr = IoUtil.getFilenameWithoutExtension(newStr) + "_(copy)." + ext;
        Path newFile = Paths.get(newStr);

        try {
            Files.copy(oldFile, newFile, StandardCopyOption.COPY_ATTRIBUTES);
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Duplicate file failed:\n{0}", ex.getMessage());
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.cannotAccessUsedFile"),
                    Resources.getMessage("title.duplicateFailed"));
        }
    }

    private void renameAction() {
        logger.info("renameAction() entering ...");
        try {
            Path oldFile = getSelectedPath();
            if (oldFile == null) {
                return;
            }

            Path oldName = oldFile.getFileName();
            String newName = getNewFilename("New File Name", oldName.toString());
            if (newName.trim().isEmpty()) {
                return;
            }
            Path newFile = oldFile.resolveSibling(newName);

            Files.move(oldFile, newFile, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Rename file failed:\n{0}", ex.getMessage());
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.cannotAccessUsedFile"),
                    Resources.getMessage("title.renameFailed"));
        }
    }

    private void emailAction() {
        Path selectedFile = getSelectedPath();
        if (selectedFile == null) {
            return;
        }

        if (Files.isDirectory(selectedFile, LinkOption.NOFOLLOW_LINKS)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.cannotSendDir"),
                    Resources.getMessage("email"));
            return;
        }

        try {
            Stage stage = GuiUtil.getStage(EmailEntryController.class, EmailEntryController.FXML, true);
            if (stage == null) {
                return;
            }
            stage.setTitle(Resources.getMessage("email"));

            EmailEntryController controller = GuiUtil.getController(EmailEntryController.class, EmailEntryController.FXML, true);
            if (controller == null) {
                return;
            }

            controller.updateEmails();
            controller.setDialogStage(stage);
            controller.setAttachPath(selectedFile);
            controller.show();
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "The controller is not available.{0}", ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void settingsAction() {
        try {
            Stage stage = GuiUtil.getStage(SettingsController.class, SettingsController.FXML, true);
            if (stage == null) {
                return;
            }
            stage.setTitle(Resources.getMessage("settings"));

            SettingsController controller = GuiUtil.getController(SettingsController.class, SettingsController.FXML, true);
            if (controller == null) {
                return;
            }

            controller.reset();
            controller.setDialogStage(stage);
            controller.setButtonsVisible(true);
            controller.show();
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "The controller is not available.{0}", ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void deleteAction() {
        logger.info("deleteAction() entering ...");
        Path oldFile = getSelectedPath();
        if (oldFile == null) {
            return;
        }

        try {
            Files.deleteIfExists(oldFile);
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Delete file failed:\n{0}", ex.getMessage());
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.cannotAccessUsedFile"),
                    Resources.getMessage("title.deleteFailed"));
        }
    }

    private PasswordDialogController getPasswordController() {
        try {
            Stage stage = GuiUtil.getStage(PasswordDialogController.class, PasswordDialogController.FXML, true);
            stage.setTitle(Resources.getMessage("password"));

            PasswordDialogController controller = GuiUtil.getController(PasswordDialogController.class, PasswordDialogController.FXML, true);
            controller.setDialogStage(stage);
            controller.setCanceled(false);
            return controller;

        } catch (IOException ex) {
            ex.printStackTrace();
            logger.log(Level.SEVERE, "Failed to create password dialog: {0}", ex.getMessage());
            return null;
        }
    }

    private String getNewFilename(String title, String suggested) {
        String newName = "";
        try {
            Stage stage = GuiUtil.getStage(InputDialogController.class, InputDialogController.FXML, true);
            if (stage == null) {
                return "";
            }
            stage.setTitle(title);

            InputDialogController controller = GuiUtil.getController(InputDialogController.class, InputDialogController.FXML, true);
            if (controller == null) {
                return "";
            }
            controller.reset();
            controller.setDialogStage(stage);
            controller.setPrompt(title);
            controller.setInput(suggested);
            newName = controller.show();

            while (newName.trim().isEmpty()) {
                if (controller.isCanceled()) {
                    break;
                } else {
                    newName = controller.show();
                }
            }
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "InputDialogController is not avalable:\n{0}", ex.getMessage());
        }

        return newName;
    }

    private void showWithPDFRenderer(String filename) {
        try {
            PdfViewPane pane = PdfViewPane.instance(innerBorderPane);
            outerBorderPane.setCenter(pane);
            pane.openFile(filename);
            currentViewMode = ViewMode.DOCVIEW;
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "{0} is not accessible:\n{1}", new Object[]{filename, ex.getMessage()});
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.fileNotAccessible"),
                    Resources.getMessage("title.openFailed"));
            toDirView();
        } catch (IllegalArgumentException ex) {
            logger.log(Level.SEVERE, "{0} may be corrupted:\n{1}", new Object[]{filename, ex.getMessage()});
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.fileCorrupted"),
                    Resources.getMessage("title.openFailed"));
            toDirView();
        }
    }

    private void showDoc(String filename) {
        try {
            EmbeddedPane pane = EmbeddedPane.istance();
            outerBorderPane.setCenter(pane);
            pane.openFile(filename);
            currentViewMode = ViewMode.DOCVIEW;
        } catch (Exception ex) {
            ex.printStackTrace();
            String title = Resources.getMessage("title.openFailed");
            String msg = "'" + filename + "': \n" + ex.getMessage();
            logger.log(Level.SEVERE, title + " " + msg);
            FXOptionPane.showMessageDialog(ReaderMain.getStage(), msg, title);
            toDirView();
        }
    }

    public void showEmbeddedDoc(ViewMode vmode, String filename) {
        logger.info("showEmbeddedDoc, entering ..., vmode = " + vmode.name() + ", filename = " + filename + ", currentViewMode = " + currentViewMode);
        switch (vmode) {
            case DOCVIEW:
                logger.info("showEmbeddedDoc, case DOCVIEW");
                String extStr = IoUtil.getFileExtension(filename);
                Extension ext = Extension.type(extStr);
                if (ext == null) {
                    logger.info("showEmbeddedDoc, case DOCVIEW, ext is null");
                    return;
                }

                logger.info("showEmbeddedDoc, case DOCVIEW, ext = " + ext);
                if (Extension.PDF == ext && OperatingSystem.MAC != OperatingSystem.currentOs()) {
                    showWithPDFRenderer(filename);
                    //showDoc(filename);
                } else {
                    showDoc(filename);
                }

                break;

            default:
                logger.info("showEmbeddedDoc, case default");
                toDirView();
                break;

        }
    }

    private void toDirView() {
        logger.info("toDirView, entering ..., currentViewMode = " + currentViewMode);
        outerBorderPane.setCenter(innerBorderPane);
        currentViewMode = ViewMode.FILESYSTEM;
    }

    private void initializeFilters() {
        //allFile = new FileChooser.ExtensionFilter("All Files", "*.*");
        //idsFile = new FileChooser.ExtensionFilter("Encrypted Files", "*.ids");

        allFilter = new DirectoryStream.Filter<Path>() {
            @Override
            public boolean accept(Path entry) throws IOException {
                return true;
            }
        };

        docFilter = new DirectoryStream.Filter<Path>() {
            @Override
            public boolean accept(Path entry) throws IOException {
                String pathStr = entry.toString();
                return Files.isRegularFile(entry, LinkOption.NOFOLLOW_LINKS) && !pathStr.toLowerCase().endsWith(Crypto.ENC_EXT.ext());
            }
        };

        folderFilter = new DirectoryStream.Filter<Path>() {
            @Override
            public boolean accept(Path entry) throws IOException {
                return Files.isDirectory(entry, LinkOption.NOFOLLOW_LINKS);
            }
        };

        encryptedFilter = new DirectoryStream.Filter<Path>() {
            @Override
            public boolean accept(Path entry) throws IOException {
                String pathStr = entry.toString();
                return pathStr.toLowerCase().endsWith(Crypto.ENC_EXT.ext());
            }
        };
        currentFilter = allFilter;
    }

    public enum ViewMode {

        DOCVIEW("docview"), FILESYSTEM("filesystem"), ZIPVIEW("zipview");

        private final String label;

        ViewMode(String name) {
            this.label = name;
        }

        public String label() {
            return label;
        }

        static public ViewMode getType(String typeStr) {
            if (typeStr == null || typeStr.trim().isEmpty()) {
                return null;
            }
            typeStr = typeStr.trim();

            return Enum.valueOf(ViewMode.class, typeStr.toUpperCase());
        }

    }
}
