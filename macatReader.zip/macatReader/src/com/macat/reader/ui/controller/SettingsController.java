/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.macat.reader.ui.controller;

import com.macat.reader.Context;
import com.macat.reader.ReaderMain;
import com.macat.reader.constants.EmailType;
import com.macat.reader.domain.EmailAccounts;
import com.macat.reader.domain.SettingsInfo;
import com.macat.reader.util.FXOptionPane;
import com.macat.reader.util.IoUtil;
import com.macat.reader.util.Util;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.prefs.BackingStoreException;
import java.util.prefs.InvalidPreferencesFormatException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import resources.Resources;

/**
 * FXML Controller class
 *
 * @author martin.tan
 */
public class SettingsController implements Initializable {
    public static final String FXML = "/com/macat/reader/ui/fxml/Settings.fxml";

    @FXML
    private Button addBtn;
    @FXML
    private Button closeBtn;
    @FXML
    private Button exportBtn;
    @FXML
    private Button importBtn;
    @FXML
    private Button changePasswordBtn;
    @FXML
    private Button deleteBtn;
    @FXML
    private TextField emailFld;
    @FXML
    private PasswordField passwordFld;
    @FXML
    private ChoiceBox<String> emailTypeChoice;
    @FXML
    private TabPane settingsTabPane;
    @FXML
    private BorderPane managerBorderPane;

    @FXML
    private Label manageAccountLb;
    @FXML
    private Label emailAccountLb;
    @FXML
    private Label passwordLb;
    @FXML
    private Label emailTypeLb;
    
    @FXML
    private TableView<SettingsInfo> emailTv;
    private TableColumn<SettingsInfo, String> emailCol;
    private TableColumn<SettingsInfo, PasswordField> passwordCol;
    private TableColumn<SettingsInfo, String> typeCol;
    private ObservableList<SettingsInfo> emailinfoData = FXCollections.observableArrayList();

    private Stage dialogStage;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeUI();
    }

    private void initializeUI() {
        ObservableList<String> emailTypeItems = FXCollections.observableArrayList(
                EmailType.GMAIL.label(),
                EmailType.EXCHANGE.label(),
                EmailType.HOTMAIL.label(),
                EmailType.YAHOO.label()
        );
        addBtn.setText(Resources.getMessage("add"));
        closeBtn.setText(Resources.getMessage("close"));
        exportBtn.setText(Resources.getMessage("export"));
        importBtn.setText(Resources.getMessage("import"));
        changePasswordBtn.setText(Resources.getMessage("changePassword"));
        deleteBtn.setText(Resources.getMessage("delete"));

        manageAccountLb.setText(Resources.getMessage("manageAccount"));
        emailAccountLb.setText(Resources.getMessage("emailAccount"));
        passwordLb.setText(Resources.getMessage("password"));
        emailTypeLb.setText(Resources.getMessage("emailType"));

        emailTypeChoice.setItems(emailTypeItems);
        emailTypeChoice.getSelectionModel().selectFirst();

        emailTv = createTable();
        managerBorderPane.setCenter(emailTv);
    }

    public void setDialogStage(Stage stage) {
        this.dialogStage = stage;
    }

    @FXML
    private void addAction() {
        String email = emailFld.getText();
        String password = passwordFld.getText();
        String typestr = emailTypeChoice.getSelectionModel().getSelectedItem();
        //EmailType type = EmailType.getType(typestr);

        if (!validateInput(email, password)) {
            return;
        }

        Context.emailPref.addAccount(email, password, typestr);

        FXOptionPane.showMessageDialog(
                ReaderMain.getStage(),
                Resources.getMessage("succeedToAddAccount"),
                Resources.getMessage("settings"));

        SettingsInfo sinfo = getSettingsInfo();
        emailinfoData.add(sinfo);
        reset();
    }

    private SettingsInfo getSettingsInfo() {
        String email = emailFld.getText();
        String password = passwordFld.getText();
        String typestr = emailTypeChoice.getSelectionModel().getSelectedItem();

        SettingsInfo sinfo = new SettingsInfo();
        sinfo.setEmail(email);

        PasswordField pass = new PasswordField();
        pass.setBorder(Border.EMPTY);
        pass.setEditable(true);
        pass.setText(password);
        sinfo.setPassword(pass);

        sinfo.setEmailType(typestr);

        return sinfo;
    }

    @FXML
    private void editAction() {
        String txt = changePasswordBtn.getText();
        if (txt.equalsIgnoreCase(Resources.getMessage("changePassword"))) {
            //passwordCol.setVisible(true);
            //editBtn.setText(Resources.getMessage("savePassword"));
            setButtonsVisible(false);
        }
        else if (txt.equalsIgnoreCase(Resources.getMessage("savePassword"))) {
            //passwordCol.setVisible(false);
            //editBtn.setText(Resources.getMessage("changePassword"));
            saveTabelData();
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("passwordSaved"),
                    Resources.getMessage("changePassword"));
            setButtonsVisible(true);
        }
        
    }
    
    public void setButtonsVisible(boolean visible) {
        //closeBtn.setVisible(visible);
        exportBtn.setVisible(visible);
        importBtn.setVisible(visible);
        deleteBtn.setVisible(visible);
        passwordCol.setVisible(!visible);
        
        if (visible) {
            changePasswordBtn.setText(Resources.getMessage("changePassword"));
            closeBtn.setText(Resources.getMessage("close"));
        }
        else {
            changePasswordBtn.setText(Resources.getMessage("savePassword"));
            closeBtn.setText(Resources.getMessage("cancel"));
        }
    }

    @FXML
    private void exportAction() {
        try {
            Path file = IoUtil.browseFile(IoUtil.XML, false,  Resources.getMessage("exportPreferences"));
            Context.emailPref.exportxml(file.toString());
        } catch (IOException | BackingStoreException ex) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("failToExportPreferences"),
                    Resources.getMessage("exportPreferences"));
        }
    }
 
    @FXML
    private void importAction() {
        try {
            Path file = IoUtil.browseFile(IoUtil.XML, true, Resources.getMessage("importPreferences"));
            Context.emailPref.importxml(file.toString());
        } catch (IOException ex) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("importFileNotExist"),
                    Resources.getMessage("importPreferences"));
        } catch (InvalidPreferencesFormatException ex) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("importFileNotValid"),
                    Resources.getMessage("importPreferences"));
        }

        updateTabelData();
    }
    
    @FXML
    private void closeAction() {
        dialogStage.close();
    }
    
    @FXML
    private void deleteAction() {
        SettingsInfo sinfo = getSelectedEmail();
        if (sinfo == null) {
            return;
        }

        emailinfoData.remove(sinfo);
        try {
            Context.emailPref.deleteUser(sinfo.getEmail());
        } catch (BackingStoreException ex) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("deletionError"),
                    Resources.getMessage("deleteAccount"));
        }
    }
    
    public void reset() {
        emailFld.setText("");
        passwordFld.setText("");
        emailTypeChoice.getSelectionModel().selectFirst();
    }

    public void show() {
        //Window win = dialogStage.getOwner();
        Stage win = ReaderMain.getStage();
        Scene scene = win.getScene();
        //Point2D popupPoint = this.localToScene(0.0, 0.0);
        double w = win.getWidth();
        double h = win.getHeight();
        double w1 = settingsTabPane.getPrefWidth();
        double h1 = settingsTabPane.getPrefHeight();
        double x = scene.getWindow().getX() + scene.getX() + w / 2 - w1 / 2;
        double y = scene.getWindow().getY() + scene.getY() + h / 2 - h1 / 2;

        dialogStage.setX(x);
        dialogStage.setY(y);
        dialogStage.showAndWait();
    }

    private boolean validateInput(String email, String password) {
        if (email == null || email.trim().equals("")) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("enterUsername"),
                    Resources.getMessage("validateInput"));
            return false;
        }

        if (!Util.validateEmail(email)) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("invalidEmail"),
                    Resources.getMessage("validateInput"));
            return false;
        }

        if (passwordFld.getText() == null || passwordFld.getText().trim().equals("")) {
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("enterPassword"),
                     Resources.getMessage("validateInput"));
            return false;
        }

        return true;
    }

    private TableView<SettingsInfo> createTable() {
        TableView<SettingsInfo> fTable = new TableView<>();
        fTable.getStylesheets().add(Resources.getStylesheet());
        //fTable.getSelectionModel().

        //fTable.setId("my-table");
        double colwidth = 80;

        emailCol = new TableColumn<>(Resources.getMessage("email"));
        emailCol.setCellValueFactory(new PropertyValueFactory<SettingsInfo,String>("email"));
        emailCol.setMinWidth(colwidth * 4);

        passwordCol = new TableColumn<SettingsInfo, PasswordField>(Resources.getMessage("password"));
        passwordCol.setCellValueFactory(new PropertyValueFactory<SettingsInfo, PasswordField>("password"));
        passwordCol.setMinWidth(colwidth);

        typeCol = new TableColumn<>(Resources.getMessage("emailType"));
        typeCol.setCellValueFactory(new PropertyValueFactory<SettingsInfo, String>("emailType"));
        typeCol.setMinWidth(colwidth);

        updateTabelData();

        fTable.setItems(emailinfoData);
        //contactTable.getColumns().addAll(nameCol, cryptCol, createTimeCol, updateTimeCol, sizeCol, typeCol);
        fTable.getColumns().addAll(emailCol, typeCol, passwordCol);
        passwordCol.setVisible(false);

        fTable.setPrefHeight(400);
        fTable.setTableMenuButtonVisible(true);
        fTable.setEditable(true);

        return fTable;
    }
/*
    private void setEditAllMode(boolean editall) {
        controlHbox.getChildren().removeAll(controlHbox.getChildren());
        if (editall) {
            controlHbox.getChildren().addAll(addPasswordHbox, new Label("           "), addAllLabel, cancelLabel);
        } else {
            controlHbox.getChildren().addAll(addLabel, editLabel, editAllLabel, deleteLabel); //, exportLabel, importLabel);
        }

        passwordCol.setVisible(editall);
        nicknameCol.setEditable(editall);
        firstnameCol.setEditable(editall);
        lastnameCol.setEditable(editall);
        //emailCol.setEditable(editall);
        passwordCol.setEditable(editall);
    }
*/
    public void updateTabelData() {
        String[] emailArray = Context.emailPref.getEmails();
        if (emailArray == null) {
            return;
        }

        EmailAccounts account;
        SettingsInfo sinfo;
        emailinfoData.clear();

        for (String email : emailArray) {
            account = Context.emailPref.getEmailAccount(email);
            if (account == null) {
                continue;
            }

            sinfo = new SettingsInfo();
            sinfo.setEmail(email);

            PasswordField pass = new PasswordField();
            pass.setBorder(Border.EMPTY);
            pass.setEditable(true);
            pass.setText(account.getPassword());
            sinfo.setPassword(pass);

            sinfo.setEmailType(account.getMailType().label());
            emailinfoData.add(sinfo);
        }
    }

    public void saveTabelData() {
        for (SettingsInfo emailinfo : emailinfoData) {
            if (emailinfo == null) {
                continue;
            }

            try {
                Context.emailPref.updateAccount(emailinfo);
            } catch (BackingStoreException ex) {
                Logger.getLogger(SettingsController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private SettingsInfo getSelectedEmail() {
        SettingsInfo settingsInfo = emailTv.getSelectionModel().getSelectedItem();
        if (settingsInfo == null) {
            FXOptionPane.showMessageDialog(
                ReaderMain.getStage(),
                Resources.getMessage("noItemSelected"), 
                Resources.getMessage("settings"));
            return null;
        }

        return settingsInfo;
    }
}
