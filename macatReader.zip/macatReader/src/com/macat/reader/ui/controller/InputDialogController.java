/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.macat.reader.ui.controller;

import com.macat.reader.ReaderMain;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author martin.tan
 */
public class InputDialogController implements Initializable {
    public static final String FXML = "/com/macat/reader/ui/fxml/InputDialog.fxml";

    @FXML
    private AnchorPane inputAnchorPane;
    @FXML
    private Label promptLabel;
    @FXML
    private TextField inputFld;
    @FXML
    private Button cancelBtn;
    @FXML
    private Button okBtn;
    
    private Stage dialogStage;
    private String inputStr;
    private boolean cancelstatus = false;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void okAction() {
        inputStr = getInput();
        if (!inputStr.isEmpty()) {
            cancelstatus = false;
            dialogStage.close();
        }
    }
    
    @FXML
    private void cancelAction() {
        inputStr = "";
        cancelstatus = true;
        dialogStage.close();
    }
    
    public void setDialogStage(Stage stage) {
        this.dialogStage = stage;
    }

    private String getInput() {
        inputStr = inputFld.getText().trim();
        return inputStr;
    }

    public boolean isCanceled() {
        return cancelstatus;
    }

    //public void setCanceled(boolean canceled) {
    //    cancelstatus = canceled;
    //}
    public void reset() {
        cancelstatus = false;
        inputStr = "";
        inputFld.setText("");
        
    }

    public String show() {
        //Window win = dialogStage.getOwner();
        Stage win = ReaderMain.getStage();
        Scene scene = win.getScene();
        //Point2D popupPoint = this.localToScene(0.0, 0.0);
        double w = win.getWidth();
        double h = win.getHeight();
        double w1 = inputAnchorPane.getPrefWidth();
        double h1 = inputAnchorPane.getPrefHeight();
        double x = scene.getWindow().getX() + scene.getX() + w / 2 - w1 / 2;
        double y = scene.getWindow().getY() + scene.getY() + h / 2 - h1 / 2;

        dialogStage.setX(x);
        dialogStage.setY(y);
        dialogStage.showAndWait();
        return inputStr;
    }

    public void close() {
        dialogStage.close();
    }

    public void setPrompt(String text) {
        promptLabel.setText(text);
    }

    public void setInput(String text) {
        inputFld.setText(text);
    }
}
