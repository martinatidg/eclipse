/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.macat.reader;

/**
 *
 * @author IDG
 */
import java.io.File;
import javafx.application.Application;
import javafx.application.HostServices;
//import javafx.<span class="stw_link" id="qwiklinxid0" onmouseover="jprshowAd('event' ,event);" onclick="jprclickAd('event' ,event);" name="jpstw1">event</span>.ActionEvent;
//import javafx.<span class="stw_link" id="qwiklinxid1" onmouseover="jprshowAd('event' ,event);" onclick="jprclickAd('event' ,event);" name="jpstw1">event</span>.EventHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
 
/**
 * @web http://java-buddy.blogspot.com/
 */
public class JavaFX_Pdf extends Application {
     
    @Override
    public void start(final Stage primaryStage) {
        Button btn = new Button();
        btn.setText("Load PDF");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FileChooser fileChooser = new FileChooser();
                  
                //Set extension filter
                FileChooser.ExtensionFilter extFilter = 
                        new FileChooser.ExtensionFilter("PDF files (*.pdf)", "*.pdf");
                fileChooser.getExtensionFilters().add(extFilter);
                File file = fileChooser.showOpenDialog(primaryStage);
                //Show open file dialog
                //<span class="stw_link" id="qwiklinxid2" onmouseover="jprshowAd('File' ,event);" onclick="jprclickAd('File' ,event);" name="jpstw1">File</span> <span class="stw_link" id="qwiklinxid3" onmouseover="jprshowAd('file' ,event);" onclick="jprclickAd('file' ,event);" name="jpstw1">file</span> = fileChooser.showOpenDialog(primaryStage);
 
                HostServices hostServices = getHostServices();
                hostServices.showDocument(file.getAbsolutePath());
            }
        });
         
        StackPane root = new StackPane();
        root.getChildren().add(btn);
         
        Scene scene = new Scene(root, 300, 250);
         
        primaryStage.setTitle("java-buddy.blogspot.com");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
 
    public static void main(String[] args) {
        launch(args);
    }
}
