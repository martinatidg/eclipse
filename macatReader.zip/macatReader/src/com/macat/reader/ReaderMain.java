/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.macat.reader;

import com.macat.reader.constants.Dir;
import com.macat.reader.ui.GuiUtil;
import com.macat.reader.ui.controller.MainUIController;
import com.macat.reader.ui.embed.EmbeddedPane;
import com.macat.reader.util.IdgLog;
import com.macat.reader.util.IoUtil;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.stage.Stage;
import resources.Resources;

/**
 *
 * @author IDG
 */
public class ReaderMain extends Application {
    private static Logger logger = IdgLog.getLogger();
    public static ReaderMain readerMain;
    static private Stage mainStage;
    private double WIDTH = 1300.0;
    private double HEIGHT = 800.0;

    @Override
    public void start(Stage stage) throws Exception {
        //mainStage = stage;
        readerMain = this;
        initializeFolder();

        mainStage = MainUIController.stage();
        mainStage.setResizable(true);
        mainStage.getIcons().add(Resources.getImage("macate.icon"));
        mainStage.setWidth(WIDTH);
        mainStage.setHeight(HEIGHT);
        mainStage.setMinWidth(WIDTH);
        mainStage.setMinHeight(HEIGHT);

        setStageListener();
        mainStage.show();
        setMediaSize();
    }

    static public Stage getStage() {
        return mainStage;
    }

    static public ReaderMain instance() {
        return readerMain;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public HostServices getHostService() {
        return getHostServices();
    }

    private void initializeFolder() {
        Path path = Paths.get(Dir.MACATEHOME.dir());

        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            try {
                Files.createDirectories(path);
            } catch (IOException ex) {
                logger.info("Failed to create the Macat home directory.");
            }
        }

        path = Paths.get(Dir.MACATELOG.dir());
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            try {
                Files.createDirectories(path);
            } catch (IOException ex) {
                logger.info("Failed to create the Macat log directory.");
            }
        }

        Path tmppath = Paths.get(Dir.MACATETMP.dir());
        System.out.println("tmppath 1: " + tmppath.toString());
        if (Files.exists(tmppath, LinkOption.NOFOLLOW_LINKS)) {
            try {
                IoUtil.deleteDir(tmppath);
            } catch (IOException ex) {
                Logger.getLogger(ReaderMain.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        try {
            Files.createDirectories(tmppath);
        } catch (IOException ex) {
            logger.info("Failed to create the Macat tmp directory.");
        }

        try {
            tmppath = Files.createTempDirectory(tmppath, null);
            System.out.println("tmppath 2: " + tmppath.toString());
        } catch (IOException ex) {
            Logger.getLogger(ReaderMain.class.getName()).log(Level.SEVERE, null, ex);
        }

        Context.setTempPath(tmppath);

        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                logger.info("Deleting the temorary folder ...");
                try { //(DirectoryStream<Path> ds = Files.newDirectoryStream(Context.getTempPath())) {
                    //for (Path file : ds) {
                    //    Files.delete(file);
                    //}
                    //Files.deleteIfExists(Context.getTempPath());
                    IoUtil.deleteDir(Context.getTempPath());
                } catch (IOException ex) {
                    ex.printStackTrace();
                    logger.info("Deleting the temorary folder ...");
                }
            }
        });
    }

    private void setStageListener() throws IOException {
        MainUIController controller = GuiUtil.getController(MainUIController.class, MainUIController.FXML);
        ChangeListener changelistener = new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number oldSceneWidth, Number newSceneWidth) {
                logger.info("stage side changed from " + oldSceneWidth + " to " + newSceneWidth);

                try {
                    setMediaSize();
                } catch (IOException ex) {
                    Logger.getLogger(ReaderMain.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };

        //Stage stage = ReaderMain.getStage();
        mainStage.widthProperty().addListener(changelistener);
        mainStage.heightProperty().addListener(changelistener);

        mainStage.maximizedProperty().addListener(new ChangeListener<Boolean>() {

            @Override
            public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {
                System.out.println("stage maximized: from " + t.booleanValue() + " to " + t1.booleanValue());
                //mainStage.widthProperty().getValue();
                try {
                    setMediaSize();
                    //controller.updateFile();
                } catch (IOException ex) {
                    Logger.getLogger(ReaderMain.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    public void setMediaSize() throws IOException {
        MainUIController controller = GuiUtil.getController(MainUIController.class, MainUIController.FXML);
        controller.setOuterBoxSize();

        EmbeddedPane ep = EmbeddedPane.istance();
        ep.setMediaSize();
        controller.updateFile();
    }
}
