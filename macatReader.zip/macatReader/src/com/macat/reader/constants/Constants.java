package com.macat.reader.constants;

import javafx.scene.paint.Color;

public class Constants {
    public static final Long DAY_MILLI = 24 * 3600 * 1000L;
    public static final Long SECONDS_TO_SLEEP = 30l;
    public static final String US_EXPORT_POLICY = "US_export_policy.jar";
    public static final String LOCAL_POLICY = "local_policy.jar";

    public static final String DATE_PATTERN = "yyyy-MM-dd";
    public static final String DATETIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_US_PATTERN = "MM/dd/yyyy";
    public static final String DATENAME_PATTERN = "EEE MMM dd HH:mm:ss z yyyy";

    public static final String GAL_URL = "https://mail.isaacdanielgroup.com/ews/Exchange.asmx";
    public static final String GMAIL_CONTACT_URL = "https://www.google.com/m8/feeds/contacts/default/full";

    public static final Color TEXT_COLOR = Color.web("#005577");
    public static final int LABEL_SIZE = 40;

    public static double TITLEBAR_HEIGHT = 38;
    public static double MENUBAR_HEIGHT = 45;
    public static double STAGE_PADDING = 20;
}
