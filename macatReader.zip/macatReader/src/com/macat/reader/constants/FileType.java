package com.macat.reader.constants;

public enum FileType {

    FOLDER("Folder"), REGULAR("Regular"), ENCRYPTED("Encrypted"), ZIP("zip");


    private final String label;

    FileType(String name) {
        this.label = name;
    }

    public String label() {
        return label;
    }

    static public FileType getType(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        typeStr = typeStr.trim();

        return Enum.valueOf(FileType.class, typeStr.toUpperCase());
    }

}
