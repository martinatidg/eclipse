package com.macat.reader.constants;

public enum Paging {

    NEXT("Next"), PREVIOUS("Previous"), FIRST("First"), LAST("Last"), GO("Go to Page");

    private final String name;
    private final String label;

    Paging(String name) {
        this.label = name;
        this.name = name.toLowerCase();
    }

    @Override
    public String toString() {
        return name;
    }

    public String label() {
        return label;
    }

    static public Paging getType(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        typeStr = typeStr.trim();

        return Enum.valueOf(Paging.class, typeStr.toUpperCase());
    }

}
