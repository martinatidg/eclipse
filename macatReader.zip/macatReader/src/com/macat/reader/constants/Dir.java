package com.macat.reader.constants;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author cc.martin.tan
 *
 */
public enum Dir {
    SEP (File.separator),
    HOME(System.getProperty("user.home")),
    SYSTMP(System.getProperty("java.io.tmpdir")),
    APP("MACATE"),
    OS(System.getProperty("os.name")),
    MAC(HOME + SEP.dir + "Library" + SEP.dir + "Application Support" + SEP.dir + APP),
    WINDOWS(HOME + SEP.dir + "AppData" + SEP.dir + "Local" + SEP.dir + APP),

    MACATEHOME(OS.dir.toLowerCase().contains("mac") ? MAC.dir : WINDOWS.dir),
    DOWNLOAD(HOME + SEP.dir + "Downloads"),
    DOCUMENT(HOME + SEP.dir +  "Documents"),
    MACATELOG(MACATEHOME + SEP.dir +  "log"),
    MACATETMP(MACATEHOME + SEP.dir +  "tmp"),
    MACATECRYPT(MACATETMP + SEP.dir + "crypt"),
    MACATEZIP(MACATETMP + SEP.dir + "zip"),
    TEST(MACATEHOME + SEP.dir +  "test"),
    ;

    private final String dir;
    private Path path = null;

    private Dir(String dir) {
        this.dir = dir;
        //path = Paths.get(dir);
    }

    public String dir() {
        return dir;
    }
    
    public Path path() {
        if (path == null) {
            path = Paths.get(dir);
        }
        return path;
    }
    
    public boolean equals(String other) {
        return dir.equalsIgnoreCase(other.trim());
    }

    public boolean contains(String str) {
        return dir.toLowerCase().contains(str.trim().toLowerCase());
    }

    @Override
    public String toString() {
        return dir;
    }
}
