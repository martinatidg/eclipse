package com.macat.reader.constants;

public enum OperatingSystem {

    MAC("Mac"), WINDOWS("Windows"), LINUX("Unix"), UNIX("Unix"), UNKNOWN("Unknown");
    private String operatingSystem = "";

    private OperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public String getOperatingSystem() {
        return this.operatingSystem;
    }
    
    static public OperatingSystem currentOs() {
        String os = System.getProperty("os.name");
        if (os == null) {
            return UNKNOWN;
        }

        os = os.trim().toLowerCase();

       if (os.contains("mac")) {
           return OperatingSystem.MAC;
       }
       else if (os.contains("windows")) {
        return WINDOWS;
       }
       else if (os.contains("linux")) {
           return LINUX;
       }
       else if (os.contains("unix")) {
           return UNIX;
       }
       else {
           return UNKNOWN;
       }
    }
}
