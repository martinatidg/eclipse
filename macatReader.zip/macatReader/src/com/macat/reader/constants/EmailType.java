/**
 *
 */
package com.macat.reader.constants;

/**
 * @author cc.martin.tan
 *
 */
public enum EmailType {

    GMAIL("Gmail", ".com", "imap.gmail.com", "smtp.gmail.com", "imaps", "587"),
    YAHOO("Yahoo", ".com", "imap.mail.yahoo.com", "smtp.mail.yahoo.com", "imaps", "465"),
    HOTMAIL("Hotmail", ".com", "pop3.live.com", "smtp.live.com", "pop3s", "587"),
    VOISCMAIL("Voiscmail", ".com", "voiscmail.com", "voiscmail.com", "pop3", "110"),
    EXCHANGE("Exchange", ".com", "mail.isaacdaniel.com", "mail.isaacdaniel.com", "", "110", "ffhc"),
    IMAP("IMAP", ".com"),
    POP3("POP3", ".com"),
    OTHER("Other", ".com"),
    SELECT("Email Type", "");

    private final String name;
    private final String tld;
    private final String label;
    private final String mailserver;
    private final String smtpserver;
    private final String protocol;
    private final String port;
    private final String domain;

    EmailType(String name) {
        this(name, "");
    }

    EmailType(String name, String tld) {
        this(name, tld, "", "", "", "");
    }

    EmailType(String name, String tld, String mailserver, String smtpserver, String protocol, String port) {
        this(name, tld,mailserver, smtpserver, protocol, port, "");
    }

    EmailType(String name, String tld, String mailserver, String smtpserver, String protocol, String port, String domain) {
        this.label = name;
        this.name = name.toLowerCase();
        this.tld = tld;
        this.mailserver = mailserver;
        this.smtpserver = smtpserver;
        this.protocol = protocol;
        this.port = port;
        this.domain = domain;
    }

    @Override
    public String toString() {
        return name();
    }

    public String label() {
        return label;
    }

    public String domain() {
        //return name + tld;
        return domain;
    }

    public String mailServer() {
        return mailserver;
    }

    public String smtpServer() {
        return smtpserver;
    }

    public String protocol() {
        return protocol;
    }

    public String port() {
        return port;
    }

    //public String domain() {
    //    return port;
    //}

    static public EmailType getType(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        typeStr = typeStr.trim();

        return Enum.valueOf(EmailType.class, typeStr.toUpperCase());
    }
}
