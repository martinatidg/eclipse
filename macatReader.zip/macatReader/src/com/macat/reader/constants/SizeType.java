package com.macat.reader.constants;

public enum SizeType {

    ORIGINAL("Original"), FITIN("FitIn");


    private final String label;

    SizeType(String name) {
        this.label = name;
    }

    public String label() {
        return label;
    }

    static public SizeType getType(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        typeStr = typeStr.trim();

        return Enum.valueOf(SizeType.class, typeStr.toUpperCase());
    }

}
