package com.macat.reader.constants;

public enum ActOption {
    PRINT("Print"), EMAIL("Email"), ENCRYPT("Encrypt"), DECRYPT("Decrypt"), SAVE_TO("Save To"), SETTINGS("Settings"),
    DOC_VIEW("Doc View"), MY_FOLDERS("My Folders"),
    GO_BACK("Go Back"), LIST_VIEW("List View"), FOLDER_VIEW("Folder View"), ZIP("zip"), UNZIP("unzip"),
    DELETE_FOLDER("Delete Folder"), NEW_FOLDER("New Folder"), OPEN_FOLDER("Open Folder"), OPEN_DOC("Open Document"),// OPEN_ZIP("Open Zip File"),
    MOVE_TO("Move To"), DUPLICATE("Duplicate"), RENAME("Rename"), DELETE("Delete"),
    FILE_FILTER("File Filter");

    private final String name;
    private final String label;

    ActOption(String name) {
        this.label = name;
        this.name = name.toLowerCase();
    }

    @Override
    public String toString() {
        return name;
    }

    public String label() {
        return label;
    }

    static public ActOption getType(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        typeStr = typeStr.trim();

        return Enum.valueOf(ActOption.class, typeStr.toUpperCase());
    }

}
