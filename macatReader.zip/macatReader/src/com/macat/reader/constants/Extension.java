package com.macat.reader.constants;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum Extension {
    // General/text
    XML("xml"), HTML("html"), HTM("htm"), TXT("txt"), TEXT("TEXT"), RTF("rtf"), CSV("csv"),
    // Microsoft Offices
    DOC("doc"), DOCX("docx"), DOCM("docm"), DOT("dot"), DOTX("dotx"), DOTM("dotm"),
    // Spreadsheets
    XLS("xls"), XLSX("xlsx"), XLW("xlw"), XLT("xlt"),
    XLSM("xlsm"), XLTX("xltx"), XLTM("xltm"), XLSB("xlsb"), WK1("wk1"), WKS("wks"),
    DBF("dbf"), SLK("slk"), UOS("uos"), PXL("pxl"), WB2("wb2"),
    //presentations
    PPT("ppt"), PPTX("pptx"), PPS("pps"), POT("pot"), PPTM, POTX, POTM, SDA, SDD, SDP,
    VISIO("cisio"),
    //WordPerfect
    WPD("wpd"),
    // WPS 2000/Office 1.0
    WPS("wps"),
    // StarWriter
    SDW("sdw"), SGL("sgl"), VOR("vor"),
    // Unified Office
    UOT("uot"), UOF("uof"),
    // Ichitaro
    JTD("jtd"), JTT("jtt"),
    // Hangul WP 97
    HWP("hwp"),
    // AporticDoc
    PDB("pdb"),
    // OpenDocument
    ODT("odt"), OTT("ott"), OTH("oth"), ODM("odm"),
    // OOo
    SXW("sxw"), STW("stw"), SXG("sxg"), 
    PDF("pdf"),
    
    // Images
    JPG("jpg"), JPEG("jpeg"), PNG("png"), GIF("gif"), BMP("bmp"), VBMP("vbmp"),

    IDSF("idsf"),

    // Media audio
    AIF("aif"), AIFF("aiff"), M3U8("m3u8"), MP3("mp3"), M4A("m4a"), MAV("mav"),
    
    // Media video
    FXM("fxm"), FLV("flv"), MP4("mp4"), M4V("m4a"),
    
    // compressed file
    JAR("jar"), ZIP("zip"), GZIP("gzip"), TAR_GZIP("tar.gz"), SEVEN_Z("7z"), AR("ar"), ARJ("arj"), BZIP2("bzip2"), CPIO("cpio"), DEFLATE("deflate"), DUMP("dump"), Z("z"), XZ("xz"), TAR("tar"), SNAPPY("snappy"), PACK200("pack200"), LZMA("lzma"), 
    
    OTHER("other");

    private final String ext;
    private static Set<Extension> zipSet;

    static {
        zipSet = new HashSet<>();
        zipSet.addAll(Arrays.asList(Z, ZIP, GZIP, SEVEN_Z, AR, ARJ, BZIP2, CPIO, DEFLATE, DUMP, Z, XZ, TAR, SNAPPY, PACK200, LZMA));
    }

    Extension() {
        this.ext = "";
    }

    Extension(String name) {
        this.ext = name.trim().toLowerCase();
    }

    public String ext() {
        return ext;
    }

    static public boolean isZipFile(String extStr) {
        Extension ext1 = type(extStr);

        return zipSet.contains(ext1);
    }

    static public boolean isZipFile(Extension ext) {
        return zipSet.contains(ext);
    }

    public static Set<Extension> zipExt() {
        return zipSet;
    }

    public boolean equals(String ext) {
        return this.ext.equalsIgnoreCase(ext);
    }

    static public Extension type(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        
        typeStr = typeStr.trim();
        typeStr.replaceFirst(".", "");

        Extension ext = OTHER;
        try {
            ext = Enum.valueOf(Extension.class, typeStr.toUpperCase());
        }
        catch (Exception e) {
            /*
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    "File extension " + typeStr.toUpperCase() + " error:\n" + e.getMessage(),
                    "File Extension Not Supported");
            */
            ext = OTHER;
        }

        return ext;
    }
}
