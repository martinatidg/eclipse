/**
 *
 */
package com.macat.reader.constants;

/**
 * @author cc.martin.tan
 *
 */
public enum FolderOption {

    CONTACTS("Contacts"), DELETED("Deleted"), DRAFT("Drafts"), GROUP("Group"),
    IMPORTANT("Important"), TRUSTED_INBOX("Trusted_Inbox"), JUNK("Junk"), OTHERS("Others"),
    OUTBOX("Outbox"), SENT("Sent"), SETTINGS("Settings"), INBOX("Inbox"),
    SPAM("Spam");

    FolderOption(String foldername) {
        this.foldername = foldername.toLowerCase();
        label = foldername;
    }

    public String label() {
        return label;
    }

    @Override
    public String toString() {
        return foldername;
    }

    static public FolderOption type(String statusStr) {
        if (statusStr == null || statusStr.trim().isEmpty()) {
            return null;
        }
        statusStr = statusStr.trim();

        return Enum.valueOf(FolderOption.class, statusStr.toUpperCase());
    }

    private final String foldername;
    private final String label;
}
