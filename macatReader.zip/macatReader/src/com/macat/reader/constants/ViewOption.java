package com.macat.reader.constants;

public enum ViewOption {

    MY_FOLDER("My Folder"), CUSTOM_FOLDER("Custom Folder"), FOLDER_VIEW("Document"), DOCUMENT_VIEW("Document View");

    private final String name;
    private final String label;

    ViewOption(String name) {
        this.label = name;
        this.name = name.toLowerCase();
    }

    @Override
    public String toString() {
        return name;
    }

    public String label() {
        return label;
    }

    static public ViewOption getType(String typeStr) {
        if (typeStr == null || typeStr.trim().isEmpty()) {
            return null;
        }
        typeStr = typeStr.trim();

        return Enum.valueOf(ViewOption.class, typeStr.toUpperCase());
    }

}
