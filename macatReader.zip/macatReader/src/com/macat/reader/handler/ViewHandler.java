/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.macat.reader.handler;

import com.macat.reader.constants.ActOption;
import com.macat.reader.constants.ViewOption;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author martin.tan
 */
public class ViewHandler implements EventHandler<MouseEvent> {

    ViewOption viewItem = null;

    public ViewHandler(ViewOption viewitem) {
        this.viewItem = viewitem;
    }

    @Override
    public void handle(MouseEvent event) {
        switch (viewItem) {
            case MY_FOLDER:
                break;
            case DOCUMENT_VIEW:
                break;

            default:
                break;
        }
    }
}
