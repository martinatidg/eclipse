package com.macat.reader.handler;

import com.macat.reader.constants.Constants;
import com.macat.reader.util.IdgLog;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import resources.Resources;

public class ToolbarLabel extends Label {

    static Logger logger = IdgLog.getLogger();
    //private ToolbarLabel thisLabel = this;

    public ToolbarLabel(String textIn, String upButtonName, String downButtonName, EventHandler<? super MouseEvent> eventHandler) {
        this(textIn, upButtonName, downButtonName, eventHandler, Constants.LABEL_SIZE, Constants.TEXT_COLOR, ContentDisplay.TOP);
    }

    public ToolbarLabel(String textIn, String upButtonName, String downButtonName, EventHandler<? super MouseEvent> eventHandler, ContentDisplay cdisplay) {
        this(textIn, upButtonName, downButtonName, eventHandler, Constants.LABEL_SIZE, Constants.TEXT_COLOR, cdisplay);
    }

    public ToolbarLabel(String textIn, String upButtonName, String downButtonName, EventHandler<? super MouseEvent> eventHandler, Color textColor, ContentDisplay cdisplay) {
        this(textIn, upButtonName, downButtonName, eventHandler, 40, textColor, cdisplay);
    }

    public ToolbarLabel(String textIn, String upButtonName, String downButtonName, EventHandler<? super MouseEvent> eventHandler, int width, Color textColor, ContentDisplay cdisplay) {
        super();
        this.getStylesheets().add(Resources.getStylesheet());

        String text = "";
        if (textIn != null && textIn.length() > 0) {
            try {
                text = Resources.getMessage(textIn);
            } catch (Exception ex) {
                text = textIn;
                logger.log(Level.INFO, "{0}", ex.getCause());
            }
        }

        //this.setId("icon-label");
        this.setText(text);
        this.setTextAlignment(TextAlignment.CENTER);
        setTooltip(new Tooltip(text));
        //setId(textIn);
        setOnMouseClicked(eventHandler);
        this.setTextFill(textColor);

        if (downButtonName == null || downButtonName.trim().isEmpty() || upButtonName == null || upButtonName.trim().isEmpty()) {
            //this.setContentDisplay(cdisplay);
            this.setAlignment(Pos.CENTER_LEFT);
            //this.setTextFill(Color.SKYBLUE);

            //return;
        }
        else {
            final ImageView downImgView = Resources.getNewImageView(downButtonName);
            final ImageView upImgView = Resources.getNewImageView(upButtonName);
            this.setGraphic(upImgView);
            this.setContentDisplay(cdisplay);
            this.setAlignment(Pos.CENTER_LEFT);
            //this.setAlignment(Pos.CENTER);
            //this.setTextFill(Color.WHITE);

            setOnMouseEntered(new EventHandlerImpl(downImgView));
            setOnMouseExited(new EventHandlerImpl(upImgView));
        }
        
        //this.setPrefHeight(width);
        //this.setPrefWidth(width + 10);
    }

    public void removeEventHandler() {
        setOnMouseClicked(null);
        setOnMouseEntered(null);
        setOnMouseExited(null);
    }

    private class EventHandlerImpl implements EventHandler<MouseEvent> {
        private final ImageView imgView;

        public EventHandlerImpl(ImageView labelImgView) {
            this.imgView = labelImgView;
        }

        @Override
        public void handle(MouseEvent t) {
            setGraphic(imgView);
        }
    }
}
