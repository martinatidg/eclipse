package com.macat.reader.pdf;

import java.awt.Dimension;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

public class PdfViewPane extends BorderPane {

    //private static BorderPane bpane;

    static private ScrollPane scrollpane;
    static private PDFViewer pdfViewer;
    static private ResizableSwingNode swingNode;
    static private PdfViewPane pdfViewerPane;
    private final Pane mom;
    //static private Stage mstage;

    private PdfViewPane(Pane dad) {
        //mstage = stage;
        this.mom = this;
        // pdfViewerPane = this;
        scrollpane = new ScrollPane();

        long start = System.currentTimeMillis();
        swingNode = new ResizableSwingNode();

        pdfViewer = PDFViewer.instance();
        //pv.openFile(file);
        swingNode.setContent(pdfViewer.getMainPanel());
        scrollpane.setContent(swingNode);

        setCenter(scrollpane);
        //setPrefSize(800, 600);


        //stage.setScene(new Scene(new Group(swingNode), W, H));
        //scene = new Scene(bpane);
        scrollpane.prefWidthProperty().bind(this.widthProperty());
        scrollpane.prefHeightProperty().bind(this.heightProperty());

        ChangeListener<Number> changelistener;
        changelistener = (ObservableValue<? extends Number> observableValue, Number oldSceneWidth, Number newSceneWidth) -> {
            System.out.println("Width: " + newSceneWidth);
            updatePdf();
        };

        mom.widthProperty().addListener(changelistener);
        mom.heightProperty().addListener(changelistener);

        long end = System.currentTimeMillis();
        System.out.println("it took " + (end - start) + " miliseconds to display");
    }

    static public PdfViewPane instance(Pane pane) {
        if (pdfViewerPane == null) {
            pdfViewerPane = new PdfViewPane(pane);
        }

        return pdfViewerPane;
    }

    public void openFile(String filename) throws IOException {
        Path file = Paths.get(filename);
        pdfViewer.openFile(file.toFile());
        updatePdf();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }

    public static String getFileExtension(String fullPath) {
        int dot = fullPath.lastIndexOf(".");
        return fullPath.substring(dot + 1);
    }

    public void updatePdf() {
        mom.autosize();
        double width = mom.getWidth();
        double height = mom.getHeight();

        if (width <= 0) {
            width = 800;
        }
        if (height <= 0) {
            height = 600;
        }

        pdfViewer.setMainSize(new Dimension((int) width, (int) height));
        swingNode.resize(width, height);
    }
}
