package com.macat.reader;

import com.google.gdata.client.contacts.ContactsService;
import com.independentsoft.exchange.Service;
import com.macat.reader.constants.*;
import com.macat.reader.constants.Constants;
import static com.macat.reader.constants.EmailType.GMAIL;
import com.macat.reader.domain.ContactsUtil;
import com.macat.reader.domain.EmailAccounts;
import com.macat.reader.domain.EmailPref;
import com.macat.reader.util.IdgLog;
import com.moyosoft.exchange.Exchange;
import com.moyosoft.exchange.ExchangeServiceException;
import com.moyosoft.exchange.mail.ExchangeMail;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Context {
    static final Logger logger = IdgLog.getLogger();
    private static Store store = null;
    private static HashMap<String, Store> storeCache = new HashMap<>();
    private static Exchange exchange;
    private static EmailAccounts currentAccount = null;
    private static Service galService;
    static public EmailPref emailPref = new EmailPref();

    private static Path tempPath = null;

    public static Path getTempPath() {
        return tempPath;
    }

    public static void setTempPath(Path tempPath) {
        Context.tempPath = tempPath;
    }
    

    public static Service getGalService() {
        logger.log(Level.SEVERE, "currentAccount.getUsername() = " + currentAccount.getUsername() + ", currentAccount.getPassword() = " + currentAccount.getPassword());
        if (galService == null) {
            galService = new Service(Constants.GAL_URL, currentAccount.getUsername(), currentAccount.getPassword());
        }
        return galService;
    }

    // public methods
    public static void setCurrentUser(EmailAccounts user) {
        currentAccount = user;
    }

    public static EmailAccounts getCurrentUser() {
        return currentAccount;
    }

    public static <T> T getServer(Class<T> cls) {
        if (cls.isInstance(store)) {
            return cls.cast(store);
        } else if (cls.isInstance(exchange)) {
            return cls.cast(exchange);
        } else {
            return null;
        }
    }

    public static void setServer() throws Exception {
        if (currentAccount == null) {
            throw new Exception("No user account is available");
        }

        EmailType type = currentAccount.getMailType();
        switch (currentAccount.getMailType()) {
            case GMAIL:
            case HOTMAIL:
            case YAHOO:
            case POP3:
            case IMAP:
                initStoreObject();
                break;
            case EXCHANGE:
                setExchange();
                logger.log(Level.SEVERE, "currentAccount.getUsername() = " + currentAccount.getUsername() + ", currentAccount.getPassword() = " + currentAccount.getPassword());
                galService = new Service(Constants.GAL_URL, currentAccount.getUsername(), currentAccount.getPassword());
                break;
            default:
                throw new Exception("The email type '" + currentAccount.getMailType() + "' is not supported.");
        }
    }

    public static void sendEmail(String to, String subject, String body, File attach) throws Exception {
        switch (currentAccount.getMailType()) {
            case GMAIL:
            case YAHOO:
            case HOTMAIL:
                sendSmtpGmail(to, subject, body, attach);
                break;
            case EXCHANGE:
                sendExchangeEmail(to, subject, body, attach);
                break;
            default:
                throw new Exception("The email type '" + currentAccount.getMailType() + "' is not supported.");
        }
    }

    public static String userEmail() {
        if (currentAccount != null) {
            return currentAccount.getEmail();
        } else {
            return "";
        }
    }

    public static String userPassword() {
        if (currentAccount != null) {
            return currentAccount.getPassword();
        } else {
            return "";
        }
    }

    public static EmailType userEmailType() {
        if (currentAccount != null) {
            return currentAccount.getMailType();
        } else {
            return null;
        }
    }

    // public methods for Gmail
    public static ContactsService getContactService() {
        String username = null;
        String[] email = currentAccount.getEmail().split("@");
        username = email[0];
        ContactsService contactSrv = ContactsUtil.authenticateId(username, currentAccount.getPassword());
        return contactSrv;
    }

    // public methods for Gmail
    public static ContactsService getContactService(EmailAccounts userAccount) {
        String username = null;
        String[] email = userAccount.getEmail().split("@");
        username = email[0];
        ContactsService contactSrv = ContactsUtil.authenticateId(username, userAccount.getPassword());
        return contactSrv;
    }

    //private methods for Gmail
    private static Store initStoreObject() throws MessagingException {
        // check if store is already there in the cache , if it is then return
        // store from the cache otherwise create a new store.
        if (storeCache.containsKey(currentAccount.getEmail()) && store.isConnected()) {
            store = storeCache.get(currentAccount.getEmail());
        } else {
            store = getSingletonStore(currentAccount.getMailType());
            storeCache.put(currentAccount.getEmail(), store);
        }

        return store;
    }

    private static Store getSingletonStore(EmailType type) throws NoSuchProviderException, MessagingException {
        Properties props = getPropertiesFromAccount();
        Store store;
        Session session = null;
        switch (type) {
            case VOISCMAIL:
                URLName url = new URLName(
                        currentAccount.getProtocol(),
                        currentAccount.getSocketClass(),
                        110,
                        "INBOX",
                        currentAccount.getEmail(),
                        currentAccount.getPassword());
                session = Session.getDefaultInstance(props, null);
                store = session.getStore(url);
                store.connect(currentAccount.getMailHost(), currentAccount.getEmail(), currentAccount.getPassword());
                break;

                /*
            case GMAIL:
            case YAHOO:
            case HOTMAIL:
            case POP3:
            case IMAP:
                */
            default:
                session = Session.getDefaultInstance(props, null);
                store = session.getStore(currentAccount.getProtocol());
                store.connect(currentAccount.getMailHost(), currentAccount.getEmail(), currentAccount.getPassword());
        }

        return store;
    }

    private static void sendSmtpGmail(String to, String subject, String body, File attachfile) throws MessagingException {
        Properties props = getSmtpProperties();
        if (props == null) {
            logger.info("Mail properties is unavailable. The email type may not have been set.");
        }

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(currentAccount.getEmail(), currentAccount.getPassword());
            }
        });

//        try {
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        Multipart multipart = new MimeMultipart();
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(currentAccount.getEmail()));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject);
        //message.setText(body);

        if (true) { //subject.contains(TrustSubject.REQUEST_SUBJECT.label())) {
            messageBodyPart.setContent(body, "text/html");
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart);
        } else {
            message.setText(body);
        }

                    // Create a multipar message
                    multipart = new MimeMultipart();

                    // Set text message part
                    multipart.addBodyPart(messageBodyPart);

                    //if (attachFileMap != null && attachFileMap.size() > 0) {
                        //for (File file : attachFileMap.values()) {
                            messageBodyPart = new MimeBodyPart();
                            //String filename = file.getPath();
                            DataSource source = new FileDataSource(attachfile);
                            messageBodyPart.setDataHandler(new DataHandler(source));
                            messageBodyPart.setFileName(attachfile.getName());
                            multipart.addBodyPart(messageBodyPart);
                        //}
                    //}

                    message.setContent(multipart);
        Transport.send(message);

        logger.info("-----------Done-------------------");

//        } catch (MessagingException e) {
//            throw new RuntimeException(e);
//        }
    }

    // public methods for Exchange
    private static void setExchange() throws ExchangeServiceException {
        if (currentAccount.getDomain() != null || !"".equals(currentAccount.getDomain())) {
            exchange = new Exchange(currentAccount.getMailHost(), currentAccount.getUsername(), currentAccount.getPassword());
        } else {
            exchange = new Exchange(currentAccount.getMailHost(), currentAccount.getUsername(), currentAccount.getPassword(), currentAccount.getDomain());
        }
    }

    // private methods for exchange
    private static boolean sendExchangeEmail(String toList, String subject, String sendMessage, File attachfile)
            throws ExchangeServiceException, IOException {
        String ccList = "";
        String bccList = "";

        ExchangeMail sendMail = null;
        sendMail = exchange.createMail();

        if (sendMail == null) {
            return false;
        }

        List<String> stringList = new ArrayList<>();
        // Credentials
        String[] toArray = toList.split(";");
        String[] ccArray = (ccList.isEmpty()) ? null : ccList.split(";");
        String[] bccArray = (bccList.isEmpty()) ? null : bccList.split(";");
        // To
        if (toArray.length > 1) {
            stringList.addAll(Arrays.asList(toArray));
            sendMail.setToRecipients(stringList);
        } else if (toArray.length == 1) {
            sendMail.setToRecipient(toList);
        }
        // Cc
        if (ccArray
                != null) {
            if (ccArray.length > 1) {
                stringList.addAll(Arrays.asList(ccArray));
                sendMail.setCcRecipients(stringList);
            } else if (ccArray.length == 1) {
                sendMail.setCcRecipient(ccList);
            }
        }
        // Bcc
        if (bccArray
                != null) {
            if (bccArray.length > 1) {
                stringList.addAll(Arrays.asList(toArray));
                sendMail.setBccRecipients(stringList);
            } else if (bccArray.length == 1) {
                sendMail.setBccRecipient(toList);
            }
        }
        stringList = null;

        // Subject
        sendMail.setSubject(subject);

        // Body
        sendMail.setBody(sendMessage);
        // Attachments
        sendMail.getAttachments().add(attachfile);

        // Send
        sendMail.send();

        return true;
    }

    // for Voisc
    public static void sendvoiscmail(String from, String to, String pwd, String subject, String body) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", EmailType.VOISCMAIL.domain());
        props.put("mail.smtp.port", "25");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(currentAccount.getEmail(), currentAccount.getPassword());
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            message.setText(body);

            Transport.send(message);

            logger.info("-----------Done-------------------");

        } catch (MessagingException e) {
            logger.log(Level.SEVERE, null, e);
            throw new RuntimeException(e);
        }
    }

    public static String[] getUserNameType() {
        String[] info = null;
        if (currentAccount.getEmail().contains("@")) {
            info = currentAccount.getEmail().split("@");
            logger.info("info: " + info[0]);
            logger.info("moreInfo: " + info[1]);
        } else {
            info = new String[2];
            info[0] = currentAccount.getEmail();
            info[1] = EmailType.EXCHANGE.toString();
        }
        return info;
    }

    public static void main(String a[]) {

        ContactsService contactService = null;
        try {
            contactService = new ContactsService("RupalMindfire-AddressApp");
            contactService.setUserCredentials("hsditest", "hsdi1234");
            System.out.print("connected");
        } catch (Exception e) {
            logger.log(Level.SEVERE, null, e);
        }
    }

    public static Properties getSmtpProperties() {
        if (currentAccount == null || currentAccount.getMailType() == null) {
            return null;
        }

        //EmailType type = currentAccount.getMailType();
        Properties props = new Properties();
                props.put("mail.smtp.host", currentAccount.getSmtpHost());
                props.put("mail.smtp.auth", currentAccount.getSmtpAuth()); // true
                props.put("mail.smtp.starttls.enable", currentAccount.getSmtpStarttls()); // true
                props.put("mail.smtp.port", currentAccount.getSmtpPort()); // 587
                props.put("mail.smtp.ssl.enable", currentAccount.getSsl());
                props.put("mail.smtp.socketFactory.port", currentAccount.getSocketPort()); //"465", yahoo only
                props.put("mail.smtp.socketFactory.class", currentAccount.getSocketClass()); //"javax.net.ssl.SSLSocketFactory", yahoo only

        return props;
    }

    private static Properties getPropertiesFromAccount() {
        Properties props = System.getProperties();
        props.setProperty("mail.store.protocol", currentAccount.getProtocol());
        props.setProperty("mail.pop3.host", currentAccount.getMailHost());
        props.setProperty("mail.pop3.port", currentAccount.getMailPort()); // 110
        props.setProperty("mail.pop3.socketFactory.port", currentAccount.getSocketPort());
        props.setProperty("mail.pop3.socketFactory.class", currentAccount.getSocketClass());
        props.setProperty("mail.pop3.socketFactory.fallback", Boolean.toString(currentAccount.getFallback()));
        props.setProperty("mail.imaps.partialfetch", Boolean.toString(currentAccount.getPartialfetch()));

        return props;
    }

}
