package com.macat.security;

/**
 *
 */
//package com.idg.macatreader;
import com.macat.reader.ReaderMain;
import com.macat.reader.constants.Extension;
import com.macat.reader.util.FXOptionPane;
import com.macat.reader.util.IdgLog;
import com.macat.reader.util.IoUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Base64;
import resources.Resources;
//import android.util.Base64;
//import android.util.Log;

/**
 * @author rajendra.prasad Jun 11, 2014 11:17:35 AM rajendra.prasad
 *
 */
public class Crypto {

    static Logger logger = IdgLog.getLogger();
    //final public static String ENC_EXT = Extension.IDSF.ext();
    final public static Extension ENC_EXT = Extension.IDSF;
    //public String TAG = "encrypt";

    public static String doEncryptFile(String filepath, String encryptedFile, String pwd) {
        logger.info("doEncryptFile filepath " + filepath);
        String ext = IoUtil.getFileExtension(encryptedFile);
        if (!ENC_EXT.equals(ext)) {
            encryptedFile += "." + ENC_EXT;
        }

        File file = new File(filepath);
        return doEncryptFile(file, encryptedFile, pwd);
    }

    public static String doEncryptFile(File file, String encryptFile, String pwd) {

        //File file = new File(filepath);
        String fileName = file.getName();
        String fileExtension = getFileExtension(fileName);
        String fileExtLength = String.valueOf(fileExtension.length());

        String encyptFileName = fileName.substring(0, fileName.lastIndexOf("."));

        logger.info("doEncryptFile filepath " + file.getPath());
        logger.info("doEncryptFile fileName " + fileName);
        logger.info("doEncryptFile fileExtension " + fileExtension);
        logger.info("doEncryptFile fileExtLength " + fileExtLength);
        logger.info("doEncryptFile encyptFileName " + encyptFileName);
        logger.info("doEncryptFile parent " + file.getParent());
        logger.info("doEncryptFile parent " + file.getParentFile());

        byte[] encryptedData = null;
        byte[] encryptedKey = null;
        byte[] extType = new byte[7];

        JNCryptor crypt = JNCryptorFactory.getCryptor();

        //String newEncryptFile = file.getParent() + File.separator + encyptFileName + "." + ENC_EXT;
        //String newEncryptFile = encfile;
        //String newEncryptFile = encyptFileName + ".ids";
        try {
            FileInputStream fis = new FileInputStream(file);
            FileOutputStream fos = new FileOutputStream(encryptFile, false);

            encryptedKey = crypt.encryptData(pwd.getBytes(), pwd.toCharArray());
            logger.info("encryptedKey " + encryptedKey.length);
            fos.write(encryptedKey); //write key 82 bytes

            fos.write(fileExtLength.getBytes()); //write extension length 1 byte
            logger.info("fileExtLength " + fileExtLength);

            String extLength = new String(fileExtLength);
            logger.info("extLength  " + extLength);
            int size = Integer.parseInt(extLength);

            System.arraycopy(fileExtension.getBytes(), 0, extType, 0, size); //copy file extension in to 7 bytes array 

            fos.write(extType); //write file extension 7 byte

            String orgExt = new String(extType);
            logger.info("orgExt  " + orgExt);

            logger.info("extTypeLength " + extType.length);

            byte fileContent[] = new byte[(int) file.length()];
            fis.read(fileContent);
            encryptedData = crypt.encryptData(fileContent, pwd.toCharArray());
            logger.info("encryptedData: " + encryptedData.length);
            fos.write(encryptedData);
            logger.info("encryptedData " + encryptedData.toString());

            fis.close();
            fos.close();
        } catch (FileNotFoundException fe) {
            logger.info("encryptedData FileNotFoundException " + fe);

            fe.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("encryptedData Exception " + e);

            e.printStackTrace();
        }
        if (encryptedData != null) {
            // Using Base64 utility help to encode the cipher-text!
            //String sCipher64 = Base64.encodeToString(encryptedData, Base64.NO_WRAP);
            String sCipher64 = Base64.encodeBase64String(encryptedData);
            logger.info("JNCryptor encoded: " + sCipher64);
            file.delete();
        }

        return encryptFile;
    }

    public static String doDecryptFile(String filepath, String pwd) {
        String decryptedBase = IoUtil.getFilenameWithoutExtension(filepath);
        return doDecryptFile(filepath, decryptedBase, pwd);
    }

    public static String doDecryptFile(String filepath, String decryptedBase, String pwd) {//throws CryptorException {
        String decryptedFile = "";
        File file = new File(filepath);

        logger.info("filepath " + filepath);

        byte nfileContent[] = new byte[(int) file.length() - 90];

        byte[] decryptKeyData = null;
        byte[] decryptedData = null;
        byte[] decryptedKey = new byte[82];
        byte[] eLen = new byte[1];
        byte[] eName;//=new byte[7];;

        JNCryptor crypt = JNCryptorFactory.getCryptor();

        try (FileInputStream fis = new FileInputStream(file);
                RandomAccessFile raf = new RandomAccessFile(file, "r"); //FileOutputStream fos = new FileOutputStream(tempFile, false);
                ) {
            //FileInputStream fis = new FileInputStream(file);

            fis.read(decryptedKey, 0, decryptedKey.length);
            try {
                decryptKeyData = crypt.decryptData(decryptedKey, pwd.toCharArray());
            } catch (CryptorException ex) {
                logger.info("The password key may not be correct, password key:" + pwd + "\n" + ex.getStackTrace());
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("msg.passwordIncorrect"),
                        Resources.getMessage("decrypt"));

                return null;
            }

            logger.info("decryptedData " + decryptKeyData.toString()); //Read decrypt key 82 bytes

            //RandomAccessFile raf = new RandomAccessFile(file, "r");
            raf.seek(82);
            raf.read(eLen);

            String extLength = new String(eLen); //Read extension length 1 byte
            logger.info("extLength  " + extLength);

            int size = Integer.parseInt(extLength);
            logger.info("size  " + size);

            eName = new byte[size];

            raf.seek(83);
            raf.read(eName); //Read extension name length byte(depends on length,may not be 7 bytes)
            String extName = new String(eName);
            logger.info("extName  " + extName.getBytes("UTF-8").length);

            String tempExt = extName;

            //decryptedFile = IoUtil.replaceExtension(filepath, tempExt);
            decryptedFile = decryptedBase + "." + tempExt;
            logger.info("Constants.tempFile  " + decryptedFile);

            File tempFile = new File(decryptedFile);
            if (!tempFile.exists()) {
                tempFile.delete();
                tempFile = new File(decryptedFile);
            }

            try (FileOutputStream fos = new FileOutputStream(tempFile, false)) {
                raf.seek(90);//Read decrypted data from 90 to length of end of file
                raf.read(nfileContent, 0, nfileContent.length);
                String fc = new String(nfileContent);
                logger.info("fc.length = " + fc.length());

                decryptedData = crypt.decryptData(nfileContent, pwd.toCharArray());

                logger.info("decryptedData  " + decryptedData);

                fos.write(decryptedData, 0, decryptedData.length);
            } catch (CryptorException ex) {
                logger.info("The password key may not be correct, password key:" + pwd + "\n" + ex.getStackTrace());
                FXOptionPane.showMessageDialog(
                        ReaderMain.getStage(),
                        Resources.getMessage("msg.decryptErr"),
                        Resources.getMessage("decrypt"));

                return null;
            }
            //fos.close();
        } catch (FileNotFoundException ex) {
            logger.log(Level.SEVERE, "File not found:\n{0}", ex.getStackTrace());

            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.fileNotFound"),
                    Resources.getMessage("decrypt"));
            return null;

        } catch (IOException ex) {
            logger.log(Level.SEVERE, "IOException:\n{0}", ex.getStackTrace());
            FXOptionPane.showMessageDialog(
                    ReaderMain.getStage(),
                    Resources.getMessage("msg.fileNotAccessible"),
                    Resources.getMessage("decrypt"));
            return null;
        }

        /*
         if (decryptedData != null) {
         // Using Base64 utility help to encode the cipher-text!
         //String sCipher64 = Base64.encodeToString(decryptedData, Base64.NO_WRAP);
         String sCipher64 = Base64.encodeBase64String(decryptedData);
         logger.info("JNCryptor decoded: " + sCipher64);
         //return true;
         }
         */
        return decryptedFile;
    }

    private static String getFileExtension(String fullPath) {
        int dot = fullPath.lastIndexOf(".");
        return fullPath.substring(dot + 1);
    }
}
