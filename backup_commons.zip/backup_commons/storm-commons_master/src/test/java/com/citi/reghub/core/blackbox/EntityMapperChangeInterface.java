package com.citi.reghub.core.blackbox;

import com.citi.reghub.core.EntityMapper;

public interface EntityMapperChangeInterface {

	public void changeEntityMapper(EntityMapper mapper);

}
