package com.citi.reghub.core.blackbox;

public interface EligibilityChangeInterface {

	/**
	 * This method is used to change the RuleGraph for the underlying bolt.
	 * 
	 * @param rulegraphname
	 */
	public void changeRuleGraph(String rgtype, String rulegraphname);
	
	/**
	 * The method is used to return the RuleGraphType.
	 * 
	 * @return
	 */
	public String getRuleGraphType();
	
	
	/**
	 * The method determines if the RuleGraph is of the given type.
	 * 
	 * @return
	 */
	public boolean isRuleGraphType(String rgtype);
	
}
