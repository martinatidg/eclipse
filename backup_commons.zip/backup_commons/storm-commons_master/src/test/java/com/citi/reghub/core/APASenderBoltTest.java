package com.citi.reghub.core;

import static org.mockito.Mockito.doNothing;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.jms.JMSConnectionClient;

public class APASenderBoltTest {
	
	private static final String PROVIDER_URL = "tibems036-d1.eur.nsroot.net:7036";
	
	@Mock
	JMSConnectionClient jmsConnection;
	
	@InjectMocks
	APASenderBolt apaSenderBolt;
	
	@Mock
	TopologyContext context;
	
	@Mock
	OutputCollector collector;
	
	private Map<String, String> config;
	
	private Map<String, Object> stormConfig;
	
	@Before
	public void setup(){
		
		MockitoAnnotations.initMocks(this);
		config= new HashMap<String, String>();
		config.put(GlobalProperties.APA_TOPIC_NAME, "EU.REGHUB_TO_GMAX.LSE.TCR");
		config.put(GlobalProperties.APA_USERNAME, "cb2app");
		config.put(GlobalProperties.APA_PWD_KEY, "cb2app");
		config.put(GlobalProperties.APA_JNDI_NAME	, "FTTopicConnectionFactory");
		config.put(GlobalProperties.APA_PROVIDER_URL, PROVIDER_URL);
		//jmsConnection=new JMSConnectionClient(stormConf);
		stormConfig=new HashMap<>();
		stormConfig.put(GlobalProperties.TOPOLOGY_CONFIG, config);
		apaSenderBolt=new APASenderBolt();
		
	}

	@Test(expected=Test.None.class)
	public void testPrepareBolt() throws Exception {
		doNothing().when(jmsConnection).initConnection();
		apaSenderBolt.prepareBolt(stormConfig, context, collector);
		
	}

	@Test(expected=Exception.class)
	public void testPrepareBoltException() {
		config.put(GlobalProperties.APA_PROVIDER_URL, null);
		apaSenderBolt.prepareBolt(stormConfig, context, collector);
	}
	
	

}