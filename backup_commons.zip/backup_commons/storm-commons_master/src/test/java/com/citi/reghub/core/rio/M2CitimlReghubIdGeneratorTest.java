package com.citi.reghub.core.rio;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.rio.spouts.M2ReghubIdGeneratorFactory;



@RunWith(JUnit4.class)
public class M2CitimlReghubIdGeneratorTest {
	
	M2CitimlReghubIdGeneratorTest test ;
	
	String M2_CITIFIX_MESSAGE = "citifix";
	String M2_CITIML_MESSAGE ="citiml";
	
	@Test
	public void testRegHubIdCTMLCOMDERV () throws Exception {
		test = new M2CitimlReghubIdGeneratorTest();
		String messagge = test.getMessage("message1.xml");
		String messageId = M2ReghubIdGeneratorFactory.getM2ReghubIdGenerator(M2_CITIML_MESSAGE).generateReghubId("m2post", "comderv", messagge);
				
		Assert.assertNotNull(messageId);
		Assert.assertTrue(messageId.contains("UA3-Msg267843387708169012527402069070992"));
	
	}
	
	@Test
	public void testRegHubIdCTMLCSHFX () throws Exception {
		test = new M2CitimlReghubIdGeneratorTest();
		String messagge = test.getMessage("message2.xml");
		String messageId = M2ReghubIdGeneratorFactory.getM2ReghubIdGenerator(M2_CITIML_MESSAGE).generateReghubId("m2post", "comderv", messagge);
		
		Assert.assertNotNull(messageId);
		Assert.assertTrue(messageId.contains("e475296e-fc53-4903-a6d8-bce226980180-03550600LDN822017433-1"));;
	
	}
	
	@Test
	public void testRegHubIdCTMLITICKET() throws Exception {
		test = new M2CitimlReghubIdGeneratorTest();
		String messagge = test.getMessage("message3.xml");
		String messageId = M2ReghubIdGeneratorFactory.getM2ReghubIdGenerator(M2_CITIML_MESSAGE).generateReghubId("m2post", "muniderv", messagge);
			
		Assert.assertNotNull(messageId);
		Assert.assertTrue(messageId.contains("CitimlMessagedb0e2702-dae6-480b-8886-d348f17ba018"));;
		
	
	}
	
	
	private String getMessage(String fileName){
		String message = null;
		try {
			message = IOUtils.toString( this.getClass().getResourceAsStream(fileName), "UTF-8");
		} catch (IOException e) {
			//e.printStackTrace();
		}
		return message;
	}
	

}
