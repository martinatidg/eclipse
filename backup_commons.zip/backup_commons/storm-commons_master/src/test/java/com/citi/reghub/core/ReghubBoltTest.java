package com.citi.reghub.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.kafka.bolt.mapper.FieldNameBasedTupleToKafkaMapper;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.utils.MockTupleHelpers;
import org.drools.core.management.GenericKieSessionMonitoringImpl.ProcessStats.GlobalProcessStatsData;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.RegHubBolt;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.StormConstants;

public class ReghubBoltTest {
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	RegHubBolt reghubBolt;
	Map props = new HashMap<>();
	
	@Before
	public void setUp(){
		Map topologyConfig = new HashMap<>();
		topologyConfig.put("topology.stream", "M2PO");
		topologyConfig.put("topology.flow", "CSHFI");
		props.put(GlobalProperties.TOPOLOGY_CONFIG, topologyConfig);
		reghubBolt = new RegHubBolt() {
			
			private static final long serialVersionUID = 1L;
			private OutputCollector collector = null;
			
			
			@Override
			public void process(Tuple input) {
			}
			
			@Override
			public OutputCollector getCollector() {
				return collector;
			}
			
			@Override
			public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
				declarer.declareStream(StormStreams.SOURCE,new Fields(FieldNameBasedTupleToKafkaMapper.BOLT_KEY, FieldNameBasedTupleToKafkaMapper.BOLT_MESSAGE));
			}

			@Override
			public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
				this.collector = collector;
			}

			@Override
			public String getAuditExceptionEvent() {
				return StormConstants.SOURCE_APP_EXCEPTION;
			}

			@Override
			public List<String> getAuditExceptionsTags() {
				List<String> exceptionTags = new ArrayList<>();
				exceptionTags.add(StormConstants.SOURCE);
				exceptionTags.add(StormConstants.EXCEPTIONS);
				return exceptionTags;
			}
		};
	}
	
	private Tuple mockNormalTuple(String key , Object message) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("key")).thenReturn(key);
		when(tuple.getValueByField("message")).thenReturn(message);
		return tuple;
	}
	
	@Test
	public void validateExceptionEntityAndAuditObjectsWhenEntityIsNotPresent(){
		Tuple tuple = mockNormalTuple("123456","fjhfjhgfhjgkgkjhgk");
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		reghubBolt.prepare(props, context, _collector);
		Entity entity = reghubBolt.createExceptionEntity(tuple);
		assertEquals("123456",entity.regHubId);
		assertEquals("M2PO",entity.stream);
		assertEquals("CSHFI",entity.flow);
		assertNull(entity.executionTs);
		assertNull(entity.publishedTs);
		assertNull(entity.receivedTs);
		assertNull(entity.regReportingRef);
		assertNull(entity.sourceId);
		assertNull(entity.sourceStatus);
		assertNull(entity.sourceUId);
		assertNull(entity.sourceVersion);
		assertNull(entity.sourceSystem);
		assertTrue(entity.reasonCodes.isEmpty());
		assertTrue(entity.info.isEmpty());
		assertEquals(EntityStatus.APP_EXCEPTION,entity.status);
		Audit audit = reghubBolt.createAudit(entity, new NullPointerException());
		assertEquals("123456",audit.regHubId);
		assertEquals("M2PO",audit.stream);
		assertEquals("CSHFI",audit.flow);
		assertEquals(StormConstants.SOURCE_APP_EXCEPTION,audit.event);
		assertEquals(StormConstants.ERROR,audit.result);
		assertEquals(NullPointerException.class.getName(),audit.info.get(StormConstants.MESSAGE));
		assertNotNull(audit.info.get(StormConstants.STACKTRACE));
		assertTrue(audit.tags.contains(StormConstants.SOURCE));
		assertTrue(audit.tags.contains(StormConstants.EXCEPTIONS));
	}
	
	@Test
	public void validateExceptionEntityAndAuditObjectsWhenEntityIsPresent(){
		Entity dummyEntity = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple("123456",dummyEntity);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		reghubBolt.prepare(props, context, _collector);
		Entity entity = reghubBolt.createExceptionEntity(tuple);
		assertEquals(dummyEntity.regHubId,entity.regHubId);
		assertEquals(dummyEntity.stream,entity.stream);
		assertEquals(dummyEntity.flow,entity.flow);
		assertEquals(dummyEntity.executionTs, entity.executionTs);
		assertEquals(dummyEntity.publishedTs, entity.publishedTs);
		assertEquals(dummyEntity.receivedTs, entity.receivedTs);
		assertEquals(dummyEntity.regReportingRef, entity.regReportingRef);
		assertEquals(dummyEntity.sourceId, entity.sourceId);
		assertEquals(dummyEntity.sourceStatus,entity.sourceStatus);
		assertEquals(dummyEntity.sourceUId, entity.sourceUId);
		assertEquals(dummyEntity.sourceVersion, entity.sourceVersion);
		assertEquals(dummyEntity.sourceSystem, entity.sourceSystem);
		assertEquals(dummyEntity.reasonCodes, entity.reasonCodes);
		assertEquals(dummyEntity.info, entity.info);
		assertEquals(EntityStatus.APP_EXCEPTION,entity.status);
		Audit audit = reghubBolt.createAudit(entity, new NullPointerException());
		assertEquals(dummyEntity.regHubId,audit.regHubId);
		assertEquals(dummyEntity.stream,audit.stream);
		assertEquals(dummyEntity.flow,audit.flow);
		assertEquals(StormConstants.SOURCE_APP_EXCEPTION,audit.event);
		assertEquals(StormConstants.ERROR,audit.result);
		assertEquals(NullPointerException.class.getName(),audit.info.get(StormConstants.MESSAGE));
		assertNotNull(audit.info.get(StormConstants.STACKTRACE));
		assertTrue(audit.tags.contains(StormConstants.SOURCE));
		assertTrue(audit.tags.contains(StormConstants.EXCEPTIONS));
	}
	

}
