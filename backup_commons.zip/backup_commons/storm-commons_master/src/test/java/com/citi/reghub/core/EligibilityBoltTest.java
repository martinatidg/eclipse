package com.citi.reghub.core;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.enrichment.client.EnrichmentClientConfig;
import com.citi.reghub.core.enrichment.client.SingletonEnrichmentClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;
import com.citi.reghub.core.rules.client.RuleGraph;
import com.citi.reghub.core.rules.client.RuleGraphResult;
import com.citi.reghub.core.rules.client.RulesClient;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

@RunWith(JUnit4.class)
public class EligibilityBoltTest {
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	private RuleGraph ruleGraph;
	private RuleGraph updatedRuleGraph;
	private String ruleGraphName = "test";
	private RulesClient rulesClient;
	private EligibilityBolt bolt;
	
	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}
		
    @Before
    public void setUp() throws Exception {
    	ruleGraph = mock(RuleGraph.class);
    	updatedRuleGraph = mock(RuleGraph.class);
    	rulesClient = mock(RulesClient.class);
    	SingletonRulesClient.setInstance(rulesClient);
    	Answer<RuleGraph> answer = new Answer<RuleGraph>() {
    		public int count = 0;
			@Override
			public RuleGraph answer(InvocationOnMock invocation) throws Throwable {
				RuleGraph rulegraph = null;
				if(count == 0)
					rulegraph = ruleGraph;
				else
					rulegraph = updatedRuleGraph;
				count++;
				return rulegraph;
			}
		};
    	when(rulesClient.load(ruleGraphName)).thenAnswer(answer);
    	when(rulesClient.getLastLoadTime(ruleGraphName)).thenReturn(12000L);
    	
    	bolt = new EligibilityBolt(ruleGraphName){
    		@Override
			protected void setCacheClient(Map<String, String> topologyConfig) {
				
			}
			@Override
			protected void setRuleClient(Map<String, String> topologyConfig) {
//				SingletonRulesClient.setInstance(rulesClient);
			}
			@Override
			protected void setMetadataClient(Map<String, String> topologyConfig) {
				SingletonMetadataClient.setInstance(mock(MetadataClientConfig.class));
			}
			@Override
			protected void setEnrichmentClient(Map<String, String> topologyConfig) {
				SingletonEnrichmentClient.setInstance(mock(EnrichmentClientConfig.class));				
			}
    	};
	}	
	
	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		EligibilityBolt bolt = new EligibilityBolt(ruleGraphName);
		
		bolt.declareOutputFields(declarer);
		
		verify(declarer, times(4)).declareStream(any(String.class), any(Fields.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitInputTuple() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		when(ruleGraph.execute(eq(trade), eq(new HashMap<>()),any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 11, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		bolt.ruleGraph = ruleGraph;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		
		bolt.execute(tuple);
		verify(ruleGraph,times(1)).execute(trade, new HashMap<>(), true);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitReportableAndAuditStreamTest(){
		Entity trade = new EntityBuilder()
				.regHubId("1")
				.info("tradeDate", LocalDate.now())
				.build();
		
		Tuple tuple = mockNormalTuple(trade);
		when(ruleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 11, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				
				return rs;
			}
		});
		
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.ruleGraph = ruleGraph;
		bolt.execute(tuple);
		verify(ruleGraph,times(1)).execute(trade, new HashMap<>(), true);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}

	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitNonReportableStreamTest(){
		
		Entity trade = new EntityBuilder()
				.regHubId("1")
				.info("tradeDate", (LocalDate) LocalDate.of(2007, 11, 4))
				.build();
		
		Tuple tuple = mockNormalTuple(trade);
		when(ruleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 11, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				
				return rs;
			}
		});
		bolt.ruleGraph = ruleGraph;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		
		bolt.execute(tuple);
		verify(ruleGraph,times(1)).execute(trade, new HashMap<>(), true);
		verify(_collector).emit(StormStreams.NON_REPORTABLE, new Values(trade.regHubId, trade));
	}
	
	@Test
	public void shouldReloadUpdatedRuleGraph() {
		Entity trade = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 10)).build();
		Tuple tuple = mockNormalTuple(trade);
		when(ruleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 11, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		when(updatedRuleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 12, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.ruleGraph = ruleGraph;
		when(rulesClient.getLastLoadTime(ruleGraphName)).thenReturn(13000L);
		bolt.execute(tuple);
		verify(ruleGraph,times(0)).execute(trade, new HashMap<>(), true);
		verify(updatedRuleGraph,times(1)).execute(trade, new HashMap<>(), true);
		verify(_collector).emit(StormStreams.NON_REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldNotReloadRuleGraph() {
		Entity trade = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 10)).build();
		Tuple tuple = mockNormalTuple(trade);
		when(ruleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 11, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		when(updatedRuleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 12, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		bolt.ruleGraph = ruleGraph;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(ruleGraph,times(1)).execute(trade, new HashMap<>(), true);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldNotReloadRuleGraphRerun() {
		Entity trade = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 10)).build();
		Tuple tuple = mockNormalTuple(trade);
		when(ruleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 11, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		when(updatedRuleGraph.execute(eq(trade), eq(new HashMap<>()), any(boolean.class))).thenAnswer(new Answer<RuleGraphResult>() {
			@Override
			public RuleGraphResult answer(InvocationOnMock invocation) throws Throwable {
				Entity trade = (Entity) invocation.getArguments()[0];
				RuleGraphResult rs = new RuleGraphResult();
				if(!(LocalDate.of(2007, 12, 5)).isAfter(trade.getLocalDate("tradeDate"))){
					rs.markReportable();
				} else {
					rs.markNonReportable();
				}
				return rs;
			}
		});
		bolt.ruleGraph = ruleGraph;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		bolt.execute(tuple);
		verify(ruleGraph,times(1)).execute(trade, new HashMap<>(), true);
		verify(ruleGraph,times(1)).execute(trade, new HashMap<>(), false);
		verify(_collector, times(2)).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector, times(2)).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitExceptionTuple(){
		Entity trade = new EntityBuilder().build();
		trade.regHubId = null;
		trade.stream = null;
		Tuple tuple = mockNormalTuple(trade);
		bolt.ruleGraph = ruleGraph;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
		verify(bolt.getCollector()).emit(StormStreams.EXCEPTION, new Values(trade.regHubId, trade));
	}
	
	
}

