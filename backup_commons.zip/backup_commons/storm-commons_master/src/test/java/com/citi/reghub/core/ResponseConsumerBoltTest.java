package com.citi.reghub.core;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.HazelcastCacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.response.handler.ParsedResponseBundle;
import com.citi.reghub.core.response.handler.ResponseMessageController;
import com.citi.reghub.core.response.handler.ResponseMessageParser;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

public class ResponseConsumerBoltTest {

	ResponseConsumerBolt bolt;
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	HazelcastCacheClient cacheClient;
	HazelcastInstance hzInstance;
	
	ResponseMessageController controller = new ResponseMessageController() {
		
		@Override
		public void process(ParsedResponseBundle prb) {
			// TODO Auto-generated method stub
			
		}

		
		@Override
		public Audit getRejectionAudit(ParsedResponseBundle prb, String event, List<String> exceptionTags) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public ResponseMessageParser getParser(String fixMessage) {
			// TODO Auto-generated method stub
			return null;
		}
	};
	
	@Before
	public void setUp() throws Exception {
		hzInstance = Hazelcast.newHazelcastInstance();
		Map props = new HashMap<>();
		props.put("cache.provider", "hazelcast");
		props.put("hazelcast.group.name", "dev");
		props.put("hazelcast.group.password", "dev-pass");
		props.put("hazelcast.network.address", "localhost");
		cacheClient = new HazelcastCacheClient(props);
		bolt = new ResponseConsumerBolt(controller);
		bolt.cacheClient = cacheClient;
		bolt.cacheConfig = new HashMap<>();
		bolt.cacheConfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
	}
	
	
	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}
	
	private RestClient mockRestClient(RawOutboundRecord rawRecord){
		RestClient restClient = mock(RestClient.class);
		when(restClient.get(any(String.class), eq(RawOutboundRecord.class))).thenReturn(rawRecord);
		return restClient;
	}
	
	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		bolt.declareOutputFields(declarer);
		verify(declarer, times(4)).declareStream(any(String.class), any(Fields.class));
	}
	
	@Test
	public void ShouldEmitPartialAndAuditStreams() {
		OutputCollector collector = mock(OutputCollector.class);
		Tuple tuple = mockNormalTuple("1041=m2post-muniderv-123123423423-1501060848651000000\001939=1\00135=AR\001751=2\001");
		RawOutboundRecord rawRecord= new RawOutboundRecord();
		rawRecord.regHubId ="1";
		rawRecord._id ="789";
		bolt._collector =  collector;
		bolt.rawOutboundServiceUrl = "dummy_url";
		bolt.restClient=mockRestClient(rawRecord);
		bolt.execute(tuple);
		verify(collector, times(1)).emit(eq(StormStreams.AUDIT), any(Values.class));
		verify(collector, times(1)).emit(eq(StormStreams.EXCEPTION), any(Values.class));
	}
	
	@After
	public void tearDown() {
		cacheClient.destroy();
		hzInstance.shutdown();
		bolt.cleanup();
	}
	
}
