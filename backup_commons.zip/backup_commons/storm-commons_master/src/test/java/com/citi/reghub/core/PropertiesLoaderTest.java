package com.citi.reghub.core;

import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.InvalidInputException;
import com.citi.reghub.core.PropertiesLoader;

import java.util.Map;
import java.util.Properties;

/*
 * THE TEST BELOW ARE BASED ON THE FOLLOWING ASSUMPTIONS TO BE TRUE.
 * 
 * 1. The total number of properties with "global" prefix should be 10 in application.properties file
 * 2. The total number of properties with "cash" prefix should be 7 in application.properties file
 * 3. Along with 7 properties mentioned in #2, there would be one extra property prefix with "cash" present in application-test.properties file.
 * 4. Though properties with "eq" prefix are present they should not be loaded at all when testing using "cash" as topology name.
 * 	   
 */

public class PropertiesLoaderTest {

	/*
	 * When a null reference is passed in place of topology name
	 */
	@Test(expected = InvalidInputException.class)
	public void testNullTopologyName() {
		new PropertiesLoader().getProperties(null);
	}

	/*
	 * When a empty string is passed in place of topology name
	 */
	@Test(expected = InvalidInputException.class)
	public void testEmptyTopologyName() {
		new PropertiesLoader().getProperties("");
	}

	/*
	 * Get env file name in the format "application-{env}.properties"
	 */
	@Test
	public void testEnvFileNameFormart() {
		String env = "test";
		String result = "application-test.properties";
		Assert.assertEquals(new PropertiesLoader().getEnvBasedFileName(env),
				result);
	}

	/*
	 * Test file loading success
	 */
	@Test
	public void testFileLoadSuccess() {
		Properties p = new PropertiesLoader()
				.loadProperties("application.properties");
		Assert.assertFalse("Properties should not be null", p.isEmpty());
	}

	/*
	 * Test file loading failure. Null reference should be returned
	 */
	@Test
	public void testEmptyPropertyReturnWhenFileLoadFailed() {
		Properties p = new PropertiesLoader()
				.loadProperties("application.not.found.properties");
		Assert.assertTrue(p.isEmpty());
	}

	/*
	 * To test if the map length is equal to default properties plus the
	 * properties from the env file; The expected length should be 18 since we
	 * only have one extra unique property in the test env file.
	 */
	@Test
	public void testPropertyTotalPropertyCountFromBaseAndEnvFiles() {
		Map<String, String> m = new PropertiesLoader().getProperties("test");
		Assert.assertTrue("Map length should be count of default + env specific file properties", m.size() == 37);
	}

	/*
	 * To test if the map length is equal to default properties plus the
	 * properties from the env file; If same keys are found in the env file the
	 * properties in the default file would be overridden.
	 */
	@Test
	public void testEnvPropertyInheritance() {
		Map<String, String> m = new PropertiesLoader().getProperties("test");
		Assert.assertTrue("eq.topology.name should have \"test\" suffix", m
				.get("topology.name").equals("m2tr_test"));
		Assert.assertTrue("Topology property overrides global",
				Integer.parseInt(m.get("kafka.spout.max.retries.count")) == 750);
	}

}
