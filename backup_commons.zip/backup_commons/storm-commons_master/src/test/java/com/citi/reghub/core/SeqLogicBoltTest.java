package com.citi.reghub.core;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.EntityCacheSeqDetails;
import com.citi.reghub.core.SequencerBolt;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.HazelcastCacheClient;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.core.constants.StormStreams;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;


public class SeqLogicBoltTest {

	HazelcastCacheClient cacheClient;
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	SequencerBolt bolt;
	HazelcastInstance hzInstance;

	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		hzInstance = Hazelcast.newHazelcastInstance();
		Map props = new HashMap<>();
		props.put("cache.provider", "hazelcast");
		props.put("hazelcast.group.name", "dev");
		props.put("hazelcast.group.password", "dev-pass");
		props.put("hazelcast.network.address", "localhost");
		cacheClient = new HazelcastCacheClient(props);
		bolt = new SequencerBolt();
		bolt.cacheClient = cacheClient;
		bolt.SeqCacheconfig = new HashMap<>();
		bolt.SeqCacheconfig.put(CacheClient.CACHE_COLLECTION_NAME, "CSHEQ_SEQUENCER_CACHE");
		bolt.SeqCacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");

	}

	@After
	public void tearDown() {
		cacheClient.destroy();
		hzInstance.shutdown();
		bolt.cleanup();
	}

	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}

	@Test
	public void shouldBeAbleToSendNewToOutputStream() {

		Entity entity = new EntityBuilder().build();
		entity.sourceStatus = SourceStatus.NEW;
		entity.regHubId = "1";
		entity.sourceId = "123";
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector).emit(StormStreams.SEQUENCED_OUTBOUND_STREAM, new Values(entity.regHubId, entity));
	}

	@Test
	public void shouldNotSendCancelBeforeNewToOutputStream() {
		Entity entity = new EntityBuilder().build();
		entity.sourceStatus = SourceStatus.CANCEL;
		entity.regHubId = "2";
		entity.sourceId = "345";
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector, times(0)).emit(StormStreams.SEQUENCED_OUTBOUND_STREAM,
				new Values(entity.regHubId, entity));
	}

	@Test
	public void shouldSendCancelAfterNewToOutputStream() {
		LocalDateTime publishedTs = LocalDateTime.parse("2015-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		EntityCacheSeqDetails seqObj = new EntityCacheSeqDetails("NEW", publishedTs, "REPORTABLE", "456");
		cacheClient.put("456", seqObj, bolt.SeqCacheconfig);
		Entity entity = new EntityBuilder().build();
		entity.regHubId = "3";
		entity.sourceId = "456";
		entity.sourceStatus =SourceStatus.CANCEL;
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector, times(1)).emit(StormStreams.SEQUENCED_OUTBOUND_STREAM,
				new Values(entity.regHubId, entity));
	}

	@Test
	public void shouldNotSendAmendAfterNewCancelToOutputStream() {
		LocalDateTime publishedTs1 = LocalDateTime.parse("2015-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		EntityCacheSeqDetails seqObj1 = new EntityCacheSeqDetails("NEW", publishedTs1, "REPORTABLE", "789");
		cacheClient.put("789", seqObj1, bolt.SeqCacheconfig);
		LocalDateTime publishedTs2 = LocalDateTime.parse("2015-08-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		EntityCacheSeqDetails seqObj2 = new EntityCacheSeqDetails("CANCEL", publishedTs2, "REPORTABLE", "789");
		cacheClient.put("789", seqObj2, bolt.SeqCacheconfig);
		Entity entity = new EntityBuilder().build();
		entity.sourceStatus = SourceStatus.AMEND;
		entity.regHubId = "4";
		entity.sourceId = "789";
		entity.publishedTs = LocalDateTime.parse("2017-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector, times(0)).emit(StormStreams.SEQUENCED_OUTBOUND_STREAM,
				new Values(entity.regHubId, entity));
	}

	@Test
	public void shouldNotSendOldAmendAfterAmendToOutputStream() {
		LocalDateTime publishedTs = LocalDateTime.parse("2016-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		EntityCacheSeqDetails seqObj1 = new EntityCacheSeqDetails("AMEND", publishedTs, "REPORTABLE", "713");
		cacheClient.put("713", seqObj1, bolt.SeqCacheconfig);
		Entity entity = new EntityBuilder().build();
		entity.sourceStatus = SourceStatus.AMEND;
		entity.regHubId = "4";
		entity.sourceId = "713";
		entity.publishedTs = LocalDateTime.parse("2016-07-04 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector, times(0)).emit(StormStreams.SEQUENCED_OUTBOUND_STREAM,
				new Values(entity.regHubId, entity));
	}

	@Test
	public void shouldNotSendDuplicateNewToOutputStream() {
		LocalDateTime publishedTs = LocalDateTime.parse("2016-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		EntityCacheSeqDetails seqObj1 = new EntityCacheSeqDetails("NEW", publishedTs, "REPORTABLE", "613");
		cacheClient.put("613", seqObj1, bolt.SeqCacheconfig);
		Entity entity = new EntityBuilder().build();
		entity.sourceStatus =SourceStatus.NEW;
		entity.regHubId = "4";
		entity.sourceId = "613";
		entity.publishedTs = LocalDateTime.parse("2017-07-05 04:14:02",
				DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector, times(0)).emit(StormStreams.SEQUENCED_OUTBOUND_STREAM,
				new Values(entity.regHubId, entity));
	}

	@Test
	public void shouldEmitExceptionTuple() {
		Entity entity = new EntityBuilder().build();
		entity.sourceStatus = null;
		OutputCollector collector = mock(OutputCollector.class);
		bolt._collector = collector;
		Tuple tuple = mockNormalTuple(entity);
		bolt.execute(tuple);
		verify(collector, times(2)).emit(any(String.class), any(Values.class));
		verify(collector).emit(StormStreams.EXCEPTION, new Values(entity.regHubId, entity));
	}

}