package com.citi.reghub.core.mongo;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Ignore;
import org.junit.Test;

import com.citi.reghub.core.ConvertToMongoMap;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityBuilder;
import com.citi.reghub.core.InvalidInputException;
import com.citi.reghub.core.MongoUnitRule;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.constants.GlobalProperties;

@Ignore
public class MongoDBUpdateBoltTest {

	@ClassRule
	public static MongoUnitRule mongoUnitRule = new MongoUnitRule();
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	private MongoDBUpdateBolt<Entity> mongoDBUpdateBolt;
	private ConvertToMongoMap toMongoMap;
	
	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}
	
	@Before
	public void setUp(){
		toMongoMap = mock(ConvertToMongoMap.class);
	}
	
	@Test
	public void shouldAckInputTupleSave() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBUpdateBolt = new MongoDBUpdateBolt<>("test", toMongoMap);
		mongoDBUpdateBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(new Document());
		mongoDBUpdateBolt.execute(tuple);
		verify(_collector, times(1)).ack(tuple);
	}
	
	@Test
	public void shouldAckInputTupleSaveNonNullId() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBUpdateBolt = new MongoDBUpdateBolt<>("test", toMongoMap);
		mongoDBUpdateBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(new Document().append("_id", new ObjectId()));
		mongoDBUpdateBolt.execute(tuple);
		verify(_collector, times(1)).ack(tuple);
	}
	
	@Test
	public void shouldAckInputTupleUpsert() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBUpdateBolt = new MongoDBUpdateBolt<>("test", toMongoMap, true);
		mongoDBUpdateBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(new Document().append("_id", new ObjectId()));
		mongoDBUpdateBolt.execute(tuple);
		verify(_collector, times(1)).ack(tuple);
	}
	
	@Test
	public void shouldFailInputTuple() {
		Tuple tuple = null;
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBUpdateBolt = new MongoDBUpdateBolt<>("test", toMongoMap);
		mongoDBUpdateBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(new Document().append("_id", new ObjectId()));
		mongoDBUpdateBolt.execute(tuple);
		verify(_collector, times(1)).fail(tuple);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowExceptionWhenConnectionUrlIsMissing() {
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, new HashMap<>());
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBUpdateBolt = new MongoDBUpdateBolt<>("test", toMongoMap);
		mongoDBUpdateBolt.prepare(stormConf, context, _collector);
	}
	
	@Test
	public void shouldCreateSSLConnection() {
		Tuple tuple = null;
		Map<String, String> props = new PropertiesLoader().getProperties("test");
		props.put("mongodb.password", "kH19akLTpDpj0aVHUndOfS8mTHFL3w3c");
		props.put("mongodb.truststore", "/var/opt/testCert");
		props.put("mongodb.truststore.password", "tsPassword");
		props.put("mongodb.decrypt.key", "testDecryptKey");
		Map<String, Object> stormConf = new HashMap<>();
		stormConf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		mongoDBUpdateBolt = new MongoDBUpdateBolt<>("test", toMongoMap);
		mongoDBUpdateBolt.prepare(stormConf, context, _collector);
		
		when(toMongoMap.toMap(any(Entity.class))).thenReturn(new Document().append("_id", new ObjectId()));
		mongoDBUpdateBolt.execute(tuple);
		verify(_collector, times(1)).fail(tuple);
	}
}
