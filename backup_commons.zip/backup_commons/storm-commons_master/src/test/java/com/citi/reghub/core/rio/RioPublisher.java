package com.citi.reghub.core.rio;

import com.citi.rio.registry.infra.Environment;
import com.citi.rio.registry.infra.Region;
import com.citi.rio.umb.UmbClientFactory;
import com.citi.rio.umb.publish.UmbPublisher;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.Scanner;

public class RioPublisher {
	
	private static final String citifix = "CITIFIX";
	private static final String citiml = "CITIML";
	
	private String msgType = citifix;
	private int msgCount = 1;
	private String rioKey = "263-OASYS_CITIFIX_TEST-002";
	private String messageFile = "m2poSampleTrade.fix";
	
	public RioPublisher msgType(String msgType){
		this.msgType = msgType;
		return this;
	}
	
	public RioPublisher msgCount(int msgCount){
		this.msgCount = msgCount;
		return this;
	}
	
	public RioPublisher messageFile(String messageFile){
		this.messageFile = messageFile;
		return this;
	}
	
	public RioPublisher rioKey(String rioKey){
		this.rioKey = rioKey;
		return this;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void publish() throws Exception {

		UmbClientFactory ucf = new UmbClientFactory(Environment.DEV, Region.NAM);
		UmbPublisher publisher = ucf.createPublisher(rioKey);
		RioPublisher pub = new RioPublisher();
		String msg = null;
		if (citifix.equalsIgnoreCase(msgType)) {
			msg = new Scanner(pub.getClasspathResource(messageFile)).useDelimiter("\\A").next();
		} else {
			msg = pub.getXMLDocument("citiml.xml").asXML();
		}
		for (int i = 1; i <= msgCount; i++) {
			System.out.println("publish time: " + i + "**********");
			publisher.publish(msg);
		}
		publisher.shutdown();
	}

	public Document getXMLDocument(String filename) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document doc = reader.read(getClasspathResource(filename));
		return doc;
	}

	public InputStream getClasspathResource(String fileName) {
		try {
			return getClass().getClassLoader().getResourceAsStream(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args) throws Exception{
		new RioPublisher().msgCount(1).publish();
	}
}
