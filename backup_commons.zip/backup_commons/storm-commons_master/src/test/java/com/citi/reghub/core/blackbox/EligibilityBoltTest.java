package com.citi.reghub.core.blackbox;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.storm.tuple.Tuple;

import com.citi.reghub.core.EligibilityBolt;

public class EligibilityBoltTest extends EligibilityBolt implements EligibilityChangeInterface {
	
	private static final long serialVersionUID = 1L;

	private static int ID_COUNTER = 0;
	
	private final int    			id;
	private String 		 			type;
	
	public EligibilityBoltTest(String ruleGraphName) {
		super(ruleGraphName);
		throw new IllegalArgumentException("Must use constructor specifying type");
	}

	public EligibilityBoltTest(String t, String ruleGraphName) {
		super(ruleGraphName);
		this.type = t;

		synchronized(EligibilityBoltTest.class) {
			id = ID_COUNTER++;
		}

		SingletonBoltTestController.registerBolt(this);
	}

	public int getID() {
		return this.id;
	}
	
	public String getRuleGraphType() {
		return this.type;
	}
	
	public boolean isRuleGraphType(String rgtype) {
		return this.type.equals(rgtype);
	}

	public void process(Tuple input) {
		String srgn = SingletonBoltTestController.getCurrentRuleGraph(this);
		if (!super.ruleGraphName.equals(srgn)) {
			System.out.println("Changing Eligibility Bolt Rule Graph from ["+super.ruleGraphName+"] to ["+srgn+"]");
			super.ruleGraphName = srgn;
			super.ruleGraphCurrentLoadTime = 0;
			super.forceRefreshCache = true;
			super.loadRuleGraph();
		}
		super.process(input);
	}
	
	/**
	 * This is to facilitate black box testing.  
	 * 
	 * @param rulegraphname
	 */
	public void changeRuleGraph(String rgtype, String rulegraphname) {
		if (!isRuleGraphType(rgtype)) {
			return;
		}

		if (super.ruleGraphName.equals(rulegraphname)) {
			return;
		}
		
		super.ruleGraphName = rulegraphname;
	}

}
