package com.citi.reghub.core.blackbox;

public interface EnrichmentChangeInterface {

	/**
	 * This method is used to change the EnrichmentPlan for the underlying bolt.
	 * 
	 * @param planName
	 */
	public void changeEnrichmentPlan(String eptype, String planName);

	public String getEnrichmentPlanType();
	
	public boolean isEnrichmentPlanType(String eptype);
}
