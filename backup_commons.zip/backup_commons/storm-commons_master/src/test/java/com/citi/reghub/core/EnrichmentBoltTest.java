package com.citi.reghub.core;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.MockTupleHelpers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.enrichment.client.EnrichmentClient;
import com.citi.reghub.core.enrichment.client.EnrichmentClientConfig;
import com.citi.reghub.core.enrichment.client.EnrichmentPlan;
import com.citi.reghub.core.enrichment.client.EnrichmentResult;
import com.citi.reghub.core.enrichment.client.SingletonEnrichmentClient;
import com.citi.reghub.core.hrmstrader.client.HrmsTraderClientConfig;
import com.citi.reghub.core.hrmstrader.client.SingletonHrmsTraderClient;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;
import com.citi.reghub.core.refdata.client.RefdataClient;
import com.citi.reghub.core.refdata.client.SingletonRefdataClient;
import com.citi.reghub.core.rules.client.RulesClient;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

@RunWith(JUnit4.class)
public class EnrichmentBoltTest {
	
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";
	
	private EnrichmentResult enrichmentResult;
	public EnrichmentClient enrichmentClient;
	private EnrichmentPlan  enrichmentPlan ;
	private String enrichmentPlanName = "test";
	private EnrichmentBolt bolt;
	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}
		
    @Before
    public void setUp() throws Exception {
    	SingletonRulesClient.setInstance(mock(RulesClient.class));
    	enrichmentClient = mock(EnrichmentClient.class);
    	enrichmentPlan = mock(EnrichmentPlan.class);
    	
    	bolt = new EnrichmentBolt(enrichmentPlanName){
			@Override
			protected void setCacheClient(Map<String, String> topologyConfig) {
				SingletonCacheClient.setInstance(mock(CacheClient.class));
			}
			@Override
			protected void setRuleClient(Map<String, String> topologyConfig) {
				SingletonRulesClient.setInstance(mock(RulesClient.class));
			}
			@Override
			protected void setMetadataClient(Map<String, String> topologyConfig) {
				SingletonMetadataClient.setInstance(mock(MetadataClientConfig.class));
			}
			@Override
			protected void setRefdataClient(Map<String, String> topologyConfig) {
				SingletonRefdataClient.setInstance(mock(RefdataClient.class));				
			}
			@Override
			protected void setHrmsTraderClient(Map<String, String> topologyConfig) {
				SingletonHrmsTraderClient.setInstance(mock(HrmsTraderClientConfig.class));
			}
			@Override
			protected void setEnrichmentClient(Map<String, String> topologyConfig) {
				SingletonEnrichmentClient.setInstance(mock(EnrichmentClientConfig.class));				
			}
		};
		bolt.enrichmentClient = enrichmentClient;
	}	
	
	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		EnrichmentBolt bolt = new EnrichmentBolt(enrichmentPlanName);
		
		bolt.declareOutputFields(declarer);
		
		verify(declarer, times(3)).declareStream(any(String.class), any(Fields.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitInputTuple() {
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		when(enrichmentClient.execute(eq(trade),any(boolean.class),eq(enrichmentPlan))).thenReturn(new EnrichmentResult()) ;
		when(enrichmentClient.getFromService(eq(enrichmentPlanName))).thenReturn(enrichmentPlan) ;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(enrichmentClient,times(1)).execute(trade, true,enrichmentPlan);
		verify(_collector, times(2)).emit(any(String.class), any(Values.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitReportableAndAuditStreamTest(){
		Entity trade = new EntityBuilder().build();
						
		Tuple tuple = mockNormalTuple(trade);
		when(enrichmentClient.execute(eq(trade), any(boolean.class),eq(enrichmentPlan))).thenReturn(new EnrichmentResult());
		when(enrichmentClient.getFromService(eq(enrichmentPlanName))).thenReturn(enrichmentPlan) ;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		when(stormConf.get(GlobalProperties.TOPOLOGY_CONFIG)).thenReturn(stormConf) ;
		bolt.prepare(stormConf, context, _collector);
		
		bolt.execute(tuple);
		verify(enrichmentClient,times(1)).execute(trade, true,enrichmentPlan);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void shouldEmitExceptionAndAuditStream(){
		Entity trade = new EntityBuilder().build();
		Tuple tuple = mockNormalTuple(trade);
		when(enrichmentClient.execute(eq(trade), any(boolean.class), any(EnrichmentPlan.class))).thenReturn(null) ;
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(bolt.getCollector(), times(2)).emit(any(String.class), any(Values.class));
		verify(bolt.getCollector()).emit(StormStreams.EXCEPTION, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldReloadUpdatedEnrichmentPlan() {
		Entity trade = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 10)).build();
		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		when(enrichmentClient.execute(eq(trade), any(boolean.class) ,eq(enrichmentPlan))).thenReturn(new EnrichmentResult());
		when(enrichmentClient.getLastLoadTime(enrichmentPlanName)).thenReturn(12000L);
		when(enrichmentClient.getFromService(eq(enrichmentPlanName))).thenReturn(enrichmentPlan) ;
		bolt.prepare(stormConf, context, _collector);
		when(enrichmentClient.getLastLoadTime(enrichmentPlanName)).thenReturn(13000L);
		bolt.execute(tuple);
		verify(enrichmentClient,times(1)).execute(trade, true,enrichmentPlan);
		verify(enrichmentClient,times(0)).execute(trade, false,enrichmentPlan);
		verify(enrichmentClient,times(2)).getFromService(enrichmentPlanName);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldNotReloadEnrichmentPlan() {
		Entity trade = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 10)).build();
		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		when(enrichmentClient.execute(eq(trade), any(boolean.class),eq(enrichmentPlan))).thenReturn(new EnrichmentResult());
		when(enrichmentClient.getLastLoadTime(enrichmentPlanName)).thenReturn(13000L);
		when(enrichmentClient.getFromService(eq(enrichmentPlanName))).thenReturn(enrichmentPlan) ;
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		verify(enrichmentClient,times(1)).execute(trade, true, enrichmentPlan);
		verify(enrichmentClient,times(0)).execute(trade, false, enrichmentPlan);
		verify(enrichmentClient,times(1)).getFromService(enrichmentPlanName);
		verify(_collector).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector).emit(eq(StormStreams.AUDIT), any(Values.class));
	}
	
	@Test
	public void shouldNotReloadRuleGraphRerun() {
		Entity trade = new EntityBuilder().info("tradeDate", LocalDate.of(2007, 11, 10)).build();
		Tuple tuple = mockNormalTuple(trade);
		Map stormConf = mock(Map.class);
		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);
		when(enrichmentClient.execute(eq(trade), any(boolean.class),eq(enrichmentPlan))).thenReturn(new EnrichmentResult());
		when(enrichmentClient.getLastLoadTime(enrichmentPlanName)).thenReturn(13000L);
		when(enrichmentClient.getFromService(eq(enrichmentPlanName))).thenReturn(enrichmentPlan) ;
		bolt.prepare(stormConf, context, _collector);
		bolt.execute(tuple);
		bolt.execute(tuple);
		verify(enrichmentClient,times(1)).execute(trade, true, enrichmentPlan);
		verify(enrichmentClient,times(1)).execute(trade, false, enrichmentPlan);
		verify(enrichmentClient,times(1)).getFromService(enrichmentPlanName);
		verify(_collector, times(2)).emit(StormStreams.REPORTABLE, new Values(trade.regHubId, trade));
		verify(_collector, times(2)).emit(eq(StormStreams.AUDIT), any(Values.class));
	}


}

