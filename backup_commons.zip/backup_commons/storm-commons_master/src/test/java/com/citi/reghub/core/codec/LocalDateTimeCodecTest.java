package com.citi.reghub.core.codec;

import java.time.LocalDateTime;

import org.junit.Test;

public class LocalDateTimeCodecTest extends CodecTestCase {

	@Test
	public void testLocalDateStringCodec() {
		writeReadCompare(LocalDateTime.now(), new LocalDateTimeCodec());
	}
}
