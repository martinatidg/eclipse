package com.citi.reghub.core.kafka;

import com.citi.reghub.core.InvalidInputException;
import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.kafka.KafkaPropertiesFactory;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.junit.Assert;
import org.junit.Test;

import java.util.Map;

public class KafkaPropertiesFactoryTest {
	
	/*
	 * Consumer Null config reference test
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testNullConsumerConfigRefernce() throws Exception {
		KafkaPropertiesFactory.getKafkaConsumerProps(null);
	}
	
	/*
	 * Producer Null config reference test
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testNullProducerConfigRefernce() throws Exception {
		KafkaPropertiesFactory.getKafkaProducerProps(null, null);
	}
	
	/*
	 * The result map length should be less or equal to the properties defined in ConsumerConfig and prefixed with "kafka.consumer. in application.properties"
	 */
	@Test
	public void testKafkaConsumerPropertiesFactory() {
		try {
			Map<String, String> config  = new PropertiesLoader().getProperties("test");
			Map<String, Object> kafkaConsumerProps = KafkaPropertiesFactory.getKafkaConsumerProps(config);
			int maxConsumerPropsCount = ConsumerConfig.configNames().size();
			Assert.assertTrue("The result map length should be less than or equal to the properties prefixed with kafka.consumer.", kafkaConsumerProps.size() <= maxConsumerPropsCount);
		} catch (Exception e) {
			Assert.fail("The result map length should be less than or equal to the properties prefixed with kafka.consumer.");
		}
	}
	
	/*
	 * The result map length should be less or equal to the properties defined in ConsumerConfig and prefixed with "kafka.consumer. in application.properties"
	 */
	@Test
	public void testKafkaProducerPropertiesFactory() {
		try {
			Map<String, String> config  = new PropertiesLoader().getProperties("test");
			Map<String, Object> kafkaProducerProps = KafkaPropertiesFactory.getKafkaConsumerProps(config);
			int maxProducerPropsCount = ProducerConfig.configNames().size();
			Assert.assertTrue("The result map length should be less than or equal to the properties prefixed with kafka.producer.", kafkaProducerProps.size() <= maxProducerPropsCount);
		} catch (Exception e) {
			Assert.fail("The result map length should be less than or equal to the properties prefixed with kafka.producer.");
		}
	}
}
