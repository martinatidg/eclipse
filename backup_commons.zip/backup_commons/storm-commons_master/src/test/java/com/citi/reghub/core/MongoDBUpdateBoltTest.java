package com.citi.reghub.core;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;


@RunWith(JUnit4.class)
@Ignore
public class MongoDBUpdateBoltTest {
/*
	private static final String SYSTEM_COMPONENT_ID = "irrelevant_component_id";
	private static final String STREAM_ID = "irrelevant_stream_id";

	public MongoDBUpdateBoltTest() {
		super(new TestMongoBroker());
	}

	private Tuple mockNormalTuple(Object obj) {
		Tuple tuple = MockTupleHelpers.mockTuple(SYSTEM_COMPONENT_ID, STREAM_ID);
		when(tuple.getValueByField("message")).thenReturn(obj);
		return tuple;
	}

	@Test
	public void shouldDeclareOutputFields() {
		OutputFieldsDeclarer declarer = mock(OutputFieldsDeclarer.class);
		MongoDBUpdateBolt<Entity> mongoBolt = new MongoDBUpdateBolt<Entity>();

		mongoBolt.declareOutputFields(declarer);

		verify(declarer, times(0)).declareStream(any(String.class), any(Fields.class));
	}

	@Test
	public void shouldUpsertTupleInMongo() {
//		final Datastore datastore = getDatastore();

		Entity entity = new EntityBuilder().build();
		entity.regHubId = "update_test_reghub_id";
		entity.sourceStatus = "EXCEPTION";
		entity.sourceVersion = "1";

		Tuple originalTuple = mockNormalTuple(entity);
		MongoDBUpdateBolt<Entity> mongoBolt = new MongoDBUpdateBolt<Entity>();

		Map stormConf = mock(Map.class);
		when(stormConf.get(GlobalPropertiesConstants.TOPOLGY_CONFIG))
		.thenReturn(new HashMap<String, String>(){{ put(GlobalPropertiesConstants.MONGO_URL , getMongoUri());}});

		TopologyContext context = mock(TopologyContext.class);
		OutputCollector _collector = mock(OutputCollector.class);

		mongoBolt.prepare(stormConf, context, _collector);

		mongoBolt.execute(originalTuple);

		Entity dbEntity= null;
//		dbEntity = datastore.createQuery(Entity.class).field("regHubId").equal(entity.regHubId).get();
		assertEquals(entity.regHubId, dbEntity.regHubId);

		entity.sourceStatus = "REPORTABLE";
		entity.sourceVersion = "2";
		Tuple updateTuple = mockNormalTuple(entity);

		mongoBolt.execute(updateTuple);

		Entity updatedEntity = null;
//		updatedEntity = datastore.createQuery(Entity.class).field("regHubId").equal(entity.regHubId).get();
		assertEquals(entity.regHubId, dbEntity.regHubId);
		assertEquals(entity.sourceStatus, updatedEntity.sourceStatus);
		assertEquals(entity.sourceVersion, updatedEntity.sourceVersion);
	}
*/

}
