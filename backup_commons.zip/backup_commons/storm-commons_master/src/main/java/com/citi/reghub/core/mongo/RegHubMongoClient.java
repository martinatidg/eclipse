package com.citi.reghub.core.mongo;

import java.util.Map;

import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.citi.reghub.core.codec.BigDecimalCodec;
import com.citi.reghub.core.codec.LocalDateCodec;
import com.citi.reghub.core.codec.LocalDateTimeCodec;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;

public class RegHubMongoClient {
    
  Logger LOGGER=LoggerFactory.getLogger(RegHubMongoClient.class);
  
	public static final String CONNECTION_URL = "url";
	public static final String PASSWORD = "password";
	public static final String TRUSTSTORE = "trustStore";
	public static final String TRUSTSTORE_PASSWORD = "trustStorePassword";
	public static final String DECRYPT_KEY = "decryptKey";

	private final MongoClient client;
	private final MongoDatabase database;
	private final MongoClientOptions.Builder builder;
	private CodecRegistry codecRegistry = null;
	{
        CodecRegistry defaultCodecRegistry = MongoClient.getDefaultCodecRegistry();
        CodecRegistry java8Codecs = CodecRegistries.fromCodecs(new LocalDateTimeCodec(), new LocalDateCodec(), new BigDecimalCodec());
        codecRegistry = CodecRegistries.fromRegistries(defaultCodecRegistry, java8Codecs);
    }

    public RegHubMongoClient(Map<String, Object> mongoProps) {
    	String connectionUrl = mongoProps.get(CONNECTION_URL).toString();
		String password = mongoProps.get(PASSWORD).toString();
		String decryptKey = mongoProps.get(DECRYPT_KEY).toString();
		String trustStore = mongoProps.get(TRUSTSTORE).toString();
		String trustStorePassword = mongoProps.get(TRUSTSTORE_PASSWORD).toString();
		LOGGER.info("ConnectionURL MongoDB {}",connectionUrl);
		LOGGER.info("trustStore MongoDB {}",connectionUrl);
		System.setProperty("javax.net.ssl.trustStore", trustStore);
		System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
		builder = MongoClientOptions.builder()
				.sslEnabled(true)
				.sslInvalidHostNameAllowed(true)
				.codecRegistry(codecRegistry);
		connectionUrl = connectionUrl.replace("${password}", jasyptEncryptor(decryptKey).decrypt(password));
		LOGGER.info("javax.net.ssl.trustStore MongoDB {}",System.getProperty("javax.net.ssl.trustStore"));
		LOGGER.info("javax.net.ssl.trustStorePassword MongoDB {}",System.getProperty("javax.net.ssl.trustStorePassword"));
		MongoClientURI uri = new MongoClientURI(connectionUrl, builder);
		this.client = new MongoClient(uri);
        database = client.getDatabase(uri.getDatabase());
    }

    public RegHubMongoClient(String url) {
    	builder = MongoClientOptions.builder().codecRegistry(codecRegistry);
    	MongoClientURI uri = new MongoClientURI(url, builder);
        this.client = new MongoClient(uri);
        database = client.getDatabase(uri.getDatabase());
    }

    public MongoClient getClient() {
        return client;
    }

    public MongoDatabase getDatabase() {
        return database;
    }

    public void close(){
        client.close();
    }

    public StringEncryptor jasyptEncryptor(String decryptKey) {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword(decryptKey);
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setKeyObtentionIterations("1000");
        config.setPoolSize("1");
        config.setProviderName("SunJCE");
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        config.setStringOutputType("base64");
        encryptor.setConfig(config);
        return encryptor;
    }
    
}
