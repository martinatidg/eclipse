package com.citi.reghub.core.codec;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.bson.BsonReader;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;

public class LocalDateCodec implements Codec<LocalDate> {

    @Override
    public LocalDate decode(BsonReader bsonReader, DecoderContext decoderContext) {
    	Instant instant = Instant.ofEpochMilli(bsonReader.readDateTime());
    	return LocalDateTime.ofInstant(instant, ZoneOffset.UTC).toLocalDate();
    }

    @Override
    public void encode(BsonWriter bsonWriter, LocalDate localDate, EncoderContext encoderContext) {
        long toEpochMilli = localDate.atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli();
        bsonWriter.writeDateTime(toEpochMilli);
    }

    @Override
    public Class<LocalDate> getEncoderClass() {
        return LocalDate.class;
    }
}
