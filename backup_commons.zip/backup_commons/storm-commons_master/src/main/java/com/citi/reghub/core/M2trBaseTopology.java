package com.citi.reghub.core;

import org.apache.storm.Config;

public class M2trBaseTopology extends BaseTopology{
	
	@Override
	protected Config getTopologyConfig() {
		Config conf = new Config();
		conf.setDebug(false);
		conf.put(Config.TOPOLOGY_EXECUTOR_RECEIVE_BUFFER_SIZE, 256);
		conf.put(Config.TOPOLOGY_EXECUTOR_SEND_BUFFER_SIZE, 256);
		conf.put(Config.TOPOLOGY_BACKPRESSURE_ENABLE, true);
		conf.put(Config.TOPOLOGY_MESSAGE_TIMEOUT_SECS, 30);
		return conf;
	}

}
