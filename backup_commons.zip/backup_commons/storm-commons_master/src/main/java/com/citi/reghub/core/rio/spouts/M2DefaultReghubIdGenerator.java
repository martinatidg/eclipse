package com.citi.reghub.core.rio.spouts;

import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.citi.reghub.core.constants.M2ReghubIdGeneratorConstants;

public class M2DefaultReghubIdGenerator implements M2ReghubIdGenerator{

	@Override
	public String generateReghubId(String stream, String flow, String messagePayload) {
		if (StringUtils.isNotEmpty(stream) && StringUtils.isNotEmpty(flow)) {
			return stream + M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + flow
					+ M2ReghubIdGeneratorConstants.M2_REGHUBID_SEPARATOR + UUID.randomUUID();
		} else {
			return null;
		}

	}

}
