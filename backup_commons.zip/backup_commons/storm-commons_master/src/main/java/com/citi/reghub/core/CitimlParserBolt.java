package com.citi.reghub.core;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.constants.StormConstants;

public class CitimlParserBolt extends RegHubBolt {

	private static final long serialVersionUID = 1L;

	private OutputCollector collector = null;
	
	private DocumentBuilderFactory factory;
	private DocumentBuilder builder;
	

	private static final Logger LOG = LoggerFactory.getLogger(CitimlParserBolt.class);

	@SuppressWarnings("rawtypes")
	@Override
	public void prepareBolt(Map config, TopologyContext topologyContext, OutputCollector outputCollector) {
		collector = outputCollector;
		try {
			factory = DocumentBuilderFactory.newInstance();
			builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		}
	};

	public void process(Tuple tuple) {
		String reghubId = (String) tuple.getValueByField("key");
		RawMsgObject rawMsgObject = (RawMsgObject) tuple.getValueByField("message");
		String citimlString = rawMsgObject.getMessage();
		LOG.info("citiml message is : " + citimlString);
		try {
			Document document = builder.parse(new InputSource(new StringReader(citimlString)));
			document.getDocumentElement().normalize();
			collector.emit(StormStreams.SOURCE,new Values(reghubId, document));
			
		} catch (SAXException | IOException e) {
			throw new RuntimeException(e);
		}
		collector.ack(tuple);
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.SOURCE,new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
		declarer.declareStream(StormStreams.AUDIT, new Fields(TUPLE_KEY, TUPLE_MESSAGE));
	}

	@Override
	public OutputCollector getCollector() {
		return collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SOURCE_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SOURCE);
		exceptionTags.add(StormConstants.PARSE_EXCEPTION);
		exceptionTags.add(StormConstants.ENTITY_CREATION_EXCEPTION);
		return exceptionTags;
	}
}