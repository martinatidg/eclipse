package com.citi.reghub.core.kafka;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;

public class KafkaPropertiesFactory {

	
	public static Map<String, Object> getKafkaConsumerProps(Map<String, String> config) {

		Validate.notNull(config, "Config map not found");
		Map<String, Object> kafkaConsumerProps = new HashMap<>();
		
		// Populate common kafka properties
		kafkaConsumerProps.putAll(getKafkaCommonProps(config));
		
		String consumerPropertiesPrefix = "kafka.consumer.";
		Set<String> allConsumerProps = ConsumerConfig.configNames();
		allConsumerProps.forEach(field -> {
			String propertyValue = config.get(consumerPropertiesPrefix + field);
			if(propertyValue != null){
				kafkaConsumerProps.put(field, propertyValue);
			}	
		});
		
		return kafkaConsumerProps;
		
	}
	
	public static Properties getKafkaProducerProps(Map<String, String> config, String producerName) {
		
		Validate.notNull(config, "Config map not found");
		Properties kafkaProducerProps = new Properties();
		
		// Populate common kafka properties
		kafkaProducerProps.putAll(getKafkaCommonProps(config));
		
		String producerPropsPrefix = StringUtils.isBlank(producerName) ? "kafka.producer." : producerName + ".kafka.producer.";
		Set<String> producerConstants = ProducerConfig.configNames();
		
		producerConstants.forEach(field -> {
			String propertyValue = config.get(producerPropsPrefix + field);
			if(propertyValue != null){
				kafkaProducerProps.put(field, propertyValue);
			}	
		});
		
		return kafkaProducerProps;
	}
	
	public static Map<String, String> getKafkaCommonProps(Map<String, String> config){
		String commonsPropsPrefix = "kafka.commons.";
		int offset = commonsPropsPrefix.trim().length();
		return config.entrySet().stream()
			.filter(map -> map.getKey().startsWith(commonsPropsPrefix))
			.collect(Collectors.toMap(map -> map.getKey().substring(offset), map -> map.getValue()));
	}
	
}
