package com.citi.reghub.core.constants;

public interface M2ReghubIdGeneratorConstants {
	
	String M2_REGHUBID_SEPARATOR = "_";
	String M2_REGHUBID_CITIML_PATTERN = "<.*"+"citimlMessageId messageIdScheme="+".+?"+">(.+?)<"+".*citimlMessageId>";
	String M2_REGHUBID_CITIML_PATTERN_FIRST_LINEBREAK = "<.*"+"citimlMessageId"+"\\R.*"+"messageIdScheme="+".+?"+">(.+?)<"+".*citimlMessageId>";
	
	String M2_CITIFIX_MESSAGE = "citifix";
	String M2_CITIML_MESSAGE ="citiml";
	String M2_CITIFIX_MESSAGE_TYPE_PATTERN = "35=(.+?)";
	String M2_REGHUBID_CITIFIX_URT_PATTERN = "100205=(.+?)";
	String M2_REGHUBID_CITIFIX_RFQ_PATTERN = "117=(.+?)";
	String M2_REGHUBID_CITIFIX_RIO_PATTERN = "10018=(.+?)";
	String M2_CITIFIX_RIO_MESSAGE_Type = "RIO";
	String M2_CITIFIX_URT_MESSAGE_Type = "URT";
	String M2_CITIFIX_RFQ_MESSAGE_Type = "RFQ";
}
