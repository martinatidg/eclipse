package com.citi.reghub.core;

import com.citi.reghub.core.Entity;

import java.io.Serializable;

public interface EntityMapper extends Serializable{
	
	public abstract Entity mapToEntity(Object message, Entity entity);

}
