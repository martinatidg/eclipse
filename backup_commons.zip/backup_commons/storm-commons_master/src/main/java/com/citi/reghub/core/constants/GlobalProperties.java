package com.citi.reghub.core.constants;

public interface GlobalProperties {

	String TOPOLOGY_NAME = "topology.name";
	String TOPOLOGY_CONFIG = "topologyConfig";
	String TOPOLOGY_FLOW_NAME = "topology.flow";
	String TOPOLOGY_STREAM_NAME = "topology.stream";
	String TOPOLOGY_MESSAGE_TYPE = "topology.messageType";
	String KAFKA_TOPIC_NAMES = "kafka.input.topic.names";
	String BOLT_KAFKA_TOPIC_NAMES = "kafka.topic.names";
	
	String MONGO_URL = "mongodb.url";
	String MONGO_PASSWORD = "mongodb.password";
	String DECRYPT_KEY= "mongodb.decrypt.key";
	String MONGO_TRUSTSTORE = "mongodb.truststore";
	String MONGO_TRUSTSTORE_PASSWORD = "mongodb.truststore.password";
	
	//APA common properties
	String APA_CONFIG= "apa.config";
	String APA_TOPIC_NAME = "apa.topic.name";
	String APA_USERNAME = "apa.jms.username";
	String APA_PWD_KEY = "apa.jms.password";
	String APA_JNDI_NAME= "apa.jms.jndi.name";
	String APA_PROVIDER_URL = "apa.jms.provider.url";
	String APA_TARGETS = "destination.targets";
	
	String RULE_GRAPH_SERVICE_URL = "rule.graph.service.url";
	String METADTA_SERVICE_URL = "metadata.service.url";
	String ENRICHMENT_SERVICE_URL = "enrichment.service.url";
	String ACCOUNT_SERVICE_URL = "account.service.url";
	String SECURITY_SERVICE_URL = "security.service.url";
	String OVEERRIDEEN_ENTITY_SERVICE_URL = "overriden.entity.url";
	String RAW_OUTBOUND_SERVICE_URL = "raw.outbound.service.url";
	String RAW_OUTBOUND_SERVICE_SEQ_URL = "raw.outbound.service.seqUrl";
	String RAW_OUTBOUND_SERVICE_REG_HUB_ID_URL = "raw.outbound.service.regHubUrl";
	String TOPOLOGY_MESSAGE_SOURCE_SYSTEM = "topology.messageSourceSystem";
	String ENTITY_SERVICE_URL = "entity.service.url";
	String HRMS_TRADER_SERVICE_URL = "hrmstrader.service.url";
}
