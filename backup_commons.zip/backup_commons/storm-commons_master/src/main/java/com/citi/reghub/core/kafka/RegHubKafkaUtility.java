package com.citi.reghub.core.kafka;

import java.util.Map;
import java.util.stream.IntStream;

import static com.citi.reghub.core.kafka.KafkaSpoutConfigConstants.DOT;
import static com.citi.reghub.core.kafka.KafkaSpoutConfigConstants.UNDERSCORE;
import static com.citi.reghub.core.kafka.KafkaSpoutConfigConstants.TOPICS_SEPARATOR;

/**
 * @author cv75309
 * 
 * @since: 11 Nov 2017
 * 
 * Utility class for Reghub Kafka module. 
 *
 */
public class RegHubKafkaUtility {

	/**
  	 * @param genericTopicsAsString: List of all generic topics to be consumed by the spout
  	 * @return list of stream specific input kafka topics (along with the generic topics) separated by TOPICS_SEPARATOR
  	 * 
  	 * This method will append stream name to each generic kafka topic
  	 */
	public static String getSourceKafkaTopics(Map<String, String> topologyConfig, String topicKey, String[] streamNamesArray) {
		
		String genericTopicsAsString = topologyConfig.get(topicKey);

		if(streamNamesArray==null || streamNamesArray.length==0 || genericTopicsAsString==null)
			return genericTopicsAsString;
  		
		String[] topicsArr = genericTopicsAsString.split(TOPICS_SEPARATOR);
		StringBuilder result = new StringBuilder();
		
		IntStream.range(0, topicsArr.length).forEach(index -> {
			result.append(topicsArr[index]);
			IntStream.range(0, streamNamesArray.length).forEach(streamIndex -> {
				result.append(TOPICS_SEPARATOR);
				result.append(topicsArr[index] + UNDERSCORE + streamNamesArray[streamIndex]);
			});
			if (index < (topicsArr.length - 1))
				result.append(TOPICS_SEPARATOR);
		});

		String streamSpecificKafkaTopics = getStreamSpecificKafkaTopics(topologyConfig, topicKey, streamNamesArray);
		if (!streamSpecificKafkaTopics.isEmpty())
			result.append(TOPICS_SEPARATOR + streamSpecificKafkaTopics);

		return result.toString();
	}

 	/**
 	 * @param topologyConfig
 	 * @param topicKey
 	 * @return: List of stream specific topics as String separated by TOPICS_SEPARATOR
 	 * 
 	 * This method will iterate over streamNames and check if the configuration has got any stream specific topic key. 
 	 * If the property is present, it will append the value to the result.
 	 */
 	public static String getStreamSpecificKafkaTopics(Map<String, String> topologyConfig, String topicKey, String[] streamNamesArray) {
 		StringBuilder result = new StringBuilder();
 		
 		if(topologyConfig==null || topologyConfig.size()==0 || topologyConfig.isEmpty() || streamNamesArray==null || streamNamesArray.length==0)
			return result.toString();
		
			IntStream.range(0, streamNamesArray.length).forEach(streamIndex -> {
				String streamSpecificTopics = topologyConfig.get(streamNamesArray[streamIndex]+DOT+topicKey);
				if(streamSpecificTopics!=null && !streamSpecificTopics.isEmpty()){
					if(streamIndex>0)
						result.append(TOPICS_SEPARATOR);
					result.append(streamSpecificTopics);
				}
				
			});
		 
		return result.toString();
	}

	
}
