package com.citi.reghub.core;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.Entity;
import com.citi.reghub.core.EntityCacheSeqDetails;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.EventTypes;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.SourceStatus;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;


public class SequencerBolt extends RegHubBolt {

	private static final long serialVersionUID = 1L;
	protected static final Logger LOG = LoggerFactory.getLogger(SequencerBolt.class);
	public static final String SEQUECNER_CACHE_COLLECTION_NAME = "cache.collection.name";
	
	public OutputCollector _collector;
	public CacheClient cacheClient;
	CacheClient lockCacheClient;
	public Map<String, String> SeqCacheconfig;
	//String hazelcastLockPeriod = "1000";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		setCacheClient(topologyConfig);
		SeqCacheconfig = new HashMap<>();
		SeqCacheconfig.put(CacheClient.CACHE_COLLECTION_NAME,topologyConfig.get(SEQUECNER_CACHE_COLLECTION_NAME));
		SeqCacheconfig.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		cacheClient = SingletonCacheClient.getInstance();
	}
	
	public void process(Tuple input) {
		Entity message = (Entity) input.getValueByField("message");
		String auditResult;
		String key = message.sourceId;
		String sourceStatus = message.sourceStatus;
		
		// If unable to lock, quit early!
		if (!cacheClient.tryLock(key, SeqCacheconfig)) {
			auditResult = "NO-LOCK";
			_collector.emit(StormStreams.PUSHBACK_REPORTABLE_STREAM, new Values(message.regHubId, message));
			pushMessageToAuditStream(message, auditResult);
			return;
		}			
			
		Map<String, Object> auditinfo;
		try {
			EntityCacheSeqDetails seqObjWithSameKey=(EntityCacheSeqDetails)cacheClient.get(key, SeqCacheconfig);
			if((seqObjWithSameKey == null) && (sourceStatus.equalsIgnoreCase(SourceStatus.NEW))) {
					message.status = EntityStatus.REPORTABLE;
					storeMessageInCacheAndPushToSequencerOutbound(message);
			}
			else if((seqObjWithSameKey != null) && (seqObjWithSameKey.publishedTs.isBefore(message.publishedTs))){
				if ((sourceStatus.equalsIgnoreCase(SourceStatus.NEW)) ||  ((sourceStatus.equalsIgnoreCase(SourceStatus.AMEND)) && (seqObjWithSameKey.sourceStatus.equalsIgnoreCase(SourceStatus.CANCEL)))) {
					message.status = EntityStatus.PENDING;
				}
				else {
					message.status =EntityStatus.REPORTABLE;
					storeMessageInCacheAndPushToSequencerOutbound(message);
				}
			}
			else {
				message.status = EntityStatus.PENDING;
			}
			
			auditinfo = getAuditInfo(message, seqObjWithSameKey);
		}
		finally {
			cacheClient.unlock(key, SeqCacheconfig);
		}
		
		auditResult = message.status;
		_collector.emit(StormStreams.COMMON_REPORTABLE_STREAM, new Values(message.regHubId, message));

		pushMessageToAuditStream(message, auditResult, auditinfo);
		_collector.ack(input);
	}

	private final Map<String, Object> getAuditInfo(Entity message, EntityCacheSeqDetails priorMessage) {
		Map<String, Object> m = new HashMap<String, Object>();
		if (priorMessage != null) {
			Map<String, Object> pe = new HashMap<String, Object>();
			pe.put("entity_status", priorMessage.getStatus());
			pe.put("entity_source_status", priorMessage.getSourceStatus());
			pe.put("entity_sourceId", priorMessage.getSourceId());
			pe.put("entity_published", priorMessage.getPublishedTs());
			m.put("prior_entity", pe);
		}
		
		Map<String, Object> ne = new HashMap<String, Object>();
		ne.put("entity_status", message.status);
		ne.put("entity_source_status", message.sourceStatus);
		ne.put("entity_sourceId", message.sourceId);
		ne.put("entity_published", message.publishedTs);
		m.put("entity", ne);
		
		return m;
	}
	
	public void storeMessageInCacheAndPushToSequencerOutbound(Entity message){
		EntityCacheSeqDetails seqObj = 	new EntityCacheSeqDetails(message);
		String key = message.sourceId;
		cacheClient.put(key, seqObj, SeqCacheconfig);
		_collector.emit(StormStreams.SEQUENCED_OUTBOUND_STREAM, new Values(message.regHubId, message));
	}
	
	public void pushMessageToAuditStream(Entity message, String auditResult) {
		Audit audit = message.toAudit();
		audit.event = EventTypes.SEQUENCING;
		audit.result = auditResult;
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}
	
	public void pushMessageToAuditStream(Entity message, String auditResult, Map<String, Object> auditinfo) {
		Audit audit = message.toAudit();
		audit.event = EventTypes.SEQUENCING;
		audit.result = auditResult;
		audit.info.putAll(auditinfo);
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
	}
	
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.PUSHBACK_REPORTABLE_STREAM, new Fields("key", "message"));
		declarer.declareStream(StormStreams.SEQUENCED_OUTBOUND_STREAM, new Fields("key", "message"));
		declarer.declareStream(StormStreams.COMMON_REPORTABLE_STREAM, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
	}

	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SEQUENCER_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SEQUENCER);
		return exceptionTags;
	}
}

