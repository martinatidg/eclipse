package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;

import org.apache.commons.lang.Validate;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.jms.JMSConnectionClient;

/**
 * 
 * TradeEchoBolt which sends the Fix message to JMS, which acts like intermediary .
 *
 */

public class APASenderBolt extends RegHubBolt {
	
	private static final Logger LOG = LoggerFactory.getLogger(APASenderBolt.class);
	private static final long serialVersionUID = 1L;
	public static final String DEFAULT_APA_TARGET = "tradecho";
	public static final String APA_TARGET = "apaTarget";
	protected OutputCollector collector;
	JMSConnectionClient jmsClient ;
	//protected JMSConnectionClient jmsConnection;
	protected Map<String, JMSConnectionClient> jmsMap = new HashMap<String, JMSConnectionClient>();
	
	@SuppressWarnings("unchecked")
	@Override
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		LOG.info("Entering APASenderBolt::prepareBolt  Preparing APASenderBolt");
		this.collector = collector;
		
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);

		String targets = topologyConfig.get(GlobalProperties.APA_TARGETS);
		if (targets != null && targets.length() > 0) {
			String[] arrTarget = targets.split(",");
			for (String target : arrTarget) {
				createJmsConnection(topologyConfig, target.trim());
			}
		} else {
			createJmsConnection(topologyConfig, null);
		}
		
		LOG.info("Exit APASenderBolt::prepareBolt ");
	}
	
	@Override
	public void process(Tuple tuple) throws Exception {
		try {
			LOG.info("Entering APASenderBolt::process ");
			String message = (String) tuple.getValueByField(StormConstants.MESSAGE);
			LOG.info("Message Received --> {}",message);
			
			String target = (String) tuple.getValueByField(APA_TARGET);
			JMSConnectionClient jmsConnection = getJmsConnection(target);
			
			jmsConnection.sendMessage(message);
			this.collector.ack(tuple);
			LOG.info("Exit APASenderBolt::process ");
		} catch (Exception e) {
			LOG.error("Error sending message to TradeEcho", e);
			this.collector.reportError(e);
			this.collector.fail(tuple);
			throw e;
		}
		
	}

	@Override
	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
	
	}

	@Override
	public OutputCollector getCollector() {

		return collector;
	}


	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.SENDER_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.SENDER);
		return exceptionTags;
	}
	
	private String getConfiguration(Map<String, String> config, String configKey, String target) {
		return config.get(getConfigurationKey(target, configKey));
	}
	
	private String getConfigurationKey(String target, String configKey) {
		return target == null ? configKey : target + "." + configKey;
	}
	
	private void putJmsConnection(String target, JMSConnectionClient jmsClient) {
		jmsMap.put(getTarget(target), jmsClient);
	}
	
	private JMSConnectionClient getJmsConnection(String target) {
		return jmsMap.get(getTarget(target));
	}
	
	private String getTarget(String target) {
		return target == null ? DEFAULT_APA_TARGET : target;
	}
	
	private void createJmsConnection(Map<String, String> topologyConfig, String target) {
		Validate.notEmpty(getConfiguration(topologyConfig, GlobalProperties.APA_PROVIDER_URL, target), "Provider URL can not be blank or null");
		jmsClient = new JMSConnectionClient(topologyConfig, target);
		try {
			jmsClient.initConnection();
			LOG.info("Successfully created JMS Connection for {}", target);
			putJmsConnection(target, jmsClient);
		} catch (Exception e) {
			LOG.error("Exception occured while initializing JMS Connection : {}", e);
			this.collector.reportError(e);
		}
	}
	@Override
	public void cleanup() {
		try {
			jmsClient.close();
		} catch (JMSException e) {
			LOG.error("Error while closing JMS Connection", e);
		}
    }
	
}
