package com.citi.reghub.core.kafka;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.storm.kafka.bolt.mapper.FieldNameBasedTupleToKafkaMapper;
import org.apache.storm.kafka.spout.Func;
import org.apache.storm.kafka.spout.KafkaSpout;
import org.apache.storm.kafka.spout.KafkaSpoutConfig;
import org.apache.storm.kafka.spout.KafkaSpoutConfig.FirstPollOffsetStrategy;
import org.apache.storm.kafka.spout.KafkaSpoutRetryExponentialBackoff;
import org.apache.storm.kafka.spout.KafkaSpoutRetryExponentialBackoff.TimeInterval;
import org.apache.storm.kafka.spout.KafkaSpoutRetryService;
import org.apache.storm.kafka.spout.RecordTranslator;
import org.apache.storm.kafka.spout.SimpleRecordTranslator;
import org.apache.storm.shade.org.apache.commons.lang.Validate;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;

import com.citi.reghub.core.constants.GlobalProperties;

public class RegHubKafkaSpout<K, V> implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String ERROR_MESSAGE = "Please provide kafka connection details.";
	private final String topicNames;
	private final Map<String, String> config;
    private final Class<? extends Deserializer<K>> keyDesClazz;
    private final Class<? extends Deserializer<V>> valueDesClazz;
    private final RecordTranslator<K, V> translator;
    public static final long DEFAULT_OFFSET_COMMIT_PERIOD_MS = 10000;
    public static final long DEFAULT_INITAIL_DELAY_MS = 500;
    public static final long DEFAULT_DELAY_PERIOD_MS = 2;
    public static final long DEFAULT_MAX_DELAY_PERIOD_MS = 10;
    public static final int DEFAULT_MAX_UNCOMMITTED_OFFSETS = 1000;
    public static final String DEFAULT_AUTO_OFFSET_REST = "UNCOMMITTED_EARLIEST";
    
	public RegHubKafkaSpout(SpoutBuilder<K, V> builder) {
		this.topicNames = builder.topicNames;
		this.config = builder.config;
		this.keyDesClazz = builder.keyDesClazz;
		this.valueDesClazz = builder.valueDesClazz;
		this.translator = builder.translator;
	}
	
	public static SpoutBuilder<?, ?> builder(String topicNames, String streamName, Map<String, String> config) {
        return new SpoutBuilder<>(topicNames, streamName, config);
    }
	
	public KafkaSpout<K, V> getSpout() {
		return new KafkaSpout<>(getKafkaSpoutConfig());
	}
	
	protected KafkaSpoutConfig<K, V> getKafkaSpoutConfig() {
		String groupId;
		String[] topicNameArray = topicNames.split(",");
		int maxUncommittedOffsets = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_MAX_UNCOMMITTED_OFFSETS) != null ? Integer.parseInt(config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_MAX_UNCOMMITTED_OFFSETS)) : DEFAULT_MAX_UNCOMMITTED_OFFSETS;
		long offsetCommitPeriod = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_OFFSET_COMMIT_PERIOD_MS) != null ? Long.parseLong(config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_OFFSET_COMMIT_PERIOD_MS)) : DEFAULT_OFFSET_COMMIT_PERIOD_MS;
		String autoOffsetReset = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_AUTO_OFFSET_RESET) != null ? config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_AUTO_OFFSET_RESET) : DEFAULT_AUTO_OFFSET_REST;
		FirstPollOffsetStrategy firstPollOffsetStrategy = FirstPollOffsetStrategy.valueOf(autoOffsetReset.toUpperCase());
		
		Map<String, Object> consumerProps = KafkaPropertiesFactory.getKafkaConsumerProps(config); 
		Validate.notNull(consumerProps.get(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG), ERROR_MESSAGE);
		String bootstrapServers = consumerProps.get(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG).toString();
		if(null!=config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_CONSUMER_GROUP_ID)){
			 groupId = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_CONSUMER_GROUP_ID);
		}else{
			 groupId = config.get(GlobalProperties.TOPOLOGY_NAME) + "_" + topicNameArray[0] + "_consumer";	
		}
		
		
		return KafkaSpoutConfig.builder(bootstrapServers, topicNameArray)
				.setProp(consumerProps)
				.setKey(this.keyDesClazz)
				.setValue(this.valueDesClazz)
				.setGroupId(groupId)
				.setRetry(getRetryService())
				.setRecordTranslator(this.translator)
				.setOffsetCommitPeriodMs(offsetCommitPeriod)
				.setFirstPollOffsetStrategy(firstPollOffsetStrategy)
				.setMaxUncommittedOffsets(maxUncommittedOffsets)
				.build();
	}

	protected KafkaSpoutRetryService getRetryService() {
		long initialDelay = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_INITIAL_DELAY_MICROSECONDS) != null ? Long.parseLong(config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_INITIAL_DELAY_MICROSECONDS)) : DEFAULT_INITAIL_DELAY_MS;
		long delayPeriod = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_DELAY_PERIOD_MILLISECONDS) != null ? Long.parseLong(config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_DELAY_PERIOD_MILLISECONDS)) : DEFAULT_DELAY_PERIOD_MS;
		int maxRetries = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_MAX_RETRIES_COUNT) != null ? Integer.parseInt(config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_MAX_RETRIES_COUNT)) : Integer.MAX_VALUE;
		long maxDelay = config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_MAX_DELAY_SECONDS) != null ? Long.parseLong(config.get(KafkaSpoutConfigConstants.KAFKA_SPOUT_MAX_DELAY_SECONDS)) : DEFAULT_MAX_DELAY_PERIOD_MS;
		return new KafkaSpoutRetryExponentialBackoff(
				TimeInterval.microSeconds(initialDelay),
				TimeInterval.milliSeconds(delayPeriod),
				maxRetries,
				TimeInterval.seconds(maxDelay)
		);
	}
	
	public static class SpoutBuilder<K,V> implements Serializable{

		private static final long serialVersionUID = 1L;
		private final String topicNames;
		private final String streamName;
		private final Map<String, String> config;
		private final Class<? extends Deserializer<K>> keyDesClazz;
		private final Class<? extends Deserializer<V>> valueDesClazz;
		
		private RecordTranslator<K, V> translator;
		
		public SpoutBuilder(String topicNames, String streamName, Map<String, String> config) {
	        this.topicNames = topicNames;
	        this.streamName = streamName;
	        Validate.notNull(config, "Config map not found");
	        this.config = config;
	        keyDesClazz = null;
	        valueDesClazz = null;
	    }
	    
	    private SpoutBuilder(SpoutBuilder<?, ?> builder, Class<? extends Deserializer<K>> keyDesClazz, Class<? extends Deserializer<V>> valueDesClazz) {
	        this.topicNames = builder.topicNames;
	        this.streamName = builder.streamName;
	    	this.config = new HashMap<>(builder.config);
	        this.translator = new SimpleRecordTranslator<>(
	        		recordToTupleTranslator, new Fields(FieldNameBasedTupleToKafkaMapper.BOLT_KEY, FieldNameBasedTupleToKafkaMapper.BOLT_MESSAGE), streamName);
	        this.keyDesClazz = keyDesClazz;
	        this.valueDesClazz = valueDesClazz;
	    }
	    
	    public <NK> SpoutBuilder<NK, V> setKeyDesClazz(Class<? extends Deserializer<NK>> keyDesClazz) {
	        return new SpoutBuilder<>(this, keyDesClazz, null);
	    }
	    
	    public <NV> SpoutBuilder<K, NV> setValueDesClazz(Class<? extends Deserializer<NV>> valueDesClazz) {
	        return new SpoutBuilder<>(this, keyDesClazz, valueDesClazz);
	    }
	    
	    public RegHubKafkaSpout<K, V> build(){
			return new RegHubKafkaSpout<K, V>(this);
		}
		
		private Func<ConsumerRecord<K, V>, List<Object>> recordToTupleTranslator = new Func<ConsumerRecord<K, V>, List<Object>>() {
			
			private static final long serialVersionUID = 1L;
			@Override
			public List<Object> apply(ConsumerRecord<K, V> r) {
				return new Values(r.key(), r.value());
			}
		};
	}

}
