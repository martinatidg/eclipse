package com.citi.reghub.core;

import java.util.Map;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.generated.AlreadyAliveException;
import org.apache.storm.generated.AuthorizationException;
import org.apache.storm.generated.InvalidTopologyException;
import org.apache.storm.generated.StormTopology;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;

public class BaseTopology {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseTopology.class);
	private static final String LOCAL = "LOCAL";
	private static final String TEST = "TEST";
	private static final String DEFAULT_TOPOLOGY_NAME = "stormTopology";
	
	protected void runTopology(String[] args) throws Exception {
		String env = "local";
		if (args.length != 0) {
			env = args[0];
		}
		LOGGER.info("Storm topology running with: " + env);
		Map<String, String> props = new PropertiesLoader().getProperties(env);
		Config conf = getTopologyConfig();
		conf.put(GlobalProperties.TOPOLOGY_CONFIG, props);
		
		StormTopology tp = buildTopology(props);
		if(tp == null) {
			throw new RuntimeException("Please specify the topology configuration");
		}
		
		try {
			if (!LOCAL.equalsIgnoreCase(env) && !TEST.equalsIgnoreCase(env)) {
				StormSubmitter.submitTopology(props.getOrDefault(GlobalProperties.TOPOLOGY_NAME, DEFAULT_TOPOLOGY_NAME), conf, tp);
			} else {
				LocalCluster cluster = new LocalCluster();
				cluster.submitTopology(props.getOrDefault(GlobalProperties.TOPOLOGY_NAME, DEFAULT_TOPOLOGY_NAME), conf, tp);
			}
		} catch (AlreadyAliveException | InvalidTopologyException | AuthorizationException e) {
			LOGGER.error("Error creating topology.", e);
		}
	}

	protected Config getTopologyConfig() {
		Config conf = new Config();
		conf.setDebug(false);
		return conf;
	}

	protected StormTopology buildTopology(Map<String, String> props) throws Exception {
		return null;
	}
}
