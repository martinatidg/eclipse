package com.citi.reghub.core.mongo;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.Validate;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.ConvertToMongoMap;
import com.citi.reghub.core.constants.GlobalProperties;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.GridFSUploadStream;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;

public class MongoDBGridFsBolt<T> extends BaseRichBolt {

	private static final Logger LOG = LoggerFactory.getLogger(MongoDBGridFsBolt.class);
	
	private static final long serialVersionUID = 1L;
	protected OutputCollector collector;
	protected RegHubMongoClient mongoClient;
	protected GridFSBucket gridFSBucket;
	protected ConvertToMongoMap toMongoMap;
	protected String collectionName;
	

	public MongoDBGridFsBolt(String collectionName, ConvertToMongoMap toMongoMap){
		this.collectionName = collectionName;
		this.toMongoMap = toMongoMap;
	}

	@Override
	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
       		Validate.notEmpty((String) topologyConfig.get(GlobalProperties.MONGO_URL), "url can not be blank or null");
		String url = topologyConfig.get(GlobalProperties.MONGO_URL);
		String password = topologyConfig.get(GlobalProperties.MONGO_PASSWORD);
		String trustStore = topologyConfig.get(GlobalProperties.MONGO_TRUSTSTORE);
		String trustStorePassword = topologyConfig.get(GlobalProperties.MONGO_TRUSTSTORE_PASSWORD);
		String decryptKey = topologyConfig.get(GlobalProperties.DECRYPT_KEY);

		if(password != null){
			Map<String, Object> mongoProps = new HashMap<>();
			mongoProps.put(RegHubMongoClient.CONNECTION_URL, url);
			mongoProps.put(RegHubMongoClient.PASSWORD, password);
			mongoProps.put(RegHubMongoClient.TRUSTSTORE, trustStore);
			mongoProps.put(RegHubMongoClient.TRUSTSTORE_PASSWORD, trustStorePassword);
			mongoProps.put(RegHubMongoClient.DECRYPT_KEY, decryptKey);
            this.mongoClient = new RegHubMongoClient(mongoProps);
        } else {
            this.mongoClient = new RegHubMongoClient(url);
        }
        gridFSBucket = GridFSBuckets.create(mongoClient.getDatabase(), collectionName);
    }

	@Override
	public void cleanup() {
		this.mongoClient.close();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(Tuple tuple) {
		try {
			T message = (T) tuple.getValueByField("message");
			insertFile((Document)toMongoMap.toMap(message));
			this.collector.ack(tuple);
		} catch (Exception e) {
			LOG.error("Error in mongo insertion", e);
			this.collector.reportError(e);
			this.collector.ack(tuple);
		}
	}

    public void insertFile(Document document) {
    	GridFSUploadOptions options = new GridFSUploadOptions()
                .chunkSizeBytes(358400)
                .metadata(document);
    	GridFSUploadStream uploadStream = gridFSBucket
    			.openUploadStream(document.getString("fileName") + "." + document.getString("extension"), options);
    	uploadStream.write((byte[]) document.get("content"));
    	uploadStream.close();
    }

    @Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
    	/**
		 * No output fields, as we are sending data to mongodb
		 */
    }

}
