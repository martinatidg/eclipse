package com.citi.reghub.core;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import java.util.Map;

public class ConvertRawMsgToObject extends BaseRichBolt {
	private static final long serialVersionUID = 1L;
	private OutputCollector collector = null;
	
	@Override
	public void execute(Tuple arg0) {
		String regHubId = arg0.getStringByField("key");
		String message = arg0.getStringByField("message");
		RawMsgObject rawMsgObejct=new RawMsgObject(regHubId,message);
		collector.emit(new Values(rawMsgObejct));
		collector.ack(arg0);
	}

	@Override
	public void prepare(Map arg0, TopologyContext arg1, OutputCollector arg2) {
		collector=arg2;

	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {
		arg0.declare(new Fields("message"));

	}

}
