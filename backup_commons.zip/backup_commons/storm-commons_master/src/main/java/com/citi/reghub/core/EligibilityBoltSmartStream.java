package com.citi.reghub.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.rules.client.RuleGraph;
import com.citi.reghub.core.rules.client.RuleGraphResult;
import com.citi.reghub.core.rules.client.RulesClient;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

public class EligibilityBoltSmartStream extends RegHubBolt {

	private static final Logger LOG = LoggerFactory.getLogger(EligibilityBolt.class);
	private static final long serialVersionUID = 1L;
	
	private OutputCollector _collector;

	private Map<String, RuleGraph> rulegraphs = new HashMap<String, RuleGraph>();
	private Map<String, Long> ruleGraphCurrentLoadTimes = new HashMap<String, Long>();

	protected RulesClient rulesClient;

	protected String  ruleGraphBaseName;
	protected boolean forceRefreshCache;

	
	public EligibilityBoltSmartStream(){
		super();
	}
	
	public EligibilityBoltSmartStream(String ruleGraphBaseName){
		this.ruleGraphBaseName = ruleGraphBaseName;
	}
	
	public String getRuleGraphName() {
		return this.ruleGraphBaseName;
	}
		
	protected void loadRuleGraph(String ruleGraphName ){
		rulegraphs.put(ruleGraphName, rulesClient.load(ruleGraphName));
		ruleGraphCurrentLoadTimes.put(ruleGraphName, Long.valueOf(rulesClient.getLastLoadTime(ruleGraphName)));
		forceRefreshCache = true;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void prepareBolt(Map stormConf, TopologyContext context, OutputCollector collector) {
		_collector = collector;
		Map<String, String> topologyConfig = (Map<String, String>) stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);
		setCacheClient(topologyConfig);
		setRuleClient(topologyConfig);
		setMetadataClient(topologyConfig);
		rulesClient = SingletonRulesClient.getInstance();
		//not loading the rule on start up , loading when called for first time. 
	}

	public void process(Tuple input) {
		System.out.println("Rule Graph Executing For: "+this.ruleGraphBaseName+":"+this.getClass().getSimpleName());
		
		Entity message = (Entity) input.getValueByField("message");
		LOG.info("Rule Graph Executing For: "+this.ruleGraphBaseName+":"+message.regHubId);	
		
		// Evaluate the ruleGraph name
		String ruleGraphName = getRuleGraphName(message);
		
		long ruleGraphLastLoadTimeInCache = rulesClient.getLastLoadTime(ruleGraphName);
		if(ruleGraphLastLoadTimeInCache == 0 || getRuleGraphCurrentLoadTime(ruleGraphName) < ruleGraphLastLoadTimeInCache){
			loadRuleGraph(ruleGraphName);
		}
		
		RuleGraph ruleGraph = rulegraphs.get(ruleGraphName);

		RuleGraphResult result = ruleGraph.execute(message, new HashMap<>(),forceRefreshCache);
		forceRefreshCache = false;

		message.status = result.status;
		message.reasonCodes.addAll(result.resultCodes);
		
		Audit audit = message.toAudit();
		ruleGraph.toAudit(audit);
		result.toAudit(audit);
		
		_collector.emit(StormStreams.AUDIT, new Values(audit.regHubId, audit));
		
		String emitStream =getStreamIdByEntityStatus(message.status);
				
		_collector.emit(emitStream, new Values(message.regHubId, message));
		_collector.ack(input);		
	}

	public void declareBoltSpecificOutFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream(StormStreams.REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.NON_REPORTABLE, new Fields("key", "message"));
		declarer.declareStream(StormStreams.EXCEPTION, new Fields("key", "message"));
		declarer.declareStream(StormStreams.AUDIT, new Fields("key", "message"));
	}

	private static String getStreamIdByEntityStatus(String status) {
		if(EntityStatus.REPORTABLE.equalsIgnoreCase(status)){
			return StormStreams.REPORTABLE;
		} else if(EntityStatus.NON_REPORTABLE.equalsIgnoreCase(status)) {
			return StormStreams.NON_REPORTABLE;
		} else {
			return StormStreams.EXCEPTION;
		}
	}
	
	@Override
	public OutputCollector getCollector() {
		return _collector;
	}

	@Override
	public String getAuditExceptionEvent() {
		return StormConstants.DOMAIN_APP_EXCEPTION;
	}

	@Override
	public List<String> getAuditExceptionsTags() {
		List<String> exceptionTags = new ArrayList<>();
		exceptionTags.add(StormConstants.DOMAIN);
		return exceptionTags;
	}
	
	private String  getRuleGraphName(Entity entity)
	{
		return entity.stream+"_"+entity.flow+"_"+ruleGraphBaseName;
	}
	
	private long  getRuleGraphCurrentLoadTime(String ruleGraphName )
	{
		return ruleGraphCurrentLoadTimes.getOrDefault(ruleGraphName, 0l) ;
	}

}
