package com.citi.reghub.core.rio.spouts;

import java.io.File;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.storm.kafka.bolt.mapper.FieldNameBasedTupleToKafkaMapper;
import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.RawMsgObject;
import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.constants.StormConstants;
import com.citi.rio.registry.infra.Environment;
import com.citi.rio.registry.infra.Region;
import com.citi.rio.umb.UmbClientFactory;
import com.citi.rio.umb.payload.Payload.Key;
import com.citi.rio.umb.subscribe.UmbMessageHandler;
import com.citi.rio.umb.subscribe.UmbMessageHandlerFactory;
import com.citi.rio.umb.subscribe.UmbPayloadHandler;
import com.citi.rio.umb.subscribe.UmbSubscriber;
import com.citi.rio.umb.subscribe.exception.MessageHandlerCreationException;
import com.citi.rio.umb.subscribe.payload.IndividualPayload;

public class RioSpout extends BaseRichSpout {

	private static final long serialVersionUID = 1L;

	Environment rioEnv = null;
	Region rioRegion = null;
	String rioClientKey = null;
	protected String stream = null;
	protected String flow = null;
	protected String messageType = null;

	private SecureRandom random = new SecureRandom();

	UmbSubscriber<IndividualPayload<String>> subscriber = null;

	SpoutOutputCollector collector;

	private LinkedBlockingQueue<IndividualPayload<String>> queue;

	private ConcurrentHashMap<String, IndividualPayload<String>> commit;

	private UmbPayloadHandler<String, IndividualPayload<String>> handler = null;

	private static final Logger LOG = LoggerFactory.getLogger(RioSpout.class);

	public RioSpout(Map<String, String> props, String spoutName) {
		rioEnv = Environment.valueOf(props.get(spoutName+"."+StormConstants.RIO_ENV));
		rioRegion = Region.valueOf(props.get(spoutName+"."+StormConstants.RIO_REGION));
		rioClientKey = props.get(spoutName+"."+StormConstants.RIO_SUBSCRIBER_KEY);
		stream = props.get(GlobalProperties.TOPOLOGY_STREAM_NAME);
		flow = props.get(GlobalProperties.TOPOLOGY_FLOW_NAME);
		messageType = props.get(GlobalProperties.TOPOLOGY_MESSAGE_TYPE);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void open(Map paramMap, TopologyContext paramTopologyContext, SpoutOutputCollector paramSpoutOutputCollector) {

		queue = new LinkedBlockingQueue<>();

		commit = new ConcurrentHashMap<>();

		collector = paramSpoutOutputCollector;

		UmbClientFactory clientFactory = new UmbClientFactory(rioEnv, rioRegion, new File("/tmp"));

		subscriber = clientFactory.createSubscriber(rioClientKey, new UmbMessageHandlerFactory<IndividualPayload<String>>() {

			public UmbMessageHandler<IndividualPayload<String>> create(final Map<Key, Object> metaData) throws MessageHandlerCreationException {

				handler = new UmbPayloadHandler<String, IndividualPayload<String>>() {

					public void onPayload(final IndividualPayload<String> payload) {
						queue.add(payload);
					}

					public void onApplicationError(final IndividualPayload<String> payload, final RuntimeException error) {
						LOG.error("Application Error: " + error);
					}

					public void onConnectionError(final Exception error) {
						LOG.error("Connection Error: " + error);
					}
				};

				return handler;
			}
		});
	}

	@Override
	public void ack(Object msgId) {
		super.ack(msgId);
		synchronized (msgId) {
			if (!commit.isEmpty()) {
				IndividualPayload<String> payload = commit.get(msgId);
				if (payload != null) {
					payload.commit();
					commit.remove(msgId);
				}
			}
		}
	}

	@Override
	public void nextTuple() {
		synchronized (this) {
			if (!queue.isEmpty()) {
				IndividualPayload<String> payload = queue.poll();
				String messageId = M2ReghubIdGeneratorFactory.getM2ReghubIdGenerator(messageType).generateReghubId(stream, flow, payload.getContent());
				
				RawMsgObject rawIncomingMsgObject = RawMsgObject.builder(messageId, payload.getContent())
						.setFlow(flow)
						.setStream(stream)
						.setReceivedTs(LocalDateTime.now(Clock.systemUTC()))
						.build();
				
				collector.emit(new Values(messageId, rawIncomingMsgObject), messageId);
				commit.put(messageId, payload);
			}
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(FieldNameBasedTupleToKafkaMapper.BOLT_KEY, FieldNameBasedTupleToKafkaMapper.BOLT_MESSAGE));
	}

	@Override
	public void close() {
		super.close();
		if (subscriber != null) {
			LOG.info("************* SHUTTING DOWN RIO SUBSCRIBER ************* ");
			subscriber.shutdown();
		}
	}

	public String generateReghubId() {
		return stream+flow+UUID.randomUUID();
	}
}
