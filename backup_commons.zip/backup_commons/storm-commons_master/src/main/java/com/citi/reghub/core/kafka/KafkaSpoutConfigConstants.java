package com.citi.reghub.core.kafka;

public interface KafkaSpoutConfigConstants {
	
	String KAFKA_SPOUT_OUTFIELDS = "kafka.spout.outfields";
	String KAFKA_SPOUT_INITIAL_DELAY_MICROSECONDS = "kafka.spout.initial.delay.microseconds";
	String KAFKA_SPOUT_DELAY_PERIOD_MILLISECONDS = "kafka.spout.delay.period.milliseconds";
	String KAFKA_SPOUT_MAX_DELAY_SECONDS = "kafka.spout.max.delay.seconds";
	String KAFKA_SPOUT_MAX_RETRIES_COUNT = "kafka.spout.max.retries.count";
	
	String KAFKA_SPOUT_MAX_UNCOMMITTED_OFFSETS = "kafka.spout.max.committed.offsets";
	String KAFKA_SPOUT_OFFSET_COMMIT_PERIOD_MS = "kafka.spout.offset.commit.period.ms";
	String KAFKA_SPOUT_AUTO_OFFSET_RESET = "kafka.spout.auto.offset.reset";
	String KAFKA_SPOUT_CONSUMER_GROUP_ID="kafka.spout.consumer.group.id";
	String DOT = ".";
	String UNDERSCORE = "_";
	String TOPICS_SEPARATOR = ",";
}
