package com.citi.reghub.core.codec;

import java.math.BigDecimal;

import org.bson.BsonReader;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;

public class BigDecimalCodec implements Codec<BigDecimal> {

    @Override
    public BigDecimal decode(BsonReader bsonReader, DecoderContext decoderContext) {
        return new BigDecimal(bsonReader.readString());
    }

    @Override
    public void encode(BsonWriter bsonWriter, BigDecimal bigDecimal, EncoderContext encoderContext) {
        bsonWriter.writeString(bigDecimal.toPlainString());
    }

    @Override
    public Class<BigDecimal> getEncoderClass() {
        return BigDecimal.class;
    }
}
