package com.citi.reghub.core.enrichment.client;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;


public class EnrichmentClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(EnrichmentClient.class);

	private static final String CACHE_ENRICHMENTPLAN_COLLECTION = "enrichment_plan";
	private static final String CACHE_ENRICHMENTPLAN_COLLECTION_TYPE = "Map";

    private final Map				props;
	public  EnrichmentClientConfig 	enrichmentClientConfig;
	private CacheClient 			cacheClient;

	public EnrichmentClient(EnrichmentClientConfig enrichmentClientConfig) {
		if(enrichmentClientConfig == null) {
			LOGGER.warn("Enrichment client config passed is null, using default configuration");
		}
		
        this.enrichmentClientConfig = (enrichmentClientConfig == null ? new EnrichmentClientConfig() :  enrichmentClientConfig);
        
        if (!this.enrichmentClientConfig.containsKey(EnrichmentClientConfig.ENRICHMENT_PLAN_SERVICE_URL)) {
        	this.enrichmentClientConfig.setDefaultEnrichmentPlanServiceUrl();
        }

        this.cacheClient = this.enrichmentClientConfig.getCacheClient();
        this.props = prepareCacheClientConfig();
        
        LOGGER.info("Instantiated Enrichment client instance with config='{}'", enrichmentClientConfig);
    }
 
    public EnrichmentResult execute(Object root, boolean forceRefereshCache,EnrichmentPlan enrichmentPlan) {
    	return new EnrichmentPlanExecutor().setConfig(enrichmentClientConfig).execute(enrichmentPlan, root, forceRefereshCache);
    }

    private String prepareEnrichmentPlanUrl(String enrichmentPlanName) {
        return String.format(enrichmentClientConfig.getEnrichmentPlanServiceUrl(),enrichmentPlanName);
    }

    public EnrichmentPlan getFromService(String enrichmentPlanName){
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing GetFromService for enrichment with name='{}'", enrichmentPlanName);
    	}

    	if (enrichmentClientConfig.getRestClient() == null) { 
    		RuntimeException ex = new RuntimeException("EnrichmentClient has invalid HTTP_CLIENT");
    		LOGGER.error("getFromService called with restClient=null", ex);
    		throw ex;
    	}

    	EnrichmentPlan enrichmentPlan = enrichmentClientConfig.getRestClient().get(prepareEnrichmentPlanUrl(enrichmentPlanName),EnrichmentPlan.class);
        
    	if(enrichmentPlan == null) {
        	RuntimeException ex = new RuntimeException("Invalid Enrichment plan name");
        	LOGGER.error("getFromService request with enrichmentPlanName='{}'", enrichmentPlanName, ex);
        	throw ex;
        }
    	
    	putInCache(enrichmentPlanName);
    	return enrichmentPlan;
    }

    public long getLastLoadTime(String enrichmentPlanName) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Hitting cache to get last load time for enrichmentPlanName='{}'", enrichmentPlanName);
    	}
    	
		Object obj = cacheClient.get(enrichmentPlanName, this.props);

		if (obj == null) {
			return 0;
		}
		
		return (long) obj;
	}

    private void putInCache(String enrichmentPlanName){
    	cacheClient.put(enrichmentPlanName, System.currentTimeMillis(), this.props);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	private static final Map prepareCacheClientConfig(){
		Map props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, CACHE_ENRICHMENTPLAN_COLLECTION);
		props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_ENRICHMENTPLAN_COLLECTION_TYPE);
		props.put(CacheClient.PUT_IF_ABSENT, "true");
		return props;
	}

}
