package com.citi.reghub.core.crypto.client;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.crypto.SecretKey;

public interface CipherClient {
	public static final int IV_LENGTH = 16;
	public static final int AES_KEY_SIZE = 128;
	public static final String ALGO_TRANSFORMATION_STRING = "AES/CBC/PKCS5Padding";
	public static final String ALGO = "AES";

    public SecretKey getKey(String keyRef);
    public byte[] encrypt(byte[] bytes, String keyRef, String iv);
    public String encrypt(String plainText, String keyRef, String iv);
    public String encrypt(LocalDate date, DateTimeFormatter format, String keyRef, String iv);
    public String encrypt(LocalDateTime timestamp, DateTimeFormatter format, String keyRef, String iv);
    public String decrypt(String cipherText, String keyRef, String iv);
    public byte[] decrypt(byte[] bytes, String keyRef, String iv);
    public LocalDate decryptAsDate(String cipherTextDate, DateTimeFormatter format, String keyRef, String iv);
    public LocalDateTime decryptAsDateTime(String cipherTextTimestamp, DateTimeFormatter format, String keyRef, String iv);
}
