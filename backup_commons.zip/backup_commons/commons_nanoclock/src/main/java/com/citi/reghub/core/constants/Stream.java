package com.citi.reghub.core.constants;

public interface Stream {

    String M2TR = "m2tr";
    String M2POST = "m2post";
    String M2PRE = "m2pre";
}
