package com.citi.reghub.core.metadata.client;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public class MetadataClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataClient.class);

    private static final String CACHE_METADATA_COLLECTION = "metadata";
    private static final String CACHE_METADATA_COLLECTION_TYPE = "Map";
	private static final String UNDEFINED = "undefined";

    private final Map					props;
    private final MetadataClientConfig 	metadataClientConfig;
    private final CacheClient 			cacheClient;

    public MetadataClient(MetadataClientConfig metadataClientConfig) {
        if(metadataClientConfig == null) {
        	LOGGER.warn("Provided metadata client config is null, using default configuration");
        }
        
        this.metadataClientConfig = (metadataClientConfig == null ? new MetadataClientConfig() :  metadataClientConfig);
        
        if (!this.metadataClientConfig.containsKey(MetadataClientConfig.METADATA_URL_KEY)) {
        	this.metadataClientConfig.setDefaultMetadataUrl();
        }
        
        this.cacheClient = this.metadataClientConfig.getCacheClient();
        this.props = prepareCacheClientConfig(null);
        
        LOGGER.info("Instantialised Metadata Client with configuration='{}'", metadataClientConfig);
    }

    public Object get(String metadataName){
    	return get(metadataName, null);
    }
    
    public Object get(String metadataName, String cacheName) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing get for metadata with metadataName='{}'", metadataName);
    	}
    	
        Object metadata = getFromCache(metadataName, cacheName);
        
        if (metadata == null) {
            metadata = getFromService(metadataName, cacheName);
        }
        
        return metadata;
    }

    public boolean isMetaDataCached(String metadataName) {    	
        return getFromCache(metadataName, null)!=null;
    }
    
    private String prepareMetadataUrl(String metadataName) {
        return String.format(metadataClientConfig.getMetadataUrl(),metadataName);
    }

    private Object getFromCache(String metadataName,String cacheName){
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing getFromCache for metadata with metadataName='{}'", metadataName);
    	}
    	if(StringUtils.isBlank(cacheName))
    		return cacheClient.get(metadataName, this.props);
    	else
    		return cacheClient.get(metadataName, prepareCacheClientConfig(cacheName));
    }

    private void putInCache(String metadataName,Object metadata, String cacheName) {
        if(StringUtils.isBlank(cacheName))
        	cacheClient.put(metadataName, metadata, this.props);
        else
        	cacheClient.put(metadataName, metadata, prepareCacheClientConfig(cacheName));
    	if (LOGGER.isTraceEnabled()) {
    		LOGGER.trace("Processed put for metadataName='{}', metadata='{}'", metadataName, metadata);
    	}
    }

    private Object getFromService(String metadataName, String cacheName){
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("Processing getFromService for metadata with name", metadataName);
    	}
    	
        if (metadataClientConfig.getRestClient() == null) {
        	RuntimeException ex = new RuntimeException("Invalid Rest client for metadata");
        	LOGGER.error("HTTP_CLIENT has not be set with metadataName='{}'", metadataName, ex);
        	throw ex;
        }
        
        Map meta = metadataClientConfig.getRestClient().get(prepareMetadataUrl(metadataName),Map.class);
        if(meta == null) {
            RuntimeException ex = new RuntimeException("Invalid metadata name has been provided");
            LOGGER.error("Get request with metadataName='{}'", metadataName, ex);
            throw ex;
        }
        
        Metadata metadata = new Metadata(meta);
        putInCache(metadataName, metadata.value, cacheName);
        
        return metadata.value;
    }
    
    public MetadataClientConfig getMetadataClientConfig() {
    	return metadataClientConfig;
    }


    @SuppressWarnings({ "rawtypes", "unchecked" })
    private final Map prepareCacheClientConfig(String cacheName){
        Map props = new HashMap<>();
        String stream = metadataClientConfig.getStreamCode()== null? UNDEFINED : metadataClientConfig.getStreamCode().toLowerCase();
		String flow = metadataClientConfig.getFlowCode()== null? UNDEFINED : metadataClientConfig.getFlowCode().toLowerCase();
		String metadataName = StringUtils.isNotBlank(cacheName) ? cacheName : (stream+"_"+flow+"_"+CACHE_METADATA_COLLECTION);
        props.put(CacheClient.CACHE_COLLECTION_NAME, metadataName);
        props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_METADATA_COLLECTION_TYPE);
        return props;
    }
}
