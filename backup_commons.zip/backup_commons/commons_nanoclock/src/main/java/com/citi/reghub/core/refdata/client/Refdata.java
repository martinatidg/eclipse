package com.citi.reghub.core.refdata.client;

public class Refdata {

	private final RefdataType type;
	private final Object data;

	public Refdata(final RefdataType type, final Object map) {
		this.type = type;
		this.data = map;
	}
	
	public String getType() {
		return type.name();
	}
	
	public Object getData() {
		return data;
	}

	public static enum RefdataType {
		ACCOUNT, SECURITY;
	}	
}
