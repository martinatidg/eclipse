package com.citi.reghub.core.event;

public enum EventSource {
	
	XM_CONSUMER("xm-consumer"),
	XM_SERVICE("xm-service"),
	XM_XSTREAM("xm-ui"),
	CORE_UI("core-ui"),
	CORE_CHANGE_REQUEST("core-cr"),
	STREAM_M2TR("stream-m2tr"),
	STREAM_M2POST("stream-m2post"),
	STREAM_NACK_HANDLER("stream-nack-handler");

	final String value;

	EventSource(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static EventSource fromValue(String v) {
		for (EventSource c : EventSource.values()) {
			if (c.value.equalsIgnoreCase(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}

}
