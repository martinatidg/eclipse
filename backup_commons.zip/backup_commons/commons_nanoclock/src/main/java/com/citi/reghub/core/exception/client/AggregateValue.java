package com.citi.reghub.core.exception.client;


import java.util.Map;

public class AggregateValue {
	
	private Map<String,Object> groupByValues;
	private int count;
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Map<String, Object> getGroupByValues() {
		return groupByValues;
	}
	public void setGroupByValues(Map<String, Object> groupByValues) {
		this.groupByValues = groupByValues;
	}
	

}
