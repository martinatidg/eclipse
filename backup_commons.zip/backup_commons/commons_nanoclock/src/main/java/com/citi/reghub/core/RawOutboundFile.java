package com.citi.reghub.core;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.UUID;
@Deprecated
/**Use RawFile instead of this*/
public class RawOutboundFile  {

	public String _id;
	public String stream;
	public String flow;

	public String sendTo;
	public LocalDateTime sendTs;

	public String fileName;
	public String extension;
	public String getStream() {
		return stream;
	}


	public byte[] content;

	public RawOutboundFile(){
		_id = UUID.randomUUID().toString();
	}

	public RawOutboundFile(String name, String ext, byte[] is){
		_id = UUID.randomUUID().toString();
		this.sendTs = LocalDateTime.now(Clock.systemUTC());
		this.fileName=name;
		this.extension=ext;
		this.content=is;
	}
	
	public String getSendTo() {
		return sendTo;
	}
	
	public void setStream(String stream) {
		this.stream = stream;
	}

}
