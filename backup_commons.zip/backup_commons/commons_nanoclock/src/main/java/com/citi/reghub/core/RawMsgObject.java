package com.citi.reghub.core;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Map;

public class RawMsgObject implements Serializable{
	
	private static final long serialVersionUID = 4047632778430980392L;
	
	String message;
	Map<String, Object> map;
	private String regHubId;
	private String stream;
	private String flow;
	private LocalDateTime receivedTs;
	
	public RawMsgObject() {

	}
	
	public RawMsgObject(String reghubId, String message) {
		this.regHubId = reghubId;
		this.message = message;
	}

	public RawMsgObject(RawMsgObjectBuilder rawMsgObjectBuilder) {
		this.flow = rawMsgObjectBuilder.flow;
		this.message = rawMsgObjectBuilder.message;
		this.regHubId = rawMsgObjectBuilder.regHubId;
		this.stream = rawMsgObjectBuilder.stream;
		this.receivedTs = rawMsgObjectBuilder.receivedTs;
	}

	public String getRegHubId() {
		return regHubId;
	}

	public void setRegHubId(String reghubID) {
		this.regHubId = reghubID;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public LocalDateTime getReceivedTs() {
		return receivedTs;
	}
	
	public void setReceivedTs(LocalDateTime receievedTs) {
		this.receivedTs = receievedTs;
	}
	
	public static RawMsgObjectBuilder builder(String reghubId, String message) {
		return new RawMsgObjectBuilder(reghubId, message);
	}
	
	public static class RawMsgObjectBuilder implements Serializable{
		
		private static final long serialVersionUID = -9121007730047977697L;
		
		private String regHubId;
		private String flow;
		private String stream;
		private String message;
		private LocalDateTime receivedTs;
		
		public RawMsgObjectBuilder(String reghubId, String message){
			this.regHubId = reghubId;
			this.message = message;
		}
		
		public RawMsgObjectBuilder setFlow(String flow) {
			this.flow = flow;
			return this;
		}
		
		public RawMsgObjectBuilder setStream(String stream) {
			this.stream = stream;
			return this;
		}
		
		public RawMsgObjectBuilder setReceivedTs(LocalDateTime receivedTs) {
			this.receivedTs = receivedTs;
			return this;
		}
		
		public RawMsgObject build(){
			return new RawMsgObject(this);
		}
	}
}