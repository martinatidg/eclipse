package com.citi.reghub.core.exception.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.event.exception.ExceptionMessage;
import com.fasterxml.jackson.core.JsonProcessingException;


public class ExceptionClient {

	private ExceptionClientConfig xmClientConfig;
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionClient.class);
	private static final String NOT_FOUND_ERROR = "Exceptions Not found for the specified payload";

	private static final String PAYLOAD="payload='{}'";

	public ExceptionClient(ExceptionClientConfig xmClientConfig) {

		if(xmClientConfig == null) LOGGER.warn("Exception client config passed is null, using default configuration");
		this.xmClientConfig = (xmClientConfig == null ? new ExceptionClientConfig() : xmClientConfig);
		if (!this.xmClientConfig.containsKey(ExceptionClientConfig.XM_SERVICE_URL_KEY))
			this.xmClientConfig.setDefaultXmServiceUrl();
		LOGGER.info("Instantiated Exception client instance with config='{}'", xmClientConfig);
	}

	
	public List<ExceptionMessage> getExceptionsFromService() { //default limit : 100, offset : 0, status: OPEN
		LOGGER.debug("Hitting xm-service for getExceptionsFromService - list of exceptions");
		ExceptionsViewWrapper exceptionsVW = xmClientConfig.getRestClient().get(xmClientConfig.getXmServiceUrl(), ExceptionsViewWrapper.class);
		if(exceptionsVW.getTotalRecords() != 0){
			return exceptionsVW.getExceptionsList();
		}
		return new ArrayList<>();
	}

	public ExceptionMessage getExceptionsById(String exceptionId) throws JsonProcessingException {
		LOGGER.debug("Hitting xm-service for getExceptionsFromServiceById with exceptionId='{}'", exceptionId);

		Map<String, Object> query = new HashMap<>();
		List<String> ids = new ArrayList<>();

		ids.add(exceptionId);
		query.put("id", ids);

		ExceptionsViewWrapper exceptionsVW = xmClientConfig.getRestClient().doPost(query,
				xmClientConfig.getXmServiceUrl(), ExceptionsViewWrapper.class, false);

		if (exceptionsVW != null && exceptionsVW.getTotalRecords() > 0) {
			return exceptionsVW.getExceptionsList().get(0);
		}

		return null;
	}

	public List<ExceptionMessage> getExceptionsByFilter(Map payload) throws JsonProcessingException {
		LOGGER.debug("Hitting Exceptions Service for getExceptionsByFilter with payload='{}'", payload);
		ExceptionsViewWrapper exceptionsVW =  xmClientConfig.getRestClient().doPost(payload , xmClientConfig.getXmServiceUrl(), ExceptionsViewWrapper.class,false);
		if (exceptionsVW == null){
			RuntimeException ex = new RuntimeException(NOT_FOUND_ERROR);

			LOGGER.error(PAYLOAD, payload, ex);

			throw ex;
		}
		if(exceptionsVW.getTotalRecords() != 0){
			return exceptionsVW.getExceptionsList();
		}
		return new ArrayList<>();
	}
	
	public AggregatePostResponse getAggregateCountByFilter(Map payload) throws JsonProcessingException {
		LOGGER.debug("Hitting Exceptions Service for getAggregateCountByFilter with payload='{}'", payload);
		AggregatePostResponse exceptionsVW =  xmClientConfig.getRestClient().doPost(payload , xmClientConfig.getXmServiceUrl()+"/aggregate", AggregatePostResponse.class,false);
		if (exceptionsVW == null){
			RuntimeException ex = new RuntimeException(NOT_FOUND_ERROR);

			LOGGER.error(PAYLOAD, payload, ex);

			throw ex;
		}else{
			return exceptionsVW;
		}
	
	}
	
	
	
	public long getExceptionsCountByFilter(Map payload) throws JsonProcessingException {
		LOGGER.debug("Hitting Exceptions Service for getExceptionsCountByFilter with payload='{}'", payload);
		ExceptionsViewWrapper exceptionsVW =  xmClientConfig.getRestClient().doPost(payload , xmClientConfig.getXmServiceUrl()+"/count", ExceptionsViewWrapper.class,false);
		if (exceptionsVW == null){
			RuntimeException ex = new RuntimeException(NOT_FOUND_ERROR);
			LOGGER.error(PAYLOAD, payload, ex);
			throw ex;
		}
		return exceptionsVW.getTotalRecords();
			
	}
	public boolean updateExceptionStatus(String id, String newStatus, String eventSource) throws JsonProcessingException {
		LOGGER.debug("Hitting Exceptions Service for updateExceptionStatus with id='{}' , newStatus='{}', eventSource='{}'", id, newStatus, eventSource);

		Map<String, String> query = new HashMap<>();
		query.put("id",id);
		query.put("newStatus", newStatus);
		query.put("eventSource", eventSource);
		StatusUpdatePostResponse response =  xmClientConfig.getRestClient().doPost(query , xmClientConfig.getXmServiceUrl()+"/status", StatusUpdatePostResponse.class,false);
		if (response == null){
			RuntimeException ex = new RuntimeException(NOT_FOUND_ERROR);

			LOGGER.error(PAYLOAD, query, ex);
			throw ex;
		}
		return response.isSuccess();
			
	}
	
	public boolean addExceptionNote(String id, String note, String source, String createdBy) throws JsonProcessingException {
		LOGGER.debug("Hitting Exceptions Service for addExceptionNote with id='{}' , note='{}', source='{}', createdBy='{}'", id, note, source, createdBy);
		Map<String, String> query = new HashMap<>();
		query.put("id",id);
		query.put("add","true");
		query.put("note", note);
		query.put("source", source);
		query.put("createdBy", createdBy);
		NotesUpdatePostResponse response =  xmClientConfig.getRestClient().doPost(query , xmClientConfig.getXmServiceUrl()+"/notes", NotesUpdatePostResponse.class,false);
		if (response == null){
			RuntimeException ex = new RuntimeException(NOT_FOUND_ERROR);

			LOGGER.error(PAYLOAD, query, ex);
			throw ex;
		}
		return response.isSuccess();
			
	}

	
	public boolean deleteExceptionNote(String id, String source, String createdBy, long createdTS) throws JsonProcessingException {
		LOGGER.debug("Hitting Exceptions Service for deleteExceptionNote with id='{}' , source='{}', createdBy='{}', createdTS='{}'", id, source, createdBy, createdTS);
		Map<String, String> query = new HashMap<>();
		query.put("id",id);
		query.put("add","false");
		query.put("source", source);
		query.put("createdBy", createdBy);
		query.put("createdTS", Long.toString(createdTS));
		NotesUpdatePostResponse response =  xmClientConfig.getRestClient().doPost(query , xmClientConfig.getXmServiceUrl()+"/notes", NotesUpdatePostResponse.class,false);
		if (response == null){
			RuntimeException ex = new RuntimeException(NOT_FOUND_ERROR);
			LOGGER.error(PAYLOAD, query, ex);
			throw ex;
		}
		return response.isSuccess();
			
	}

}
