package com.citi.reghub.core.converter;

public class FloatConverter implements TypeConverter<String, Float> {

	public Float convert(String obj, String format) {
		// TODO Auto-generated method stub
		return new Float(obj);
	}

}
