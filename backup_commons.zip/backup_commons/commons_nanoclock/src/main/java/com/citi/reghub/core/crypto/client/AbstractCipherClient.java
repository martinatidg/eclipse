package com.citi.reghub.core.crypto.client;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.cache.client.CacheClient;

public abstract class AbstractCipherClient implements CipherClient {
	
	protected Cipher cipher;

	protected CacheClient cacheClient;

    protected static final String CACHE_CRYPTO_KEY_COLLECTION = "cryptoKeys";
    protected static final String CACHE_CRYPTO_KEY_COLLECTION_TYPE = "Map";

    public static Logger LOGGER = LoggerFactory.getLogger(AbstractCipherClient.class);
    
	public abstract void generateAndStoreKey(String keyRef);

    public AbstractCipherClient(CacheClient cacheClient) {
    	this.cacheClient = cacheClient;
    }

	protected byte[] getIv (String str) {
		byte[] iv = str.getBytes();
		LOGGER.debug("IV input having length '{}'", iv.length);
		if (iv.length != CipherClient.IV_LENGTH) {
			iv = Arrays.copyOfRange(iv, 0, CipherClient.IV_LENGTH);
		}
		LOGGER.debug("IV created having length '{}'", iv.length);
		return iv;		
	}
	
	@Override
	public byte[] encrypt(byte[] bytes, String keyRef, String iv) {
		return encrypt(new String(bytes), keyRef, iv).getBytes();
	}
	
	@Override
	public String encrypt(String plainText, String keyRef, String iv) {
		String cipherText = null ; 
		try { 
			Cipher cipher = getCipher(Cipher.ENCRYPT_MODE, keyRef, iv);
			byte[] cipherTextInByteArr = cipher.doFinal(plainText.getBytes());
			cipherText = Base64.getEncoder().encodeToString(cipherTextInByteArr);
		} catch(IllegalBlockSizeException illegalBlockSizeExc) {
			LOGGER.error("Encryption failed for keyRef '{}'", keyRef, illegalBlockSizeExc);
			throw new RuntimeException(illegalBlockSizeExc);
		} catch(BadPaddingException badPaddingExc) {
			LOGGER.error("Encryption failed for keyRef '{}'", keyRef, badPaddingExc);
			throw new RuntimeException(badPaddingExc);
		} 
		return cipherText; 
	}

	@Override
	public String encrypt(LocalDate date, DateTimeFormatter format, String keyRef, String iv) {
		return encrypt(date.format(format), keyRef, iv);
	}

	@Override
	public String encrypt(LocalDateTime timestamp, DateTimeFormatter format, String keyRef, String iv) {
		return encrypt(timestamp.format(format), keyRef, iv);
	}
	
	@Override
	public byte[] decrypt(byte[] cipherBytes, String keyRef, String iv) {
		return decrypt(new String(cipherBytes), keyRef, iv).getBytes();
	}

	@Override
	public String decrypt(String cipherText, String keyRef, String iv) {
		String plainText = null ; 
		try {
			Cipher cipher = getCipher(Cipher.DECRYPT_MODE, keyRef, iv);
			byte[] plainTextInByteArr = cipher.doFinal(Base64.getDecoder().decode(cipherText));
			plainText = new String(plainTextInByteArr);
		} catch(IllegalBlockSizeException illegalBlockSizeExc) {
			LOGGER.error("Decryption failed for keyRef '{}'", keyRef, illegalBlockSizeExc);
			throw new RuntimeException(illegalBlockSizeExc);
		} catch(BadPaddingException badPaddingExc) {
			LOGGER.error("Decryption failed for keyRef '{}'", keyRef, badPaddingExc);
			throw new RuntimeException(badPaddingExc);
		} 
		return plainText; 
	}

	@Override
	public LocalDate decryptAsDate(String cipherTextDate, DateTimeFormatter format, String keyRef, String iv) {
		String plainTextDate = decrypt(cipherTextDate, keyRef, iv);
		return LocalDate.parse(plainTextDate, format);
	}

	@Override
	public LocalDateTime decryptAsDateTime(String cipherTextTimestamp, DateTimeFormatter format, String keyRef, String iv) {
		String plainTextTimestamp = decrypt(cipherTextTimestamp, keyRef, iv);
		return LocalDateTime.parse(plainTextTimestamp, format);
	}

	protected SecretKey generateKey() throws NoSuchAlgorithmException {
		KeyGenerator keygen = KeyGenerator.getInstance(ALGO) ; // Specifying algorithm key will be used for  
		keygen.init(AES_KEY_SIZE) ; // Specifying Key size to be used, Note: This would need JCE Unlimited Strength to be installed explicitly  
		return keygen.generateKey();
	}
	
	private Cipher getCipher(int cipherMode, String keyRef, String iv) {
		Cipher c = null ; 
		try { 
			c = Cipher.getInstance(ALGO_TRANSFORMATION_STRING); // Transformation specifies algortihm, mode of operation and padding 
		} catch(NoSuchAlgorithmException noSuchAlgoExc) {
			LOGGER.error("Cipher failed to initialise for keyRef '{}'", keyRef, noSuchAlgoExc);
			throw new RuntimeException(noSuchAlgoExc);
		} catch(NoSuchPaddingException noSuchPaddingExc) {
			LOGGER.error("Cipher failed to initialise for keyRef '{}'", keyRef, noSuchPaddingExc);
			throw new RuntimeException(noSuchPaddingExc);
		}
		
		try {
			c.init(cipherMode, getKey(keyRef), new IvParameterSpec(getIv(iv))); 
		} catch(InvalidKeyException invalidKeyExc) {
			LOGGER.error("Cipher failed to initialise for keyRef '{}'", keyRef, invalidKeyExc);
			throw new RuntimeException(invalidKeyExc);
		} catch (InvalidAlgorithmParameterException e) {
			LOGGER.error("Cipher failed to initialise for keyRef '{}'", keyRef, e);
			throw new RuntimeException(e);
		} 
		return c;
	}
	
	protected Object getFromCache(String keyRef){
        LOGGER.debug("Processing getFromCache for Crypto Keys with keyRef='{}'", keyRef);
        return cacheClient.get(keyRef,prepareCacheClientConfig());
    }

	protected void putInCache(String keyRef,Object key){
        cacheClient.put(keyRef, key,prepareCacheClientConfig());
        LOGGER.trace("Processed put for keyRef='{}'", keyRef);
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private Map prepareCacheClientConfig(){
        Map props = new HashMap<>();
        props.put(CacheClient.CACHE_COLLECTION_NAME, CACHE_CRYPTO_KEY_COLLECTION);
        props.put(CacheClient.CACHE_COLLECTION_TYPE, CACHE_CRYPTO_KEY_COLLECTION_TYPE);
        return props;
    }
}
