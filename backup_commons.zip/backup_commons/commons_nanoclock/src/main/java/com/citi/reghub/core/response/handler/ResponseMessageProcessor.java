package com.citi.reghub.core.response.handler;

public interface ResponseMessageProcessor {

	public String getMessageType();
	
	public void process(ParsedResponseBundle prb);
}
