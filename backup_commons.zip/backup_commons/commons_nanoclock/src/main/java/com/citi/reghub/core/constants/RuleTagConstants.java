package com.citi.reghub.core.constants;

public interface RuleTagConstants {

	String OWNER_BUSINESS ="biz";
	String OWNER_TECH = "tech";
	String OWNER_SMC ="smc";
	String OWNER_AMC ="amc";
	String OWNER_ORC ="orc";
	
	String LEVEL_WARNING ="warning";
	String LEVEL_EXCEPTION ="exception";
	String LEVEL_NACK ="nack";
	
	String TYPE_DATA_QULAITY ="data-quality";
	String TYPE_NON_REPORTABLE ="non-reportable";
	String TYPE_APPLICATION ="application";
	String TYPE_TECHNICAL ="tech";

}
