package com.citi.reghub.core.converter;

public class IntegerConverter implements TypeConverter<String, Integer>{

	public Integer convert(String obj, String format) {
		// TODO Auto-generated method stub
		return new Integer(obj);
	}

}
