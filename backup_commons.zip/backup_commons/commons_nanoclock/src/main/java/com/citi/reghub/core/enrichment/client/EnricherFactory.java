package com.citi.reghub.core.enrichment.client;

import com.citi.reghub.core.enrichment.client.enricher.Enricher;
import com.citi.reghub.core.enrichment.client.enricher.HRMSTraderEnricher;
import com.citi.reghub.core.enrichment.client.enricher.MetadataEnricher;
import com.citi.reghub.core.enrichment.client.enricher.RefDataEnricher;

public class EnricherFactory {

	public static final String METADATA = "metadata";
	public static final String REFDATA = "refdata";
	public static final String HRMS_TRADER = "hrms_trader";

	public static Enricher getEnricher(String enrichmentType) {

		if (enrichmentType.equalsIgnoreCase(METADATA)) {
			return new MetadataEnricher();
		} else if (enrichmentType.equalsIgnoreCase(REFDATA)) {
			return new RefDataEnricher();
		} else if (enrichmentType.equalsIgnoreCase(HRMS_TRADER)) {
			return new HRMSTraderEnricher();
		}
		return null;
	}

}
