package com.citi.reghub.core.converter;

import java.math.BigDecimal;

public class BigDecimalConverter implements TypeConverter<String, BigDecimal> {

	public BigDecimal convert(String obj,String format) {
		// TODO Auto-generated method stub
		return new BigDecimal(obj);
	}

}
