package com.citi.reghub.core.cache.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SingletonCacheClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(SingletonCacheClient.class);
	private static CacheClient instance;

	public static CacheClient getInstance() {
		if (instance == null) {
			LOGGER.error("CacheClient instance='{}'", instance, new RuntimeException("Instance of Cache client is invalid"));
			throw new RuntimeException("setInstance must be called before getInstance on SingletonCacheClient");
		}
		return instance;
	}

	public static void setInstance(Map cacheClientProps) {
		instance = CacheClientFactory.getInstance(cacheClientProps);
	}

	public static void setInstance(CacheClient cacheClient) {
		instance = cacheClient;
	}
}
