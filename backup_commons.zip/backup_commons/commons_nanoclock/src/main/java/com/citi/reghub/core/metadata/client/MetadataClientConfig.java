package com.citi.reghub.core.metadata.client;

import java.util.HashMap;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;

public class MetadataClientConfig extends HashMap<String,Object> {

	public static final String REST_CLIENT = "restClient";
    public static final String METADATA_URL_KEY = "metadataUrl";
    public static final String CACHE_CLIENT = "cacheClient";
    public static final String METADATA_URL_VALUE = "http://localhost:8082/reghub-api/metadata-service/metadata/%s";
    public static final String FLOW_CODE = "flowCode";
    public static final String STREAM_CODE = "streamCode";

    public RestClient getRestClient() {
        return (RestClient) get(REST_CLIENT);
    }

    public String getMetadataUrl() {
        return (String) get(METADATA_URL_KEY);
    }

    public MetadataClientConfig setDefaultMetadataUrl() {
        return set(METADATA_URL_KEY, METADATA_URL_VALUE);
    }

    public CacheClient getCacheClient(){
    	return (CacheClient)get(CACHE_CLIENT);
    }
    
    public String getFlowCode(){
    	return (String)get(FLOW_CODE);
    }
    
    public String getStreamCode(){
    	return (String)get(STREAM_CODE);
    }
    
    public MetadataClientConfig set(String key, Object value){
        put(key,value);
        return this;
    }

}
