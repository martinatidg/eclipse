package com.citi.reghub.core;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class EntityBuilder {
	
	private Entity entity;
	
	public EntityBuilder(){
		this.entity = new Entity();
		entity.sourceStatus="PendingNew";
		entity.sourceId="483953962";
		entity.status="REPORTABLE";
		entity.stream="M2TR";
		entity.flow="CSHEQ";
		entity.sourceVersion="1";
		entity.sourceUId="207000081";
		entity.info.put("tradeType", "Market");
		entity.info.put("tradeSubType", null);
		entity.info.put("tradeExecType", "New");
		entity.info.put("tradeDate", LocalDate.of(2016, 7, 4));
		entity.info.put("tradeExecTs", LocalDateTime.parse("2016-07-04 03:58:27", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		entity.info.put("tradeCapacity", "AGENCY");
		entity.info.put("tradeQty", new BigDecimal("2500.000000"));
		entity.info.put("tradePriceCcy", "EUR");
		entity.info.put("tradePrice", new BigDecimal("100.000000"));
		entity.info.put("settlementPrice", new BigDecimal("47.300000"));
		entity.info.put("settlementCcy", "EUR");
		entity.info.put("origSrcSys", null);
		entity.info.put("rioTxnTs", LocalDateTime.parse("2016-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		entity.info.put("firmAcctId", "PACW1");
		entity.info.put("firmAcctIdType", "ACCOUNTMNEMONIC");
		entity.info.put("cptyAcctId", "02WB644");
		entity.info.put("cptyAcctIdType", "ACCOUNTMNEMONIC");
		entity.info.put("sourceFirmCode", "02");
		entity.info.put("securityId", "7921619");
		entity.info.put("securityIdType", "FII");
		entity.info.put("traderId", "0109");
		entity.info.put("buySellInd", "B");
		entity.info.put("oceanCreatedTs", LocalDateTime.parse("2017-01-10 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		entity.regHubId=entity.stream+entity.flow+entity.sourceUId;
		entity.executionTs=LocalDateTime.parse("2016-07-04 03:58:27", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		entity.publishedTs=LocalDateTime.parse("2016-07-04 04:14:02", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		entity.receivedTs=LocalDateTime.now(Clock.systemUTC());
	}
	
	public EntityBuilder regHubId(String reghubId){
		entity.regHubId = reghubId;
		return this;
	}
	
	public EntityBuilder status(String status){
		entity.status = status;
		return this;
	}
	
	public EntityBuilder stream(String stream){
		entity.stream = stream;
		return this;
	}
	
	public EntityBuilder flow(String flow){
		entity.flow = flow;
		return this;
	}
	
	public EntityBuilder sourceSystem(String sourceSystem){
		entity.sourceSystem = sourceSystem;
		return this;
	}
	
	public EntityBuilder sourceStatus(String sourceStatus){
		entity.sourceStatus = sourceStatus;
		return this;
	}
	
	public EntityBuilder sourceId(String sourceId){
		entity.sourceId = sourceId;
		return this;
	}
	
	public EntityBuilder regReportingRef(String regReportingRef){
		entity.regReportingRef = regReportingRef;
		return this;
	}
	
	public EntityBuilder sourceUid(String sourceUid){
		entity.sourceUId = sourceUid;
		return this;
	}
	
	public EntityBuilder executionTs(LocalDateTime executionTs){
		entity.executionTs = executionTs;
		return this;
	}
	
	public EntityBuilder publishedTs(LocalDateTime publishedTs){
		entity.publishedTs = publishedTs;
		return this;
	}
	
	public EntityBuilder receivedTs(LocalDateTime receivedTs){
		entity.receivedTs = receivedTs;
		return this;
	}
	
	public EntityBuilder sourceVersion(String sourceVersion){
		entity.sourceVersion = sourceVersion;
		return this;
	}
	
	public EntityBuilder setRdsEligible(boolean rdsEligible){
		entity.setRdsEligible(rdsEligible); 
		return this;
	}
	
	public EntityBuilder info(String key,Object value){
		entity.info.put(key, value);
		return this;
	}
	
	public EntityBuilder info(Map info){
		entity.info = info;
		return this;
	}
	
	public Entity build(){
		return entity;
	}

}