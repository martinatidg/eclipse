package com.citi.reghub.core.constants;

public interface EntityInfoMapConstants {
	
	public static final String SECURITY_SMCP = "sourceSecuritySmcp";
	public static final String SECURITY_ISIN = "sourceInstrumentIsin";
	public static final String SECURITY_CUSIP = "sourceSecurityCusip";
	public static final String SOURCE_LEI = "sourceLei";
	public static final String SOURCE_FIRM_CODE = "sourceFirmCode";
	public static final String SOURCE_CFI_CODE="sourceCfiCode";
	public static final String EXECUTION_VENUE_TYPE = "tradeVenueType";
	public static final String VENUE_OF_EXECUTION = "executionVenue";
	public static final String PRIMARY_EXNG = "primaryExng";
	public static final String MIN_EXECUTION_TS = "minExecutionTs";
	public static final String MAX_EXECUTION_TS = "maxExecutionTs";
	public static final String INSTRUMENT_FULL_NAME = "instrumentFullName";
	public static final String REF_INSTRUMENT_CLASSIFICATION = "refInstrumentClassification";
	public static final String REPORTING_DATE = "reportingDate";
	public static final String ISSUER_GFCID="issuer_Gfcid";
}
