package com.citi.reghub.core.converter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeConverter implements TypeConverter<String, LocalDateTime> {

	public LocalDateTime convert(String obj, String format) {
		// TODO Auto-generated method stub
		if(format == null || format.isEmpty())
			return LocalDateTime.parse(obj);
		return LocalDateTime.parse(obj, DateTimeFormatter.ofPattern(format));
	}

}
