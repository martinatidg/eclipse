package com.citi.reghub.core.singleton.clients;

import java.lang.reflect.Field;

import org.junit.BeforeClass;
import org.junit.Test;

import com.citi.reghub.core.cache.client.SingletonCacheClient;
import com.citi.reghub.core.enrichment.client.SingletonEnrichmentClient;
import com.citi.reghub.core.entity.client.SingletonEntityClient;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;
import com.citi.reghub.core.refdata.client.SingletonRefdataClient;
import com.citi.reghub.core.rules.client.SingletonRulesClient;

public class SingletonClientTest {

	@BeforeClass
	public static void setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException, InstantiationException {
		Field rulesClientInstance = SingletonRulesClient.class.getDeclaredField("instance");
		rulesClientInstance.setAccessible(true);
		rulesClientInstance.set(SingletonRulesClient.class.newInstance(), null);

		Field cacheClientInstance = SingletonCacheClient.class.getDeclaredField("instance");
		cacheClientInstance.setAccessible(true);
		cacheClientInstance.set(SingletonCacheClient.class.newInstance(), null);

		Field metaClientInstance = SingletonMetadataClient.class.getDeclaredField("instance");
		metaClientInstance.setAccessible(true);
		metaClientInstance.set(SingletonMetadataClient.class.newInstance(), null);

		Field refdataClientInstance = SingletonRefdataClient.class.getDeclaredField("instance");
		refdataClientInstance.setAccessible(true);
		refdataClientInstance.set(SingletonRefdataClient.class.newInstance(), null);
	}

	@Test(expected = RuntimeException.class)
	public void shouldNotGetRulesClient() {
		SingletonRulesClient.getInstance();
	}

	@Test(expected = RuntimeException.class)
	public void shouldNotGetMetadataClient() {
		SingletonMetadataClient.getInstance();
	}

	@Test(expected = RuntimeException.class)
	public void shouldNotGetEnrichmentClient() {
		SingletonEnrichmentClient.getInstance();
	}

	@Test(expected = RuntimeException.class)
	public void shouldNotGetCacheClient() {
		SingletonCacheClient.getInstance();
	}

	@Test(expected = RuntimeException.class)
	public void shouldNotGetEntityClient() {
		SingletonEntityClient.getInstance();
	}

	@Test(expected = RuntimeException.class)
	public void shouldNotGetRefdataClient() {
		SingletonRefdataClient.getInstance();
	}

}
