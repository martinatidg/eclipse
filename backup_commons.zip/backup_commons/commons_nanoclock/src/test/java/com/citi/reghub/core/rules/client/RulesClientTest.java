package com.citi.reghub.core.rules.client;

import  static com.citi.reghub.core.constants.EntityStatus.APP_EXCEPTION;
import  static com.citi.reghub.core.constants.EntityStatus.NON_REPORTABLE;
import static com.citi.reghub.core.constants.RuleTagConstants.LEVEL_EXCEPTION;
import static com.citi.reghub.core.constants.RuleTagConstants.LEVEL_WARNING;
import static com.citi.reghub.core.constants.RuleTagConstants.OWNER_AMC;
import static com.citi.reghub.core.constants.RuleTagConstants.OWNER_BUSINESS;
import static com.citi.reghub.core.constants.RuleTagConstants.OWNER_ORC;
import static com.citi.reghub.core.constants.RuleTagConstants.OWNER_TECH;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_APPLICATION;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_DATA_QULAITY;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_NON_REPORTABLE;
import static com.citi.reghub.core.constants.RuleTagConstants.TYPE_TECHNICAL;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.citi.reghub.core.Audit;
import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;
import com.citi.reghub.core.constants.EntityStatus;
import com.citi.reghub.core.constants.EventTypes;
import com.citi.reghub.core.metadata.client.MetadataClientConfig;
import com.citi.reghub.core.metadata.client.SingletonMetadataClient;

public class RulesClientTest {

    RestClient restClient;
    RulesClientConfig rulesClientConfig;
    MetadataClientConfig metadataConfig;
    RulesClient rulesClient;
    CacheClient cacheClient;

    @Before
    public void setUp() throws Exception {
        restClient = mock(RestClient.class);
        cacheClient = mock(CacheClient.class);
        rulesClientConfig = new RulesClientConfig().set(RulesClientConfig.REST_CLIENT, restClient).set(RulesClientConfig.CACHE_CLIENT, cacheClient);
        metadataConfig = new MetadataClientConfig().set(MetadataClientConfig.REST_CLIENT, restClient).
        		set(MetadataClientConfig.CACHE_CLIENT, cacheClient).setDefaultMetadataUrl().set(MetadataClientConfig.FLOW_CODE, "FLOW1");

        RuleGraph rulegraph = new RuleGraphBuilder().name("m2tr-pre-eligibility-check")
                .rule("my-rule-1", "exchange-eligibility-check.drl", "exchangeCodes", "exchangeCodes", "RESULT_CODE_1","custom_cache")
                .rule("my-rule-2", "only-buy-eligible.drl", "RESULT_CODE_1")
                .build();
        
		RuleGraph rulegraph_all = new RuleGraphBuilder().name("rule_frame_work_test_grp")
				.rule("my-rule-3", "appExceptionRule.drl", "RESULT_CODE_1", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-4", "techExceptionRule.drl", "RESULT_CODE_2", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-5", "nonReportableRule.drl", "RESULT_CODE_3", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-6", "bizExceptionRule.drl", "RESULT_CODE_4", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.build();

		RuleGraph rulegraph_tech_nonRep_biz = new RuleGraphBuilder().name("rule_frame_work_test_tech_nonRep_biz_grp")				
				.rule("my-rule-7", "techExceptionRule.drl", "RESULT_CODE_2", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-8", "nonReportableRule.drl", "RESULT_CODE_3", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-9", "bizExceptionRule.drl", "RESULT_CODE_4", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.build();
		
		RuleGraph rulegraph_all_newFormate = new RuleGraphBuilder().name("rule_frame_work_test_grp_new_formate")
				.rule("my-rule-N3", "CommonTestRuleNewFormate.drl", "RESULT_CODE_1", TYPE_APPLICATION, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-N4", "CommonTestRuleNewFormate.drl", "RESULT_CODE_2", TYPE_TECHNICAL, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-N5", "CommonTestRuleNewFormate.drl", "RESULT_CODE_3", TYPE_NON_REPORTABLE, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-N6", "CommonTestRuleNewFormate.drl", "RESULT_CODE_4", TYPE_DATA_QULAITY, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.build();
		
		RuleGraph rulegraph_tech_nonRep_biz_newFormate = new RuleGraphBuilder().name("rule_frame_work_test_tech_nonRep_biz_grp_new_formate")				
				.rule("my-rule-N7", "CommonTestRuleNewFormate.drl", "RESULT_CODE_2", TYPE_TECHNICAL, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.rule("my-rule-N8", "CommonTestRuleNewFormate.drl", "RESULT_CODE_3", TYPE_DATA_QULAITY, LEVEL_WARNING, "1.0", new ArrayList<String>())
				.rule("my-rule-N9", "CommonTestRuleNewFormate.drl", "RESULT_CODE_4", TYPE_NON_REPORTABLE, LEVEL_EXCEPTION, "1.0", new ArrayList<String>())
				.build();
		
		
        when(restClient.get("http://localhost:8081/reghub-api/rules-service/rule-graphs/m2tr-pre-eligibility-check/details",RuleGraph.class))
                .thenReturn(rulegraph); 

        when(restClient.get("http://localhost:8081/reghub-api/rules-service/rule-graphs/rule_frame_work_test_grp/details",RuleGraph.class))
                .thenReturn(rulegraph_all);

        when(restClient.get("http://localhost:8081/reghub-api/rules-service/rule-graphs/rule_frame_work_test_tech_nonRep_biz_grp/details",RuleGraph.class))
        .thenReturn(rulegraph_tech_nonRep_biz);
        
        when(restClient.get("http://localhost:8081/reghub-api/rules-service/rule-graphs/rule_frame_work_test_grp_new_formate/details",RuleGraph.class))
        .thenReturn(rulegraph_all_newFormate);
        
        when(restClient.get("http://localhost:8081/reghub-api/rules-service/rule-graphs/rule_frame_work_test_tech_nonRep_biz_grp_new_formate/details",RuleGraph.class))
        .thenReturn(rulegraph_tech_nonRep_biz_newFormate);
        
        Map<String,Object> metadata = new MetadataBuilder().value(Arrays.asList("NYSE","NASDAQ")).buildAsMap();
        when(restClient.get("http://localhost:8082/reghub-api/metadata-service/metadata/exchangeCodes",Map.class))
                .thenReturn(metadata);
        rulesClient = new RulesClient(rulesClientConfig);
        SingletonMetadataClient.setInstance(metadataConfig);
    }

    @Test
    public void shouldBeAbleToGetAndExecuteDroolsRuleAsAllNonReportable()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NYSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","S");}};
        }};

        RuleGraphResult result = rulesClient
                .load("m2tr-pre-eligibility-check")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(EntityStatus.NON_REPORTABLE));
        assertThat(result.getRuleResults().get(0).getStatus(),equalTo(EntityStatus.NON_REPORTABLE));
        assertThat(result.getRuleResults().get(1).getStatus(),equalTo(EntityStatus.NON_REPORTABLE));
    }


    @Test
    public void shouldBeAbleToGetAndExecuteDroolsRuleAsOneNonReportable()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NYSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("m2tr-pre-eligibility-check")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(EntityStatus.NON_REPORTABLE));
        assertThat(result.getRuleResults().get(0).getStatus(),equalTo(EntityStatus.NON_REPORTABLE));
        assertThat(result.getRuleResults().get(1).getStatus(),equalTo(EntityStatus.REPORTABLE));
    }


    @Test
    public void shouldBeAbleToGetAndExecuteDroolsRuleAsAllReportable()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("m2tr-pre-eligibility-check")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(EntityStatus.REPORTABLE));
        assertThat(result.getRuleResults().get(0).getStatus(),equalTo(EntityStatus.REPORTABLE));
        assertThat(result.getRuleResults().get(1).getStatus(),equalTo(EntityStatus.REPORTABLE));

    }
    
    @Test
    public void shouldPopulateAuditObject() {
        Trade trade = new Trade(){{
            this.exchangeCode = "NSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraph rg = rulesClient.load("m2tr-pre-eligibility-check");
        RuleGraphResult result = rg.execute(trade, new HashMap<>(), false);
        
        Audit audit = new Audit();
        rg.toAudit(audit);
        result.toAudit(audit);
       
       assertThat(audit.event, equalTo(EventTypes.RULE_GRAPH_EXECUTION + " : "+rg.name));
       assertThat(audit.result, equalTo(result.status));
    }
    
    @Test
    public void shouldGetLastLoadTimeWhenPresentInCache(){
    	Map<String, String> props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, "rule_graph");
		props.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		props.put(CacheClient.PUT_IF_ABSENT, "true");
    	when(cacheClient.get("myRuleGraph", props)).thenReturn(1002345L);
    	long lastLoadTime = rulesClient.getLastLoadTime("myRuleGraph");
    	assertEquals(1002345L,lastLoadTime);
    }
    
    @Test
    public void shouldGetLastLoadTimeWhenNotPresentInCache(){
    	Map<String, String> props = new HashMap<>();
		props.put(CacheClient.CACHE_COLLECTION_NAME, "rule_graph");
		props.put(CacheClient.CACHE_COLLECTION_TYPE, "Map");
		props.put(CacheClient.PUT_IF_ABSENT, "true");
    	when(cacheClient.get("myRuleGraph", props)).thenReturn(null);
    	long lastLoadTime = rulesClient.getLastLoadTime("myRuleGraph");
    	assertEquals(0L,lastLoadTime);
    }
    
    @Test
    public void shouldLoadRuleFromCache(){
    	Rule rule = new RuleBuilder().build("", "my-first-rule", "rule.drl", "");
    	Rule updatedRule = new RuleBuilder().build("", "my-first-rule", "updatedRule.drl", "");
    	RuleResult result = rule.execute(null, new HashMap<>(),true);
    	RuleResult updatedResult = updatedRule.execute(null, new HashMap<>(),false);
    	assertEquals(result.status,EntityStatus.NON_REPORTABLE);
    	assertEquals(updatedResult.status,EntityStatus.NON_REPORTABLE);
    }
    
    @Test
    public void shouldRebuildRuleToRefreshCache(){
    	Rule rule = new RuleBuilder().build("", "my-first-rule", "rule.drl", "");
    	Rule updatedRule = new RuleBuilder().build("", "my-first-rule", "updatedRule.drl", "");
    	RuleResult result = rule.execute(null, new HashMap<>(),true);
    	RuleResult updatedResult = updatedRule.execute(null, new HashMap<>(),true);
    	assertEquals(result.status,EntityStatus.NON_REPORTABLE);
    	assertEquals(updatedResult.status,EntityStatus.REPORTABLE);
    }
    
    @Test(expected=RuntimeException.class)
    public void shouldThrowExceptionIfRuleCompilationFails(){
    	Rule rule = new RuleBuilder().build("", "my-first-rule", "Badrule.drl", "");
    	rule.execute(null, new HashMap<>(),true);
    }
    
    @Test
    public void shouldSetRulesClient(){
    	SingletonRulesClient.setInstance(rulesClient);
    	assertNotNull(SingletonRulesClient.getInstance());
    }
    
    @Test
    public void shouldCreateAndSetRulesClient(){
    	SingletonRulesClient.setInstance(rulesClientConfig);
    	assertNotNull(SingletonRulesClient.getInstance());
    }
    
    @Test
    public void shouldBeAbleToGetAndExecuteOldDroolsRuleInNewFW()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("rule_frame_work_test_grp")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(APP_EXCEPTION));
    }

    @Test
    public void shouldBeAbleToGetAndExecuteOldDroolsRuleInNewFW_non_rep()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("rule_frame_work_test_tech_nonRep_biz_grp")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(NON_REPORTABLE));
    }
    
    @Test
    public void shouldBeAbleToGetAndExecuteNewDroolsRuleInNewFW()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("rule_frame_work_test_grp_new_formate")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(APP_EXCEPTION));
    }
    
    @Test
    public void shouldBeAbleToGetAndExecuteNewDroolsRuleInNewFW_non_rep()  {
        Trade trade = new Trade(){{
            this.exchangeCode = "NSE";
            this.info = new HashMap<String,Object>(){{ put("buySellIndicator","B");}};
        }};

        RuleGraphResult result = rulesClient
                .load("rule_frame_work_test_tech_nonRep_biz_grp_new_formate")
                .execute(trade, new HashMap<>(),false);

        assertThat(result.getStatus(),equalTo(NON_REPORTABLE));
    }
}
