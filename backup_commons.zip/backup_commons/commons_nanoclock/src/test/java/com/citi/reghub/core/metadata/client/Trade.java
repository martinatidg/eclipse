package com.citi.reghub.core.metadata.client;

import java.math.BigDecimal;

public class Trade {
	
	public String tradeRef = "123456";
	public BigDecimal amount = new BigDecimal("120085.785");
	public Broker broker = new Broker();

}

class Broker{
	public String brokerId = "505HAS";
}
