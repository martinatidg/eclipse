package com.citi.reghub.core.hrmstrader.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import com.citi.reghub.core.cache.client.CacheClient;
import com.citi.reghub.core.client.RestClient;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

//@Ignore
public class HrmsTraderClientTest {
	
	RestClient restClient;
	
	HrmsTraderClientConfig hrmsTraderClientConfig;
	
	HrmsTraderClient hrmsTraderClient;
	
	CacheClient cacheClient;
	
	@Before
	public void setUp(){
		restClient = mock(RestClient.class);
		cacheClient = mock(CacheClient.class);		
		hrmsTraderClientConfig = new HrmsTraderClientConfig().set(HrmsTraderClientConfig.REST_CLIENT, restClient).
				set(HrmsTraderClientConfig.CACHE_CLIENT, cacheClient).setDefaultHrmsTraderUrl();
		hrmsTraderClient = new HrmsTraderClient(hrmsTraderClientConfig);
		
        when(restClient.get("http://localhost:9090/reghub-api/hrms-trader-service/trader/1",Map.class))
        .thenReturn(getHrmsTraderInfo());
	}
	
	@SuppressWarnings("unused")
	@Test(expected = RuntimeException.class)
	public void testGetTraderForNotExist(){
		Object obj = hrmsTraderClient.getTrader("2");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetTrader(){
		Map<String,Object> trader = hrmsTraderClient.getTrader("1");
		assertNotNull(trader);
		Map<String,Object> traderInfo = (Map<String,Object>)trader.get(HrmsTraderClient.HRMS_TRADER_MAP_KEY);
		assertNotNull(traderInfo);
		assertTrue(traderInfo.get("decrGeId").equals("1"));
	}
	
	private Map<String,Object> getHrmsTraderInfo() {
		Map<String,Object> traderInfo = new HashMap<String,Object>();
		traderInfo.put("Id", "59b0001f3ef0fd0ff809b790");
		traderInfo.put("geId","MIVG1YC0okQXdHbRa31IvA==");
		traderInfo.put("soeId","5NEVQHDJOwmRWgpd725NcQ==");
		traderInfo.put("firstName","EwFh6TPTIuQlXPOfajZMPQ==");
		traderInfo.put("surname","9NxqAX9XOZcRJQUwy8hKLQ==");
		traderInfo.put("dateOfBirth","3WnxxCBSP5VqaY9XjobjPQ==");
		traderInfo.put("nationality","KruMxY0p2j+Ha9ij4SGo+Q==");
		traderInfo.put("nationalId","LnXtQCP7hnJBIZwWk8P3Hg==");
		traderInfo.put("m2Concat","h86v3Ul1XSrYcvIhRxKZZSQmdPNp5EN5qcxf3+f8fA0=");
		traderInfo.put("jobTitleDesc","9wZtdVJF7ba1EyPkhBt59VD0avr/hk+eBNAU7q/fTts=");
		traderInfo.put("workCountry","+XdOdu+1uENFVE5oKNe9sxQHqJD3tFYHVR3A8baeY+g=");
		traderInfo.put("dirMgrLvl04Name","tl5ixIoB9H9aPJt0AvN/1Q==");
		traderInfo.put("dirMgrLvl04JobTitleDesc","QC2NwmTCFA9RTA56AMz9uLYAs60oEZ+goGUUWKQt2qHBaK3CoBrZy1ki5A211vNi");
		traderInfo.put("dirMgrLvl05Name","KTbDG21EqkM34Rn4y4JDMA==");
		traderInfo.put("dirMgrLvl05JobTitleDesc","zsl976ayeKjZsybmi4zlE3lS/jVV+1p9wYZ+jkVkIxijUCP0EWdCvklyBmnuTUHd");
		traderInfo.put("dirMgrLvl06Name","ivntWRd0eofmO8kFvfooHQ==");
		traderInfo.put("dirMgrLvl06JobTitleDesc","H/2CakhgVfOjl+d2Mg4HnQ==");
		traderInfo.put("rcvdDateTime","lyjDtO3niyeCp4sB8OZwv0fqfhRlap/Jb2qEa/pOX7g=");
		traderInfo.put("nationalityCountryCode","IE");
		traderInfo.put("reportableM2NCI","C");
		traderInfo.put("decrGeId","1");
		traderInfo.put("decrSoeId","JO25180");
		traderInfo.put("decrRcvdDateTime","2017-09-06T15:03:11.382");

		return traderInfo;
	}

}
