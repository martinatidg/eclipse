/**
 * 
 */
package com.citi.reghub.core.xm.xstream.jms;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Future;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.test.context.junit4.SpringRunner;

import com.citi.reghub.core.xm.message.RequestMessage;
import com.citi.reghub.core.xm.xstream.schema.RegHubMsg;
import com.citi.reghub.core.xm.xstream.schema.ReghubNotificationMsg;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JMSProcessorTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSProcessorTest.class);
	private Future<?> task;

	@Autowired
	private JMSProcessor processor;
	@Autowired
	@Qualifier("outboundQueue")
	private BlockingQueue<RegHubMsg> outboundQueue;
	@Autowired
	@Qualifier("inboundQueue")
	private BlockingQueue<ReghubNotificationMsg> inboundQueue;
	@Autowired
	private AsyncTaskExecutor taskExecutor;

	@Before
	public void setUp() {
		task = taskExecutor.submit(() -> {
			try {
				processor.startSender();
			} catch (XmMessageException e) {
				LOGGER.error("InboundHandler stopped.", e);
			}
		});
	}

	 @Test
	 public void testSend() throws XmMessageException, InterruptedException {
		 RequestMessage reqMsg = new RequestMessage();
		 outboundQueue.put(reqMsg.getMessageObj());
		 ReghubNotificationMsg resMsg = inboundQueue.take();

		 Assert.assertNotNull("The response is null.", resMsg);
	 }
	 
	 @After
	 public void clean() {
		 task.cancel(true);
	 }
}
