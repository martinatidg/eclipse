package com.citi.reghub.core.xm.kafka;

import java.util.ArrayList;
import java.util.List;

import org.apache.kafka.clients.producer.ProducerConfig;

import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.exception.ExceptionMessage;
import com.citi.reghub.core.exception.Note;

public class TestData {
	public static Note getNote(String noteName, String createdBy) {
		Note note = new Note();
		note.setNote(noteName);
		note.setCreatedBy(createdBy);
		note.setCreatedTS(System.currentTimeMillis());

		return note;
	}

	public static ExceptionMessage getExMsg(String exId) {
		List<Note> notes = new ArrayList<>();
		notes.add(getNote("note1", "Martin"));
		notes.add(getNote("note2", "Michael"));
		notes.add(getNote("note3", "Evan"));

		ExceptionMessage exmsg = new ExceptionMessage();
		exmsg.setId(exId);
		exmsg.setSourceId("sourceId");
		// exmsg.setStatus("OPEN");
		exmsg.setReasonCode("IOEXCEPTION");
		exmsg.setDescription("IO Timeout");
		exmsg.setFunctionOwner("Reghub");
		exmsg.setXstreamEligible(true);
		exmsg.setNotes(notes);
		exmsg.setType("AX");
		exmsg.setLevel("WARN");
		exmsg.setRequestedTS(System.currentTimeMillis());
		exmsg.setCreatedTS(System.currentTimeMillis());
		exmsg.setUpdatedTS(System.currentTimeMillis());

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope evtmsg = new EventEnvelope();
		evtmsg.setEventName("kafkaException");
		evtmsg.setEventSource("Kafaka cluster");
		evtmsg.setEventTime(System.currentTimeMillis());
		evtmsg.setEventVersion(1);
		evtmsg.setExceptionMessage(getExMsg("Ex00001"));

		return evtmsg;
	}

	public static void main(String[] args) {
		System.out.println(ProducerConfig.configNames());
	}
}
