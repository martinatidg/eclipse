package com.citi.reghub.core.xm.xstream.storm.outbound;

import org.junit.Test;

public class XstreamOutboundTopologyTest {
	@Test
	public void runTopologyTest() throws Exception {
		XstreamOutboundTopology.main(new String[]{"local"});
	}
}
