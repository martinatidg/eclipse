package com.citi.reghub.core.xm.jms.integration;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;

import org.junit.Test;

public class GeneralTest {
	@Test
	public void testAny() {
		String format = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
		String datestr = "2017-08-02T00:00:00.000+0000";
		ZonedDateTime zdt = null;
		if(format == null || format.isEmpty()) {
			zdt = ZonedDateTime.parse(datestr);
		}
		else {
			zdt = ZonedDateTime.parse(datestr, DateTimeFormatter.ofPattern(format));
		}

		System.out.println(zdt.getLong(ChronoField.EPOCH_DAY));
		System.out.println(zdt.getLong(ChronoField.ERA));
	}
}
