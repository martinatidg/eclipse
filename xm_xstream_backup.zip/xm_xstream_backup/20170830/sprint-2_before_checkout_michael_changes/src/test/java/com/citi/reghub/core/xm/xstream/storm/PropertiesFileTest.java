package com.citi.reghub.core.xm.xstream.storm;

import java.util.Properties;

import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.PropertiesLoader;
import com.citi.reghub.core.xm.constant.Key;


public class PropertiesFileTest {
//	@Test
//	public void testPropertiesFile() {
//		String expected = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
//		Properties properties = new PropertiesLoader().loadProperties("application-dev.properties");
//		String actual = (String)properties.get(Key.ENTITY_SERVICE_URL.value());
//
//		System.out.println(actual);
//		Assert.assertEquals(expected, actual);
//		
//		expected = "sd-fbf2-5314.nam.nsroot.net:9092,sd-e1cb-e6aa.nam.nsroot.net:9092,sd-fa0e-052c.nam.nsroot.net:9092";
//		actual = (String)properties.get(Key.KAFKA_SERVER.value());
//
//		System.out.println(actual);
//		Assert.assertEquals(expected, actual);
//	}

//	@Test
//	public void testXmProperties() {
//		String expected = "http://localhost:9088/reghub-api/entity-service/entities/generic/";
//		String actual = XmProperties.getEntityServiceUrl();
//
//		System.out.println("key: " + Key.ENTITY_SERVICE_URL.value() + " = " + actual);
//		Assert.assertEquals(expected, actual);
//		
//		expected = "sd-fbf2-5314.nam.nsroot.net:9092,sd-e1cb-e6aa.nam.nsroot.net:9092,sd-fa0e-052c.nam.nsroot.net:9092";
//		actual = XmProperties.getKafakaServer();
//
//		System.out.println("key: " + Key.KAFKA_SERVER.value() + " = " + actual);
//		Assert.assertEquals(expected, actual);
//
//		expected = "com.tibco.tibjms.naming.TibjmsInitialContextFactory";
//		actual = XmProperties.getJmsProvider();
//
//		System.out.println("key: " + Key.PROVIDER.value() + " = " + actual);
//		Assert.assertEquals(expected, actual);
//
//		expected = "tibjmsnaming://icgesbint.nam.nsroot.net:7222";
//		actual = XmProperties.getJmsProviderUrl();
//
//		System.out.println("key: " + Key.PROVIDER_URL.value() + " = " + actual);
//		Assert.assertEquals(expected, actual);
//
//		expected = "citi.cibtech.na.gicapbpm_153176.XAQueueCF";
//		actual = XmProperties.getJmsJndi();
//
//		System.out.println("key: " + Key.CONNECTION_JNDI.value() + " = " + actual);
//		Assert.assertEquals(expected, actual);
//
//	}
//

}
