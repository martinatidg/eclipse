package com.citi.reghub.core.xm.xstream.temp;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.generated.Bolt;

import com.citi.reghub.core.xm.constant.Key;
import com.citi.reghub.core.xm.kafka.EventEnvelopeSerializer;

public class LocalTopologyRunner {
//	private static final int TEN_MINUTES = 5000;

	public static void main(String[] args) throws Exception {
		Config config = new Config();
		config.setDebug(true);

		Map<String, String> topologyConfig = new HashMap<>();
//		topologyConfig.put(Key.KAFKA_SERVER.value(), XmProperties.getKafakaServer());
		topologyConfig.put(Key.KAFKA_KEY_SERIALIZER.value(), StringSerializer.class.getName());
		topologyConfig.put(Key.KAFKA_VALUE_SERIALIZER.value(), EventEnvelopeSerializer.class.getName());

		LocalCluster cluster = new LocalCluster();
		cluster.submitTopology("EmulatorTopology", config, new EmulatorTopology().buildTopology(topologyConfig));
	}
}