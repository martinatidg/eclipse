package com.citi.reghub.core.xm.constant;

public enum Key {
	ENTITY_SERVICE_URL("entity.service.url"),
	KAFKA_SERVER("kafka.commons.bootstrap.servers"),
	KAFKA_KEY_SERIALIZER("kafka.commons.key.serializer"),
	KAFKA_VALUE_SERIALIZER("kafka.commons.value.serializer"),
	KAFKA_TOPIC("kafka.common.event.topic"),
	
	QUEUE_REQUEST("xm.jms.queue.request"),
	QUEUE_RESPONSE("xm.jms.queue.response"),
	PROVIDER("xm.jms.provider"),
	PROVIDER_URL("xm.jms.provider.url"),
	CONNECTION_JNDI("xm.jms.jndi"),
	;
	private final String value;

    Key(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Key fromValue(String v) {
        for (Key c: Key.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
