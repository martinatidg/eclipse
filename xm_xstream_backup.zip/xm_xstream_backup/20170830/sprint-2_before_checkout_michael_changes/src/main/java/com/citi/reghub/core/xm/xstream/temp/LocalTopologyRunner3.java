package com.citi.reghub.core.xm.xstream.temp;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.storm.Config;
import org.apache.storm.LocalCluster;

import com.citi.reghub.core.xm.kafka.EventEnvelopeSerializer;

public class LocalTopologyRunner3 {
	public static void main(String[] args) throws Exception {
		Config config = new Config();
		config.setDebug(true);

		Map<String, String> topologyConfig = new HashMap<String, String>();
		topologyConfig.put("kafka.commons.bootstrap.servers",
				"sd-dec5-c167.nam.nsroot.net:9092,sd-9caf-fdef.nam.nsroot.net:9092,sd-fdc5-8620.nam.nsroot.net:9092");
		topologyConfig.put("kafka.commons.key.serializer", StringSerializer.class.getName());
		topologyConfig.put("kafka.commons.value.serializer", EventEnvelopeSerializer.class.getName());

		LocalCluster cluster1 = new LocalCluster();
		cluster1.submitTopology("XmOutboundTopology", config, new InboundTopology().buildTopology(topologyConfig));
	}
}