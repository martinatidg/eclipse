package com.citi.reghub.core.xm.xstream.temp;

import java.util.Map;

import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.xm.xstream.storm.inbound.FromXstreamBolt;

public class InboundTopology extends BaseTopology {
	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {

		final TopologyBuilder tp = new TopologyBuilder();

		tp.setSpout("JMSConsumerSpout", new JMSConsumerSpout(), 3);
		tp.setBolt("inboundBolt", new FromXstreamBolt(), 3).shuffleGrouping("JMSConsumerSpout");

		return tp.createTopology();
	}
}
