package com.citi.reghub.core.xm.xstream.temp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

//import org.apache.commons.io.IOUtils;
import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.jms.JMSReceiver;
import com.citi.reghub.core.jms.XmJMSException;
import com.citi.reghub.core.xm.xstream.schema.outbound.NotificationMsg;

public class JMSConsumerSpout extends BaseRichSpout {
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSConsumerSpout.class);
	private static final long serialVersionUID = 1L;
	private SpoutOutputCollector outputCollector;
	private static BlockingQueue<NotificationMsg> xmQueue = new LinkedBlockingQueue<>(100);
	private static JMSReceiver receiver;

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		System.out.println("XmSpout.declareOutputFields(),  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
		declarer.declare(new Fields("message"));
	}

	@Override
	public void open(Map map, TopologyContext topologyContext, SpoutOutputCollector spoutOutputCollector) {
		this.outputCollector = spoutOutputCollector;
		System.out.println("XmSpout.JMSConsumerSpout(),  rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr");
		Map<String, String> config = (Map<String, String>)map.get(GlobalProperties.TOPOLOGY_CONFIG);

		try {
			receiver = new JMSReceiver(config);
			receiver.startListener(xmQueue);
		} catch (XmJMSException e) {

			e.printStackTrace();
		}
	}

	@Override
	public void nextTuple() {
		System.out.println("JMSConsumerSpout.nextTuple(),  enter .fffffffffffffff...............");
		NotificationMsg rnm;

		System.out.println("JMSConsumerSpout.nextTuple(),  before taking queue, size = " + xmQueue.size());

		rnm = xmQueue.poll();
		if (rnm == null) {
			System.out.println("JMSConsumerSpout.nextTuple(),  queue is empty");
			return;
		}

		System.out.println("JMSConsumerSpout.nextTuple(),  rnm = " + rnm);
		System.out.println("JMSConsumerSpout.nextTuple(),  before emitting ---------------.");
		List<Object> msgs = new ArrayList<Object>();
		msgs.add(rnm);
		outputCollector.emit(msgs);
	}
}
