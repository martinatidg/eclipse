package com.citi.reghub.core.xm.xstream.storm.outbound;

import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;
import com.citi.reghub.core.xm.constant.Constants;
import com.citi.reghub.core.xm.constant.Key;
import com.citi.reghub.core.xm.kafka.EventEnvelopeSerializer;


public class XstreamOutboundTopology extends BaseTopology {
	public static void main(String[] args) throws Exception {
		new XstreamOutboundTopology().runTopology(args);
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConf) throws Exception {
		final TopologyBuilder topologyBuilder = new TopologyBuilder();

		RegHubKafkaSpout<String, EventEnvelope> regKafkaSpout = RegHubKafkaSpout
				.builder(topologyConf.get(Key.KAFKA_TOPIC.value()), StormStreams.INBOUND_KAFKA_STREAM_NAME, topologyConf)
				.setKeyDesClazz(StringDeserializer.class).setValueDesClazz(EventEnvelopeSerializer.class)
				.build();

		topologyBuilder.setSpout(Constants.OUTBOUND_SPOUT.value(), regKafkaSpout.getSpout(), 3);
		topologyBuilder.setBolt(Constants.CONVERT_BOLT.value(),
				new ToXstreamBolt(), 3).shuffleGrouping(Constants.OUTBOUND_SPOUT.value(),
				StormStreams.INBOUND_KAFKA_STREAM_NAME);
		topologyBuilder.setBolt(Constants.PRODUCER_BOLT.value(), new JMSQueueBolt(), 3).shuffleGrouping(Constants.CONVERT_BOLT.value());

		return topologyBuilder.createTopology();
	}
}
