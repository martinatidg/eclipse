package com.citi.reghub.core.xm.xstream.storm;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.exception.ExceptionMessage;
import com.citi.reghub.core.exception.Note;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgException;
import com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory;
import com.citi.reghub.core.xm.xstream.schema.inbound.SenderStatus;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound.NotificationMsg;

public class XmMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(XmMapper.class);
	private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";


	private enum FnOwner {
		AMC(1), BUS(2), TECH(4), SMC(5);

		private final int value;
		FnOwner(int v) {
	        value = v;
	    }

	    public int value() {
	        return value;
	    }

	    public static FnOwner fromValue(String v) {
	        for (FnOwner c: FnOwner.values()) {
	            if (c.name().equalsIgnoreCase(v)) {
	                return c;
	            }
	        }
	        throw new IllegalArgumentException(v);
	    }
	}

	private ObjectFactory factory = new ObjectFactory();

	public XmFeedMsg  outboundMap(ExceptionMessage exception, Entity entity) {
		MOMsgEntity momsgEntity = mapEntity(entity);
		MOMsgException mom = sgExceptionmapException(exception);
		
		XmFeedMsg feedMsg = factory.createXmFeedMsg();
		feedMsg.setMoEntity(momsgEntity);
		feedMsg.getMoException().add(mom);
//		feedMsg.setRequestId(value);
//		feedMsg.setSenderCompID(value);
//		feedMsg.setTimestamp(value);
		
		return feedMsg;
		
	}

	private MOMsgException sgExceptionmapException(ExceptionMessage exception) {
		MOMsgException moMsgException = factory.createMOMsgException();
		moMsgException.setCreatedBy(exception.getFunctionOwner());
		moMsgException.setDescription(exception.getDescription());
		//moMsgException.setExceptionType(exception.getType());
		moMsgException.setFirstRaisedDatetime(exception.getCreatedTS());
		moMsgException.setFnOwner(FnOwner.fromValue((exception.getFunctionOwner())).value());
		moMsgException.setSenderCompID(exception.getSourceId());
		moMsgException.setSenderExceptionID(exception.getId());
		//moMsgException.setSenderExceptionVersion(exception.get);
		moMsgException.setSenderStatus(SenderStatus.valueOf(exception.getStatus()));
		moMsgException.setSrcSysID(exception.getSourceId());
		moMsgException.setWorkflowStatus(exception.getStatus());

		
		return moMsgException;
	}

	private MOMsgEntity mapEntity(Entity entity) {

		LOGGER.info("XmMapper.outboundMap(), entity = \n{}", entity);

		MOMsgEntity outmsg = factory.createMOMsgEntity();
		Map<String, Object> info = entity.info;

		outmsg.setSrcSystemID(entity.sourceId);								// 1
		outmsg.setSrcSystemRef((String)info.get("sourceSystem"));			// 2,  "SourceFrontOfficeSystem")); FXLMREG
		outmsg.setTradeID(entity.sourceUId);								// 3,  OK
		outmsg.setTradeVersion(getInt(entity.sourceVersion));				// 4,  OK
		outmsg.setQuantity(getDouble(info.get("tradeQty")));				// 5,  ? octTradeQty
		outmsg.setPrice(getDouble(info.get("tradePrice")));					// 6,  ?
		outmsg.setExecCurrency((String)info.get("tradePriceCcy"));			// 7,  ? strikePriceCcy
		outmsg.setSide((String)info.get("buySellInd"));						// 8,  OK, null
		outmsg.setTraderID((String)info.get("traderId"));					// 9,  OK, null

		outmsg.setLegalEntity((String)info.get("sourceFirmLEI"));			// 10, ? AMC
		outmsg.setClientLegalEntity((String)info.get("sourceCptyLEI"));		// 11, ? AMC

		outmsg.setSecurityID((String)info.get("securityId"));				// 12, ? SMC
		outmsg.setSecurityIDSource((String)info.get("securityIdType"));		// 13, ? SMC

		outmsg.setFirmMnemonic((String)info.get("firmAcctId"));				// 14, OK, FLVELO
		outmsg.setUnderlying((String)info.get("underlyingInstrument"));		// 15, OK, XXXXXXXXXXXX
		outmsg.setCustomerMnemonic((String)info.get("cptyAcctId"));			// 16, OK, null
		outmsg.setProductType((String)info.get("productType"));				// 17, OK, PRODUCT_TYPE
		outmsg.setSourceFrontOfficeSystem((String)info.get("sourceSystem")); //18, OK, entity.sourceSystem
		outmsg.setPrimaryAssetClass((String)info.get("primaryAssetClass"));	// 19, OK, ForeignExchange
		outmsg.setParty1GFCID((String)info.get("sourceFirmGFCID"));			// 20, OK, 1000101733
		outmsg.setParty1Mnemonic((String)info.get("firmAcctId"));			// 21, OK, same as 14
		outmsg.setParty2GFCID((String)info.get("sourceCptyGFCID"));			// 22, OK, 1000101733
		outmsg.setParty2Mnemonic((String)info.get("cptyAcctId"));			// 23, OK, same as 16

		outmsg.setMessageID((String)info.get("messageID"));					// 24, ?, RegHub
		outmsg.setMessageType((String)info.get("messageType"));				// 25, ?, RegHub
		outmsg.setMessageCategory((String)info.get("messageCategory"));		// 26, ?, RegHub

		//outmsg.setExceptionID(exception.getId());							// 27, OK, RegHub
		
		outmsg.setExceptionClass((String)info.get("exceptionClass"));		// 28, ?, RegHub exception.getClass()
		outmsg.setCreationTimestamp(getLong(entity.receivedTs));				// 29, ?, RegHub exception.getUpdatedTS(), exception.getCreatedTS(), entity.receivedTs, entity.publishedTs, entity.lastUpdatedTs
		outmsg.setExecutionDateTime(getLong(entity.executionTs));			// 30, ?, RegHub entity.executionTs

		outmsg.setTradeStatus((String)info.get("tradeStatus"));				// 31, ? exception.getStatus(), entity.status, entity.sourceStatus
		outmsg.setTradeDate(getLong((String)info.get("tradeDate")));		// 32, ? 2017-08-01 00:00:00.000Z

		return outmsg;
	}

	private long getLong(final String dateTimeStr) {
		if (dateTimeStr == null ||  dateTimeStr.trim().isEmpty()) {
			return 0;
		}

		LocalDateTime time;
		try {
			time = LocalDateTime.parse(dateTimeStr, DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT));
		}
		catch (Exception e) {
			LOGGER.error("XmMapper.getLong(dateTime string), error:\n{}", e);
			return 0;
		}
		
		return getLong(time);
	}

	private long getLong(LocalDateTime time) {
		return time.atZone(Clock.systemUTC().getZone()).toInstant().getEpochSecond();
	}
	
	private double getDouble(Object obj) {
		if (obj == null) {
			return 0.0;
		}

		double value = 0.0;
		try {
			value = Double.parseDouble((String)obj);
		}
		catch (Exception e) {
			LOGGER.error("XmMapper.getDouble(), error:\n{}", e);
		}

		return value;
	}

	private int getInt(Object obj) {
		if (obj == null) {
			return 0;
		}

		int value = 0;
		try {
			value = Integer.parseInt((String)obj);
		}
		catch (Exception e) {
			LOGGER.error("XmMapper.getInt(), error:\n{}", e);
		}

		return value;
	}

	public EventEnvelope inboudMap(NotificationMsg nmsg) {
		EventEnvelope envelope = new EventEnvelope();
		ExceptionMessage xmsg = new ExceptionMessage();

		List<MsgExceptionNote> xnotes = nmsg.getNote();
		
		xmsg.setId(nmsg.getExceptionID());
		nmsg.getExceptionRefNumber();
		nmsg.getStatus();
		nmsg.getTypeOfOwner();
		xmsg.setStatus(nmsg.getStatus().value());
		xmsg.setNotes(getNotes(xnotes));

		envelope.setEventName("exceptionUpdated");
		envelope.setEventSource("XM-XSTREAM");
		envelope.setEventTime(System.currentTimeMillis());
		envelope.setEventVersion(1);
		envelope.setExceptionMessage(xmsg);

		return envelope;
	}
	
	private List<Note> getNotes(List<MsgExceptionNote> xnotes) {
		List<Note> notes = new ArrayList<>();

		for (MsgExceptionNote xnote : xnotes) {
			Note note = new Note();
			note.setNote(xnote.getNote());
			note.setCreatedBy(xnote.getLastUpdatedBy());
			note.setCreatedTS(xnote.getNoteTimestamp());

			notes.add(note);
		}

		return notes;
	}
}
