package com.citi.reghub.core.xm.xstream.storm.outbound;

import java.util.Map;

import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.constants.GlobalProperties;
import com.citi.reghub.core.jms.JMSQueueClient;
import com.citi.reghub.core.jms.XmJMSException;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;


public class JMSQueueBolt extends BaseBasicBolt {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSQueueBolt.class);
	private JMSQueueClient msgSender;

	@Override
	public void prepare(Map stormConf, TopologyContext context) {
		super.prepare(stormConf, context);
		Map<String, String> config = (Map<String, String>)stormConf.get(GlobalProperties.TOPOLOGY_CONFIG);

		try {
			msgSender = new JMSQueueClient(config);
		} catch (XmJMSException e) {
			LOGGER.error("Failed to initialize JMSSender:\n{}", e);
		}
	}

	public void execute(Tuple tuple, BasicOutputCollector arg1) {
		LOGGER.debug("JMSProducerBolt.execute(), enter .............");

		XmFeedMsg msg = (XmFeedMsg) tuple.getValueByField("message");
		try {
			msgSender.sendMessage(msg);
		} catch (XmJMSException e) {
			LOGGER.error("JMSProducerBolt.execute(), error:\n", e);
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		LOGGER.info("JMSProducerBolt.declareOutputFields(), This method is not implemented.");
	}
}
