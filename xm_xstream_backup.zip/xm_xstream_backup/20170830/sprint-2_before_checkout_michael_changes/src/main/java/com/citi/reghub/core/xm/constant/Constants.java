package com.citi.reghub.core.xm.constant;

public enum Constants {
	// outbound
	OUTBOUND_TOPOLOGY("OutboundTopology"),
	OUTBOUND_SPOUT("EventMessage_spout"),
	CONVERT_BOLT("xm_converter_bolt"),
	PRODUCER_BOLT("JMS_Producer_bolt"),
	EVENT_FILTER("XM-XSTREAM"),
	// inbound
	INBOUND_FIELD("message"),
	XM_JMS_SPOUT("XmJmsSpout"),
	FROM_BOLT("FromXstreamBolt"),
	KAFKA_BOLT("ReghubKafkaBolt")
	;

	private final String value;

    Constants(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Constants fromValue(String v) {
        for (Constants c: Constants.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
