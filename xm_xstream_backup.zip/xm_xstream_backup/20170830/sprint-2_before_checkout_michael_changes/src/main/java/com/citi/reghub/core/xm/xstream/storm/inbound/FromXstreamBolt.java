package com.citi.reghub.core.xm.xstream.storm.inbound;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.jms.XmMarshaller;
import com.citi.reghub.core.xm.constant.Constants;
import com.citi.reghub.core.xm.xstream.schema.outbound.NotificationMsg;
import com.citi.reghub.core.xm.xstream.storm.XmMapper;

public class FromXstreamBolt  extends BaseBasicBolt {
	private static final Logger LOGGER = LoggerFactory.getLogger(FromXstreamBolt.class);

	private static final long serialVersionUID = 1L;

	public void execute(Tuple tuple, BasicOutputCollector outputCollector) {
		String msg = (String)tuple.getValueByField(Constants.INBOUND_FIELD.value());
		NotificationMsg nmsg = null;
		try {
			nmsg = (NotificationMsg) XmMarshaller.unmarshal(msg);
		} catch (JAXBException e) {
			LOGGER.error("Failed to marshall the message: {}", e);
		}

		XmMapper mapper = new XmMapper();
		EventEnvelope envelope = mapper.inboudMap(nmsg);

		List<Object> msgs = new ArrayList<>();
		msgs.add(envelope);

		outputCollector.emit(msgs);
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields(Constants.INBOUND_FIELD.value()));
	}
}
