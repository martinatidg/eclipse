package com.citi.reghub.core.xm.xstream.temp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.exception.ExceptionMessage;
import com.citi.reghub.core.exception.Note;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgEntity;
import com.citi.reghub.core.xm.xstream.schema.inbound.MOMsgException;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.MsgExceptionNote;
import com.citi.reghub.core.xm.xstream.schema.outbound.NotificationMsg;
import com.citi.reghub.core.xm.xstream.schema.outbound.Status;

public class TestData {
	private static com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory outfactory = new com.citi.reghub.core.xm.xstream.schema.outbound.ObjectFactory();
	private static com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory infactory = new com.citi.reghub.core.xm.xstream.schema.inbound.ObjectFactory();
	private static Random random = new Random();
	private static String[] sourceIds =
		{"03550600LDN822356275", "03550600LDN822356352", "03550600LDN822356502", "N14527300NYK2017080115118_E",
		 "03550600LDN822356286", "03550600LDN822356359", "03550600LDN822356290", "03550600LDN822356298",
		 "03550600LDN822356401", "03550600LDN822356417", "03550600LDN822356389", "03550600LDN822356447"};

	private static String[] eventNames =
		{"exceptionRequested", "exceptionCreated", "exceptionUpdated", "exceptionClosed"};

	private static String[] fnOwners = {"AMC", "BUS", "TECH", "SMC"};
	private static String[] eventSources = {"reporting stream", "UI", "file sender", "XM-XSTREAM_1"};
	private static String[] types = {"DQ", "AX", "BX"};
	private static String[] levels = {"WARN", "EXCEPTION"};

	public static Note getNote(String noteName, String createdBy) {
		Note note = new Note();
		note.setNote(noteName);
		note.setCreatedBy(createdBy);
		note.setCreatedTS(System.currentTimeMillis());

		return note;
	}

	public static ExceptionMessage getExMsg(String exId) {
		List<Note> notes = new ArrayList<Note>();
		notes.add(getNote("note1", "Martin"));
		notes.add(getNote("note2", "Michael"));
		notes.add(getNote("note3", "Elan"));

		ExceptionMessage exmsg = new ExceptionMessage();
		exmsg.setId(exId);
		exmsg.setSourceId(sourceId());
		exmsg.setStatus("OPEN");
		exmsg.setReasonCode("IOEXCEPTION");
		exmsg.setDescription("test data");
		exmsg.setFunctionOwner(fnOwner());
		exmsg.setXstreamEligible(true);
		exmsg.setNotes(notes);
		exmsg.setType(type());
		exmsg.setLevel(level());
		exmsg.setRequestedTS(System.currentTimeMillis());
		exmsg.setCreatedTS(System.currentTimeMillis());
		exmsg.setUpdatedTS(System.currentTimeMillis());

		return exmsg;
	}

	public static EventEnvelope getEvtMsg() {
		EventEnvelope evtmsg = new EventEnvelope();
		evtmsg.setEventVersion(1);
		evtmsg.setEventSource(eventSource());
		evtmsg.setEventName(eventName());
		evtmsg.setEventTime(System.currentTimeMillis());
		evtmsg.setExceptionMessage(getExMsg(exId()));

		return evtmsg;
	}
	
	private static String fnOwner() {
		int index = random.nextInt(4);
		return fnOwners[index];
	}

	private static String sourceId() {
		int index = random.nextInt(12);
		return sourceIds[index];
	}

	private static String eventName() {
		int index = random.nextInt(4);
		return eventNames[index];
	}

	private static String eventSource() {
		int index = random.nextInt(4);
		return eventSources[index];
	}

	private static String type() {
		int index = random.nextInt(3);
		return types[index];
	}

	private static String level() {
		int index = random.nextInt(2);
		return levels[index];
	}

	private static String exId() {
		int i = random.nextInt(1000000000);
		return String.format("%09d", i);
	}
	
	public static NotificationMsg getNoteMsg(XmFeedMsg xmmsg) {
		NotificationMsg notemsg = outfactory.createNotificationMsg();
		MsgExceptionNote exNote = outfactory.createMsgExceptionNote();
		
		MOMsgEntity msgObj = xmmsg.getMoEntity();
		List<MOMsgException> exmsg = xmmsg.getMoException();
		exNote.setNote("Approved");
		exNote.setLastUpdatedBy(xmmsg.getRequestId());
		exNote.setNoteTimestamp(msgObj.getExecutionDateTime());
		
		notemsg.setExceptionID(msgObj.getExceptionID());
		notemsg.setExceptionRefNumber(msgObj.getSrcSystemRef());
		notemsg.setStatus(Status.CLOSED);
		notemsg.setTypeOfOwner(msgObj.getTraderID());
		notemsg.getNote().add(exNote);
		
		return notemsg;
	}
}
