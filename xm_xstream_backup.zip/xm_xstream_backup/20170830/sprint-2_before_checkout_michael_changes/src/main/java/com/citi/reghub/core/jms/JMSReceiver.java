package com.citi.reghub.core.jms;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.xm.constant.Key;
import com.citi.reghub.core.xm.xstream.schema.outbound.NotificationMsg;
//import com.citi.reghub.core.xm.xstream.storm.XmProperties;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class JMSReceiver implements MessageListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSReceiver.class);

	private String CONNECTION_JNDI;// = XmProperties.getJmsJndi();
	private String PROVIDER_URL;// = XmProperties.getJmsProviderUrl();
	private String factoryName = TibjmsInitialContextFactory.class.getName();
	private String QUEUE_RESPONSE;// = XmProperties.getJmsQueueResponse();

	private Connection connection;
	private InitialContext context;

	private BlockingQueue<NotificationMsg> xmQueue;
	
	public JMSReceiver(Map<String, String> config) throws XmJMSException {
		CONNECTION_JNDI = config.get(Key.CONNECTION_JNDI.value());;
		PROVIDER_URL = config.get(Key.PROVIDER_URL.value()); 
		QUEUE_RESPONSE = config.get(Key.QUEUE_RESPONSE.value());
	}

	public void onMessage(Message message) {
		System.out.println("JMSReceiver.onMessage(), enter ooooooooooooooooo");
		try {
			String xml = ((TextMessage) message).getText();
			System.out.println("Message received:\n{}" + xml);
			LOGGER.info("Message received:\n{}", xml);

			NotificationMsg msgObj = (NotificationMsg) XmMarshaller.unmarshal(xml);
			boolean c = msgObj instanceof NotificationMsg;
			LOGGER.info("Unmarshaled to RegHubMsg: {}", c);
			System.out.println("JMSReceiver.onMessage(), msgObj:\n" + msgObj);
			xmQueue.put(msgObj);
			System.out.println("JMSReceiver.onMessage(), sssssizzzeeeeeeee, xmQueue.size() = " + xmQueue.size());
		} catch (Exception e) {
			System.out.println("JMSReceiver.onMessage(), error:\n{}" + e);
			LOGGER.error("JMSReceiver.onMessage(), error:\n{}", e);
		}
	}

	public void startListener(BlockingQueue<NotificationMsg> queue) throws XmJMSException {
		System.out.println("JMSReceiver.startListener(), enter vvvvvvvvvvvvvvvvvvvvvvvvvvvv");
		xmQueue = queue;
		try {
			Properties env = new Properties();
			env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
			env.put(Context.PROVIDER_URL, PROVIDER_URL);
			context = new InitialContext(env);
			ConnectionFactory connectionFactory = (QueueConnectionFactory) context.lookup(CONNECTION_JNDI);

			connection = connectionFactory.createConnection();
			connection.start();

			Queue respQueue = (Queue) context.lookup(QUEUE_RESPONSE);
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(respQueue);
			consumer.setMessageListener(this);
		} catch (Exception e) {
			throw new XmJMSException(e);
		}
	}
}
