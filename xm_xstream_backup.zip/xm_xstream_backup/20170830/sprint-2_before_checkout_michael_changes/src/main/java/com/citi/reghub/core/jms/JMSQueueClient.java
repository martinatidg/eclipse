package com.citi.reghub.core.jms;

import java.io.Serializable;
import java.util.Map;
import java.util.Observable;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.xm.constant.Key;
import com.citi.reghub.core.xm.xstream.schema.inbound.XmFeedMsg;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class JMSQueueClient extends Observable implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSQueueClient.class);

	private String CONNECTION_JNDI;
	private String PROVIDER_URL;
	private String QUEUE_REQUEST;

	private String factoryName = TibjmsInitialContextFactory.class.getName();
	private Connection connection;
	private InitialContext context;

	public JMSQueueClient(Map<String, String> config) throws XmJMSException {
		CONNECTION_JNDI = config.get(Key.CONNECTION_JNDI.value());;
		PROVIDER_URL = config.get(Key.PROVIDER_URL.value()); 
		QUEUE_REQUEST = config.get(Key.QUEUE_REQUEST.value());

		try {;
			Properties env = new Properties();
			env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
			env.put(Context.PROVIDER_URL, PROVIDER_URL);
			context = new InitialContext(env);
			ConnectionFactory connectionFactory = (QueueConnectionFactory) context.lookup(CONNECTION_JNDI);
			connection = connectionFactory.createConnection();
			connection.start();
		} catch (Exception e) {
			throw new XmJMSException(e);
		}
	}

	public void sendMessage(XmFeedMsg outmsg) throws XmJMSException {
		try {
			Session queueSession = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			TextMessage message = queueSession.createTextMessage();
			LOGGER.info("XmServer.sendResponse(), outmsg: {}", outmsg);
			String msg = XmMarshaller.marshal(outmsg);
			message.setText(msg);
			LOGGER.info("XmServer.sendResponse(), msg: {}", msg);

			Queue reqQueue = (Queue) context.lookup(QUEUE_REQUEST);
			MessageProducer producer = queueSession.createProducer(reqQueue);
			producer.send(message);

			queueSession.close();
		} catch (Exception e) {
			throw new XmJMSException(e);
		}
	}
}
