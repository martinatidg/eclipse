package com.citi.reghub.core.xm.xstream.storm;

import java.util.Map;
import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.storm.jms.JmsProvider;

import com.citi.reghub.core.xm.constant.Key;

public class XmJmsProvider implements JmsProvider {
	private static final long serialVersionUID = 1L;
	private String connectionJndi;
	private String destination;
	private InitialContext context;

	public XmJmsProvider(Map<String, String> config, boolean isOutbound) throws NamingException {
		this.connectionJndi = config.get(Key.CONNECTION_JNDI.value());

		if (isOutbound) {
			this.destination = config.get(Key.QUEUE_REQUEST.value());
		}
		else {
			this.destination = config.get(Key.QUEUE_RESPONSE.value());
		}

		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, config.get(Key.PROVIDER.value()));
		env.put(Context.PROVIDER_URL, config.get(Key.PROVIDER_URL.value()));
		context = new InitialContext(env);
	}

	@Override
	public ConnectionFactory connectionFactory() throws Exception {
		return (QueueConnectionFactory) context.lookup(connectionJndi);
	}

	@Override
	public Destination destination() throws Exception {
		return (Destination)context.lookup(destination);
	}
}
