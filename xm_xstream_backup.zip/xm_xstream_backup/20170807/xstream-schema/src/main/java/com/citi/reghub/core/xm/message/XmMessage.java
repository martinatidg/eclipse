package com.citi.reghub.core.xm.message;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

public interface XmMessage<T> {
	T getMessageObj();
	String marshal() throws JAXBException;

	default public String marshal(T msg) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xm.xjc" );
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(msg, writer );
		
		return writer.toString();
	}

	default public T unmarshal(String xml) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance( "com.citi.reghub.core.xm.xjc" );

		Unmarshaller u = jc.createUnmarshaller();
		T msgObj = (T)u.unmarshal(new StreamSource(new StringReader(xml)));
		
		return msgObj;
	}
}
