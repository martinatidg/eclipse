package com.citi.reghub.core.xm.message;

import javax.xml.bind.JAXBException;

import com.citi.reghub.core.xm.xjc.ObjectFactory;
import com.citi.reghub.core.xm.xjc.ReghubNotificationMsg;
import com.citi.reghub.core.xm.xjc.Status;

public class ResponseMessage implements XmMessage<ReghubNotificationMsg> {
	private ReghubNotificationMsg msg;

	public ResponseMessage() {
		ObjectFactory obj = new ObjectFactory();
		msg = obj.createReghubNotificationMsg();
		msg.setExceptionID("3333333333333");
		msg.setExceptionRefNumber("55555555555");
		msg.setStatus(Status.CLOSED);
		msg.setTypeOfOwner("Manager");
	}

	public void setExceptionId(String exId) {
		msg.setExceptionID(exId);
	}

	@Override
	public ReghubNotificationMsg getMessageObj() {
		return msg;
	}

	@Override
	public String marshal() throws JAXBException {
		return marshal(msg);
	}
}
