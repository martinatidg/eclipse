package com.citi.reghub.core.xm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.jms.client.XMMessageProcessor;
import com.citi.reghub.core.xm.jms.client.XmMessageException;

/**
 * @author Martin Tan
 *    validate the environment after all bean registered but before
 *    launching the job scheduler
 */
@Component
public class AppListener implements ApplicationListener<ContextRefreshedEvent> {
	private static final Logger LOGGER = LoggerFactory.getLogger(AppListener.class);

	@Autowired
	private XMMessageProcessor processor;

	@Override
	public void onApplicationEvent(ContextRefreshedEvent arg0) {
		LOGGER.info("Start XM Xstream.......");

		try {
			processor.setProperties();
			processor.startResponseProcessor();
			processor.startRequestProcessor();
		} catch (XmMessageException e) {
			LOGGER.info("XM Xstream failed to start: {}", e.getMessage());
		}
		
	}
}
