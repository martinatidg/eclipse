package com.citi.reghub.core.xm;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration

@PropertySource("classpath:application.properties") // disable/enable batch auto start
public class XmConfiguration {

}
