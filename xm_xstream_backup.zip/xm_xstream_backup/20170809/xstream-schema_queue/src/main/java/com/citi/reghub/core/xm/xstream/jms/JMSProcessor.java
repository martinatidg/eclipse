package com.citi.reghub.core.xm.xstream.jms;

import java.util.concurrent.BlockingQueue;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;

import com.citi.reghub.core.xm.message.XmMarshaller;
import com.citi.reghub.core.xm.xstream.XmProcessor;
import com.citi.reghub.core.xm.xstream.schema.RegHubMsg;
import com.citi.reghub.core.xm.xstream.schema.ReghubNotificationMsg;

public class JMSProcessor implements XmProcessor {
	private static final Logger LOGGER = LoggerFactory.getLogger(JMSProcessor.class);
	@Value("${xm.jms.queue.response}")
	private String queueResponse;
	@Autowired
	private JmsTemplate jmsTemplate;
	@Autowired
	@Qualifier("requestDestination")
	private Destination requestDestination;
	@Autowired
	@Qualifier("responseDestination")
	private Destination respnseDstination;
	@Autowired
	@Qualifier("requestMeaasgeConverter")
	private RequestConverter requestMeaasgeConverter;

	@Autowired
	@Qualifier("outboundQueue")
	private BlockingQueue<RegHubMsg> outboundQueue;
	@Autowired
	@Qualifier("inboundQueue")
	private BlockingQueue<ReghubNotificationMsg> inboundQueue;

	@Override
	public void startSender() throws XmMessageException {
		LOGGER.info("JMSProcessor.startSender() enter ........");

		int c = 0;
		while (true) {
			LOGGER.info("JMSProcessor.startSender(), sending message {}", c++);
			Object obj;
			try {
				obj = outboundQueue.take();
				if (obj == null) {
					break;
				}

				jmsTemplate.setMessageConverter(requestMeaasgeConverter);
				jmsTemplate.convertAndSend(requestDestination, obj);
			} catch (InterruptedException e) {
				LOGGER.error("JMSProcessor.startSender(), Failed to send message:\n{}", e);
				throw new XmMessageException(e);
			}
		}
	}

	@JmsListener(destination = "${xm.jms.queue.response}")
	public void listen(Message message) throws XmMessageException {
		LOGGER.info("JMSProcessor.listen(), response received.");
		try {
			String xmlmsg = ((TextMessage) message).getText();
			LOGGER.info("JMSProcessor.listen(), Response received:\n{}", xmlmsg);

			Object changedObj = XmMarshaller.unmarshal(xmlmsg);
			inboundQueue.put((ReghubNotificationMsg) changedObj);
		} catch (JMSException | JAXBException | InterruptedException e) {
			LOGGER.error("JMSProcessor.listen(), failed to process response", e);
			throw new XmMessageException(e);
		}
	}
}