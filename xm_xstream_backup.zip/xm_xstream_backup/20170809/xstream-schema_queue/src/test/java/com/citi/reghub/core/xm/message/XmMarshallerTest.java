package com.citi.reghub.core.xm.message;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;

import com.citi.reghub.core.xm.xstream.schema.RegHubMsg;

public class XmMarshallerTest {
	@Test
	public void testMarshal() throws JAXBException {
		RequestMessage reqmsg = new RequestMessage();
		RegHubMsg msg = reqmsg.getMessageObj();
		String xml = XmMarshaller.marshal(msg);

		Assert.assertNotNull("The marshalled result is null.", xml);
		Assert.assertFalse("The marshalled result is empty.", xml.trim().isEmpty());
	}

	@Test
	public void testUnmarshal() throws JAXBException {
		RequestMessage reqmsg = new RequestMessage();
		String xml = reqmsg.marshal();
		Object msg = XmMarshaller.unmarshal(xml);

		Assert.assertNotNull("The unmarshalled result is null.", msg);
		Assert.assertTrue("The unmarshalled object is not the expected type.", msg instanceof RegHubMsg);
	}
}
