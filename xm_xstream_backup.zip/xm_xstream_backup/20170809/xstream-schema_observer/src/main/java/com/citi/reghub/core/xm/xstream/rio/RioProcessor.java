package com.citi.reghub.core.xm.xstream.rio;

import javax.jms.Message;
import javax.jms.MessageListener;

import com.citi.reghub.core.xm.xstream.XmProcessor;
import com.citi.reghub.core.xm.xstream.jms.XmMessageException;

public class RioProcessor  implements XmProcessor, MessageListener {

	@Override
	public void onMessage(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void send(Object msgxml) throws XmMessageException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object receive() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void listen(Message message) throws XmMessageException {
		// TODO Auto-generated method stub
		
	}

}
