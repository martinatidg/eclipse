package com.citi.reghub.core.xm;

import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;

import com.citi.reghub.core.xm.xstream.XmProcessor;
import com.citi.reghub.core.xm.xstream.jms.JMSProcessor;
import com.citi.reghub.core.xm.xstream.jms.RequestConverter;
import com.citi.reghub.core.xm.xstream.jms.ResponseConverter;
import com.citi.reghub.core.xm.xstream.rio.RioProcessor;

@Configuration
@EnableJms
@PropertySource("classpath:application.properties")
public class XmConfiguration {
	@Value("${xm.message.type}")
	private String msgType;
	@Value("${xm.jms.queue.request}")
	String queueRequest;
	@Value("${xm.jms.queue.response}")
	String queueResponse;
	@Value("${xm.jms.jndi}")
	String connectionFactoryJndi;
	@Value("${xm.jms.provider}")
	String provider;
	@Value("${xm.jms.provider.url}")
	String url;

	@Bean
	public InitialContext context() throws NamingException {
		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, provider);
		env.put(Context.PROVIDER_URL, url);

		return new InitialContext(env);
	}

	@Bean
	public ConnectionFactory connectionFactory() throws NamingException {
		return (QueueConnectionFactory) context().lookup(connectionFactoryJndi);
	}
	
	@Bean
	@Qualifier("requestMeaasgeConverter")
	public RequestConverter requestMeaasgeConverter() {
		return new RequestConverter();
	}

	@Bean
	@Qualifier("responseMeaasgeConverter")
	public ResponseConverter responseMeaasgeConverter() {
		return new ResponseConverter();
	}

	@Bean 
	public JmsTemplate jmsTemplate() throws NamingException {
		return new JmsTemplate(connectionFactory());
	}

	@Bean
	public Destination requestDestination() throws NamingException {
		return (Queue) context().lookup(queueRequest);
	}

	@Bean
	public Destination responseDestination() throws NamingException {
		return (Queue) context().lookup(queueResponse);
	}

	@Bean
	public XmProcessor xmProcessor() {
		if ("JMS".equals(msgType)) {
			return new JMSProcessor();
		}
		else {
			return new RioProcessor();
		}
	}
}
