package com.citi.reghub.core.xm.message;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

public class XmMarshaller {
	private static String xjcPackage = "com.citi.reghub.core.xm.xstream.schema";
	private XmMarshaller() {
		throw new UnsupportedOperationException(
				"The Util class contains static methods only and cannot be instantiated.");
	}

	public static String marshal(Object msg) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(xjcPackage);
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(msg, writer);

		return writer.toString();
	}

	public static Object unmarshal(String xml) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(xjcPackage);

		Unmarshaller unmarshaller = jc.createUnmarshaller();
		return unmarshaller.unmarshal(new StreamSource(new StringReader(xml)));
	}
}
