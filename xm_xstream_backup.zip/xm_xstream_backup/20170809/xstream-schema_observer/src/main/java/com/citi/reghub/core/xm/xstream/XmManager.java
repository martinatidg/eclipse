package com.citi.reghub.core.xm.xstream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.xstream.jms.XmMessageException;

@Component
public class XmManager {
	@Autowired
	private XmProcessor processor;

	public void send(Object obj) throws XmMessageException {
		processor.send(obj);
	}

	public Object receive() throws XmMessageException {
		return processor.receive();
	}
}
