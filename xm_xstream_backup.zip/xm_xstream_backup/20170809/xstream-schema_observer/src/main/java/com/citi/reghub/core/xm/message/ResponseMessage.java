package com.citi.reghub.core.xm.message;

import javax.xml.bind.JAXBException;

import com.citi.reghub.core.xm.xstream.schema.ObjectFactory;
import com.citi.reghub.core.xm.xstream.schema.ReghubNotificationMsg;
import com.citi.reghub.core.xm.xstream.schema.Status;

public class ResponseMessage {
	private ReghubNotificationMsg msg;

	public ResponseMessage() {
		ObjectFactory obj = new ObjectFactory();
		msg = obj.createReghubNotificationMsg();
		msg.setExceptionID("3333333333333");
		msg.setExceptionRefNumber("55555555555");
		msg.setStatus(Status.CLOSED);
		msg.setTypeOfOwner("Manager");
	}

	public void setExceptionId(String exId) {
		msg.setExceptionID(exId);
	}

	public ReghubNotificationMsg getMessageObj() {
		return msg;
	}
	public void setMessageObj(ReghubNotificationMsg msg) {
		this.msg = msg;
	}

	public String marshal() throws JAXBException {
		return XmMarshaller.marshal(msg);
	}
}
