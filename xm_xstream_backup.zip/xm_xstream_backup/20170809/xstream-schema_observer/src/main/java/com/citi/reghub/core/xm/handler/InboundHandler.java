package com.citi.reghub.core.xm.handler;

import java.util.Observable;
import java.util.Observer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.citi.reghub.core.xm.xstream.jms.JMSProcessor;
import com.citi.reghub.core.xm.xstream.schema.ReghubNotificationMsg;

@Component
public class InboundHandler implements Observer {
	private static final Logger LOGGER = LoggerFactory.getLogger(InboundHandler.class);

	@Override
	public void update(Observable o, Object arg) {
		LOGGER.info("XmDataIn, processor. entering -------------------");

		JMSProcessor processor = (JMSProcessor) o;
		ReghubNotificationMsg msg = (ReghubNotificationMsg) processor.receive();
		
		LOGGER.info("XmDataIn, processor. msg = {}", msg);
	}
}
