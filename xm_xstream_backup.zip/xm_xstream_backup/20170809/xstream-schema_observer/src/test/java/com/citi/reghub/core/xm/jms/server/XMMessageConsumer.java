package com.citi.reghub.core.xm.jms.server;

import static com.citi.reghub.core.xm.jms.server.Key.CONNECTION_JNDI;
import static com.citi.reghub.core.xm.jms.server.Key.PROVIDER;
import static com.citi.reghub.core.xm.jms.server.Key.PROVIDER_URL;
import static com.citi.reghub.core.xm.jms.server.Key.QUEUE_REQUEST;
import static com.citi.reghub.core.xm.jms.server.Key.QUEUE_RESPONSE;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.reghub.core.xm.message.ResponseMessage;
import com.citi.reghub.core.xm.message.XmMarshaller;
import com.citi.reghub.core.xm.xstream.jms.XmMessageException;
import com.citi.reghub.core.xm.xstream.schema.RegHubMsg;
import com.tibco.tibjms.naming.TibjmsInitialContextFactory;

public class XMMessageConsumer implements MessageListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(XMMessageConsumer.class);
	private Map<Key, String> config = null;
	private Properties env = null;
	private static ConnectionFactory connectionFactory;

	private String factoryName = TibjmsInitialContextFactory.class.getName();
	private static Queue queue;

	public static void main(String[] args) {

		XMMessageConsumer xmconsumer = new XMMessageConsumer();
		try {
			xmconsumer.startQueue();
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	public XMMessageConsumer() {
		config = new HashMap<>();
		config.put(QUEUE_REQUEST, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.ReqQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		initJMS();
	}

	public void onMessage(Message message) {
		try {
			String xml = ((TextMessage) message).getText();
			LOGGER.info("Message received:\n{}", xml);

			RegHubMsg msgObj = (RegHubMsg)XmMarshaller.unmarshal(xml);
			boolean c = msgObj instanceof RegHubMsg;
			LOGGER.info("Unmarshaled to RegHubMsg: {}", c);

			String exId = msgObj.getExceptionID();
			sendResponse(exId);
		} catch (JMSException | JAXBException e) {
			LOGGER.error("Consumer error:\n{}", e);
		} catch (XmMessageException e) {
			e.printStackTrace();
		}
	}

	public void startQueue() throws NamingException {
		try {
			InitialContext jndi = new InitialContext(env);
			connectionFactory = (QueueConnectionFactory) jndi.lookup(config.get(CONNECTION_JNDI));

			Connection connection = connectionFactory.createConnection();
			queue = (Queue) jndi.lookup(this.config.get(QUEUE_REQUEST));
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer = session.createConsumer(queue);
			consumer.setMessageListener(this);

			connection.start();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

	private void initJMS() {
		env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.factoryName);
		env.put(Context.PROVIDER_URL, this.config.get(PROVIDER_URL));
	}

	public void sendResponse(String exceptionId) throws XmMessageException {
		HashMap<Key, String> config = new HashMap<>();
		config.put(QUEUE_REQUEST, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");
		config.put(CONNECTION_JNDI, "citi.cibtech.na.gicapbpm_153176.XAQueueCF");
		config.put(PROVIDER_URL, "tibjmsnaming://icgesbint.nam.nsroot.net:7222");
		initJMS();

		config.put(QUEUE_RESPONSE, "citi.fibo.na.gicapbpm_153176.Xstream.Reghub_mifid.RespQueue");
		config.put(PROVIDER, factoryName);
		try {
			XMProducer producer = new XMProducer(config);
			ResponseMessage requestMessage = new ResponseMessage();

				requestMessage.setExceptionId(exceptionId);
				String msg = requestMessage.marshal();

				LOGGER.info("Consumer sending response message:\n{}", msg);
				producer.sendMessage(msg);
		}
		catch (JMSException | JAXBException e) {
			throw new XmMessageException(e);
		}
	}
}
