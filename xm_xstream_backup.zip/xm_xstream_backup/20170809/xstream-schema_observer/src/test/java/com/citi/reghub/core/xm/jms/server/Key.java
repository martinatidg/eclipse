package com.citi.reghub.core.xm.jms.server;

public enum Key {
	QUEUE_REQUEST("jms.queue.request"),
	QUEUE_RESPONSE("jms.queue.response"),
	USERNAME("jms.username"),
	PASSWORD("jms.password"),
	CONNECTION_JNDI("jms.connection.jndi"),
	PROVIDER("jms.provider"),
	PROVIDER_URL("jms.provider.url");
	
	private String key;

	private Key(String key) {
		this.key = key;
	}

	public String key() {
		return key;
	}
}
