package com.citi.reghub.core.xm.integration;

public class XmJMSException extends Exception{
	private static final long serialVersionUID = 1L;

	public XmJMSException(Throwable cause) {
		super(cause);
	}
}
