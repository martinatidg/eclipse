package com.citi.reghub.core.exception;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class EventEnvelopeTest {
	@Test
	public void testExceptionMessageBuilder() {
		long createdTS = System.currentTimeMillis();
		Note note = new NoteBuilder().source("XM-Xstream").exceptionNote("UI Exception").createdBy("Martin")
				.createdTS(createdTS).build();
		List<Note> notes = new ArrayList<>();
		notes.add(note);

		ExceptionMessage message = new ExceptionMessageBuilder().createdTS(createdTS).description("UI Exception")
				.id("100000001").level("EXCEPTION").reasonCode("running out of memory").functionOwner("BUS")
				.regReportingRef("Stream flow 100001").requestedTS(createdTS).sourceId("s0001").status("OPEN")
				.type("DQ").updatedSource("UI").updatedTS(createdTS).xstreamEligible(true).notes(notes).build();

		EventEnvelope envelope = new EventEnvelopeBuilder().eventData(message).eventName("exceptionCreated")
				.eventSource("UI").eventVersion(1).eventTime(createdTS).build();

		Assert.assertEquals("not equal.", createdTS, envelope.getEventTime());
		Assert.assertEquals("not equal.", message, envelope.getExceptionMessage());
		Assert.assertEquals("not equal.", "exceptionCreated", envelope.getEventName());
		Assert.assertEquals("not equal.", "UI", envelope.getEventSource());
		Assert.assertEquals("not equal.", 1, envelope.getEventVersion());
	}
}
