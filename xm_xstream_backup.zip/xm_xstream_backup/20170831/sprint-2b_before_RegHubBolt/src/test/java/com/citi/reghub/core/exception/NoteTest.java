package com.citi.reghub.core.exception;

import org.junit.Assert;
import org.junit.Test;

public class NoteTest {

	@Test
	public void testNoteBuilder() {
		long createdTS = System.currentTimeMillis();
		Note note = new NoteBuilder().source("XM-Xstream").exceptionNote("UI Exception").createdBy("Martin")
				.createdTS(createdTS).build();

		Assert.assertEquals("not equal.", "XM-Xstream", note.getSource());
		Assert.assertEquals("not equal.", "UI Exception", note.getNote());
		Assert.assertEquals("not equal.", "Martin", note.getCreatedBy());
		Assert.assertEquals("not equal.", createdTS, note.getCreatedTS());
	}
}
