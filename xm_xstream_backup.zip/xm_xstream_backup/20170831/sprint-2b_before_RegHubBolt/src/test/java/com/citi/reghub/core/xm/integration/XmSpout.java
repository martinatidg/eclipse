package com.citi.reghub.core.xm.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

//import org.apache.commons.io.IOUtils;
import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;

import com.citi.reghub.core.exception.EventEnvelope;

public class XmSpout extends BaseRichSpout {
	private static final long serialVersionUID = 1L;
	private SpoutOutputCollector outputCollector;

//	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		System.out.println("XmSpout.declareOutputFields(),  enter....");
		declarer.declare(new Fields("message"));
	}

//	@Override
	public void open(Map map, TopologyContext topologyContext, SpoutOutputCollector spoutOutputCollector) {
		this.outputCollector = spoutOutputCollector;
	}

//	@Override
	public void nextTuple() {
		EventEnvelope evtmsg = TestData.getEvtMsg();
//		System.out.println("XmSpout.nextTuple(),  evtmsg = " +  evtmsg);

		List<Object> msgs = new ArrayList<Object>();
		msgs.add(evtmsg);
		outputCollector.emit(msgs);
	}
}
