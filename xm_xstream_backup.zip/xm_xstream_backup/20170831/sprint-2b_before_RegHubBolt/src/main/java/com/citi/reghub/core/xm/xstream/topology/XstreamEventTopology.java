package com.citi.reghub.core.xm.xstream.topology;

import java.util.Map;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.jms.bolt.JmsBolt;
import org.apache.storm.topology.TopologyBuilder;

import com.citi.reghub.core.BaseTopology;
import com.citi.reghub.core.EventEnvelopeSerializer;
import com.citi.reghub.core.constants.StormStreams;
import com.citi.reghub.core.exception.EventEnvelope;
import com.citi.reghub.core.kafka.RegHubKafkaSpout;
import com.citi.reghub.core.xm.xstream.Constants;

public class XstreamEventTopology extends BaseTopology {

	public static final String KAFKA_INPUT_TOPIC_NAMES = "kafka.input.topic.names";
	
	public static void main(String[] args) throws Exception {
		new XstreamEventTopology().runTopology(args);
	}

	@Override
	public StormTopology buildTopology(Map<String, String> topologyConfig) throws Exception {
		final TopologyBuilder topologyBuilder = new TopologyBuilder();
		
		String inputTopicNames = topologyConfig.get(KAFKA_INPUT_TOPIC_NAMES);
		
		XstreamMessageProducer messageProducer = new XstreamMessageProducer();
		XstreamJmsProvider provider = new XstreamJmsProvider(topologyConfig, true);
		JmsBolt jmsBolt = new JmsBolt();
		jmsBolt.setJmsProvider(provider);
		jmsBolt.setJmsMessageProducer(messageProducer);

		RegHubKafkaSpout<String, EventEnvelope> regKafkaSpout = RegHubKafkaSpout
				.builder(inputTopicNames, StormStreams.INBOUND_KAFKA_STREAM_NAME, topologyConfig)
				.setKeyDesClazz(StringDeserializer.class).setValueDesClazz(EventEnvelopeSerializer.class)
				.build();

		topologyBuilder.setSpout(Constants.KAFKA_SPOUT.value(), regKafkaSpout.getSpout(), 3);
		topologyBuilder.setBolt(Constants.EVENT_BOLT.value(),
				new EventBolt(), 3).shuffleGrouping(Constants.KAFKA_SPOUT.value(),
				StormStreams.INBOUND_KAFKA_STREAM_NAME);
		topologyBuilder.setBolt(Constants.TO_XM_BOLT.value(),
				new ToXstreamBolt(), 3).shuffleGrouping(Constants.EVENT_BOLT.value()); //,				StormStreams.INBOUND_KAFKA_STREAM_NAME);
		topologyBuilder.setBolt(Constants.JMS_BOLT.value(), jmsBolt, 3).shuffleGrouping(Constants.TO_XM_BOLT.value());

		return topologyBuilder.createTopology();
	}
}
