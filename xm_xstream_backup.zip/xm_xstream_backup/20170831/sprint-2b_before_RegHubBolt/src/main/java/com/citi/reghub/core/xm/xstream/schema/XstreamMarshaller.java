package com.citi.reghub.core.xm.xstream.schema;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

public class XstreamMarshaller {
	public static final String INBOUND_PACKAGE = "com.citi.reghub.core.xm.xstream.schema.inbound";
	public static final String OUTBOUND_PACKAGE = "com.citi.reghub.core.xm.xstream.schema.outbound";
	private XstreamMarshaller() {
		throw new UnsupportedOperationException(
				"The Util class contains static methods only and cannot be instantiated.");
	}

	public static String marshal(Object msg) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(INBOUND_PACKAGE);
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(msg, writer);

		return writer.toString();
	}

	public static String marshal(Object msg, String packageName) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(packageName);
		StringWriter writer = new StringWriter();
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		m.marshal(msg, writer);

		return writer.toString();
	}

	public static Object unmarshal(String xml) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(OUTBOUND_PACKAGE);

		Unmarshaller unmarshaller = jc.createUnmarshaller();
		return unmarshaller.unmarshal(new StreamSource(new StringReader(xml)));
	}

	public static Object unmarshal(String xml, String packageName) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(packageName);

		Unmarshaller unmarshaller = jc.createUnmarshaller();
		return unmarshaller.unmarshal(new StreamSource(new StringReader(xml)));
	}
}
