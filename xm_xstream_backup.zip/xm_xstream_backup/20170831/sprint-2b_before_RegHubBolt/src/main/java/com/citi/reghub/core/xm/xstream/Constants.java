package com.citi.reghub.core.xm.xstream;

public enum Constants {
	// outbound
	XM_EVENT_TOPOLOGY("EventTopology"),
	KAFKA_SPOUT("KafkaSpout"),
	EVENT_BOLT("EventBolt"),
	TO_XM_BOLT("ToXstreamBolt"),
	JMS_BOLT("JmsBolt"),
	EVENT_FILTER("XM-XSTREAM"),
	// inbound
	MESSAGE_FIELD("message"),
	JMS_SPOUT("XmJmsSpout"),
	FROM_BOLT("FromXstreamBolt"),
	KAFKA_BOLT("KafkaBolt")
	;

	private final String value;

    Constants(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Constants fromValue(String v) {
        for (Constants c: Constants.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
