package com.citi.reghub.core.xm.xstream.topology;

import com.citi.reghub.core.Entity;
import com.citi.reghub.core.exception.ExceptionMessage;

public class EmitMsg {

	private ExceptionMessage exception;
	private Entity entity;

	public EmitMsg(ExceptionMessage exception, Entity entity) {
		this.exception = exception;
		this.entity = entity;
	}

	public ExceptionMessage getException() {
		return exception;
	}

	public void setException(ExceptionMessage exception) {
		this.exception = exception;
	}

	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}

}
