package com.citi.reghub.core.exception;

import java.util.List;
import java.util.Map;

public class ExceptionMessageBuilder {
	private String id;
	private String sourceId;
	private String regReportingRef;
	private String status;
	private String reasonCode;
	private String description;
	private String functionOwner;
	private boolean xstreamEligible;
	private List<Note> notes;
	private String type;
	private String level;
	private Map<String, Object> attributes;
	private long requestedTS;
	private long createdTS;
	private long updatedTS;
	private String updatedSource;

	public ExceptionMessageBuilder id(String id) {
		this.id = id;
		return this;
	}

	public ExceptionMessageBuilder sourceId(String sourceId) {
		this.sourceId = sourceId;
		return this;
	}

	public ExceptionMessageBuilder regReportingRef(String regReportingRef) {
		this.regReportingRef = regReportingRef;
		return this;
	}

	public ExceptionMessageBuilder status(String status) {
		this.status = status;
		return this;
	}

	public ExceptionMessageBuilder reasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
		return this;
	}

	public ExceptionMessageBuilder description(String description) {
		this.description = description;
		return this;
	}

	public ExceptionMessageBuilder functionOwner(String functionOwner) {
		this.functionOwner = functionOwner;
		return this;
	}

	public ExceptionMessageBuilder xstreamEligible(boolean xstreamEligible) {
		this.xstreamEligible = xstreamEligible;
		return this;
	}

	public ExceptionMessageBuilder notes(List<Note> notes) {
		this.notes = notes;
		return this;
	}

	public ExceptionMessageBuilder type(String type) {
		this.type = type;
		return this;
	}

	public ExceptionMessageBuilder level(String level) {
		this.level = level;
		return this;
	}

	public ExceptionMessageBuilder attributes(Map<String, Object> attributes) {
		this.attributes = attributes;
		return this;
	}

	public ExceptionMessageBuilder requestedTS(long requestedTS) {
		this.requestedTS = requestedTS;
		return this;
	}

	public ExceptionMessageBuilder createdTS(long createdTS) {
		this.createdTS = createdTS;
		return this;
	}

	public ExceptionMessageBuilder updatedTS(long updatedTS) {
		this.updatedTS = updatedTS;
		return this;
	}

	public ExceptionMessageBuilder updatedSource(String updatedSource) {
		this.updatedSource = updatedSource;
		return this;
	}

	public ExceptionMessage build() {
		ExceptionMessage xmsg = new ExceptionMessage();

		xmsg.setId(id);
		xmsg.setSourceId(sourceId);
		xmsg.setRegReportingRef(regReportingRef);
		xmsg.setStatus(status);
		xmsg.setReasonCode(reasonCode);
		xmsg.setDescription(description);
		xmsg.setFunctionOwner(functionOwner);
		xmsg.setXstreamEligible(xstreamEligible);
		xmsg.setNotes(notes);
		xmsg.setType(type);
		xmsg.setLevel(level);
		xmsg.setAttributes(attributes);
		xmsg.setRequestedTS(requestedTS);
		xmsg.setCreatedTS(createdTS);
		xmsg.setUpdatedTS(updatedTS);
		xmsg.setUpdatedSource(updatedSource);

		return xmsg;
	}

}
