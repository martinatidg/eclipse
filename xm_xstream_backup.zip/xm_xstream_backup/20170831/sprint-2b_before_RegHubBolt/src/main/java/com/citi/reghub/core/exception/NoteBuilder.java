package com.citi.reghub.core.exception;

public class NoteBuilder {
	private String source;
	private String exceptionNote;
	private long createdTS;
	private String createdBy;

	public NoteBuilder source(String source) {
		this.source = source;
		return this;
	}

	public NoteBuilder exceptionNote(String exceptionNote) {
		this.exceptionNote = exceptionNote;
		return this;
	}

	public NoteBuilder createdTS(long createdTS) {
		this.createdTS = createdTS;
		return this;
	}

	public NoteBuilder createdBy(String createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public Note build() {
		Note note = new Note();

		note.setNote(exceptionNote);
		note.setSource(source);
		note.setCreatedBy(createdBy);
		note.setCreatedTS(createdTS);

		return note;
	}
}
