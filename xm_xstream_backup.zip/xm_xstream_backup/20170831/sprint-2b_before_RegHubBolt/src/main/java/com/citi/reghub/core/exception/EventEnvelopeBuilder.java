package com.citi.reghub.core.exception;

public class EventEnvelopeBuilder {
	private int eventVersion;
	private String eventSource;
	private String eventName;
	private long eventTime;
	private ExceptionMessage eventData;

	public EventEnvelopeBuilder eventVersion(int eventVersion) {
		this.eventVersion = eventVersion;
		return this;
	}

	public EventEnvelopeBuilder eventSource(String eventSource) {
		this.eventSource = eventSource;
		return this;
	}

	public EventEnvelopeBuilder eventName(String eventName) {
		this.eventName = eventName;
		return this;
	}

	public EventEnvelopeBuilder eventTime(long eventTime) {
		this.eventTime = eventTime;
		return this;
	}

	public EventEnvelopeBuilder eventData(ExceptionMessage eventData) {
		this.eventData = eventData;
		return this;
	}

	public EventEnvelope build() {
		EventEnvelope envelope = new EventEnvelope();
		envelope.setEventName(eventName);
		envelope.setEventSource(eventSource);
		envelope.setEventTime(eventTime);
		envelope.setEventVersion(eventVersion);
		envelope.setExceptionMessage(eventData);

		return envelope;
	}
}
